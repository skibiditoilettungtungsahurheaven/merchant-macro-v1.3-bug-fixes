Merchant Macro for Mac
======================
Same macro as the Windows version (buys the items you pick from the Mysterious Merchant), made to run on macOS.
Read the "IMPORTANT" tab inside the macro.

HOW TO START
1. Unzip the whole folder (double click the .zip) and put the folder somewhere normal, e.g. Desktop or Documents.
2. Right click start_macro.command -> Open -> Open.
   (Only the first time. A normal double click is blocked by macOS for files from the internet.)
   If macOS still says it can't be opened: System Settings -> Privacy & Security -> scroll down -> "Open Anyway".
   Another way that always works: open Terminal, type  bash  and a space, drag start_macro.command
   into the Terminal window, press Enter.
3. The first start downloads Python (if you don't have it) and the libraries. It takes a few minutes.
   If the Python installer opens, click Continue / Install until it finishes.
4. Keep the Terminal window open while the macro runs. Closing it closes the macro.

PERMISSIONS (needed once)
macOS lets the macro see the game and click only with these permissions for "Terminal":
  System Settings -> Privacy & Security ->
    Screen Recording   - turn on Terminal (the macro needs to see the merchant)
    Accessibility      - turn on Terminal (clicks and anti-AFK jumps)
    Input Monitoring   - turn on Terminal (hotkeys F3 / F7 / F8 / F10)
After turning them on, quit Terminal completely (Cmd+Q) and start start_macro.command again.
The macro writes in its log which permission is still missing.
Newer macOS versions sometimes ask again about screen access ("...requesting to bypass the private window
picker") - click Allow.

HOTKEYS
On a Mac keyboard press the F keys together with fn (fn+F7 etc.), otherwise the keys change brightness/volume.
Default: F7 calibrate, F3 start/pause, F8 check now, F10 exit. You can change them in Settings.
(F11 is not used by default because on a Mac it shows the desktop.)

TIPS
- Roblox can be fullscreen or a big window. While Roblox is fullscreen the macro window is hidden behind it,
  that's normal - the macro still works. Use Cmd+Tab to look at the macro window.
- Calibration works the same as on Windows: open the merchant, hover TAP TO TRADE of slot 1 and press fn+F7,
  then slot 2, then slot 3.
- Weather tab: tick the weathers you want to hear about. While the macro is running it watches the icon row
  at the top of the game and sends a screenshot to Discord when a ticked weather starts. It reacts only to
  the weather icon itself (the square with a coloured frame and a timer), never to screen colours. "Check weather now"
  writes to the log what it sees and saves the strip it looks at as debug_weather.png next to the macro.
- Stock screenshot: one per hour. It is sent the moment the stock refreshes; if the macro didn't see the
  refresh (the merchant window was closed), it sends the stock by itself 2 minutes after the hour is up.
- The macro reacts only to the merchant window. Opening the inventory (or any other window) over the merchant
  doesn't make it click or report a purchase.
- If the macro ever buys the wrong item, send the log and the picture last_buy.png from the macro folder
  (it is the frame the macro looked at when it decided to buy).
- Updates: when a new version comes out, the macro shows "A New Update Is Available!". Update downloads the new
  files and restarts the macro (your settings stay; the previous files are kept in the old_version folder).
- If something doesn't work, send a screenshot of the macro window and of the Terminal window.
- mac_check.command (start it the same way, after start_macro.command worked once) checks
  permissions, the screenshot, which app is in front and the hotkeys. Send a screenshot of its
  window and the picture mac_check.png it saves.
