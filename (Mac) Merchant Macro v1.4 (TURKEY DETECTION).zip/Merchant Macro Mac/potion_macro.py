"""
Зрение и клики для Merchant Macro (версия для Mac). Сам макро (окно) — macro_gui.pyw,
запускать через start_macro.command.
Если запустить этот файл двойным кликом — он просто откроет окно macro_gui.pyw.
Старый консольный режим: python potion_macro.py --console

Горячие клавиши (работают, пока окно Roblox активно или нет — неважно):
  F7  — калибровка: наведи мышь на кнопку "TAP TO TRADE" слота 1, жми F7,
        потом слота 2 — F7, потом слота 3 — F7. Сохраняется в macro_config.json.
  F9  — старт / пауза
  F11 — сохранить debug.png (что макро видит прямо сейчас)
  F10 — выход

Проверка на картинке без игры:
  python potion_macro.py --test screenshot.png x1,y1 x2,y2 x3,y3
"""
import json
import os
import sys
import time

import cv2
import numpy as np

import platform_io as pio

# ---------------- НАСТРОЙКИ ----------------
SCAN_INTERVAL = 10          # раз во сколько секунд проверять торговца
CLICKS_PER_BUY = 3          # сколько раз жать TAP TO TRADE, когда зелье найдено
OPEN_KEY = ""               # клавиша открытия торговца перед проверкой, напр. "e" (пусто = не жать)
# Цвет колбы в HSV (OpenCV: H 0-179). Бирюзовая колба ~ H 90, зелёная Roll Luck ~ H 70.
HSV_LOW = (80, 150, 170)
HSV_HIGH = (100, 255, 255)
# --------------------------------------------

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(HERE, "macro_config.json")

VK = {"F7": "F7", "F9": "F9", "F10": "F10", "F11": "F11"}
pio.init()


def log(msg):
    print(time.strftime("[%H:%M:%S] ") + msg, flush=True)


# ---------- ввод (мышь/клавиатура/активное окно — в platform_io.py) ----------
mouse_move = pio.mouse_move
click = pio.click
press_key = pio.press_key
roblox_focused = pio.roblox_focused
key_hold = pio.key_hold                  # клавиши пути к торговцу (Merchant Failsafe): нажать / отпустить
key_is_down = pio.key_is_down


def focus_game():
    return False


def key_pressed(name):
    return pio.hotkey_pressed(pio.hotkey_code(VK[name]))


# ---------- зрение ----------
def scan_region(buttons):
    """Прямоугольник с тремя карточками, вычисленный по трём кнопкам TAP TO TRADE.
    С запасом по сторонам и вниз: видны карточки целиком, вместе с кнопками (там же появляется SUCCESS!/FAILED)."""
    xs = [b[0] for b in buttons]
    ys = [b[1] for b in buttons]
    sp = (max(xs) - min(xs)) / 2  # расстояние между карточками
    x0 = int(min(xs) - sp * 0.60)
    x1 = int(max(xs) + sp * 0.60)
    y0 = int(min(ys) - sp * 0.92)
    y1 = int(max(ys) + sp * 0.22)
    return x0, y0, x1, y1, sp


# Образцы слов из названия зелья (белый текст, снято при расстоянии между карточками 367 px)
_TPL_SP = 367.0
_TPL_B64 = {
    "large": "iVBORw0KGgoAAAANSUhEUgAAAEsAAAAhCAAAAAC0SgkKAAABGklEQVRIDa3BUXJiVwBEMZ39L7pzH2Ag9vxQhZTvyffke/I9+Z4Y+YYY+YYY+YYY+YYY+b8hDxMmN/OQmyGXGHk3N7mbGDnmKZe55IiRN/OQm9EQhsyRY35EjLyZMOQydzGEkWMII2Lkr5HLkJuRY+QYuUzEyF8jlyE3I8fIMXKMiJFf5ibHyN0QRo55SYy8m4dcRh7mIce8SYy8GWHIMfJjLrkZ8hQjLyPHkGPkx+Rl5ClGXkaOIcfI3cibkacY8jTCHDlG7kbeDPkR8xSGzCXHyN2QN3NkRMxTmJccIw/zlMs8RMxTLiOGHCMP85KbOXLkI5PLkF/yicndyC/5xMjNyC/5xMhl5Ld8ZH7kj3xojvxLviffk+/5D6C6bCKRk05CAAAAAElFTkSuQmCC",
    "small": "iVBORw0KGgoAAAANSUhEUgAAAE0AAAAhCAAAAAC5VHlNAAABLUlEQVRIDa3BSXIkBxAEMfj/Hx3Kaq6HudDUQN4p75R3yjvlfxk5Q+RlTv5s5AyRM1/yNyNniDDf8jcjZ4gwhMkfjZwhYsgvI4w8Rr4N+TRyhoghvwyZE+bkw7zkw8gZIob8Mv+Qx3zKy8gZIszJt/mHPCYMeYycIcK85NOQM+SM/DLkjJwh8piXvAw5Q86QH0POyBkiH+YlZ8gZeQz5NC85I2eIfJmTM+QxeQx5zJeckTNEfgxhyBl5DDkjDDkjZ4j8MsKQM/IYwsgZckbOEGH5MMKQx+QxhJEz5IycIcLkMXKGPCaPIYycIWfkDBHzI2fIY/IYwpB55Aw5Q8J8yWPIGXkMOfMtZ04Yksc88mHIY/IY8hhi5DHkjOSd8k55p7xT3invlHfKO+Wd/gPJcn0iGfhFIQAAAABJRU5ErkJggg==",
}
_TPL = None
# Чем меньше число, тем важнее. "other" — зелье с колбой, но не Large и не Small (напр. Medium).
PRIORITY = {"large": 0, "other": 1, "small": 2}
KIND_RU = {"large": "Large", "small": "Small", "other": "другое"}


def _templates():
    global _TPL
    if _TPL is None:
        import base64
        _TPL = {k: cv2.imdecode(np.frombuffer(base64.b64decode(v), np.uint8), cv2.IMREAD_GRAYSCALE)
                for k, v in _TPL_B64.items()}
    return _TPL


def _white_text(bgr):
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    return (((hsv[..., 2] > 200) & (hsv[..., 1] < 50)) * 255).astype(np.uint8)


def potion_kind(img_bgr, buttons, slot, offset=(0, 0)):
    """Читает название зелья в карточке: 'large', 'small' или 'other'."""
    sp = scan_region(buttons)[4]
    bx, by = buttons[slot][0] - offset[0], buttons[slot][1] - offset[1]
    h, w = img_bgr.shape[:2]
    x0, x1 = max(int(bx - sp * 0.5), 0), min(int(bx + sp * 0.5), w)
    y0, y1 = max(int(by - sp * 0.52), 0), min(int(by - sp * 0.18), h)
    if x1 <= x0 or y1 <= y0:
        return "other", {}
    region = _white_text(img_bgr[y0:y1, x0:x1])
    scores = {}
    for name, tpl in _templates().items():
        best = -1.0
        for f in (0.88, 0.94, 1.0, 1.06, 1.12):
            s = sp / _TPL_SP * f
            t = cv2.resize(tpl, (max(int(tpl.shape[1] * s), 4), max(int(tpl.shape[0] * s), 4)),
                           interpolation=cv2.INTER_AREA)
            t = ((t > 110) * 255).astype(np.uint8)
            if t.shape[0] > region.shape[0] or t.shape[1] > region.shape[1]:
                continue
            best = max(best, float(cv2.matchTemplate(region, t, cv2.TM_CCOEFF_NORMED).max()))
        scores[name] = round(best, 2)
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    # уверенно: совпадение >= 0.62 и заметно лучше второго варианта
    if ranked and ranked[0][1] >= 0.62 and (len(ranked) == 1 or ranked[0][1] - ranked[1][1] >= 0.12):
        return ranked[0][0], scores
    return "other", scores


def find_potions(img_bgr, buttons, offset=(0, 0)):
    """Все колбы на экране: список (слот 0..2, (x, y)) — по одной на слот."""
    sp = scan_region(buttons)[4]
    x0, x1 = int(min(b[0] for b in buttons) - sp * 0.5), int(max(b[0] for b in buttons) + sp * 0.5)
    y0, y1 = int(min(b[1] for b in buttons) - sp * 0.85), int(max(b[1] for b in buttons) - sp * 0.15)
    ox, oy = offset
    h, w = img_bgr.shape[:2]
    cx0, cy0 = max(x0 - ox, 0), max(y0 - oy, 0)
    cx1, cy1 = min(x1 - ox, w), min(y1 - oy, h)
    roi = img_bgr[cy0:cy1, cx0:cx1]
    if roi.size == 0:
        return []
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, HSV_LOW, HSV_HIGH)
    n, _, stats, cents = cv2.connectedComponentsWithStats(mask)
    min_area = (sp * 0.035) ** 2
    max_area = (sp * 0.30) ** 2
    per_slot = {}
    for i in range(1, n):
        area = stats[i, cv2.CC_STAT_AREA]
        if not (min_area <= area <= max_area):
            continue
        bx = cents[i][0] + cx0 + ox
        by = cents[i][1] + cy0 + oy
        slot = int(np.argmin([abs(bx - b[0]) for b in buttons]))
        if slot not in per_slot or area > per_slot[slot][0]:
            per_slot[slot] = (area, (int(bx), int(by)))
    return [(s, p) for s, (_, p) in sorted(per_slot.items())]


def find_best_potion(img_bgr, buttons, offset=(0, 0)):
    """Лучшая колба по приоритету Large > другое > Small.
    Возвращает (слот, (x, y), вид, [(слот, вид), ...]) или None."""
    found = find_potions(img_bgr, buttons, offset)
    if not found:
        return None
    kinds = {s: potion_kind(img_bgr, buttons, s, offset)[0] for s, _ in found}
    _, slot, pos = min((PRIORITY[kinds[s]], s, p) for s, p in found)
    return slot, pos, kinds[slot], sorted(kinds.items())


def find_potion(img_bgr, buttons, offset=(0, 0)):
    """Возвращает (номер слота 0..2, (x, y) колбы) лучшего зелья или None."""
    res = find_best_potion(img_bgr, buttons, offset)
    return (res[0], res[1]) if res else None


# ---------- любые товары торговца ----------
# Товар узнаётся по белому названию в карточке («1x Large Level Potion» и т.п.): надпись вырезается
# по своим краям и сравнивается с образцами со скринов — так неважно, какое разрешение у экрана.
ITEMS = (  # (id, название как в игре)
    ("large", "1x Large Level Potion"),
    ("small", "1x Small Level Potion"),
    ("epic", "1x Epic Roll Potion"),
    ("roll_luck", "2x Roll Luck Potion"),
    ("fortune", "1x Fortune Potion"),
    ("heads", "1x Heads Potion"),
    ("luck", "+50% Luck (30m)"),
    ("money", "+25% Money (30m)"),
    ("flip", "+25% Flip Speed (15m)"),
    ("super", "Random Super Soda"),
    ("scroll3", "3x Engraving Scroll"),
    ("scroll1", "1x Engraving Scroll"),
    ("ticket", "5x Accessory Ticket"),
    ("pliers", "1x Gem Pliers"),
)
ITEM_NAMES = dict(ITEMS)
_NAME_W, _NAME_H, _PREFIX = 192, 20, 10   # размер образца; _PREFIX — колонки с цифрой «1x»/«3x»
ITEM_MIN_SCORE, ITEM_MIN_GAP = 0.60, 0.06  # уверенно узнали товар
ITEM_MAYBE_SCORE, ITEM_MAYBE_GAP = 0.45, 0.10  # «похоже на один из этих» — для честного приоритета
ITEM_CLEAR_GAP = 0.20                       # отрыв от второго места, при котором хватает и невысокой оценки
ITEM_PAIR_MARGIN = 0.15                     # перевес в сравнении двух похожих названий по отличающимся буквам
PAIR_MIN_SP = 175                           # меньше этого расстояния между карточками сравнение пар не делаем
_SHIFT = 3                                  # допуск сдвига надписи по горизонтали (в колонках образца)
_REF_META = []   # [(id, соотношение сторон надписи), ...] — заполняется ниже, в конце файла
_REF_B64 = ""
_REFS = None


def _drop_edges(m, sp):
    """Убирает узкие полоски у самых краёв области (рамка карточки на маленьких экранах)."""
    col = m.sum(0)
    on = np.where(col > 0)[0]
    if len(on) == 0:
        return m
    runs, st = [], on[0]
    for a, b in zip(on[:-1], on[1:]):
        if b - a > 1:
            runs.append((st, a))
            st = b
    runs.append((st, on[-1]))
    w, lim = m.shape[1], max(sp * 0.04, 2)
    keep = np.ones(w, bool)
    for a, b in runs:
        if b - a + 1 <= lim and (a <= 1 or b >= w - 2):
            keep[a:b + 1] = False
    return m * keep[None, :]


def name_feature(img_bgr, bx, by, sp):
    """Надпись-название карточки с кнопкой (bx, by): (образец 0..7, ширина/высота) или None.
    Надпись вырезается по своим краям и растягивается до одного размера — разрешение экрана не важно."""
    h, w = img_bgr.shape[:2]
    x0, x1 = max(int(bx - sp * 0.48), 0), min(int(bx + sp * 0.48), w)
    y0, y1 = max(int(by - sp * 0.45), 0), min(int(by - sp * 0.27), h)
    if x1 - x0 < 20 or y1 - y0 < 6:
        return None
    m = _drop_edges((_white_text(img_bgr[y0:y1, x0:x1]) > 0).astype(np.float32), sp)
    rows = m.sum(1)
    if rows.max() < 3:
        return None
    # Высота надписи. «Хвостики» букв (g, p) и верхушки заглавных — тонкие: если мерить по крайним
    # строкам, они то попадают, то нет, и высота прыгает. Поэтому берём «центр тяжести» надписи
    # и её разброс по вертикали — на них пара лишних или пропавших пикселей не влияет.
    on = rows > rows.max() * 0.08
    ya = yb = int(rows.argmax())
    while ya > 0 and (on[ya - 1] or (ya > 1 and on[ya - 2])):   # сплошной блок вокруг самой густой строки:
        ya -= 1                                                  # далёкие точки (край цены, блики) не в счёт
    while yb < len(on) - 1 and (on[yb + 1] or (yb < len(on) - 2 and on[yb + 2])):
        yb += 1
    yy = np.arange(ya, yb + 1, dtype=np.float32)
    wgt = rows[ya:yb + 1]
    mean = float((yy * wgt).sum() / wgt.sum())
    std = float(np.sqrt(((yy - mean) ** 2 * wgt).sum() / wgt.sum()))
    ya = max(int(round(mean - std * 2.0)), 0)
    yb = min(int(round(mean + std * 2.0)), len(rows) - 1)
    band = m[ya:yb + 1]
    c = np.cumsum(band.sum(0))
    total = c[-1]
    if total < 20 or band.shape[0] < 4:
        return None
    xa, xb = int(np.searchsorted(c, total * 0.003)), int(np.searchsorted(c, total * 0.997))
    band = band[:, xa:xb + 1]
    v = cv2.resize(band, (_NAME_W, _NAME_H), interpolation=cv2.INTER_AREA)
    if v.max() - v.min() < 1e-3:
        return None
    return np.round((v - v.min()) / (v.max() - v.min()) * 7).astype(np.float32), band.shape[1] / band.shape[0]


def _unit(u):
    u = u - u.mean()
    return u / (np.linalg.norm(u) + 1e-6)


def _prep(f):
    """Для сравнения: слегка размытая надпись целиком + резкое начало (цифра количества «1x»/«3x»)."""
    u, a = f
    u = u / 7.0
    return cv2.GaussianBlur(u, (0, 0), sigmaX=0.8, sigmaY=0.5), _unit(u[:, :_PREFIX]), a


def _corr_shift(v, w):
    """Похожесть двух надписей с допуском небольшого сдвига (на маленьких экранах буквы «гуляют»)."""
    best = -1.0
    for dx in range(-_SHIFT, _SHIFT + 1):
        a = v[:, max(dx, 0):v.shape[1] + min(dx, 0)]
        b = w[:, max(-dx, 0):w.shape[1] + min(-dx, 0)]
        best = max(best, float((_unit(a) * _unit(b)).sum()))
    return best


def _name_score(f, g):
    (v, p, a), (w, q, b) = f, g
    return 0.7 * _corr_shift(v, w) + 0.3 * float((p * q).sum()) - 0.5 * abs(np.log(a / b))


def _refs():
    global _REFS
    if _REFS is None:
        import base64
        atlas = cv2.imdecode(np.frombuffer(base64.b64decode("".join(_REF_B64)), np.uint8), cv2.IMREAD_GRAYSCALE)
        _REFS = []
        for k, (item, aspect) in enumerate(_REF_META):
            u = atlas[k * _NAME_H:(k + 1) * _NAME_H].astype(np.float32) / 36
            _REFS.append((item, _prep((u, aspect))))
    return _REFS


def _pair_margin(f, ra, rb):
    """Сравнение двух похожих товаров (Large/Small, 1x/3x Scroll) только по тем местам надписи,
    где их образцы различаются. > 0 — надпись ближе к ra, < 0 — к rb."""
    v, a, b = f[0], ra[0], rb[0]

    def dist(r, other):
        out = 1e9
        for dx in range(-_SHIFT, _SHIFT + 1):
            x = v[:, max(dx, 0):v.shape[1] + min(dx, 0)]
            y = r[:, max(-dx, 0):r.shape[1] + min(-dx, 0)]
            o = other[:, max(-dx, 0):other.shape[1] + min(-dx, 0)]
            out = min(out, float((np.abs(y - o) * (x - y) ** 2).sum()))
        return out

    return (dist(b, a) - dist(a, b)) / (float((np.abs(a - b) ** 3).sum()) + 1e-6)


def _rank_card(img_bgr, buttons, slot, offset=(0, 0)):
    """[(id, оценка, лучший образец), ...] от лучшего к худшему и сама надпись (или [], None)."""
    sp = scan_region(buttons)[4]
    bx, by = buttons[slot][0] - offset[0], buttons[slot][1] - offset[1]
    f = name_feature(img_bgr, bx, by, sp)
    if f is None:
        return [], None
    f = _prep(f)
    best = {}
    for item, g in _refs():
        sc = _name_score(f, g)
        if sc > best.get(item, (-9.0, None))[0]:
            best[item] = (sc, g)
    # к надписи добавляем размер (sp) — _decide по нему решает, можно ли верить сравнению пары
    return sorted(((i, sc, g) for i, (sc, g) in best.items()), key=lambda t: -t[1]), tuple(f) + (sp,)


def item_scores(img_bgr, buttons, slot, offset=(0, 0)):
    """Похожесть карточки на каждый известный товар: [(id, оценка), ...] от лучшего к худшему."""
    return [(i, sc) for i, sc, _ in _rank_card(img_bgr, buttons, slot, offset)[0]]


def _decide(ranked, f=None):
    """(id или None, кандидаты). Кандидаты — товары, которыми карточка может быть, если узнали не уверенно.
    ranked — из _rank_card (с образцами) или из item_scores (без них)."""
    if not ranked:
        return None, []
    top, score = ranked[0][0], ranked[0][1]
    gap = score - ranked[1][1] if len(ranked) > 1 else 1.0
    if score >= ITEM_MIN_SCORE and gap >= ITEM_MIN_GAP:
        return top, [top]
    if score >= ITEM_MAYBE_SCORE and gap >= ITEM_CLEAR_GAP:
        return top, [top]           # оценка невысокая (мелкий экран), но ни на что другое не похоже вообще
    if score >= ITEM_MIN_SCORE and f is not None and len(ranked[0]) > 2 and (len(f) < 4 or f[3] >= PAIR_MIN_SP):
        # два очень похожих названия — решает сравнение по отличающимся буквам
        if _pair_margin(f, ranked[0][2], ranked[1][2]) >= ITEM_PAIR_MARGIN:
            return top, [top]
    if score >= ITEM_MAYBE_SCORE:
        return None, [r[0] for r in ranked if r[1] >= score - ITEM_MAYBE_GAP]
    return None, []


def identify_item(img_bgr, buttons, slot, offset=(0, 0)):
    """Какой товар в карточке: (id или None, уверенность)."""
    ranked, f = _rank_card(img_bgr, buttons, slot, offset)
    item, _ = _decide(ranked, f)
    return item, (round(ranked[0][1], 2) if ranked else 0.0)


# Окно торговца открыто, только если в карточках стоят названия ЕГО товаров. Белый текст на тех же местах бывает
# и у других окон (инвентарь: белая рамка и числа «x66»), и раньше макро принимал их за торговца. У настоящего
# окна все три названия узнаются с оценкой от 0.72; у инвентаря, куда ни поставь кнопки, — не выше 0.45, и то
# в одной карточке. Достаточно двух узнанных карточек из трёх: третьей может оказаться товар, которого макро
# ещё не знает.
OPEN_NAME_SCORE = 0.45
OPEN_NAME_CARDS = 2


def _rank_all(img_bgr, buttons, offset=(0, 0)):
    return [_rank_card(img_bgr, buttons, s, offset) for s in range(len(buttons))]


def _names_known(ranks):
    return sum(1 for ranked, _ in ranks if ranked and ranked[0][1] >= OPEN_NAME_SCORE) >= OPEN_NAME_CARDS


def merchant_open(img_bgr, buttons, offset=(0, 0), ranks=None):
    """True, если на экране именно окно торговца: в карточках есть белые названия, и это названия его товаров."""
    if stock_signature(img_bgr, buttons, offset) is None:
        return False
    if scan_region(buttons)[4] < ITEM_MIN_SP:
        return True                   # окно Roblox слишком маленькое, буквы не различить — остаётся прежняя проверка
    return _names_known(ranks if ranks is not None else _rank_all(img_bgr, buttons, offset))


def card_shows(img_bgr, buttons, slot, item, offset=(0, 0)):
    """True, если в карточке slot по-прежнему читается тот самый товар item.
    Проверяется прямо перед каждым кликом по TAP TO TRADE и когда появляется SUCCESS!/FAILED: сток мог смениться,
    а окно торговца — закрыться другим окном (инвентарь). Смотрим только на саму карточку: что после сделки
    происходит с двумя другими, неизвестно."""
    got, cands = _decide(*_rank_card(img_bgr, buttons, slot, offset))
    return got == item or (got is None and item in cands)


def identify_stock(img_bgr, buttons, offset=(0, 0)):
    """Товары во всех трёх карточках: [(слот, id или None), ...]. Пусто, если торговец закрыт."""
    ranks = _rank_all(img_bgr, buttons, offset)
    if not merchant_open(img_bgr, buttons, offset, ranks):
        return []
    out = []
    for s in range(len(buttons)):
        item, cands = _decide(*ranks[s])
        out.append((s, item or (cands[0] if cands else None)))   # не уверены — показываем самое похожее
    return out


def stock_is_sure(img_bgr, buttons, offset=(0, 0)):
    """True, если окно торговца открыто и все карточки узнаны уверенно (дорисовались)."""
    ranks = _rank_all(img_bgr, buttons, offset)
    if not merchant_open(img_bgr, buttons, offset, ranks):
        return False
    return all(_decide(*ranks[s])[0] for s in range(len(buttons)))


UNSURE = "?"   # find_best_item: в стоке есть карточка, которая МОЖЕТ быть товаром выше по списку — не покупаем
TOO_SMALL = "too_small"   # окно Roblox настолько маленькое, что буквы не различить (1x/3x и т.п.)
ITEM_MIN_SP = 120         # минимальное расстояние между карточками в пикселях (~окно 950x530)


def find_best_item(img_bgr, buttons, order, enabled, offset=(0, 0)):
    """Лучший товар по списку приоритета order (сверху важнее) среди включённых enabled.
    Возвращает (слот, (x, y) куда жать, id, [(слот, id), ...]) или None, если окно торговца не открыто.
    Если подходящего нет — (None, None, None, сток); если не уверены — (None, None, UNSURE, сток)."""
    if stock_signature(img_bgr, buttons, offset) is None:
        return None
    if scan_region(buttons)[4] < ITEM_MIN_SP:
        return None, None, TOO_SMALL, [(s, None) for s in range(len(buttons))]
    ranks = _rank_all(img_bgr, buttons, offset)
    if not _names_known(ranks):
        return None                                 # белый текст есть, но это не товары торговца (другое окно)
    rank = {item: i for i, item in enumerate(order) if item in enabled}
    never = len(order) + 1
    stock, picks, doubts = [], [], []
    for s in range(len(buttons)):
        item, cands = _decide(*ranks[s])
        stock.append((s, item))
        if item is not None:
            if item in rank:
                picks.append((rank[item], s, item))
        elif cands:
            rs = [rank.get(c, never) for c in cands]
            if all(r < never for r in rs):          # кем бы ни была — она нам нужна: считаем по худшему варианту
                picks.append((max(rs), s, cands[0]))
            if min(rs) < never:                     # а вдруг это товар выше по списку
                doubts.append((min(rs), s))
    best = min(picks) if picks else None
    if any(best is None or (r < best[0] and s != best[1]) for r, s in doubts):
        return None, None, UNSURE, stock            # неясная карточка может оказаться важнее — ждём следующий кадр
    if best is None:
        return None, None, None, stock
    _, slot, item = best
    return slot, tuple(buttons[slot]), item, stock


# ---------- окно «CLICK ANYWHERE TO CLOSE» (после катсцены мифика/годли) ----------
_CLOSE_SP = 252.0   # расстояние между карточками на скрине, с которого снят образец надписи
_CLOSE_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAO8AAAATCAAAAABdSwUHAAAMq0lEQVRYCb3Be5TP5b4H8Pdz+/5+M+PSYEsYZuiC7trpMpEhjUGm"
    "Oh3FSTvtSELJbYguCiPkFqMsk0QX5aQbyWZXii5IUYMxuY7rGJe5/H7f7/M8n8/WXuesvc5a/bVX67xe4q/4fxUB8PgXA0BLLQX+"
    "hQB4AIw/nngEgElKwRxPxBOBC5gZgGRmLRwZcCLNQYdaORfoahHzQais9gI6UsqBZMw6KQKbjCsLeC28EGDSKoJkeJ9CkpUl471W"
    "sEyRYStZe8UEQClQCgDpDHvtoQE4BD4CYA2xABCQICjv47VxstAS57HgRJqDdi7mtaUw0JojYQBiiGSK106SdNDJGAttHSsAAoB4"
    "FGARhGxCY1k7FaiI8RumwEpdK6QTSkvLUigmQYhFxhGR1sKyEsSQZEDGM0UBJPlYdQoxDEc+sAaC40khfCzU8F5ZESmvCKS8ZBMB"
    "EEqJGAAFLyV5IQCoSCECwBogAEKHNo4o5iULz1LiPCelFUpLHwlDsHFmBqukEFoxk7BaSCsF2MddiBixAuABiMcAq2Rax2svrCn5"
    "4qDv1V2/+hMAIfO6h6+WSNKNb21Xr6JsVaSGtVTDhczrqL74UOqkEKCpdcW+WSqKXTwgdni650uHYPWXBek8MUHBdLZ7Lgtml+PG"
    "O8Wsg77HHXbu/nl8oFA4MSPNDZLBK2QDALsL5Z29AYSVpZ+fjNvHWgMgwWOTAHr28KQAkHqu0jXv0TpIlG46VCvwGzaNO7WrV1G2"
    "+rS843ZeuAtgGF8vp01jf3TDLwkpfXBD+4tw9PMdTOMvckoBGAZADAVUlPlIHeU0Eq+U5+aI+aUAWOXlYv5u0LV94xLA6anhk03V"
    "WG4xMHZ4ljPeA2hewCwmnBXy8v4pbtmPYYtRWLsuNxfvbqjbrj9/HuWpxVvEQ1ertzZzv2xfIKehbFZS6ml1Tz9hxKJISAAHp3Ne"
    "TwDK6VNzkm5oJgBJflwI4I7bwThPhC8e69AnBhLSv7kzyTiPru0bUwJ8bH7YM9sU7VQ4r9nDdaUU4K3vhIHs82dS8GrdR35Ea2dw"
    "3nAAYjjAqePqieM7U685uMj27KKLSgE42TtHvFJCrR/Tbt/urHZfrfKjm9kCMbKBf6kSAIdKd7z7aCO9YlMUbzuIxYmptuUorP1M"
    "TtVHp9PQFmFhxmD/t894Ul1sXmaGtDo1OZiBAy9FTk9KrxkpzVx1dg2AU9vjd+SYtYdTbs70G9ZHw7L8J5YhN3oALZuZeE+cXh/Y"
    "75o+HNDB/VlZHM0/TBKSM4Ybd2h3RtsvP0TPrigq9USoO6qhOLIndp1SH/2dr71fVm3ha1KL9kWjW2NNrQ7l1wDE44DoeZvbvbzK"
    "NPIV3KuLLioF4GTvHFryEw1vja8/rI1lHmQ3MoPH3Ht9uPIHDyAMnB9xyaYmrfYsMK7tIE7EX9/efBTWrjF3ZUeF/mm58b8bTORN"
    "79R7XqJ8qnohrXSBni73z/LKTa5TM1KqIt4/BYDwdbp3w2ul1HBksHOJHJKJCaiVIA+AUsKGE7BvgZN096381ccJ2bMbNq+KJId6"
    "yCViw+owNauMwl55KCoFMXXoz/uKknzFI+L4TMrrwsu3SpO1I8bDszCarIQAIEYA7qmGetoxsobjrnsXXVQKwMneOX7Zjw3HqMoZ"
    "FrGEJPlkU377XrVjiWAAYaprMBFvN+kkJyZd20H841UVL144Cms/dReNlRtqerl5J+TY+odnXf3ggZb2WZos13yGWa78JbZuZmrN"
    "SBmfy+WTAUi4/G5iaalOHYedS+SQTDc5CYJMAhBepT/FvxYFkRzfICysdkFsfLx6otcyajxGnXrRiZTQRP6uzigqBUD3/5ne+BFs"
    "R2ViXllOPg58sCfmOWaHtnZPOUOwAMSTgJ5GiUkW2gUUdOqii0oBONk7h14vuexhv21lqMiQEyOamNpULN0uCQApfdV/4cX0gSgu"
    "cW0H8bt9sOzoKKxdp2S/q45FzcoWwo1uknyha5cvb0qZ74aLN7+nWQxnSBPVjJT1C5U1AIZa3TuXi3en514t1q+PhrVQXnleuscC"
    "YKHqTuQdy70MnhNnp3jBemhTUXjGBnzxQP7pbS8ipZ3v1Q1FpThvRHMx7Xg84l7ZwfKdqSNTndrz/Q/a8pjGykvBi38GIEYB6WPd"
    "iZcjY5WOgrxsXVwCgFW3rrR4b4d7aONq1rWBp2BocwHm09OUJyFIhA9eXfli2kS1+QPfZoB8+eb2R98Yg0/WUZA5WMro1TIb79MB"
    "Tz+Q9UbuRe+ffUDOLg+eZ+mMV+CqAgrmOlaseJjk/M7K69o4qmcyBjYXyYDw6q8KAElKHyd2LWZxwRh5Yi5xxMOy6KUzEakb/pO+"
    "/gAqIbQNenWSi8oIwJiGGOed4tvy8P53ycv61ifpTy0tl49nwGsSr+0CIMYA8Wfp7AxvU0UobH62Li4BwKpbVyre2/YB2rpCkWTp"
    "9ZCmEhWN8OEmQSy0i48Pjq/191xQMTfRZoB868Tg2PJ+Ys0GEaUOaoaTc5MxXNcH8wakzu54/TeVeXg6Mi/g3BYn+JaUqgIK5vra"
    "1V6IryTnd9YJo/3p944yBmZEnygWO87hPJKUPk7sWiylmYQzUwSb6IlmKDztWLX7C29bbnzgZaR73CoXlRGAx5ui8AwzenbGiq3K"
    "mmuuax7QiTkYnOnXsKAfagCIAoDHXMCTq1l65VWPbF1cAoBVt65i8d4LxrpTC2ql43qWBmfIX998rG70UjWRMNTmQTCzAi/Y32aA"
    "fHdLn6t/zdLrPjWgTndgzd+0cC2H2TU93NPX3Hf4yI3Hp2s5BfuLq3X4THpVAZk5oryQWQjJ+bdhbcV9onKhZQzM4Mk1RnnvAJCk"
    "9HFi12LNPLq+mllhdcqzqJoMJpVe4CvneKZUJKl7Z7mojAD0u9y8941JqMcz3PxjXrCybf9iqPDsI63sU1ISCIAoAHDPFbFvP6o1"
    "jevsTu2WrYtLALDq1lW8tlcNbuo/3uzMpUdC90hLP6filjz69mNPHBe33ywFAO+/WtNmgFy57cLh1UZvWM9atL8bq7Y4HwvGi92X"
    "lr3V6FE61GrnihCFYt+iGskvpFUVkJmt9s4Gs5ScfxuWHOh2vfr7l4yBzdwU6axiB4AkpY8TuxabUPfOtttWKpd/C7a97TUr/WhT"
    "WrVJU5ujtS63s1xURgAu7xscWpxQl9xvqqdGJu+7s0nVv50v2j+kVTQlwYEjAKIAEA0fSk9WHKH2tORQ947um2oAW6pyc9yKndzu"
    "PqVKT9a/pGLpmScaqmecf6IJ5h2T3vjhjc4uSOqUEcHJhVn3Bu9so37Xgj7eFDi0/w+8v5WV96PrU2zTajspZs2aL4x+hvYuFiGe"
    "T4tGCszDya8BuM22R3f/xq7GQ5WdYfFAa3xGDPnLKfIcWJ0yASXLQPynITF3uPzCS/3Z1095AeCKfixKKtIvq3zZ9squKj3hWP1y"
    "9q8tcGZ3yjXCr9wR5nZN/lrR4NKgemY4KBOfWQDfOjhRACi+JD8dYJF8c1evTrASwMKTt92C4tIo5YZcYwPQidcqn7yIJlfzlfdj"
    "z1LPusmg2M4VlvXgJjytRV/z/pYw61GJzz8NHDrciQ+/ZeVV/8wAb23H0IwoeHu7kc/5E3Ms09MNaibY+AzAA0iOV/nZ+rXS1C4d"
    "9Mb16qEGhkyozIIj7CmwOmUCDsyLM/GVfQxJ9nrFNmMlANE5R5KGrS0+3fVWwAmFRWV/6t8YxCrx/acKvW6IAiBS7/3shjRHpAAs"
    "LJckxgHwukGnjCbVe78qlz1vAgjAK8c7dfXLfjbx5MU3NqtTeXDtOTkwkyZXa364VfT+diNvvp3e+zkRQ5ec8GPfx6/c4eP5V8pP"
    "NgYO7e/Gqq2svMrJETT7XHhne8MzKwxNVEcWhZ6eTauZ5M0MwAOICtRdHbFsL6UPkfLlsG8G4BXC1w+xg7Y6pUDvKZaSSTXKaZlS"
    "u2/rUesFA9A+46bWqRUH1oWuaxeCgEi+fsjW6dTugvDE1yXSQ7a6Lqt+1eGNh616rKH0MQALyqUX4wESkoQBh3WrfJCSxD/5NMvs"
    "NFGQkEp45ZBK2nphDQvPUgIxromraqmAMI1DGSdmc04FDlKBPSsfTwqtvJMuEPHayHjD+pxJIu7YBtawEwBI27qsJWmWkHBKyVpl"
    "A3KCSJPVKQnDoYRkAy+IFUOQjgDEHGSoFQvPIojYJALvjY85r9kGMeuZtfCSHAXKamFqFADt2YoJ+F0C/z5SYIBZCPwfDCBCZDwx"
    "NBN+owDEhHJxANJD4n9YYgj88cQE/C6Bfx8pMH4HA7Ds2UNAEv5JAQikhAHAkPhf5IkF/nj/ABhXzuFMuaKQAAAAAElFTkSuQmCC"
)
_CLOSE_TPL = None
CLOSE_MIN_SCORE = 0.50
CLOSE_WHITE = 215     # яркость белых букв надписи (фон под окном игра затемняет)


def close_popup_region(buttons):
    """Где искать надпись. Она всегда на одном месте относительно карточек торговца (и на ПК, и на
    телефоне): по центру, на ~0.8 расстояния между карточками выше кнопок. Берём зону с запасом —
    другие белые надписи (заголовок окна, названия товаров, TRADED) в неё не попадают."""
    xs = [b[0] for b in buttons]
    ys = [b[1] for b in buttons]
    sp = (max(xs) - min(xs)) / 2
    cx, by = sum(xs) / len(xs), sum(ys) / len(ys)
    vx, vy, vw, vh = pio.virtual_screen()          # границы всех мониторов
    return (int(max(cx - sp * 0.75, vx)), int(max(by - sp * 1.25, vy)),
            int(min(cx + sp * 0.75, vx + vw)), int(min(by - sp * 0.42, vy + vh)), sp)


def _letters(gray):
    """Только белые буквы (1) — фон, каким бы он ни был, становится 0."""
    return (gray >= CLOSE_WHITE).astype(np.float32)


def find_close_popup(img_bgr, buttons, offset=(0, 0)):
    """Ищет надпись «CLICK ANYWHERE TO CLOSE» по форме её белых букв (фон не важен) в разных размерах.
    Возвращает ((x, y) на экране, уверенность) или (None, уверенность)."""
    global _CLOSE_TPL
    if _CLOSE_TPL is None:
        import base64
        tpl = cv2.imdecode(np.frombuffer(base64.b64decode("".join(_CLOSE_B64)), np.uint8), cv2.IMREAD_GRAYSCALE)
        _CLOSE_TPL = _letters(tpl)
    sp = close_popup_region(buttons)[4]
    th = _CLOSE_TPL.shape[0] * sp / _CLOSE_SP          # примерная высота букв на этом экране
    ds = min(max(16.0 / th, 0.5), 1.0)                 # уменьшаем только крупную картинку: мелким буквам это вредно
    F = cv2.resize(_letters(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)), None, fx=ds, fy=ds,
                   interpolation=cv2.INTER_AREA)

    def match(f):
        k = sp / _CLOSE_SP * f * ds
        t = cv2.resize(_CLOSE_TPL, (max(int(_CLOSE_TPL.shape[1] * k), 8), max(int(_CLOSE_TPL.shape[0] * k), 3)),
                       interpolation=cv2.INTER_AREA)
        t = cv2.copyMakeBorder(t, 2, 2, 2, 2, cv2.BORDER_CONSTANT)
        if t.shape[0] > F.shape[0] or t.shape[1] > F.shape[1]:
            return -1.0, None
        r = cv2.matchTemplate(F, t, cv2.TM_CCOEFF_NORMED)
        # там, где в окне почти нет букв (ровный фон), корреляция бессмысленна — обнуляем
        m = cv2.boxFilter(F, -1, (t.shape[1], t.shape[0]), anchor=(0, 0))[:r.shape[0], :r.shape[1]]
        m2 = cv2.boxFilter(F * F, -1, (t.shape[1], t.shape[0]), anchor=(0, 0))[:r.shape[0], :r.shape[1]]
        r[(m2 - m * m < 0.01) | ~np.isfinite(r)] = 0
        _, mx, _, loc = cv2.minMaxLoc(r)
        return mx, (offset[0] + int((loc[0] + t.shape[1] / 2) / ds), offset[1] + int((loc[1] + t.shape[0] / 2) / ds))

    # грубо по размерам 0.7..1.5, потом точнее вокруг лучшего
    coarse = [(match(f), f) for f in 0.7 * 1.09 ** np.arange(10)]
    (best, pos), bf = max(coarse, key=lambda c: c[0][0])
    for f in (bf / 1.06, bf / 1.03, bf * 1.03, bf * 1.06):
        s, p = match(f)
        if s > best:
            best, pos = s, p
    return (pos if best >= CLOSE_MIN_SCORE else None), round(float(best), 2)


# ---------- сток торговца и Discord ----------
def stock_signature(img_bgr, buttons, offset=(0, 0)):
    """'Отпечаток' названий трёх товаров (белый текст). None, если окно торговца не открыто."""
    sp = scan_region(buttons)[4]
    h, w = img_bgr.shape[:2]
    sig = []
    for bx, by in buttons:
        bx, by = bx - offset[0], by - offset[1]
        x0, x1 = max(int(bx - sp * 0.48), 0), min(int(bx + sp * 0.48), w)
        y0, y1 = max(int(by - sp * 0.45), 0), min(int(by - sp * 0.25), h)
        if x1 <= x0 or y1 <= y0:
            return None
        m = _white_text(img_bgr[y0:y1, x0:x1])
        if (m > 0).mean() < 0.03:  # в карточке нет названия — торговец закрыт
            return None
        sig.append(cv2.resize(m, (160, 24), interpolation=cv2.INTER_AREA).astype(np.float32) / 255)
    return np.stack(sig)


def stock_difference(a, b):
    """Насколько отличаются названия: максимум по кускам строки (так видно даже смену одного слова).
    Помехи фона дают ~0.01–0.05, смена товара ~0.12+."""
    d = np.abs(a - b)                      # (3 карточки, 24, 160)
    chunks = d[:, :, :156].reshape(3, 24, 6, 26).mean(axis=(1, 3))  # 6 кусков по ширине
    return float(chunks.max())


def stock_changed(a, b, threshold=0.08):
    """True, если хотя бы в одной карточке название заметно другое."""
    if a is None or b is None:
        return False
    return stock_difference(a, b) > threshold


# ---------- таймер "New deals in MM:SS" ----------
# Образец цифры «5» (фиолетовый текст таймера). Первая цифра минут становится «5» только
# в момент обновления стока (00:0x -> 59:59), потому что таймер идёт вниз.
_FIVE_B64 = ("iVBORw0KGgoAAAANSUhEUgAAAA0AAAAUCAAAAABzWejzAAAARUlEQVQYGUXBgRHCMAADMf3+Q5typEHKXGWuMleZqwz5yZCfjByZ"
             "IzKvZK5iYb5yzCOvIa8hxzyafM2j+au5kjkizCOPDwGMFg/I9eZNAAAAAElFTkSuQmCC")
_FIVE = None


def timer_rect(buttons):
    """Широкая полоса над карточками, где ищем строку таймера (он выровнен по правому краю окна).
    Полоса с запасом: точки калибровки могут стоять выше/ниже на кнопке TAP TO TRADE."""
    xs = [b[0] for b in buttons]
    ys = [b[1] for b in buttons]
    sp = (max(xs) - min(xs)) / 2
    by = sum(ys) / len(ys)
    return (int(max(xs) - sp * 0.6), int(by - sp * 1.92),
            int(max(xs) + sp * 0.75), int(by - sp * 1.30), sp)


def _purple_text(img_bgr):
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    return (hsv[..., 0] >= 115) & (hsv[..., 0] <= 155) & (hsv[..., 1] >= 40) & (hsv[..., 2] >= 170)


def _timer_lines(img_bgr):
    """Делит фиолетовый текст в полосе на строки. Каждая строка: (y0, y1, [маски символов слева направо]).
    Рамки вывесок (длинные тонкие линии) выбрасываются, строки собираются по высоте символов —
    поэтому вывеска «Mysterious Merchant» не склеивается с таймером, даже если касается его."""
    m = _purple_text(img_bgr).astype(np.uint8)
    H = m.shape[0]
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
    comps = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area < 2 or h > H * 0.45:
            continue
        if w > 2.5 * h + 3:                    # горизонтальная линия (рамка)
            continue
        if h > 6 and w <= max(2, 0.12 * h):    # вертикальная линия (рамка)
            continue
        comps.append((x, y, w, h, i))
    lines = []  # [y0, y1, [компоненты]]
    for c in sorted(comps, key=lambda c: -c[3]):
        x, y, w, h, i = c
        for L in lines:
            overlap = min(L[1], y + h) - max(L[0], y)
            if overlap >= 0.5 * min(h, L[1] - L[0]):
                L[2].append(c)
                break
        else:
            lines.append([y, y + h, [c]])
    out = []
    for y0, y1, cs in lines:
        cs.sort(key=lambda c: c[0])
        groups = []  # символы: компоненты, пересекающиеся по X (двоеточие = две точки)
        for c in cs:
            if groups and c[0] <= groups[-1][1]:
                groups[-1][0].append(c)
                groups[-1][1] = max(groups[-1][1], c[0] + c[2])
            else:
                groups.append([[c], c[0] + c[2]])
        glyphs = []
        for g, _ in groups:
            gx0 = min(c[0] for c in g)
            gx1 = max(c[0] + c[2] for c in g)
            gy0 = min(c[1] for c in g)
            gy1 = max(c[1] + c[3] for c in g)
            glyphs.append(np.isin(lab[gy0:gy1, gx0:gx1], [c[4] for c in g]))
        out.append((y0, y1, glyphs, sum(int(gl.sum()) for gl in glyphs)))
    return out


def _parse_timer_glyphs(glyphs):
    """Если строка кончается на «ЦЦ:ЦЦ» — True/False (первая цифра минут «5»?), иначе None."""
    if not glyphs:
        return None
    tallest = max(g.shape[0] for g in glyphs)
    glyphs = [g for g in glyphs if g.shape[0] >= tallest * 0.35 or g.shape[1] <= g.shape[0]]
    if len(glyphs) < 5:
        return None
    m1, m2, colon, s1, s2 = glyphs[-5:]
    hs = [g.shape[0] for g in (m1, m2, s1, s2)]
    if max(hs) > 1.3 * min(hs) or min(hs) < 6:
        return None
    # двоеточие: узкое и из двух точек (посередине пустые ряды)
    if colon.shape[1] > 0.6 * colon.shape[0] or colon.any(1).all() or colon.shape[0] < 0.5 * min(hs):
        return None
    return float((_glyph_vec(m1) * _FIVE).sum()) > 0.65  # «5» ≈ 0.75–1.0, «3»/«8» ≈ 0.5, остальные < 0.2


def _timer_candidates(img_bgr):
    sp = img_bgr.shape[0] / 0.62  # высота полосы = 0.62 расстояния между карточками
    lines = [L for L in _timer_lines(img_bgr) if sp * 0.04 <= L[1] - L[0] <= sp * 0.16]
    lines.sort(key=lambda L: -L[3])  # сначала самые «плотные» строки
    return lines


def find_timer_row(img_bgr):
    """Строка «New deals in MM:SS» в полосе: (y0, y1) или None."""
    _load_five()
    for y0, y1, glyphs, _ in _timer_candidates(img_bgr):
        if _parse_timer_glyphs(glyphs) is not None:
            return y0, y1
    return None


def _load_five():
    global _FIVE
    if _FIVE is None:
        import base64
        _FIVE = _glyph_vec(cv2.imdecode(np.frombuffer(base64.b64decode(_FIVE_B64), np.uint8),
                                        cv2.IMREAD_GRAYSCALE) > 0)


def _glyph_vec(g):
    v = cv2.resize(g.astype(np.float32), (16, 24), interpolation=cv2.INTER_AREA)
    v -= v.mean()
    n = np.sqrt((v * v).sum())
    return v / n if n > 0 else v


def timer_tens_is_five(img_bgr):
    """По картинке полосы с таймером: первая цифра минут — «5»? True/False, None если таймер не виден."""
    _load_five()
    for _, _, glyphs, _ in _timer_candidates(img_bgr):  # ищем строку, что кончается на «ЦЦ:ЦЦ»
        r = _parse_timer_glyphs(glyphs)
        if r is not None:
            return r
    return None


# ---------------- РЕЗУЛЬТАТ ПОКУПКИ (SUCCESS! / FAILED) ----------------
# После покупки надпись TAP TO TRADE на карточке меняется на зелёную «SUCCESS!» или красную «FAILED».

def result_rect(buttons, slot):
    """Область вокруг кнопки TAP TO TRADE нужного слота."""
    xs = sorted(b[0] for b in buttons)
    sp = (xs[-1] - xs[0]) / 2 if len(xs) > 1 else 300
    bx, by = sorted(buttons)[slot]
    return (int(bx - sp * 0.42), int(by - sp * 0.13), int(bx + sp * 0.42), int(by + sp * 0.13), sp)


def result_colors(img_bgr):
    """Доля ярко-зелёных и ярко-красных пикселей текста в области кнопки."""
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    green = (h >= 45) & (h <= 85) & (s >= 110) & (v >= 170)
    red = ((h <= 8) | (h >= 170)) & (s >= 130) & (v >= 170)
    n = float(h.size) or 1.0
    return green.sum() / n, red.sum() / n


RESULT_MIN = 0.03   # минимум «цветных» пикселей, чтобы считать, что надпись появилась


def purchase_result(img_bgr, baseline=None):
    """'success' / 'failed' / None. baseline — цвета этой же области до клика."""
    g, r = result_colors(img_bgr)
    if baseline:
        g, r = g - baseline[0], r - baseline[1]
    if g >= RESULT_MIN and g > r * 2:
        return "success"
    if r >= RESULT_MIN and r > g * 2:
        return "failed"
    return None


# ---------- погода ----------
# Иконка погоды появляется в ряду иконок вверху экрана (слева от предметов): такой же квадрат, как у предметов,
# но с цветной рамкой, монетой погоды и таймером мм:сс. Ищем её только в узкой полосе с этим рядом — такие же
# монеты летают и в самой игре. Образцы сняты с пяти скринов (по одному на погоду), см. dev\weather.
# Погода засчитывается, только если найденное — действительно такая иконка: рамка цвета этой погоды со всех
# четырёх сторон, за рамкой фон иконки, внизу белые цифры таймера. Просто похожее пятно (плакат на стене,
# монета в мире игры) рамки и таймера не имеет. На цвет экрана и освещение макро не смотрит вообще.
WEATHERS = (("rainy", "Rainy"), ("foggy", "Foggy"), ("thunderstorm", "Thunderstorm"),
            ("full_moon", "Full Moon"), ("solar_eclipse", "Solar Eclipse"))
WEATHER_NAMES = dict(WEATHERS)
WEATHER_MIN_SCORE = 0.62      # оценка от 0 до 1, начиная с которой погода считается найденной
WEATHER_FRAME_TOL = 22        # цвет рамки на экране может отличаться от цвета рамки образца не больше (на канал)
# Размер иконки погоды (с рамкой) в долях расстояния между карточками торговца: на ПК 0.284, на телефоне 0.325
_W_SCALES = (0.262, 0.275, 0.289, 0.303, 0.318, 0.334, 0.351)
_W_SCREEN_H = 0.2385          # расстояние между карточками в долях высоты окна игры
_W_BUTTON_Y = 0.806           # высота кнопок TAP TO TRADE в долях высоты окна игры
_W_TOP, _W_BOTTOM = 0.012, 0.145   # полоса с рядом иконок: от и до, в долях высоты окна игры
_W_HALF = 0.66                # полуширина полосы в долях высоты окна игры (ряд стоит по центру окна)
_W_LUM = 0.25                 # вес яркости рядом с цветом: цвет монеты и рамки важнее, чем «тёмный квадрат»
_W_MIN_STD = 6.0              # ровный однотонный участок с образцом не сравниваем
_W_CHECK_FROM = 0.45          # рамку и таймер проверяем у мест, похожих на иконку хотя бы настолько
_W_INNER_DIFF = 24            # фон иконки сразу за рамкой отличается от рамки хотя бы на столько (в одном канале)
_W_INNER_FLAT = 20            # ...и он ровный: вплотную к рамке и чуть глубже яркость одна и та же (с таким допуском)
_W_WHITE = 165                # точка цифр таймера: все три канала не темнее этого
_W_TIMER_MIN, _W_TIMER_MAX = 0.05, 0.45   # доля белых точек там, где стоит таймер
_W_TIMER_DEV = (0.09, 0.21)   # разброс цифр таймера «мм:сс» по ширине, в долях стороны иконки (у образцов 0.15–0.17)
_W_ZONE_MIN, _W_ZONE_MAX = 0.5, 2.0       # сила цвета монеты относительно образца (у настоящих иконок 0.93–1.12)
_WEATHER = None
_WEATHER_B64 = (
    "V1RIMxgFAP////////////////////////////8A/1lZWVlZWVlZWVlZWVlZWVlZWVlZWVn//1lZWVlZWVlZWVlZWVlZWVlZWVlZ"
    "WVn//1lZWVlZWVlZ////////WVlZWVlZWVn//1lZWVlZWf////////////9ZWVlZWVn//1lZWVlZ////////////////WVlZWVn/"
    "/1lZWVlZ////////////////WVlZWVn//1lZWVn//////////////////1lZWVn//1lZWVn//////////////////1lZWVn//1lZ"
    "WVn//////////////////1lZWVn//1lZWVn//////////////////1lZWVn//1lZWVn//////////////////1lZWVn//1lZWVn/"
    "/////////////////1lZWVn//1lZWVlZ////////////////WVlZWVn//1lZWVlZ////////////////WVlZWVn//1kAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAFn//1kAAAAAAAAAAAAAAAAAAAAAAAAAAFn//1kAAAAAAAAAAAAAAAAAAAAAAAAAAFn//1kAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAFn//1kAAAAAAAAAAAAAAAAAAAAAAAAAAFn//1kAAAAAAAAAAAAAAAAAAAAAAAAAAFn//1lZWVlZWVlZWVlZWVlZ"
    "WVlZWVlZWVn//1lZWVlZWVlZWVlZWVlZWVlZWVlZWVn/AP////////////////////////////8AAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgICAgICAAAAAAAA"
    "AAAAAAAAAAAAAAICAgICAgICAgIAAAAAAAAAAAAAAAAAAgICAgICAgICAgICAAAAAAAAAAAAAAAAAgICAgIBAQICAgICAAAAAAAA"
    "AAAAAAACAgICAQEBAQEBAgICAgAAAAAAAAAAAAACAgICAQEBAQEBAgICAgAAAAAAAAAAAAACAgIBAQEBAQEBAQICAgAAAAAAAAAA"
    "AAACAgIBAQEBAQEBAQICAgAAAAAAAAAAAAACAgICAQEBAQEBAgICAgAAAAAAAAAAAAACAgICAQEBAQEBAgICAgAAAAAAAAAAAAAA"
    "AgICAgIBAQICAgICAAAAAAAAAAAAAAAAAgICAgICAgICAgICAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXJhaW55XofMe4uqaom+ZYbAZIW/ZIW/ZIW/ZIXBZIXDZIXDZIXDZIXD"
    "ZIXDY4jEYYfDYYbCYIbBYIbBYIbBYIbBYIbBYYfDYYbAbIi6foqmaoe/UV50SktYSEpXSEpXSEpXSEpWSEpUSEpUSEpUSEpUSEtV"
    "R0xYSE1ZSExZR0xYR0xYR0xYR0tYR0tYSElXSEtdVGF/b4avaYa9RE1hR0lTRkhSRkhSRkhSRkhSRkhSRkhSRkhSRkhSRkhSR0lT"
    "R0lTR0lTR0lTR0lTR0lTRkhSRkhSRkhSSEpUSktXY4W/aYW9QktgRUdRREZQREZQREZQREZQRUdRRUdRRUdRRUdRRUdRRUdRRUdR"
    "RUdRRUdRRUdRRUdRREZQREZQREZQRkhSSUpVYobDaoW9RExgRkhSREZQREZQREZQREZQRUVQRUVQRUdPREdNQkdORUlUQ0dNRkdR"
    "REZQREZQREZQREZQREZQREZQRkhSSUpWZIfCaoW9RExhR0lTREZQREZQREZQQ0ZQQUdRP0VOKTA8MEFCMkxBLFFAN1RHQ0hNREdP"
    "Q0ZOQ0ZOREZPREZQREZQRkhSSkpWZIfDaYa7RExgRkhSREZQREZQREZQQkdRP0pSLTpAGywtKkA8L0lAF0owGkwsQFdOREhPREZP"
    "REVPREZQREZQREZQRkhSSkpWZIfCaYa7Q0xfRkhSRUdRRUdRRUdRRkdRNU1FIUQ3GSg2L0NHJzU7ESEmCSQbJE83LVdCQVRNREZQ"
    "REZQREZQREZQSEpUSktYY4a+aIW6Q0xfRkhSRUdRRUdRRUdRQ0lNKU02HDY1GSQ0GSMxGiIzHCM3FikwHkk1FlMyQWJRREdPREZQ"
    "REZQREZQSEpUSktYZIa/aIS6RE1gR0lTRUdRSEZSQ0dPMlVCIkk1HSs2GyQ1HSQ1GiEyGiAzIi46KkA+IUozQ2hVQUhQRkZRRUdR"
    "RUdRSEpUSktYZIfAaIS6RE5gSEpURUdRSkVTRElPI1kyKEk+HCg1GiMzHCIzHyY2ICk8Iik9Ki5BJDg5ID45LjhASUdSR0dSRkhS"
    "SEpUS0xXZIfCaIW6RE5gSEpURUdRRkZTRUhPKVczHzwyICo7Iiw9KTBDHyc5ICg7JCo9JCU6Gy40HkYzMT1CSUdSR0dSRkhSSEpU"
    "S0xXZIfDaIW7RExiSEhWSEVXR0VWQkdPMlI+JDY1ISc4HCI4ICZAGyM7IyhBKS5BHCcyGTIsKFQwPkVKRkhSRkhSRkhSSEpUSUxW"
    "ZYfAaYW8RExiRklURkdURUdSREdSNEtBKj06Hyc0HSU4GiM4HSc6Iyk6ISgyEiQgFDohN1tCREhQRkhSRkhSRkhSSUtVSU1XZYfA"
    "aYa8RUxjRkpTREhRQklPRUdSLDs5HDYuGiYrHig0GiQ0Gyc3HCcyER8eGTAfHUsnOFBDRUdRRkhSRkhSRkhSSUtVSk1YZYbAaYW7"
    "R01kSElTRkhQRkhQRUdPNzxBJUM8NlZLMT8+GyUtGyUyGysuJT4wJ04uKlo4NUE5RUdQRkhSRkhSRkhSSEpUSUxXZIbCaoa8Rkxj"
    "SElTRkhQRUdPRUdPX19kaGpoKEk7coJ8KjE1KTE3MDw7ZnRqO1dFR11PcXN1QkRNRUdRRkhSRkhSSEpUSUxYZYfCaYa8RU1jSElT"
    "R0hQRkhQQ0NLn5yhhoCDQExJjJSVP0RJX2RoQ0dIUFNSi5CQPT9BpaOqTE1XR0lTRkhSRkhSSEpUSkxZY4fAa4e9R05kSElTR0hQ"
    "R0hQRENKnpuhioSKRExPi4+SQEVKUFVZQkJGmZibS0tQPT9EiIuQXF5nR0lTR0lTRkhSSUtVS0xZYoe+aoa8Rk1kSEpTRkhQRkhP"
    "R0lPU1NZXl5kPj1Ed3N6Xl5kTVFVQ0RJdXZ7WVpfU1NbaWlxREZQR0lTR0lTRkhSSUtVTExZY4i/bYbASU9lS0lWSUlUR0lQSEpQ"
    "R0lPRklRRklRRklSRklSR0lSSUpRR0hQSUpSSEhTR0hTR0lTSEpUSEpUR0lTSUtVSk1aZofAbYfASlJmTkxZTEtVSkxUSkxTSkxU"
    "SEpWSEpWSEpWSUpWSUpVSktTSUpSSUpTSUpUSUtWSUtWSkxWSkxWSkxWSkxWSlFiZ4i5coq6XnOZVGGBUV98UWF+UGB+T2F/TWGA"
    "TWGATWGATWF/TWF+TWF9TWF8TWF8TGJ8TWF9T2B9UGB9UGF+UWF+UWF+X3OWbYu3hJGmdo62c4y5cYu4cYu4cYu4cYu3cYu2cYu2"
    "cYu2cYu2cYu2cYu2cYu2cYu2cYu2cYu2cYu2cYu2cou3dI25dI25fY63i5KsBWZvZ2d5pqWryMbMuLa8tLK4s7G3tLK4tLK4tLK4"
    "tLK4s7G3s7G3s7G3tLK4s7G3s7G3tbO5srC2tLK4s7G3srC2tLK4s7G3s7G3uLa8x8XLsa+1lJKYgoCGgX+FgX+Ff32Df32Df32D"
    "gH6EgH6Ef36EgH6EgH6EgH6DgX+Ff32DgH6Ef32DgH6EgH6EgH6EgoCGkpCWsK60qaitcG50bGpvamhuamhuaWhuaWduaWdraWds"
    "aGhrZmhqaWhqamhqaGdpb2Zra2dramhsamhsamhsamhsamhsa2twcW50pqarpqesbW1yZ2drZ2VpZ2VnamVsaWZsZmdpaGZqZ2Zq"
    "YmZmZWdmZWZkZGdnaWNnZ2NnZmRoZmRoZmRoZmRoZmRoamhub21zpqarpaaraWpvZWZqZ2VpZmRmaGJoZmRoXmNiZGJmY2JnX2Ri"
    "YmViYGJfYGRhZmJiZmJlZGJmZGJmZGJmZGJmZGNnZmVqbWpwpqarpaarZmdsZWZraGRqZmNoaGJoZmRoXWFgYmBkX19jW2FeWmBc"
    "WF9bVmVdYGBeYl9hYF5iYF5iYF5iYF5iYV9jY2JnamhupqarpaesZmdsZGRpaWRrZGNnaGNoZWRnW2BfYWBjTltSM1Y/LVVAMVRF"
    "IVM5TmZWXl9fX11hX11hX11hYF5iYl9jZWFnaGZspKSppaesZmdsY2NoaGNqZGNnaGNnZWNmUGBWN1tEMFE8N1pFTGNUHjgrDC4b"
    "Ik41SmpXVGJZYV9hYl9jYmBkYWFkY2JmaGZspaWqpaesZmdsY2NoaGNpZWVpZ2NlY2VjOl1GMVw8Y05IWFJNUEZEKBkZDRkSLEk1"
    "IlQ1NmhMYGNgYV5iYF9iX2BjYGJkaGZspKSqp6asZ2ZsY2JoZ2RqZmRoZmZmU2RZNGJCSU84ZRkgXg4aXwwbYA0dSRshNUIxI08u"
    "MGVCW2deYl9jX2BjX2BiXmFjZ2dtpKSpqKasaGZsY2FnZGJoZWNoYmRiNV1DNWVDXCwpaBAcaQgXaAoXZQwXcw0bdjhBWl1XLF08"
    "VG9jYWBlYl9hYmBhY2FkamdtpaWrqKasaGZsY2FnZGJoZWNoYmRiL1Y7JE0sTh0aaRAabQ0aahAaZREYaxAcZRwpY1FVKVU4QWpR"
    "XGBiYV9lYmBiY2FkamdtpaWrqKasaGZsY2FnZGJoZmRoYmVjOlxGOlA1WBcbbAwachEibBIgZxAeaRIiXREiWjtCLVI2OGFFXmJh"
    "YWBkYmFjY2FkamdtpqWrqKasaGZsZGJoYmBmZmRoY2ZjRl9PVW5TXRseYw8aYQsaYw4daxAgahIhMxwcHiwfHkwsTmdTYWFgYWFi"
    "Y2JjZGFkamdsp6WsqKasaGZsZGJoYmBlZGJmZGZkT2JTM2ZATkUyZBgfZA8cZQwaZA8bQw8TGB8TFS4WMF4+WWVYYmFgYWBhY2Jj"
    "ZWJlaWZrp6WsqKasaGZsZGJnYmBlZGJmZGRnYGVhKlg1R2xTX1tXXSUrXw4cYBQdMyggGzkeHU4qOFFAXF5dYWBhYGBjYWFjZGJn"
    "aWdupqSrqKasaGZsZGJmY2FlZWNnZGRnXV5eTmBTLVxBTmNVWFFLXUlLUEpGVWVYNk84NlY9ZmtmVVZWYGBhYGFkYGFkY2Fnamhv"
    "p6WsqKasaGZsZGJmYmBkZGJmYF9im5qajI6QVl5biIuJlZiUeHp7TVZSWmVegoZ/h5KJU1JTVlRWYF9iYWJlYWBlYmBnamhvp6Ws"
    "qKasaGZsZGJmY2FlY2FlXVteoqGihYSGdnd5d3l5oaOkO0FBQEtJf4WFdXV2XmBimpicZGJnYWBiY2FnYmBmY2Fnamhup6WsqKas"
    "aGZsZGJmYmBkYV9jYWBjeHd4gH5/VVNUhIOEbm5vc3FzVVFTnp2eV1RWXlteg4GEXVxfYWBiYV9lYV9lY2FnamhupqSrqKasaWdt"
    "ZWNnY2FlYmBkZ2VoZ2VoZWNmaGVpYmBjYV9iZGBjYl1gXlxfYF1gYl1hX11gY2FkYmBjYmBmYmBmZGJoamhvpqSrqKasa2lvZmRo"
    "ZWNnZWNnaGZqaWdraWdraWdtZ2VpZGJnZGJmZWJmZWJnZWNnZWJmZGJmZGJmZGNmZWNpZWNpZ2Vra2lwpqSrrauxf32DaWdraGZq"
    "aGZqa2ltbmxwbmxxbWtxbGpuamhtaGZqaWdramhtamhsamhsamhsamhsaGZraGZsaGZsamhugH6FrKqxvbvBq6mvpqSqpqSqp6Wq"
    "qKasqqiuqqiuqaetqKasqKasqKasqKasqKasqKasqKasqKasqKasqKasqKasqKasqKasq6mvvbvBDHRodW5kZXJzdG9ybc22WIaH"
    "kKWbd62ebK+gb6qgdKqgdKufcaueb6ueb6ueb6ueb6ueb6ueb6ueb6yfcK2gca2gca2gca2gca2gca2gca6hcqCcfoWIh6yjeJOJ"
    "XnVrTXRrTXFrWnFrWnFqWHFqVXJqVXFqVXJqVXJqVXFqVXFqVXFqVXFqVXJqVXFqVXFqVXJqVXJqVXRtWJSJXbeybbyvbFJJQUZI"
    "U0JEUUVHUUNFT0JET0FDUENFUUJEUEJEUUNFUUJDUEJDUEJDUENDUEVFUkRET0RET0VFUEdHUkdHUk1LWtC2WL6xbk9GPkRFUUFD"
    "UENFT0JETkJDTUFCS0JDTEJDTEJDTENETENDTENDTENDTERETUVFTkRET0RET0RET0VFUEZGUUpIWNC2WL6xbk9GPUVGUkFDUENF"
    "T0JETkFDTkBCTEJCSkpHRzs9Rz0/Sz1ARFNTQkpIR0RDSkRDTURET0RET0RET0RET0ZGUUhGVs+1V72wbVFIP0VGUkFDUENFT0JE"
    "TkFETUJDTGBeV6eocSInLjM3SygxMpGXTW1vS0FDR0RGTURET0RET0RET0RET0dHUkpIV8+2WL+vbVNIQEVGUkFDUENFT0JETkVG"
    "Tnx5drLGrFluXSguJxIWLQ4VKBcgJSIpOUdNXT5FUERET0RET0RET0RET0dHUkpIV8+2WMGvbVJJQkZFT0ZETkRDTERDTGxrbaGm"
    "mEljUV5rSSMnKRAWJxAVKA8TJyhMYR0nOio5UUJHUUVET0ZES0VGTUdIVExJWs2zVsKubVFJQ0dFTkZETURCS0ZETaKipFdaTlJX"
    "LCcnI0NNOEJUQUFMNxMaKBMeMCIqPS11mUd6j0RFTURFRkRGTEhIVExJW860VsKubVFKQ0dFTkVDTEVDTFJRWqWlsVJWNDM6Jk12"
    "Xx1UWztzeFhnQ0pTPhUaKDM3Sz94k22juEVGT0RFTkRGTUhJVU1KXM2zVsKubVFJREhFUUdDT0ZETnd6iHB2fFVXMEBVQCSBlRVc"
    "fkFgXxgfK0lfYBMWJiUmNlZ0h57Ez0ZNWEZIUUZIUkxMWU9MXtC2WMKvbU1JQ0NGUEJGUEJGT4KLmFJaVVh0WUlUOBAqOU1eVk1S"
    "PxIVKzVNaRIWJBYaL0VWar/W5ExUX0pJU0hKVEtLWE5LXdG3WcKvbU5KQ0JIUD9IUT9IUGh6h11tamuVcklUOREWIlFURVlbKD9E"
    "KllsYiYtJiYmPVlcbNHZ5WFmb0tKU0hKVEtMV1BOXs+1WMKubVBKREdIUEVHT0VHTlJqd1Z/hGuMZkpeSSoqInFzPJSUKX2DOnaA"
    "ThYcJx0gNGJjbNHT21NVXUlLU0hKVEtNV1FQX82zVcOvbk9JQ0dJUEZHSERISkRZZDRwglBfNyo0KFRbNXd9MElHH2dsLjg9Kw8W"
    "JRUZKqmwsZqdpEdJUUhKUklLVUtNV09OXdC2WMKubVFLREpLVEdJUEdIUUNHTyUrPB8kK0VbRB5sezOPlDx/dxwiIhEUJBITJTo9"
    "QtXYzFxfZEhKUkhKUklLVUtNV09NXc+1V8OvblNNRkpKVUhJUUdHUkRGTkNCTEJHUxgvRTVsfydedB1ohA0dKyUnNy0wNoqNjJCX"
    "kkJES0lLU0lLU0lLVUtNV09OXdC2WMOvblROSEpKVEhJUUdHUUJETJmZoIWKj09hbIGOjoiYnGWEizg8QqerraeonpSXkNzc3klL"
    "U0pMVElLU0lLVEtNV1BOXdC2V8KubVJMRUtLVEhIUUdHUUFCS52eo31/g3N1eXx9gJmqrzZmcHBycre5upqYnKKgpLi8wVRWXUhK"
    "UklLU0lLU01OV1BOWtC3VcOwblROR0lJUkpKU0pKVEZHT29weXl7gD9BRn1/g2Nob2pveVFSU1BOUGxtcz0+Q3h5fkNETEdJUUlL"
    "U0lLU01OV1BOWtC3VcSxb1dRSk1NVktLVEpKVUlKU0hJU0ZIUUpKU0lKU0hMU0ZMVUhJUExMUkdLVEpMVEhKUkdJUUpMVEpLVEtL"
    "VExNVk9OVtC2VsWxcFVQSU9PWExMVk1NWExMVkxNV0tNV0xNWE1PWU5OWUlOWUtMVk1PWUxOWEtNVktNVUpMVEtNVUtMVU1NVkxM"
    "Vk9OXM60U8KubXNtZ1BQWU9PWFBQW1BQWk9QWk1PWE5QWE9RWk9PWk5PWU9PW09QW09QWk5QWk5QWE9RWU9RWU9QWU9PWFFSW21u"
    "ZdC2WpidlrmwdMGxacKyasKyasKyasKyasKyasKyasKyasKyasKyasKyasKyasKyasKyasKyasGwacCwacCwacCwacCwabqwbqOc"
    "hwlmdWxsX21vb26or8orLkJgY3lwcopwcopwco5xc49wc45vco1vco1ucYxucYxtcItrcYZrcIZqcIVscodrcYZtc4dwdYlvdIxu"
    "c4tscYlZX3IeJDV6fZNoa39DRlpDRllDRldDRldCRVdBRFZBRFZARFVAQ1VARFU+RVI+RVI+RFE9Q1A+RVI9Q048Qk4+RFNCSFdB"
    "R1Zkan15fpWZnrQVGCYUFiAUFiASFB4SFB4SFB4RFB4QEx0REx0REx0QEx0PEhoQEhoQEhsOERsPERoOEBoOEBoPERsSFB4TFR8R"
    "FSKYnbeYnbMUFyUUFiAUFiASFB4SFB4SFB4REx0SFB4UEx4VEx4SERwSEhsSEhsQERwPEBwSDxkQERsPERsPERsTFR8SFB4MER2Y"
    "nbeZnrQVGCYVFyEUFiATFR8TFR8TFR4TFR4TFR0TEx4VFSAVFiEUFx8TExwUEx4SEx4QEhwQEhwPERsPERsTFR8SFB4OEh6Wnbea"
    "n7UWGScVFyEUFiAUFiAUFiAUFh8UFhwRExkUFB0sMjo3ND4PFx4OERkSEhwSEh0REh0QEhwQEhwQEhwTFR8TFR8SEyCVnrean7UW"
    "GScWGCIWGCIUFiAUFiAUFx8RFRoODxVGSU16eX1nVV8gGSMQDxgTFR4VFiEUFSAQEhwQEhwREx0VFyETFR8SEyCVnrian7gXGSoX"
    "GCUWFyMVFyEWGCIRFxwJEBASERMxKS0zLzEzLS8/ODwrGyRTSk87ODsiKCoUGCAQEx0QExwTFh8VFyESEyGVnrian7kZGywYGSYW"
    "FyQVFyEWGCIbHCJCOj0yGB9BKTA7LzVFODxHPEFBOT9ORkxxeXsuLzEpLzYPExwREyATFCEXGSMSEyGWn7ian7kdHzEbHCoYGSYX"
    "GSMVFyFBQkhcWFo3Ky9KQ0dPVVdUVlg/NDtDOD4lJypoW2E3ODo9REsTFyASFCEVFiMYGiUSFCGWn7man7keIjofIDEeHy0dHysY"
    "GiRXVl1CPEJCPEFFR01PU1kqLTMVFh08ODo6LCwyISUPExgsMzoYGycSFCETFCEXGiUUFSGWn7ian7kZHTQcHiwdHyodHyoWFyMk"
    "Hyc4JStZU1gvMzdITVErLzJKS1IxLDBJMzdCGCETDxUYHiUaHSwSEyAUFSIaGiYUFCGWn7ian7kaHTIbHCoaGycaGycUFiEYERpA"
    "JCtdVFYtMDFNUVIcHx8ZGh0xLDFHNjpBGiQUEBEQFh0ZHCsTFCEWFyUaGicVFSOWn7iboLobHi0aHCcaHCYXGSMUFiAjHCQ7JStM"
    "QUFDQ0ZUVVkkJScQEBE6MjQvKS9EO0BLRUUOFBsYGykUFSMXGCYZGikWFyaVn7iboLocHjAbHCgZGyYZGiUXGSNUTlZFQEM5MDI/"
    "PUBWWF1cXmIrLC1CNjskIydtdHVKSksRGCAVGSQVFiYVFiMaGywXGCiVnriboLobHi8bHCkbHCkaGycZGyUzNjxrams7NDdMREhB"
    "OD0/Nzs/MDFEKC9DLTRzaXAnJikXHiYZHCwYGScZGigaGysZGimWn7iboLodHy8dHiobHCgbHCgbHCkoKTJeVVkpHyJTS04yLS8g"
    "GxwvGx1OMzgjGR0uKjA8OjwcIioaHSsaGyobHCsdHi4cHSyVn7iboLocHzAeHywaGykbHCobHCqTkpqDhogrJimmpahYWFp7eXtR"
    "TEyysK8pKy4wMzja2tsmLDQXGykZGiobHCsdHiwdHiyXoLmboLodHzEeHy4aHCsaHSweHy6YmaF5en41Njx/gIVUVVtMTVI1NjqN"
    "j5UoKi2Xl5y6uL04PkUVGCcWFyUYGSYaGygeHyyYobyan7kcIDIcIC0bHisaHy0aHCpfYGxwcXgjIyuGh4xVVltZWl88PUOKjJFJ"
    "Sk4eHiZvbnYjKTAWGSMZGigYGScaGicaGieWnrmboLoeITMeIC4dHy4cHi0dHy8dHiwhIi8hIi8cHSgcHCYaGiQZHCUYHCYZGyQa"
    "GykYGSYUGiIWGiMYGigYGScbGygbGyqXn7ucobsfIjMfIC0dHiwbHy8cIC8dIC4gJDQhIzIfHy4dHSscHCkaHigaHigbHicbHCob"
    "HCkWHCQYHCYaGyoZGigaGiccHSyXn7yRlrBDRlgiIzIfIC8eIjIdITEeIjAiJjYjJjQfHy0eHisfHy0aHikaHigbHigcHSscHSoY"
    "HiYaHikbHCocHSsbHClAQVGNlbFRVnKPlbKaoL2bob6bob6bob6bob+cosKbocGbob2bobybobybobybobyan7uZn7uaoLuaoLma"
    "obmaoLuaoL6aoL6OlK5ITWUNc29sYXJfZWNsaXBzZchoSqVmV71oUsBnTsBnTsFpUMFoUL9oTb1oTb1oTL1oTL1oTL1oTL1oTL1o"
    "TL1oTL1oTL1oTMBnTMBnTMBnTMBnTb9mS7ZmT5xqU7xmV29IPlI6M1A4MVY+OFdAOVQ9NU85ME45MU46MU85ME84L084L084L1E5"
    "ME84L085MFE4MFA4MFA4MFA4MFE5MXlJNcNmS7dmVVk2LUw3MUs2MFA8NlE9N088Nko4MUo3MUo3MUw2MEw1L1A1L1A3MEw2MEs2"
    "MUk3MUk3MEs2MEs2MEs2MEw3MVE5MshnSbpnUlk3LEw3MUs2ME45M1E9N087NUo4MUs1L0o0Lko0Lks0L0k0MkY0Mkk2MEo1L0o2"
    "MEo2MEo1L0o1L0s2MEw3MVE5M8xmSbdnUFc3LEw3MUs2ME04MlE9N1E8N0w3Mkw0MU0yMVkmK1k0NkkzMkc1M0g2MUg0MEk0L0k0"
    "Lkk0Lko1L0s2MEw3MVI6M81mSbpmUlo3LUw3MUs2ME05M1E9N1I9OEw3NFcvMmYhKnMaKVoxNEkzMEUyL0k2MEk0Lks0Lks0Lkk0"
    "Lko1L0s2MEw3MVM6M8xmSbppUlo4LU04Mkw3MU86NFE8NlI9OFI2NG0nMH0ZKnIhLk8gJEolJDUVE1E2MFM1L0wtJ0sxK0w3MUw3"
    "MUw3MU45M1Q6Nc1mS7poUmQ+M1c+N1Y9NlQ7NFQ7NFY7NVY8NnomLocaLXEYKVQRHVcRGlQUGlQsLmcxOGIbJVc3NFM7NVI8N1Q+"
    "OFQ+OFtAPMpnTb5qTmU/Mlg/OFY9NlQ7NFQ7NFg7NFo4M30hKZIaLWQTISkCBjwGClAQFmUeKW4oNWgYJmU4OFM9N1U9OFQ+OFU/"
    "OVtAPMpnS75rUWI+MVQ9NlM8NFQ7NFQ7NFQ4MkQTElcOElUJD0wFCkgCBzYDBUYLEXMZKnUYK30YLWEvMFI8NlU7NlI8NlQ+OFg/"
    "OsxnS7xoU106L046Mkw3L043L1A2L002L1UZHToHCGYDCYUCDYICC2IECW8THIwZKo4dMIMeLlgxME03MU82MU03MU85M1I8Nsxm"
    "S7tnUls5Lk05MUo3Lks3Lk43L1cwLnggLFUNFIgDDXMDBXQBA5MDD2IIDo0XJ4cfLmEqLkw2MEw2ME02MEw2ME44MlA6NMpkSbdo"
    "VVs5Lk45MUw4MEs4ME43L28gJpEdLYYaJ2gEC40BD5ABDJYDEzECA1gQFnUjKlA2MUs4Mk03MU03MU03MVA6NFE8Ms1mS7dpVVw5"
    "Lk45MU04ME04ME81LnQXIHMOGV0OFDoEBHYCDXgDDl0DDCoEBFcSGlMVGlM1MUw5Mk03MU03MU03MVA6NFE9MstlSrdpVVw5Lk45"
    "MU04MEw4ME83L2IaHmwaIVQPFD8CBTICAkcMEX4bK2USH2QVIUYXGk4sKkw4Mk03MU03MU44MlA6NFI9M8pkSbdpVF06Lk86Mk45"
    "MU82L1E3MFYhIl4pLFQgImYRG0MHC10MF5UdMY4cL3ElL1czNEw3M0s4MU44Mk44Mk85M1A6NFQ9M8hlSbZoU106Lk86Mk45MVA4"
    "MU43L2ZWUHRlYkIrKoBubUolJ1okK3IdKoBUWGJUUlFJRX53cllHQE84Mk85M085M1A6NFM8MspnS7ZoUV86LVI6NlA5NE84NEk2"
    "MqKalYZ9fE9FRZSSkV1LTnVkZ1w/Qr2vr4qEgjkyMaObmE88NVA5MlA5MlA6M1E7NFU9NspoSLZpUGE7L1U7OFI6N1A6N0k4NqKZ"
    "lomCfkpAP4+Ih1pJS2ZPU3JjYpyYlJ+Xkko8OKGVkUw3L1I4MVA6MlA6MlE7M1U8OMpmRrZpUGE7LlQ5NVE5NU86NUs7N1RJRGBX"
    "U0A0MnhubGZWVlRBQkg9OUE9N1ZNR0c7NVtQSk45MVM3MVA6MlA6MlE7M1c9OcplRrZqUWE7LlI8OFI4NVM6NFI6M086MVE6M1A5"
    "NE45M046NFA7NE44MlE5M1A4Mk85M1A7NFE7M1E6MlA6MlE7M1I8NFc+NMtkTLZrU2Q/MVM+OFQ7NVQ9NVM8NVA8M045MVA7NU49"
    "Nk49NlA9NVE+NVI8NFI8NE87M088M1I8NFI8NFI8NFI8NFQ+NlxANchmTbRuWpZZSntMO31KOntKOnxLO3tLOnpJOHxLO3pLO3lK"
    "O3pKOXtKOX1LOn1LOnpKOXpLO3pKOnpKOnpKO3pKOn1NPZRYR8FqTqJ2ZLJuWrVsV7VsV7VtU7VtU7VtUbVtT7VtT7VtT7VtT7Vt"
    "T7VtT7VtT7VtT7VtT7VtT7VtT7VtT7VtT7VtT7VtT7RvVqN1Xg=="
)


def weather_region(buttons, bounds=None):
    """Полоса вверху окна игры, где стоит ряд иконок, вычисленная по трём кнопкам TAP TO TRADE.
    bounds = (left, top, right, bottom) экрана: полоса за него не выходит. Возвращает (x0, y0, x1, y1, sp)."""
    xs = [b[0] for b in buttons]
    ys = [b[1] for b in buttons]
    sp = (max(xs) - min(xs)) / 2
    h = sp / _W_SCREEN_H                      # высота окна игры
    cx = sum(xs) / len(xs)
    top = sum(ys) / len(ys) - _W_BUTTON_Y * h  # верх окна игры
    x0, x1 = int(cx - _W_HALF * h), int(cx + _W_HALF * h)
    y0, y1 = int(top + _W_TOP * h), int(top + _W_BOTTOM * h)
    if bounds:
        if y0 < bounds[1]:                    # оценка «уехала» выше экрана — берём полосу от самого верха экрана
            y0, y1 = bounds[1], bounds[1] + (y1 - y0)
        x0, x1 = max(x0, bounds[0]), min(x1, bounds[2])
        y1 = min(y1, bounds[3])
    return x0, y0, x1, y1, sp


def _half(a):
    """Уменьшение вдвое: среднее по квадратам 2x2."""
    h, w = a.shape[0] // 2 * 2, a.shape[1] // 2 * 2
    a = a[:h, :w]
    return (a[0::2, 0::2] + a[0::2, 1::2] + a[1::2, 0::2] + a[1::2, 1::2]) * 0.25


def _features(rgb):
    """RGB -> (красный-зелёный, жёлтый-синий, яркость*_W_LUM): серые участки дают ноль в первых двух каналах."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    return np.stack((r - g, (r + g) * 0.5 - b, (r + g + b) * (_W_LUM / 3.0)), axis=-1).astype(np.float32)


def _weather_level(w, feats):
    """Заготовки для сравнения на одном размере: веса, сумма весов, для каждого образца — (вес*признаки, норма).
    У яркости вычитается среднее (важен рисунок, а не общий уровень), у цветовых каналов — нет."""
    ws = float(w.sum())
    out = []
    for t in feats:
        d = t.copy()
        d[:, :, 2] -= float((t[:, :, 2] * w).sum()) / ws
        out.append((np.ascontiguousarray(d * w[:, :, None]), float(np.sqrt((d * d * w[:, :, None]).sum()))))
    return np.ascontiguousarray(w), ws, out


def _zone_feat(f, idx):
    """Признаки точек одной зоны монеты; у яркости вычтено среднее по зоне. Возвращает (признаки, норма)."""
    z = f[idx[0], idx[1]].copy()
    z[:, 2] -= float(z[:, 2].mean())
    return z, float(np.sqrt((z * z).sum()))


def _weather_refs():
    global _WEATHER
    if _WEATHER is None:
        import base64
        data = base64.b64decode(_WEATHER_B64)
        n, count = data[4], data[5]
        pos = 6
        w = np.frombuffer(data, np.uint8, n * n, pos).reshape(n, n).astype(np.float32) / 255
        pos += n * n
        zmap = np.frombuffer(data, np.uint8, n * n, pos).reshape(n, n)
        pos += n * n
        ids, tpls, frames = [], [], []
        for _ in range(count):
            ln = data[pos]
            ids.append(data[pos + 1:pos + 1 + ln].decode("ascii"))
            pos += 1 + ln
            frames.append(np.frombuffer(data, np.uint8, 3, pos).astype(np.int32))   # цвет рамки, RGB
            pos += 3
            tpls.append(np.frombuffer(data, np.uint8, n * n * 3, pos).reshape(n, n, 3).astype(np.float32))
            pos += n * n * 3
        zones = [np.nonzero(zmap == 1), np.nonzero(zmap == 2)]      # центр монеты, обод монеты
        feats = [_features(t) for t in tpls]
        _WEATHER = {"n": n, "ids": ids, "zones": zones, "frame": frames,
                    "fine": _weather_level(w, feats),
                    "coarse": _weather_level(_half(w), [_features(_half(t)) for t in tpls]),
                    "zone_tpl": [[_zone_feat(f, idx) for idx in zones] for f in feats]}
    return _WEATHER


def _weather_match(win, level, k):
    """Совпадение окна признаков (n, n, 3) с образцом k целиком: взвешенная корреляция, от -1 до 1."""
    w, ws, tp = level
    s1 = float((win[:, :, 2] * w).sum())
    var = float((win * win * w[:, :, None]).sum()) - s1 * s1 / ws
    if var < _W_MIN_STD * _W_MIN_STD * ws:
        return 0.0
    return float((win * tp[k][0]).sum()) / (tp[k][1] * var ** 0.5)


def _weather_maps(img, level):
    """То же для всех мест изображения сразу (грубый поиск): по карте на каждый образец."""
    w, ws, tp = level
    n = w.shape[0]
    hh, ww = img.shape[0] - n + 1, img.shape[1] - n + 1
    a = n // 2

    def corr(src, kernel):                    # сумма src*kernel по окну n x n, левый верхний угол окна в (y, x)
        return cv2.filter2D(src, cv2.CV_32F, kernel, borderType=cv2.BORDER_CONSTANT)[a:a + hh, a:a + ww]
    ch = [np.ascontiguousarray(img[:, :, c]) for c in range(3)]
    s1 = corr(ch[2], w)
    var = sum(corr(c * c, w) for c in ch) - s1 * s1 / ws
    ok = var >= _W_MIN_STD * _W_MIN_STD * ws
    sd = np.sqrt(np.where(ok, var, 1.0))
    maps = []
    for wt, den in tp:
        num = sum(corr(ch[c], np.ascontiguousarray(wt[:, :, c])) for c in range(3))
        maps.append(np.where(ok, num / (den * sd), 0.0))
    return maps


def _zone_scores(win, refs, k):
    """Совпадение центра и обода монеты с образцом k — по отдельности (от -1 до 1). У разных погод монеты
    отличаются именно цветом центра и обода, а «квадрат с рамкой и пятном» похож у всех. Сравнивается не только
    оттенок, но и сила цвета: бледное пятно того же оттенка (пустой квадрат, стена) — это не монета, оценка 0."""
    out = []
    for idx, (tz, tn) in zip(refs["zones"], refs["zone_tpl"][k]):
        z, zn = _zone_feat(win, idx)
        if tn <= 1e-3 or zn < _W_ZONE_MIN * tn or zn > _W_ZONE_MAX * tn:
            out.append(0.0)
        else:
            out.append(float((z * tz).sum()) / (zn * tn))
    return out


def _median(line):
    """Медианный цвет линии точек (по каждому каналу отдельно)."""
    return np.sort(line, axis=0)[len(line) // 2]


def _frame_line(rgb, col, across, pos, a0, a1, reach, inward):
    """Одна сторона рамки: строка (across=True) или столбец рядом с pos, где не меньше 80 % точек — цвета рамки col.
    a0..a1 — участок стороны без углов. Идём изнутри иконки наружу (inward = +1, если внутрь — это вправо/вниз) и
    берём первую такую линию: снаружи фон игры может случайно совпасть с рамкой по цвету, а фон иконки — нет.
    Возвращает координату линии или -1."""
    lim = rgb.shape[0] if across else rgb.shape[1]
    for i in range(2 * reach + 1):
        p = pos + inward * (reach - i)
        if 0 <= p < lim:
            d = np.abs((rgb[p, a0:a1] if across else rgb[a0:a1, p]) - col)
            if int((d.max(axis=1) <= WEATHER_FRAME_TOL).sum()) * 5 >= (a1 - a0) * 4:
                return p
    return -1


def _slot_check(rgb, bx, by, size, col):
    """Настоящая ли это иконка погоды в ряду. rgb — снимок полосы (целые числа), (bx, by) — левый верхний угол
    найденного места, size — его размер, col — цвет рамки этой погоды. Возвращает (рамка_ок, таймер_ок):
    рамка — линии цвета col со всех четырёх сторон, образующие квадрат нужного размера, а сразу за ними фон
    иконки другого цвета; таймер — белые цифры по центру нижней части."""
    hh, ww = rgb.shape[:2]
    e = 0.02 * size                                   # середина рамки отстоит от края иконки на полторы точки
    reach = max(3, int(0.08 * size + 0.5))
    xa, xb = max(0, int(bx + 0.22 * size)), min(ww, int(bx + 0.78 * size))
    ya, yb = max(0, int(by + 0.22 * size)), min(hh, int(by + 0.78 * size))
    if xb - xa < 8 or yb - ya < 8:
        return False, False
    y0 = _frame_line(rgb, col, True, int(by + e + 0.5), xa, xb, reach, 1)                    # верх
    y1 = _frame_line(rgb, col, True, int(by + size - 1 - e + 0.5), xa, xb, reach, -1)        # низ
    x0 = _frame_line(rgb, col, False, int(bx + e + 0.5), ya, yb, reach, 1)                   # лево
    x1 = _frame_line(rgb, col, False, int(bx + size - 1 - e + 0.5), ya, yb, reach, -1)       # право
    if min(y0, y1, x0, x1) < 0:
        return False, False
    w, h = x1 - x0, y1 - y0                           # между внутренними краями рамки: около 0.93 размера иконки
    if abs(w - h) > max(2, int(0.05 * size + 0.5)) or min(w, h) < 0.80 * size or max(w, h) > 1.10 * size:
        return False, False
    dn = max(3, int(0.05 * size + 0.5))               # вплотную к рамке (за её сглаженным краем)
    d = dn + 2                                        # и чуть глубже, но ещё не доходя до монеты
    for near, deep in ((rgb[y0 + dn, xa:xb], rgb[y0 + d, xa:xb]), (rgb[y1 - dn, xa:xb], rgb[y1 - d, xa:xb]),
                       (rgb[ya:yb, x0 + dn], rgb[ya:yb, x0 + d]), (rgb[ya:yb, x1 - dn], rgb[ya:yb, x1 - d])):
        mn, md = _median(near), _median(deep)         # вплотную к рамке и чуть глубже — один и тот же фон иконки,
        if int(np.abs(md - col).max()) < _W_INNER_DIFF or abs(int(mn.sum()) - int(md.sum())) > 3 * _W_INNER_FLAT:
            return False, False                       # не цвета рамки (между ними нет другой рамки или рисунка)
    side = (w + h) / 2.0                              # таймер: белые цифры внизу иконки, по центру
    ty0, ty1 = int(y0 + 0.66 * side), min(hh, int(y0 + 0.86 * side) + 1)
    tx0, tx1 = int(x0 + 0.18 * side), min(ww, int(x1 - 0.18 * side) + 1)
    if ty1 <= ty0 or tx1 <= tx0:
        return True, False
    white = rgb[ty0:ty1, tx0:tx1].min(axis=2) >= _W_WHITE
    cnt, area = int(white.sum()), white.size
    if cnt < _W_TIMER_MIN * area or cnt > _W_TIMER_MAX * area:
        return True, False
    xs = (np.nonzero(white)[1] + tx0).astype(np.int64)
    mean = float(xs.sum()) / cnt
    dev = max(0.0, float((xs * xs).sum()) / cnt - mean * mean) ** 0.5
    return True, (abs(mean - (x0 + x1) / 2.0) <= 0.12 * side
                  and _W_TIMER_DEV[0] * side <= dev <= _W_TIMER_DEV[1] * side)


def weather_scores(img_bgr, buttons, offset=(0, 0)):
    """Лучшее совпадение для каждой погоды в полосе: {id: (оценка, иконка_ок, (x, y), размер, части, (рамка, таймер))}.
    x, y — центр иконки в координатах экрана; части = (вся иконка, центр монеты, обод). Оценка — худшая из частей,
    это только «насколько похоже на монету этой погоды». иконка_ок — у найденного места есть цветная рамка этой
    погоды и таймер (_slot_check); без этого погода не засчитывается, какой бы высокой ни была оценка.
    img_bgr — снимок полосы weather_region, offset — его левый верхний угол на экране."""
    refs = _weather_refs()
    n = refs["n"]
    sp = (max(b[0] for b in buttons) - min(b[0] for b in buttons)) / 2
    rgb = np.ascontiguousarray(img_bgr[:, :, ::-1]).astype(np.float32)
    rgb_i = np.ascontiguousarray(img_bgr[:, :, ::-1]).astype(np.int32)
    best = {wid: (0.0, False, None, 0.0, (0.0, 0.0, 0.0), (False, False)) for wid in refs["ids"]}
    for k_scale in _W_SCALES:
        size = k_scale * sp                                   # размер иконки с рамкой на экране
        fw, fh = int(round(rgb.shape[1] * n / size)), int(round(rgb.shape[0] * n / size))
        if size < n or fw < n or fh < n:
            continue                                          # окно игры слишком маленькое
        fine_rgb = cv2.resize(rgb, (fw, fh), interpolation=cv2.INTER_AREA)   # иконка становится n x n
        fine = _features(fine_rgb)
        maps = _weather_maps(_features(_half(fine_rgb)), refs["coarse"])     # грубо: иконка n/2 x n/2
        for k, wid in enumerate(refs["ids"]):
            m = maps[k].copy()
            for _ in range(2):                                # два лучших места на грубой карте
                cy, cx = np.unravel_index(int(np.argmax(m)), m.shape)
                if m[cy, cx] <= 0.3:
                    break
                m[max(0, cy - 3):cy + 4, max(0, cx - 3):cx + 4] = -1
                top = (0.0, 0, 0)
                for fy in range(max(0, 2 * cy - 2), min(fh - n, 2 * cy + 2) + 1):      # уточняем на полном размере
                    for fx in range(max(0, 2 * cx - 2), min(fw - n, 2 * cx + 2) + 1):
                        s = _weather_match(fine[fy:fy + n, fx:fx + n], refs["fine"], k)
                        if s > top[0]:
                            top = (s, fx, fy)
                whole, fx, fy = top
                if whole <= 0:
                    continue
                centre, rim = _zone_scores(fine[fy:fy + n, fx:fx + n], refs, k)
                s = max(0.0, min(whole, centre, rim))
                parts = (False, False)
                if s >= _W_CHECK_FROM:
                    parts = _slot_check(rgb_i, fx * size / n, fy * size / n, size, refs["frame"][k])
                slot = parts[0] and parts[1]
                if (slot, s) > (best[wid][1], best[wid][0]):
                    pos = (int(offset[0] + (fx + n / 2) * size / n), int(offset[1] + (fy + n / 2) * size / n))
                    best[wid] = (s, slot, pos, size, (whole, centre, rim), parts)
    return best


def find_weather(img_bgr, buttons, offset=(0, 0)):
    """Какие погоды сейчас видны в ряду иконок: [(id, оценка, (x, y), размер), ...], самая уверенная — первой.
    Засчитывается только иконка с цветной рамкой и таймером."""
    found = [(wid, v[0], v[2], v[3]) for wid, v in weather_scores(img_bgr, buttons, offset).items()
             if v[0] >= WEATHER_MIN_SCORE and v[1]]
    return sorted(found, key=lambda f: -f[1])


def monitor_rect(buttons=None):
    """Границы монитора, где стоит торговец (иначе основного): (left, top, right, bottom)."""
    mons = pio.monitors()
    mon = mons[1] if len(mons) > 1 else mons[0]
    if buttons:
        cx = sum(b[0] for b in buttons) / len(buttons)
        cy = sum(b[1] for b in buttons) / len(buttons)
        for m in mons[1:]:
            if m["left"] <= cx < m["left"] + m["width"] and m["top"] <= cy < m["top"] + m["height"]:
                mon = m
                break
    return mon["left"], mon["top"], mon["left"] + mon["width"], mon["top"] + mon["height"]


def grab_weather(buttons, bounds=None):
    """Снимок полосы с рядом иконок: (картинка, (x0, y0)); (None, None) — полоса не помещается на экран."""
    region = weather_region(buttons, bounds or monitor_rect(buttons))
    if region[2] - region[0] < 60 or region[3] - region[1] < 20:
        return None, None
    return grab(region)


def grab_screen(buttons=None):
    """Скрин всего экрана (того монитора, где стоит торговец; иначе основного)."""
    mons = pio.monitors()
    mon = mons[1] if len(mons) > 1 else mons[0]
    if buttons:
        cx = sum(b[0] for b in buttons) / len(buttons)
        cy = sum(b[1] for b in buttons) / len(buttons)
        for m in mons[1:]:
            if m["left"] <= cx < m["left"] + m["width"] and m["top"] <= cy < m["top"] + m["height"]:
                mon = m
                break
    return pio.grab_rect(mon["left"], mon["top"], mon["width"], mon["height"])


def send_discord(webhook_url, img_bgr, text=""):
    """Отправляет картинку (и текст) в Discord через вебхук. Возвращает (ok, сообщение)."""
    import urllib.request
    import urllib.error
    import uuid
    ok, png = cv2.imencode(".png", img_bgr)
    fname, ctype = "screen.png", "image/png"
    if ok and len(png) > 8 * 1024 * 1024:  # лимит Discord — сжимаем в JPG
        ok, png = cv2.imencode(".jpg", img_bgr, [cv2.IMWRITE_JPEG_QUALITY, 90])
        fname, ctype = "screen.jpg", "image/jpeg"
    if not ok:
        return False, "не удалось сжать картинку"
    boundary = uuid.uuid4().hex
    payload = json.dumps({"content": text[:1900]}, ensure_ascii=False).encode("utf-8")
    body = b"".join([
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"payload_json\"\r\n"
        f"Content-Type: application/json\r\n\r\n".encode(), payload, b"\r\n",
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"files[0]\"; filename=\"{fname}\"\r\n"
        f"Content-Type: {ctype}\r\n\r\n".encode(), png.tobytes(), b"\r\n",
        f"--{boundary}--\r\n".encode(),
    ])
    req = urllib.request.Request(webhook_url.strip(), data=body, method="POST", headers={
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "User-Agent": "DiscordBot (potion-macro, 1.0)",
    })
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return True, f"HTTP {r.status}"
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}: {e.read()[:200].decode('utf-8', 'replace')}"
    except Exception as e:
        return False, str(e)


def grab(region):
    x0, y0, x1, y1, _ = region
    x0, y0, x1, y1 = int(x0), int(y0), int(x1), int(y1)
    return pio.grab_rect(x0, y0, x1 - x0, y1 - y0), (x0, y0)


def save_image(path, img):
    """Пишет картинку в файл: True/False. cv2.imwrite не умеет пути с неанглийскими буквами (папка пользователя
    вида C:/Users/Пользователь/...) и молча ничего не сохраняет, поэтому сжимаем сами и пишем файл обычным способом."""
    try:
        ok, buf = cv2.imencode(os.path.splitext(path)[1] or ".png", img)
        if not ok:
            return False
        with open(path, "wb") as f:
            f.write(buf.tobytes())
        return True
    except Exception:
        return False


def save_debug(buttons, path="debug.png"):
    region = scan_region(buttons)
    img, off = grab(region)
    res = find_potion(img, buttons, off)
    for b in buttons:
        cv2.circle(img, (b[0] - off[0], b[1] - off[1]), 8, (0, 0, 255), 2)
    if res:
        cv2.circle(img, (res[1][0] - off[0], res[1][1] - off[1]), 20, (0, 255, 0), 3)
    save_image(os.path.join(HERE, path), img)
    log(f"debug.png сохранён. Найдено: {res}")


# ---------- индейка ----------
# Когда в игре сбегает индейка, вверху экрана на несколько секунд появляется затемнённая полоса с объявлением:
# «[ANNOUNCEMENT] A Turkey has escaped! Chase it down and catch it!» — белый наклонный текст с тёмной обводкой.
# Ищем именно эту строку текста (другие объявления тем же шрифтом не считаются). Образец снят со скрина
# пользователя (экран 1080p), см. dev\turkey в папке Mac-версии.
# Строка стоит по центру окна игры: ширина ≈ 0.84 высоты окна, центр — на 0.18 высоты. На другом экране размер
# текста может отличаться, поэтому сначала строка ищется на уменьшенной картинке в 22 размерах (0.6–1.37 от
# ожидаемого), потом найденное место сверяется с образцом точнее: вся строка и отдельно обе её половины
# («A Turkey has escaped!» и «Chase it down and catch it!»). Оценка — худшее из трёх сравнений.
# Смотрим только на «белизну» точек (белые буквы = 1, остальное = 0): полоса затемняет игру под текстом, так что
# даже на белом фоне белыми остаются одни буквы. Одна проверка ~10 мс — её можно делать 10 раз в секунду.
TURKEY_MIN_SCORE = 0.66       # настоящая надпись даёт 0.80–0.98, другой текст тем же шрифтом — не выше 0.52
_T_WIDTH = 0.841              # ширина строки в долях высоты окна игры (908 точек при 1080)
_T_TEXT_W = 908.0             # ширина строки в образце (сам образец на 4 точки шире с каждой стороны)
_T_TOP, _T_BOTTOM = 0.06, 0.34    # полоса, где ищем: от и до, в долях высоты окна игры (строка — на 0.17–0.20)
_T_HALF = 0.62                # полуширина полосы в долях высоты окна игры
_T_WHITE_LO, _T_WHITE_HI = 200, 240   # «белизна»: самый тёмный канал точки от LO (0) до HI (1)
_T_COARSE_W = 200.0           # ширина строки на уменьшенной картинке (при ожидаемом размере текста)
_T_COARSE_MIN = 0.30          # грубая оценка, с которой место сверяется точнее (у настоящей надписи от 0.45)
_T_SCALES = tuple(0.60 * 1.04 ** i for i in range(22))     # размеры текста относительно ожидаемого
_T_FINE_W = 454.0             # ширина строки при точной сверке
_T_FINE_REL = (0.95, 0.96, 0.97, 0.98, 0.99, 1.0, 1.01, 1.02, 1.03, 1.04, 1.05)   # уточнение размера
_T_SPLIT = 0.45               # где кончается первая фраза (доля ширины образца)
_TURKEY = None
_TURKEY_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAA5QAAAAsCAAAAAA/LKgRAAALBElEQVR42u1dL5giOwyfe9/71qFwqFPrVq3CoVbhVuFQqHMoHM+g"
    "cCgUDoXCrcKheAaHwvEMCofqOwZmmqZJmpnl9uZ2G7E30+mfNO2vTZOUS5JIkSJFihQpUqRIkSJFihSp6mQuVKF6PolwfrU4jgWr"
    "r/bw/GrugvXPNe3/HVeLyk2cy59vVWLGfIujch861QRx5gP/F4N2Es+GIC070zt1a/ilB3V1Ffo+iqOS9COUofauLVgLymGhWlt3"
    "UhCeP7P6yq91xFqYvtR/MWOQsy+tvoZKp9U/lhWnwBy/BZ7esVHGI6VEL5dOHUAPqVVn4wj+6YPEgVeAQPZepcfn9SNAWVqcQmEe"
    "biaC8gMW8I1STfl4cZwVbX3qjXL3flACGqPMJ3mjbIh1m1Jdi6B8n/Z6g2IbLakfKQ7z1UFp7gpKnNm+Y+trqjcdwjUWtcf17iTW"
    "xVe18ECxfzOZ/KdJpOrQsHCJ/wpozeJ5tfxG2Y0bpW6nbGrVk48UxxQcZb/kTtm460bZpo6UTSpnx4JyrmqaUbyyp7xlL59bQ27Z"
    "QP26vPXJxtOHncNYM/vY/fnP0VHdAyfoGja64PzXtLNN6GeZLhI7uZ0eUA1StY6ytKCJUzzm5w8b51s3+1iHZRdEVXVfCrj+H7Ih"
    "oUP1JOd7mb2mkhmDbw+4086DGdCDlrf26M84ShJPkLszNwtOKyyRnw8PWYme2b75Ari+rsnRmAji7OVG09MpaNu+fPguQ/6pACiN"
    "KypwoDXYfHGgQOnzYeyqQerkqYMAfBjlOU+S8eQtV7PzpCNlY8Epz4kPJ4K1upEYTkdeNnGKTipZHG1aHGuie/sA6FlQ2g/ElAVJ"
    "LbDan4GPzGBQioZEsjWhIMOdYni/I6yjfIzVLSAnqTaqu316vfMr3uLNiQSloUC58vB5paZVEVqwrZbf+pCYH3YZM8BKOJDmEvz2"
    "6tWS5+97aTP7fkT9n5yI9s6UY3dO27EbPKfcYCyIJlc2DVj11kSDZ8nrrALliO7Jzk+rAVCmyR37PLMTpy1tyiu6tfSxQxRcBPwF"
    "I+/j2L7vBFBC5WFt88zMnUF5SZ9qQOm8PCGN7rab3lpuOIrabUJTVn6bdmb3Bzz+uco1EjwGjIyU+dcSJmHG7zj5QWiIY7jYRjnG"
    "lTRuH2ZqcYgz9js5i9DBZqJoCybOwZQe29OqPWhB8uIi5nRrLc5XNww48bYSJvGucqMeLnhEWhYDyhYpzondoCi8LakTYLEj5SNS"
    "GOC3ei4jvP6Paccbd7ZLU3vOqcPg/nqpJ3b3GZL5jbNPXvNJbWUv40yQfjc75ME6DMpZKMQq53McFsfZ6d4h/zri1i0YprARXWSw"
    "rb3JVviBnciJPWFesy4I7fU2ybt5BYrWoCTmoD1ezomjSl2XBrFEkwT7dZ1weNjmzDcp3ptguVs+YBOrgLdVaVA67PmFBrjA3j5u"
    "yFp4PQ4qXF76PmQOewZaeN56oEWmrR2TbqzKdiC7CTMfhLEJxD2C55HICtM9MAZr2Sqs4uFAzwbUBjzok1lpgz0nNy99IEqiyPBu"
    "EtbcYWTemkkBcTLiteejwV1A6Reqc2w9UBOHW7rh8wM4CjJ8hLvR5DUEX/Z7rg/wuUsjoZY979jxYUGpcaVcjHTZQKrEAVMemSkr"
    "M7Gh8/hqjAvK7HiTn2rF8UWWgwB34HkS6EGB4SVeikorBMqzOMTtwGTeK+w8hrMSUtPPrgJzaV1PNO3hdDJc+9FTRfL8NRkPmkUJ"
    "vDzB1AmJfvySlAclMZ0lcTzDimelQOkcZZlNOQBKBc4KCZ/rcQBHYn/El3uBUjHC2o2yBQbYWFffxlt+WqTZmbIFcDxMoeXXlmnK"
    "Y6W78ELm98s/cm316A9kQ437gHKJ9V4js8h0j7VNvICkIzyyBsUBdWkMyk3Wy1vqCzLXrPhesz3r0vO9FQCSKbDmpoadH8K8mtCj"
    "QfjRs9paSlAOrMWxUUJ7rQkbJeMLwsZKOK5HXeOGZWoY8qwhM98IRQmExhEvyj3HfsA25DpOsf+lqJeSFAfZhVFoDGp+/fXwRrml"
    "QZnQrO0QKJFrRNqM3IiRsKrEy1lMOesVIQ0yVBtlX3cHZPO+I2VhUCY+KKXG+4yu1HMGoqbwUVJs6caxh+wkhrURug0ZT3UHQSGb"
    "UqDsMeJ4daICWpz325Q6JKHkaY4ZCZTLqxnaASW7gAit9YHc4IcFI4mh787RDO+uDOb6hUFJxm6EVJm7gdLoQLlVKeXtsLxo5xrf"
    "WceP/u4jpQKUukt4mgPHLVhRI47xrwClhAabPshUNWtn2MrjW+JIWdPvvMrtrvhGOEgKizOISbLMFu5DTwVB+YrzNxhGnhROdIWd"
    "J2Apk0VxR1DqVzaBodfk/uIg7JtM/fV3gNLY09gNaBiU2mlbys7z20AZGq79vUDps3YDVse4DpWdZza/OIJBgLkTqQyonY7gK8X0"
    "oKTst7TwJ5wsdibgIyFe+oxBBZou3gVKo7XzBGufO93jL8NNFXZsNSjtYxqb/IMCZRvaEYqAcshst3cEZfr8ItS1DBipIEKcqIzA"
    "uPeLGeFV6pOdVD2lDzGdKIU2mKC9VXPEJ7/KBU+cnSfUTZZhmqulKS2OsygOpRSUGvSWBiUOsMgNjQb6RQpvRmetSwx64QuBcsML"
    "IFQXxfxZMptpoisLgHJIRzN4hbooKsFw98dS8xd5bwdW7C3jE2DvWGXpsvD7Xv3krD15Bedgc5TjeZy464RQ6AYGB2l3Q1vlSrbz"
    "QH/EwDiBS2T32mpQDkWT/RTctwFL1NxbdLoaUE5YUHZAzwg7zxjYT8EoDw2hszDxPD3gEHI27kcn24GV1lql3o7QtxFVYFUKlCY/"
    "XIZCB0gLiDtdoCKtmCUwLDM92/MeT6SsUq3nITE26tJGMyYwTpOJWQXXF4l0jAq2Er/jB2SdYcTREmt3xTEVx0Dt8BVDURkXEuTj"
    "yO0/5A1PUW6EnhkIfE2Am+G2crElqLd0PG7XW7gwcJ04VfodB8qVxquhAyV7g8O9TKXRp2g++kZ9RyRNmYXuOgSNxpI1V2N5NtpY"
    "h7cS4lgUvUVD13nSWbHdxAkLSiOCUuvIKiYJyVcXcpVR+UraeQy9QSXsbqxyVzu/Q2q/TPDYLeSwdczQmZuaC9nYeU05Kmdczf+6"
    "J/J3hGG7RmIm1Apg1P4gezUnS+2G7XDTnN1tQBwrWRwNQUbwgADuVLGMOb/D59x/esG5nbtEb+SKH4r5gK0tNRNjTVXYl4bXiTvs"
    "CEucivmFF22NG3V/yrlJ720vQY9ZVvMz0P2YjbImL2RcIInuKL221ay9g5Zi93Gsu27+V5y2sa9TvE6OyeaIbr7ZhBW+HRS2jofE"
    "cbAZ594xnI+00y3AtGaNRQ9vWfq5acWAC9kFBOQ200hiyXDn2PodPk72dSEJoIPCoHR2Hqa2uv7+yizsxrbnYp32epsZUySz4r5y"
    "ZAdoOEeBLbJbMvN85re+4jGVn2/szd8dsvNwvO+4lSfb8JYK72lCKlS+f/5CNkb04KhAb0T3FmIkInak4MtdsK21q25R9a6DoKQ7"
    "hBScrC8bvyBa2B4c7qjfnboqZueG38LRtbMM4RVQyz5hT33xzUDer+be1LKDNQ0nVSbNb/5WjsyfyHSkalIF/z8lU1G+Ph/TkapJ"
    "f8XpfQ9KjTP/xOkU6VPulH/mlhM3ykj3o78rN7V/0r9xXCJFqggoGQPfH8J5HMBIn472lA81gjJSpN9HZ8P8olflaRhBGSlSpEiR"
    "IkWK9DH0P/nvdlU0XLV6AAAAAElFTkSuQmCC"
)


def _whiteness(img_bgr):
    """Карта белизны: 255 — белая точка (все три канала не темнее _T_WHITE_HI), 0 — темнее _T_WHITE_LO."""
    mn = cv2.min(cv2.min(img_bgr[:, :, 0], img_bgr[:, :, 1]), img_bgr[:, :, 2])
    return cv2.convertScaleAbs(cv2.subtract(mn, _T_WHITE_LO), alpha=255.0 / (_T_WHITE_HI - _T_WHITE_LO))


def _turkey_refs():
    """Образец строки в нужных размерах: {"coarse": [(размер, картинка)], "fine": [(уточнение, картинка)]}."""
    global _TURKEY
    if _TURKEY is None:
        import base64
        tpl = cv2.imdecode(np.frombuffer(base64.b64decode("".join(_TURKEY_B64)), np.uint8), cv2.IMREAD_GRAYSCALE)

        def sized(k):
            return cv2.resize(tpl, (max(8, int(round(tpl.shape[1] * k))), max(3, int(round(tpl.shape[0] * k)))),
                              interpolation=cv2.INTER_AREA)
        _TURKEY = {"w": tpl.shape[1],
                   "coarse": [(sc, sized(_T_COARSE_W * sc / _T_TEXT_W)) for sc in _T_SCALES],
                   "fine": [(rel, sized(_T_FINE_W * rel / _T_TEXT_W)) for rel in _T_FINE_REL]}
    return _TURKEY


def turkey_region(buttons, bounds=None):
    """Полоса вверху окна игры, где появляется объявление, вычисленная по трём кнопкам TAP TO TRADE.
    bounds = (left, top, right, bottom) экрана: полоса за него не выходит. Возвращает (x0, y0, x1, y1, h),
    h — высота окна игры в точках."""
    xs = [b[0] for b in buttons]
    ys = [b[1] for b in buttons]
    h = (max(xs) - min(xs)) / 2 / _W_SCREEN_H       # высота окна игры
    cx = sum(xs) / len(xs)
    top = sum(ys) / len(ys) - _W_BUTTON_Y * h         # верх окна игры
    x0, x1 = int(cx - _T_HALF * h), int(cx + _T_HALF * h)
    y0, y1 = int(top + _T_TOP * h), int(top + _T_BOTTOM * h)
    if bounds:
        if y0 < bounds[1]:                            # оценка «уехала» выше экрана — берём полосу от верха экрана
            y0, y1 = bounds[1], bounds[1] + (y1 - y0)
        x0, x1 = max(x0, bounds[0]), min(x1, bounds[2])
        y1 = min(y1, bounds[3])
    return x0, y0, x1, y1, h


def turkey_score(img_bgr, game_h):
    """Насколько снимок полосы turkey_region похож на объявление об индейке.
    Возвращает (оценка 0..1, (x, y) центра строки на снимке или None, части); части = (грубая оценка, вся строка,
    первая фраза, вторая фраза, размер текста относительно ожидаемого). Надпись есть, если оценка >=
    TURKEY_MIN_SCORE. game_h — высота окна игры в точках (пятое число из turkey_region)."""
    refs = _turkey_refs()
    none = (0.0, None, (0.0, 0.0, 0.0, 0.0, 0.0))
    w = _whiteness(img_bgr)
    c = _T_COARSE_W / (_T_WIDTH * game_h)             # уменьшение: строка ожидаемого размера -> _T_COARSE_W
    cw, ch = int(round(w.shape[1] * c)), int(round(w.shape[0] * c))
    if cw < 16 or ch < 4:
        return none
    small = cv2.resize(w, (cw, ch), interpolation=cv2.INTER_AREA if c < 1 else cv2.INTER_LINEAR)
    if int(small.max()) < 40:                         # белого в полосе нет совсем
        return none
    best = (0.0, 0.0, 0, 0, None)
    for sc, t in refs["coarse"]:
        if t.shape[1] > cw or t.shape[0] > ch:
            continue
        _, v, _, loc = cv2.minMaxLoc(cv2.matchTemplate(small, t, cv2.TM_CCOEFF_NORMED))
        if np.isfinite(v) and v > best[0]:
            best = (float(v), sc, loc[0], loc[1], t.shape)
    coarse, sc, lx, ly, shp = best
    if coarse < _T_COARSE_MIN:
        return 0.0, None, (coarse, 0.0, 0.0, 0.0, sc)
    # точная сверка: вырезаем место из полного снимка и приводим строку к ширине _T_FINE_W
    tw, th = shp[1] / c, shp[0] / c                   # размер образца на снимке
    ax0, ay0 = int(max(0, lx / c - 0.05 * tw)), int(max(0, ly / c - 0.6 * th))
    ax1, ay1 = int(min(w.shape[1], lx / c + 1.05 * tw)), int(min(w.shape[0], ly / c + 1.6 * th))
    k = _T_FINE_W * refs["w"] / (_T_TEXT_W * tw)
    fw, fh = int(round((ax1 - ax0) * k)), int(round((ay1 - ay0) * k))
    if fw < 50 or fh < 8:
        return 0.0, None, (coarse, 0.0, 0.0, 0.0, sc)
    fine = cv2.resize(w[ay0:ay1, ax0:ax1], (fw, fh), interpolation=cv2.INTER_AREA if k < 1 else cv2.INTER_LINEAR)
    top = (0.0, 1.0, 0, 0, None)
    for rel, t in refs["fine"]:
        if t.shape[1] > fw or t.shape[0] > fh:
            continue
        _, v, _, loc = cv2.minMaxLoc(cv2.matchTemplate(fine, t, cv2.TM_CCOEFF_NORMED))
        if np.isfinite(v) and v > top[0]:
            top = (float(v), rel, loc[0], loc[1], t)
    full, rel, fx, fy, t = top
    if t is None:
        return 0.0, None, (coarse, 0.0, 0.0, 0.0, sc)
    split = int(t.shape[1] * _T_SPLIT)
    halves = []
    for a0, a1 in ((0, split), (split, t.shape[1])):  # каждая фраза может стоять на пару точек в стороне
        x0, x1 = max(0, fx + a0 - 3), min(fw, fx + a1 + 3)
        y0, y1 = max(0, fy - 2), min(fh, fy + t.shape[0] + 2)
        v = float(cv2.matchTemplate(fine[y0:y1, x0:x1], np.ascontiguousarray(t[:, a0:a1]),
                                    cv2.TM_CCOEFF_NORMED).max())
        halves.append(v if np.isfinite(v) else 0.0)
    score = max(0.0, min(full, halves[0], halves[1]))
    pos = (int(ax0 + (fx + t.shape[1] / 2.0) / k), int(ay0 + (fy + t.shape[0] / 2.0) / k))
    return score, pos, (coarse, full, halves[0], halves[1], sc * rel)


def grab_turkey(buttons, bounds=None):
    """Снимок полосы с объявлением: (картинка, (x0, y0), высота окна игры); (None, None, 0) — полоса не
    помещается на экран. bounds — границы монитора (monitor_rect), чтобы не узнавать их при каждой проверке."""
    region = turkey_region(buttons, bounds or monitor_rect(buttons))
    if region[2] - region[0] < 200 or region[3] - region[1] < 40:
        return None, None, 0.0
    img, off = grab(region)
    return img, off, region[4]


# ---------- сеты аксессуаров (Set Swapping) ----------
# Макро умеет надеть сет аксессуаров: нажать кнопку аксессуаров (синяя шляпа в левом столбце кнопок), найти в
# открывшемся окне предметы сета, для каждого нажать на ячейку и на EQUIP, потом BACK. Предметы в окне стоят не на
# постоянных местах, поэтому ищутся по картинке; если один и тот же предмет есть и с камнем, и без, берётся с камнем
# (значок камня — в левом верхнем углу ячейки). Образцы сняты со скринов автора (экран 1080p), см. dev\sets
# в папке Mac-версии. Размеры считаются от высоты окна игры, а она — по трём кнопкам TAP TO TRADE.
SETS = (("beelzebub", "Beelzebub"), ("seraphim", "Seraphim"), ("jester", "Jester"))
SET_NAMES = dict(SETS)
SET_PIECES = {"beelzebub": ("beelzebub_a", "beelzebub_b"), "seraphim": ("seraphim_dove", "seraphim_bag"),
              "jester": ("jester_a", "jester_b")}
SET_MIN_SCORE = 0.90          # предмет найден: свои дают 0.96–0.99, самый похожий чужой — 0.83
SET_ICON_MIN = 0.75           # кнопка аксессуаров найдена (на настоящем скрине 0.95)
_S_REF_H = 1080.0             # образцы сняты с экрана этой высоты и хранятся уменьшенными вдвое
_S_REL = (0.94, 1.0, 1.06)    # допуск на размер предмета
_S_ICON_REL = (0.88, 0.94, 1.0, 1.06, 1.12)
_S_DY = 15 / 1080.0           # образец предмета взят на столько ниже центра ячейки (в долях высоты окна игры)
_S_CELL = 58 / 1080.0         # половина стороны ячейки
_S_GEM_MIN = 0.08             # доля ярких цветных точек в углу ячейки: с камнем 0.16–0.32, без камня до 0.03
_S_BTN_TOP, _S_BTN_BOTTOM = 0.925, 0.995     # полоса с надписями EQUIP / BACK / EQUIP VANITY (по высоте окна)
_S_LABEL_H = 0.024            # высота этих надписей не больше такой (на скринах 0.018–0.023)
_S_DOTS_W = (0.012, 0.045)    # «...» на месте EQUIP, пока предмет не выбран: ширина трёх точек (на видео 0.025)
_S_DOTS_H = 0.014             # ... и высота не больше такой (точки маленькие — этим отличаются от текста)
_S_DOTS_BELOW = 0.008         # точки стоят у нижнего края надписей и чуть ниже BACK
_S_EQUIP_X, _S_VANITY_X = -0.216, 0.215      # их центры относительно середины окна (BACK — ровно посередине)
# Карточка выбранного предмета (название, вид и картинка) — справа от персонажа. Смотрим на её левую часть: правую
# закрывает лента выпавших монет. (от середины окна по ширине: от, до; от верха окна: от, до) в долях высоты окна.
_S_INFO = (0.40, 0.63, 0.19, 0.45)
_S_INFO_STEP = 48             # точка «изменилась», если хоть один её цвет стал другим больше, чем на столько
SET_INFO_MIN = 0.012          # карточка сменилась, если изменилась такая доля её точек
_S_EQUIP_W = (0.055, 0.105)   # ширина надписи EQUIP (на скрине 0.077); другая ширина — там другая надпись
_S_BACK_W = (0.040, 0.100)    # ширина надписи BACK (на скрине 0.066)
_SETS = None
_SET_B64 = {
    "icon": (
        "iVBORw0KGgoAAAANSUhEUgAAAD4AAAA1CAIAAACWZM/QAAAQxklEQVRo3rVaS5McxRGurKqex87sW4+VFgmJFQoRAuMAjC1BhMO+"
        "OOyDI3z0X/PJB26O8AUOvhA+OIKXwcYGAZKQhACxktDuah+zM91dD+ejqmd2djFEONyWl57unuqsrC+//DJr4A9/fD2EAEqpELz3"
        "AHgafRip2OJzNQwlKLAx4LmjB0FDVDG64KylyzoqTw8qfB5ixFMNQE9H/IdfpXsRD/yMnyJAvoKP4T/8f1CBbgJ4BcYY4C8BGHqG"
        "D2sLNBJP0lvoPdEqPvAt3jm8hE/EGOgl8jJ8VOEXyEI8x2EVneAkg4LCBxoCXx7ZNg0Kv0yP4TiNqYpeH/Bx0IrcghfoWzQw/VPk"
        "L4MWAz+TZkUO0jI4/qVnIh9sg5ETK/NAi9GF7Ho80AlGQX5U7KfpRZwXzhyvG2vYsSo9FKLh5eJrNIHI7tDsAY+rShbgkuGUlOal"
        "oSu8Bvicjx5vonPZV+NDZoJ/cPLyHvkr1y0tKhsW+AVyA21T7DR8lkzl79DrtHgFaIVjHhrhpNi97Ehae8VIoCUnyAhmQvSKQcKu"
        "TCuvaBFpADw1+CX8H6FCXJyeY38li5s5EIqahRCXp4/gaig6oXCxVGJuECR4fhb/orkFT4P+eEgj4EQ9o43nDD6QrYEBiLCKihyv"
        "aSo+w0k5nCDYdqSHcR5ogzG6Mb1xtuBerBc7LZ9DXdegEgAIMZriMlSVChVCmt7BaPPkduBgUbXKK4gwic6w3+nRNCUCj1U+u0VH"
        "DjJ6Jga0kDxFYaTR2bXxpaFA0UEXRSFsIYaKd+RkyvGEb7S7gdHdu3e/vnevjA5H1hgS0Tl8l4BdiW/zQoeQ1gpHiA7v8VojYIBB"
        "iGsMWmZHAUiMIQ8D2RzkhUBrqgMGHtTtaE6cfPLixYt4i7hrDCxaiozkKCErgAnsCx6S+REZauO5X8/Uu2i6JbtpYPwKAUWNY4XC"
        "oaGnwB6K7GvjhdvoiVBQMBKAHK0ZMK0m8CuJE4SL1g59v/nFrRWmQrSiwbC8DoRTM37kophOXgkIZ8BAJxrUo73ezfe8qvFtXT8K"
        "TGg8byZKwj1+tuxECWWynCykYPcCBnom6nQjxPRdRAuhziSv012Db5l54uKOaSFGGS2CkDQ/Ro6WNCEXE8OMHZDDnlyhXDuOQhg5"
        "rQsVHPuJB7XMCYwTz8vFh2Gs+OB0cg0vY2Ki/ILII9NFRKsRIzSRb83ciWlFC0iErCF/5BnGKcYk08llTL5j4kTUYvjSmwxEU3sV"
        "2D2BXOnGrGuIICUH0apwKmPODJEhzKzb4vWBmC2nnEHjOfEQURIBMkLKpw1ZjPmaL9ocnQ1jBiuQF2JJkYEOBue0J1tAF0QuQHAm"
        "TtbyNTEIeH7s5CAUy0NJ6Mi7a/YS86ssd2QtIc6l/6IzPAFPczIHNXU0EMcAyFIjiiKwvDpeiQUxZq9rgj/yLbmRWJx5IljBn6R1"
        "3UqpjdgGZ2K8JtdrCmhCcxS/ko+FUoAhJEDRGbnIwgRlzBKGQjlw7Kk0M0niKq2uRiJt9A/lXhWnpsivICwjmSPRBp4VZB6UwGH7"
        "HSUcjXGXwpbHhxHqkaCRVSOlsI5noFpyMM2PTQdO1RLIirEcGGa4FoYlWeJZjk6abyO8JhfECmUSJfIcCDaEVZZUTNIhwVSxmRPz"
        "JPAAMoJDm7xFUVk55bwd+vla+67aXypCq+2ZtTCkSGBqgjbLqZhzAnEjoUgjF+RcLiahjwXDDMImdmGMdbnUpKiUbiTqgkg4mhTh"
        "XVZEFppzaFnr+0Mko9lR63zodovFpdbCsbh0QneK3duf7tz8V2/v3nIB7YK+zPxLSgxHpIgXEDMxE7cyUHO8pdiDfEwaDQKKRjk6"
        "CpJxuiGSR29RskOdFziwDVFyRhd6EM25tz8Dr/yudeacn19EGYJDjECzIlDF6jn9/JXRjRt3P/lgfuf2sW5lW85TXkVMGy3yTfQd"
        "yBmTf3K5RHESLYluYxOyicRtI4V5ZlmzIZdHbyTI2PTADBty8sfBS2/L3vHWhecGs/MIhJgCStV830PLzh3vvLDUuvyj8sY/b73z"
        "5qr/ttPBoHRFpOQr7wTR0CrXBmMwy3gis/WkFGsUgc2ZlsDMJ0aCI8hndD1TIcPQWa3zwLDvbDh2CrpztBhaqZz9Gn2A6zbUsej2"
        "9bNXi96xe2/++YnRN53WTgneBJPiJXEe5jc6revKuSorRMVpGyVWyAwCDZeQ10W3yMwQNp4PpZJbNBUKvJz8LecrqZtQ0A8qU5xZ"
        "wzjj7KMOH3jZb21s/fvjbq/TmuvPvnj14VtvnPbbRZd116REUakiyMufVANGqlRM4s0pkkl6HY3W2aNBJAuVSz5pF8q2FTs715xB"
        "l7qvTp31nGCNOtJ0mAlmcO0f8+WXpVWPoW/ccFigk2glaZVp0ix2kEl9LQkL60xNugIToWKfGinDYOJIWEfF2/CRzEGoByGCUtaS"
        "HAtSIkmJx/GgaxddZ7GYP+bgSI8LYEAtzJnTJ9pf3TjWGfm47drBmpKDvrDI1hFFJtsnVTgSkBeXoxwSmYl3A+PHNATYuDhxorBS"
        "Q/BBOF7qHqoOELekZ/B5iuoAZQVm8Th0Oipn+akjsnDBdFycXB3h/HypoSwU1i46+BamTcfLipnXJ6Gd9DAOXxNuA8NfABQnDy/z"
        "E9Fb1yQfpODAGdI9ahAQXDwlf5pI7bhK5kIT0bI/DK3egsH7lAFE80bVsD7HCupuU476nd7Qt0dEznWB1QauWMAondH4X+9IdiWE"
        "01QcwgVLS9QFiJgsA6Smm5C2SaIhYCpxUiom0GRqVXigxIwAxERSUXcEaU0hhFC31Mrp/R23/f5HbdOffeZie2HZtQrpeBCYfI2L"
        "Mny0uXt/PXx+3X11tzesQ3dGWTTMjKIeOqwAW33r51sQaNV1ii/CI76/Nsa4KF0ToRqKukmopDBFZ08WJjhpWmf0WVpAQjf6H9UO"
        "SoyISA1xNFSjPa13vy7feN2/u6TXLnSeWsO0vLuzN9rcNBvrYXsvPt7T+wPrK8TbqIhbg3bZ6sHc2XDqYvf0GRuq9ffeaLt1YysW"
        "Z9StUSy8G/5uNDpfHEvhAxqGOyUhS19MeT5IhoqsO1wLV3yrwkBpB2jhLAfbvgqmhQWcK+M396v7D8u3/ma5BmwzrByRG6ZVgi4+"
        "WNn25vEnF3/2anH2KTezgDfr4GbK/e23/7Tcr2PTu4ipKyE0wvwTxbBmGg3DNH0YOnLXTtgB1SB4IgEY1PPrxVL/6pXOwqnoC1UP"
        "7ebmztf3qs9u6709QyD1xpDSLIgHFDeMaBk9UUgRT54+fvWnMz++XPYWapIALL/AtBeX8SNlbUjdwKZp0eTLLFWnLuYCj5J+iE2p"
        "wd2vwIqL1HGJbm2tzv/yt+GpS3voaNKxyMJ+qRy4m59vvfOuv30r1vvI7cBdO04enrse1s/Ozb/w4uLLL5WnToy0taT2Sd2SwoFQ"
        "bm/2cXlSjcJxqpIZgmkislREJOU4gR9oWkiK87EaMxAvFb5pWNULV1415y9vayN5B9knGuN7s8Xzzx9bO+ev39x8/4N491Y53OVC"
        "wDjdVp1O6+yZlStX3NNPD7szOJJBvuGaKnCCKGIYbDwosLYgkUhinZRZLjJSI3LcioEj84ZteH2qrmIrqTjffrS+PBrMzM7iexyk"
        "+genRcmoP6teeOn4pUvxs2sPPv7YbW4XRXv+3IXehXOwuuK7PQcFxZ/mjMuFH5pZaDD7+/7ResfGRN0iVVPx3zQPk7iFoy1XtmkE"
        "s9bJKi5yzxRit231Z29/OxquvPKrweKJYIwUhtS4ilzUIax7c/aFl09celZXNTqq7vcrFKS8wiY1O5TOMgeJi5qiO5vF9sMCqZ1Q"
        "oaWOARWafl12tskN4TBdykmlzbpX5Yek6kXTKZshxZ6Jj7fuvLu+92j+579pn7qEea9G92vVCboZG0UY+th0yERH1CCVTCoKQ6rq"
        "cNS6E2q7v7N7/e9z1SZ0Sq6yDYjAigc6RNIUmCrqGruT6JXInShGFDdcNUivyOz3lYONmxuvvzb/i9/PnLswanW4FoYQc0OPyJna"
        "1CEtSOrxoThDTkEMF6HuVvvVw68GN66VX97qbN/rF6OgauZf7l6FVFAf7rd812FZ7hxo/nJTnlSmT/0Jr1W5qKFXuwd/eW337NO9"
        "yz+ZO3O+bnVQ9jouhlUulkOyWXqqJCRaruoMtgd3rn/76Qfw4O58GJwslGl5hcmIX2i4xaeVEPkBHZSbAt9hegZh4pWYu0Ck0yWz"
        "R08PxWFhy9VY1V9ubnzxyddLJxbWnuuvXYzLK2XRKfn1UoAWzI9YJhtXl/fvPb7+ofr8o5nBxqodFW3UcSMq2w3KCqey6syqZKzg"
        "RU1xy8NznxUmk1EyXfYbRK8nHTReON49Aen6Uy9Fx1Lb4Yop93YfV+/d2fxwrlpe7a490zmz1lo+ud/poddnaq/3N/buXNv69CNL"
        "bt5bMGXRrWpah9rgOBpSLUhwCWlXYSL1NGjJUZs2ncatRTUuq5G0bZ49iZ4ovTgOczmXGpKEP0XboI9pHsVfKOtHj7fWrw9ac7sn"
        "VuHC5c780tbdO+XtjxeG98/q0haVVRVtmdG2jqVIZYFEYJQahvtnYnmmwgMF1H/DOhfYoaH2VGKr3EpUUicBLwX3qhhXGMIGlYj2"
        "LWOO2yLGveHDh3vrn2BhMKdD19bGDkyBLEWx4HObLndaY+qMqzjOIsQNYHh3sNm9aETv0aY37YHxSoFIA24ykoDjBj8XJQGkY6nS"
        "/gTiVUemSD9jdSeOSKKkpOmpAyoCn+VTFvSa11N6UaDypp6oAO5lg/Qx096WtF0ORSsVeJD2pUD2OoUrsDrkgA/c2wHpk3DqaLKD"
        "7A9ST5UbZLQLpCEcrKpT09E0zZsxEiDR6rgnzEtiNbcngyjHBNmj7CbTJ/cjx3JA3N00RDhSqVemmy4m6TOQWKFWrf4hTDwJX8IF"
        "G0ZtwuRYRIYm2cDrZKgZNU5AU80MyaYHZsO8Do3bxiknRqO/x7LvNT3bLbvRKrVXlM7VBMhOdzKuaXMd6sCMsX4onMED96nB6LTp"
        "nFtbWh9lTfbN9/o8Jy+p9oEZlzYrqTmbitEDJgIclgCTKWlye1uxEqNuAglEwVNWz6S2D/k1TtKw+gFH8u54II8FSZRI0oftm57M"
        "ZJg2W+4Te0kwNN2H7flA26DayIYt9+78oWGjJAAFE7X69wNewEKBmORZMLattGeKABgnqTF+puwe63Xxd7oawqx2K2vn0d8eYtu3"
        "+acLmqqBQ3BPAk/pH2h1prAgskMlaRuC0duj7dDLl9JPDMST03l0GjDj8in4/rW/uvpxTeY65+X3Auwh2bzKW8B5t2Mc1gApkclP"
        "O/ImSSMrUkCmvWDesEAbUIdGExaCNf3juSUlmGp+UHC0/DqA9dOnT6+srKhoC02/eCHdzrscQRrceeeD/aEnusRpu0Cszj+EEaJQ"
        "efTQxEOU2inTYJCWEwlpIy1mlStoY8zBvd+DDNNgHQ/aoneef7lCv1JJGzNEvwFybwQmd3ZiRvyE+ydRmQvLcW+y2Utq+lha5kmQ"
        "1fzbE522JpHrqOcIR5KvbebB3Ub5mUoE7lFzBB5QRZOtnAN74UewzmQkHIrsgx/TTl/aAFLQMG7KWVEflTRsc0Y9H+nlWasOvRKm"
        "NPX/4RARJpQfedtMfpOjvyPZTfweJsreSCrRmx35yZ2Q6cbB/3BMVtDpXHhTtAv5EdKCfAfZ/we75Tjnk0YIZAAAAABJRU5ErkJg"
        "gg=="
    ),
    "beelzebub_a": (
        "iVBORw0KGgoAAAANSUhEUgAAACYAAAAjCAIAAAB3ku9KAAAHHUlEQVRIx51XTW8kSRGNjMyq6up297Tt3Z2ZnZH2gIDDaiX2vCdu"
        "HJH4qXDgxh8ACSGBBEiAYC7ILLMztru7KjMjeBFVbns8LZghbdndXVXx8eK9l9nh8+dfUKCg0jRRqTCHSirMItKERKKJJUpphXuO"
        "ReVtDbntapCAxYEpBrKba61RObVtoVqlliaWMrbKRbUJoQ4DM6tU3JmIqkogUiVCDAoSSaNKYSpSU+Cu0pe5+0n/yZfrzZ4Pvxuv"
        "f/7dd39rur3WnYrmAxeUayu2OtCOYt+FuJHxtpbc9ClQlVK7JiMZ8zDkxJE1VOS0BJFRtZAQUSu0Kflzoq+l/en22Uttn/SLcHb+"
        "fLj407VclRIpcM3XtwfEyvsDmuib0LaLsOp1kXLQih8EssbEurE2KcaYVBVZGSjZ5YFDFA3bGr4Kq28W7Y+WzVb0k931+vqN7Pj3"
        "QX657n/d0Zva5ZyHimciO1xF8pO9vlykq1iudGw0t8wZUQMjgQBFx5E5JuJQNCilGITjQjk8H+vPFtsfx/57Z43u/nnGlSS/qvIH"
        "Wf6iDr+9Cd9KuNm9KaVUnxrKTV3Hqq9q+bvs6fUeIHfLZewSWxoyPNSQwztMKtlnxHiLHicmrHP54dPl9z8937R08+erv7zNvzrI"
        "b9p01ae/jvlfw03OOo7GF3q8EqnhNxzK7eFtf7ZYrVYpWQrxy56LwmcvXjRNC5JGS4l+w6XQV5V+gIq4fVXoj1L+IfuxW0i73A27"
        "3f6mZI1pAWARPTLIbrkXi8VhPLSgSc4AQJSYbWqXl5cINEjGa5ueSHjxxcugGjl5ERox4MKpaKMBPLodcq4xS87hdrEGE5PEVEa0"
        "Y6FNGyWTg4b0gSN+rQ+oAnVJBcKHw4Ha2Cw7LBun8dZCp1EYDAafS9XbYcQzqDQEHWQcteKB9eYyuBYTuNdBWNAwNbEZXu+TYGSK"
        "slrnJwAPvvDhcDiAmjIit30gRqbEXhRiTTgbsQx9BwFNAIm2awHae2MjdIAbNtvt8skmLjqJvC/gcBE2zWUxhXAE//Xps2f7w357"
        "eRGAIBzj4uJCoCEfMNo0sufq+QpgwzP92QqegpqM8C4lcurjNUSGh3Ch6SBI4EbjmHE1oikKKUZ0vFwux3Hcnp9/++/Xnz79bBiG"
        "uD3fijFKg6csY5lSotEYuV/2MTXksp3STSmV7t+ofwIidd0Cv7CUXAtm1rBBaEA71De3txmDh2bWT7ZIFyShDTQ47A4pNrDZgmuw"
        "k44xPYTFLdUaihpYICUF2cL0S2aTlhjcwLuma8C7gugV/2tDAfPdj4NiTALywe18gvaIKigDJQEut2xt28YIcUJ//22Buph93/fw"
        "peqWA3My2cgkToqLsxW4beTFZpKiOaOZo7RoMYWZ/Q6r2ihnPPU+RaAjyOr0c+qlpklNizRDHmGrYA3oZqSDTzWI68JCb3jCoC/w"
        "99i3bbwf2Ecv89MUV5t123U2Wl8T8xMkhpygM/xHMmF700YYlgnPtQsYIUoXs8ljk6d7NN/UMCuNnVfK2qx77lsE2O12sOMmmOk4"
        "FUNVdm/QGhKnZpbmO+H/rwVmmLVZaMOylpKCM6e4M0CTINmqX0+V2o6tc0rUEiJN4vkfkPoNNlLReYlVDofxndP2kKkRtBvbFs0B"
        "d5lv/8gWp/h3r62tu09mTkVfqWBmRW0/wOya1KbNiLFBPDyPxQqMybsD6U09mEC4Y/zD2dq01VuZk81FgPExhKPxJj8k+Ebp+wku"
        "Q0+wckNScAjyeAF0CHPBFu40lS1T1UcaNUJ48vtN1fcwNOAuwk4hhTTBJjgNDl86+Zmd5qw3YQ+B4I+Tqe21THM3jxCf+p0ASLaL"
        "oBpjNxAWx49g+GE6IHmZ+Osydz99MLBjso8aeQINa9BslMSbRibqxJgBMEyEJ3WaedpfsnqtGxepgeG8mNryf+FI2qkgI+kjYO3I"
        "hBhwW6I8jDMS0RKquW7lJh4NwON9kCfNyU52aRNXquNcxgSm7WVgmmFMnGUqMnn5xa3oWPR0/51CjHP6LvJz9w+mm8zC8YAPazoJ"
        "GLLYtAWHQYeEJ6u2QRqzrE02l3gwyymHUaHKwwRzAxO2x1OHBZkkhdnonYp9Krhcsb9AsjbAatK1o4Ed3Y5FT/miN0ql0GyTd+cH"
        "P46Q3q/JdEwfhpVY6Put3iDyXM586BTkjXaaifTeNO8mpx8yZjMLvav3mFInhcyCtG0cndnWDYuadSYnBkb3I5vgnb6R0V2N0+V0"
        "bBgpkp9CLSZPKTFHYwpOEjA7O8xKPBL2hOTfMwedafCOWacaJkuzr5Xk524LVAlH7oZ9Nwu+wVVzSjNedrcSeZhvDv1h+kn3z9D9"
        "3uThJLCf+gIfo4sDyu6NJ4J92PaaVoveTS7og6mQf9HFZ8Zk+7ZkwnE/N5FMNnhCf/MJ80QlD/H4DyprJU5i3MUNAAAAAElFTkSu"
        "QmCC"
    ),
    "beelzebub_b": (
        "iVBORw0KGgoAAAANSUhEUgAAACYAAAAjCAIAAAB3ku9KAAAILElEQVRIx21XS28lVxE+r37ce+2xx4yQRmIIGQaJxShkEyQkYMWO"
        "NVv+I/wDXgobJLJghKJYQZnMxElG4/i+uvs8qviqTt9re+D46rrdffpU1VdffVW2T37wxBhDLhjvgudg3eP3Pzh7/Ky3+atPX3z3"
        "9pvEaRzHxWLx7Mc/bZrF1dXV9fV1yuMQt13bWe/YOZxgyTCbbIgM4U9mxl3LcoGFh4UKFp7LbixvTGN9cG2xTd8vF00YpmEsmazL"
        "OU/TtF6vX7x4cXNz45yLMe73+zSmOMY0xM6GJrQUPA6zVqzh692PelA/Qex5b50V48Ua5xBQQ8lN9HbHKXKb2ftmyGnc7T/9/D/n"
        "5+djoVQITm+325PVKpZsbbhYnRLTVHLET85N0wTnShJ31QmL2z4ERBmwrLXFGbKIOjW2WfVtcTYWimNK48RlyoYFOmt3ux0R4RQn"
        "4Ri8O+LEMS5DYxNHKnh/nMZTXcvlEntev349DIM13DpPhQByIA1cQSFCOpdnSGrrKcWbQGuBl2EMJrxn0zKl/U72cvHGJzaNd0Dm"
        "gtxHu80rmv61OoX5lk3ZD2+2WxyYqDC20Oy0mDR3FpDpug7ZKiUPwwh8xB2+s0EzA1IEiwhNyLkr5pGh35b0EZs/BLoMbmSLTAOM"
        "jJ1tk1IySqfjIQHPYINtzbmcRPDIGqBhlG94Wr2TI5RonXWPjH8OrEze+/ZnKf0mTmyEEEDK+QavgZwwIm/KPcKF814YW+lzd/V9"
        "jzSlXHJOMA8qgQx1KwyKqySse492vx9vnsYy+Lh05d+dvWyak7Y/p3DlTdO2bdfBznrYw1cxeyfQUGsoG3HKFL/qF4HiNGx4uGlo"
        "j2cuOBC5FMrGJHatNT8y5ecWMfUv+4l96l3/0Lhfj7tXZfu2u9jYVURgwCmlUqIQTYxJlaI03o0S3vRdJx4gxiRRtn0LjiA3CNTK"
        "bvoe06/Y/W6YHuXxjbPnw/SQx2TdzrWDPz3LnW+1/JWV/3eJSWCNTOLjFROxF5MkQN/yuuBNSrFnem7LL/P++3lC9h/n0lD8ou1t"
        "6E/T+CSv30/u47jcmwRVklMVVFACoaJCalTurv0aOEzW+jveF2aHADKfWfdhog/G4bTsVrRDLXyyunixOoPDDzKdlHKKIHC3aPqV"
        "UVAw2I4aQz0ziDA4BdyY1WolBojG/R4REt7wJseh5HG5OF2Pae38n327PH3wPIcyEje+s/RsTAsCdRkp+M46hI8KJqCC7ENENQxR"
        "vGoS6nM3ShANAYGsWLU8sLAPOgJdhcRNlN6UcUgTHAO1ng7xvZK/7VZf+tUm9P/s3d+DnajUPPLMcSkwAFUhRPT3TEIYwZoSE4Ct"
        "uMMevqFw0gX2O9jPnE+8+clobkx42Zam0EXZtDS6ZvGyuEvOg6KWJZNV5CW8Wet1hSNX8QxR4lnUheSJRGhRT7pY6rw8JPfDzJPJ"
        "Nz68NM11G34RJ+TvsrWfBbdhm1naE2uAsGW1HHEUkKv1GQ4EgWtig9A80ijhB33kzGa/NqmgKXjXObQ4zsGkxPk6mdJ3X1O8duGU"
        "zJfOf+X6odjlst0jC6plApJKWFFs5yhnZuIJSUBYaMiwXaGPKS1PTjjlYbNNhkC2teFLHx7ntk3paSY0HPjyj2X3p+A3JYv88yIw"
        "XEdPJqdmSL9xYm3XzhwgxsVms0H4MFlDxMWUEwfnIQgquIbTUNKr5D+27WfBA7hzE177xV9sc4XGIhrtYpqQb8hZwaDgBScolRCJ"
        "52Zyjz7S61HwMeIaFwJLcFkHCwgYEhaYb0z+owcM9CG7B77dcP5rYz7xPKKebRNQNVr/YFDtzJVB99TH4WMFw4SGHuO4H6GMI1KH"
        "5HkZTCCAQ44Oak48sMu+xzCCbnuOKof7ZL4wtHEduixMRVssO0Zo6JI1lyBwkdZUZx5RlcpJuWqkuWz3u5gTYTPLPhSZZTTZjF+g"
        "Xa58B7eZoU9fx3zS9dmiEqFmskGA0wSwdh0oHsy5mjZFdWYsLGk9WCR8u92PUySvFYwBBaeHgLEHXQCN8KRt8Btv+pw2w/S3ZPu2"
        "2fWhcxhlLGlhVI4cYQRrkEvLc/OCoZmxViIQOQRaMnpJQcr0IGNSTtJEjWMSu9qwLQWbnL8kE1sX2TZcI+C7TanCqOOdqpGW/hxl"
        "VbWCI/UCm6HKuJbzWVxBnrwFQb0CJRvwJzduLdeSrAmwkuqaiCvX7jQXgmSO6oBRVTAATC+ZVzV0FiSCEtcRU4GAKVSjHlbfOeAm"
        "AJtaXZYP8dlDfP+77KGBBugToJO5kqHx3CCUjJQXgCiyL62O1XHBWsyoZoIvrKnTaJArV7VU+2Ixh4m5ujiPd7cmTXY64SNWDBsw"
        "I5nEySRtTFVKxFKT4kAGK6BpoFJ6gqeMQ9oA5KblY8SkWMvharVSSkoDjqOjBvAI3gkmZBV5MqKLmg6uUGk1lTkrsKEZeqeTHyad"
        "2/KfJ8haNiRQwBKuIfOYcuf6YXvUpno1jzKCnpl1DwHU7lQHuJmcWlSsxLk9Qp+JOmj4KIog4NWBk+dGg11OtZgUzjo4qaVcBUwj"
        "qmPrTByNz81SfYc+s2Hx47ZYw+0zeWlmgfBn9nHmeWWEqnS1KOe6+bYqgCRV5+wDTeqwU5vuXX1Ayzg4JZMqHRvLLc5MRwDrvFZL"
        "XbynylJ79JulKd8rEtZJES6S3hb1qS+oz+7oSD1ZfbTyf47CZ+1tW7CK1l3ftXs4c79vuMrqIjJ2Oyx2y4VEoOJ7vAtUy0xXICnJ"
        "r4EeSSH/NRMfWVP7eR2r6jqGLimvyMv/ruLTfwFoxlqqvRPt1gAAAABJRU5ErkJggg=="
    ),
    "seraphim_dove": (
        "iVBORw0KGgoAAAANSUhEUgAAACYAAAAjCAIAAAB3ku9KAAAKoklEQVRIx31XW2xcVxU9r/sav8bPOHFqO682jhtAInEobSkhLbRF"
        "RUJQpQpC5SEViChCqhB8IMQPfKB+FCHxR1UeKqVV6AP6SBsBatomoY1TJ02J4zR2XBIn8djjmbkzc1/nHNY5d5wCElxd2TNz7z37"
        "7LXXWntfuuG6ta7j3nXnHWNbt3luW1exR2tNKZWKRlHj2FuHnz/4QqaIYpxqxYjCRUa50lxTrrlMSTQ80L3vrjv33HSzcvjVlerK"
        "5bBSCau16uLlKy8ee2O+vEIlJfaghOIT//3jT+zaeUsU61RlSsml0jJCZlkWR2mWpUHBzbRcrpQkyRhljFJNmNRMU4SW2MWeiZ2P"
        "/OiHt058JM1izkiHJwJXXL2yfLlUOfj2W9NLi5Rws09C9GpI+twzB5JmEkWRUsoLfKmljNM4bET1iiCZ57rr1g2sGSy+8JdXfvvc"
        "i8v1RCgmkCKWYMmWkTW/fPhnA9391VLV9dxaWBaEvnrsxNN/PXpyerbZbCIzpKG1MimacAT5iDiKcSKk67qe5yopldJum+uLAldZ"
        "b3d31Ax7e0Yf+PL9SUQfPfCMZEwpwhgTlO/74r0Dff0rpZXl5bIftIVRNDN7/ie/eWw5lH4mEAMBcCfCaXvk8Ipnn/3T7ttuk1Ii"
        "Ki1rTpBCUuzwB0aGOZGB5505c6VSvuoHo6VSiXOe4UHGMkJ62to/c+snuVSdXZ3LlfD8/D8XS+Xp8+eTyCxrQEcwrahCEWgevpXl"
        "3r17BWONRgO/MoCexZ7g42Obo0a5WQsdxnuLhaF1gyfPnzt0/FhDS0YFntWc7dq1qysoCM4SmTJHSJc2dXb07JkaFiWM/O9DNJoh"
        "tpIkSbFY1MCUKYb6V5bjWrXN8ZuJ3Lx1m+L8iaefqscJY22gbcJVT0F/bd9nnYKg2pFRI5AqXCi9fvTNmdlZThyCRWSKpJQmKReZ"
        "0g5KqRS4jiz5+ZnZw6+9OjU1tWPHjr7ePsdxOFXCXFIrleqmLVscH2lzwZy/nzgVJmkKdVB576d2773nbhQ1jbOVavXilYWrpeU3"
        "J6dK1YqWikiSEoAPZKmnpauUMAzKIpVJTbgjvELBn5iY2Llzp+cGqACnpL0t8Fx/zdoh1w+4ALp8w/DwTTt3VMqllcpSltYf2v/A"
        "ujX9WmnEmpmbnb4w+/Jrx6YuXGqAnxya1i4TABf6cB09ONjjeKKZhEJTXzt0ZP2a3bs/vX///lqtRrTwhOeJrLONuw5P04Rz7bgs"
        "aPcRNmBOM5NhtQpIxsa3ru/rj+N0Zu790+/NnDo7/dRLrxR7+rYM9ne6Yqi/b/PIcHd3t9/R1tff09vd14iyerk+ffbSUjOj60dG"
        "unu79+zZMz4+vmF0g+/6KkkdJNruMp4JISCvdl/0FdtBVzCegfeQcM76TE6fm/nVk49PnTt7y0c/9uBXv97W4bvMi1NJGfEdrTId"
        "NWQ9iWsZ7qWlhfLshQXeWSw2mo1Tp05dunTp5o/fnMQxil7wA2VkAwMijvB9x9OZylId1pqu4xAtc+4haFAItm7aMjay8b4v3Bv4"
        "Pm4jxI1VLm9RqkVRpqJUwSMDrirV2qHDR3hHV5dUEgoBsOVyOU3SM+++Ozo8AoOFM8D50jT1HJ4lkXHBOFZZAszzeKAh/Lmv2H3D"
        "xk1S0mrYaESNZjNtNONaI2lGEvEIZAQqxXGzUT82dfrRpw7QoeFhJMDsIUBMQtcPrvv+Qw+laVivL9+4fTtW7yy4OI0PZMZUPCFg"
        "HTR3MEoSKTMlwzCCCQRBe71eydABRMHHEwYPRiJ57vz8j3/x8MzFBaZdCplDyJm2ZXJIQmAsxPf9dZ2FHzz4jds/cSvHiuA9jIIS"
        "RlUCXWo/0VqmsQDnNU00FqDV6hJzoC4mM+3wQDBv7v25xXL55dePS1F4e3Ly4sWL2DHVErz9N6eQymXYaTA6OnrP7bu33bCtUY98"
        "hzPuQk6pTBE8VcgJcbEBksDOJNSnsM+2oLMeRZVmPPnOJBAe3ziW1Gpn5+aeP3gwVWhyWe7sMD9oVGZAnEOvanTt2u999zvwd9RP"
        "qMwjLpytDuBkAlJYFB1YOh7EBXAiQ0EZaUZRm+ei/9SWaiuNBqH+Y3/4XVyPR/rXvn/lChIzMBOYj7IEgB0atzXfAezn7/ncYLEH"
        "9k2kRDMSzEXJNArMXQnMiLIWhn9wRhWGtXK1Njl1cnRkhAPnLCGUh/Wmx90kkVejaGX+gqkSYPxPx4XlO24hmNj+IbBubGx8sVaP"
        "CbTfBlEqGquEFYK2KEsyJkE9wWnSSKam3v31k0+88970huENlavh/fd9qa+jAxaZkfjC4mIzSXTKAmWaF+ov7SbNRxsZm6Wbr7/h"
        "29/81vZt28JKtd4INSUAFvQhWaO/p8PzgmJXUXhBpHQaN5eWSnOXFn76yM8vVypYx1JSjw4OuYxCTV5bcHZ+DrMFNxMLM82SgHyI"
        "iUFGkVUti7tvv2Ns02b02HrUTNGFoe4gCMOwsyNYLNf6e/2VKgRWj9MsqtcOHTl85MQkfJyY9sWlNs1wdmEexIBfUyESqdEgwQtt"
        "yKyF6Ziog2z1aCNlzbu6ih3FzpVm/Y3jb8E8b5qYgCfA59AzCoUC7pGSVEO4XrxSrvzt2NHjM2fM9KQyuDdBX1Egh5k0zCyUaXwV"
        "aAyWmwZMYtqVoTyhzOoYd9O164ag8faOjlpY+8q+fRvXX4d2PTAw8I+zM+PjNzq4FBTisH7oyOtvnj45N38hMjjZFg/cOJq6zYOs"
        "Blnt/oTYNp0PWrr1Fc5l2kvQVUwJQc0BRJQk5y7Mnjh9CtPck39+Dl61eei6yRMnZq8s/PHQwfmlq7Fp4jltCV2tjWUFOJBjaD60"
        "ToOibt2Yh8UEgGyRpdmonYsUujNvLYXLH75+rL+376Wjr2kDEU3RS81ICccw4xa3bmBPmvut+WKybzk+KIO6EvOoEaGphrFJOOrQ"
        "et0CgEhGUrpKLbMGy1BJM7yaoNJMYsCHmXkLh7EtO0jZPJTFmlzD0Y51NiSuG/ZeCynq6GlmIW6etUNxqyTUrIfJ0bDSjhSO1RmU"
        "nQ+mClMQpTx3lLy219Bubdksia3ApFuFsLsRMEizOOzVkgC/4iYQyhSCWQXn4RnJ94s82LU8ciA/0FwL3WtZmtLqD8Y9I1CENPBZ"
        "Z8d+8w/awgUA85vzHkVUaxlTdbNFbSdxwyR6LSud71612pqNZ/7nczrVpiNBrBllJid7UJslsRUHalmL8aaEJmtqrmKOpdIQxzCC"
        "Qp1Zi21EaIyTrTCrSbf+ULs43ppM+YVv5hiMKq4hCmeZ4V+GsRNAYz4TBD2AotoSDmY0SBRHf1SmwJbbysBjtgInQM7SAsA0yV/f"
        "7AWbqE0de8dGhbQmRHN2K9MvcuZZiTFzQUpuFW4DaFNVizhtIW30aK6b9x3zC6eU/N9DcFN+bTnILMcNQTNLQ0NKiy1WtBIDx8x7"
        "JX7iNhtzWMGZtzjjaP/9XpBrw8geWiZ5O8GLGyA2pqxMPsDQasiyXzHdKmYKQhuumrowXATeZLW0hObMRClMwXNernJ41Su0sVbw"
        "wzqSkDhbnmWoym06RuioSJ4CIZ6Ja7DANlFs2IWkLVpa8zQvuMpu1BJJ5T3ZPG5KyIwlWFfnlEPo/wKMVNljw23xQQAAAABJRU5E"
        "rkJggg=="
    ),
    "seraphim_bag": (
        "iVBORw0KGgoAAAANSUhEUgAAACYAAAAjCAIAAAB3ku9KAAAI+UlEQVRIx11X2Y5bWRU9073XLk9VSbmmpLvTCf3QPPBCPyChFr+B"
        "kBBqCYknfoBXxKfwCUg88QACiUYQqWloQhKSmlyTy+Xp2nc4A2vvc10JOI6rbN979t5rr7X2LjncO8iCC8HVSisppRAmMc57qbwO"
        "Hu9DEFJpbbSWctDr7w6HBwf7j472P3h0OBzu7e0dDPrdLFVKCdztXbUz2Lm+uX758h+u8n95/vWvf/PblcxqRPAuWCdVIocHhwZv"
        "vPM6QYhEBKlFUD5Lw8NBd293F4fu7+89+ejDp08+2t0ddru9GumJYLQUEpm09g/2T49fL5bTXq9/O77e290fXZx9+eUf8qVdV37n"
        "4INSpJW11q2vz87/+Oe/GVSmlBYK91OeiRTO1+2t9q9++Yujve1ueytNMi4+4PPh8HCw/fDFi2/Wy7yuy3VZtFpbR48PZvP5cplr"
        "3fEuPT45u7u76HYeFFX59KOjZ88+7XUfOFcqXVb5/Gi7byThgYgaIZ0PAsAaVa5Xp8dnTx49qutQloX3gB7Ae6GnJu1VhRch9QF4"
        "OJOar796roIb9Ab5YuWsb6VIep61s77vPdg9SFvdovbeWVGtVag//viRkbFdAk+XmPAQhbVbyqRVabPWAB0M6IIXzjmhbFWJt8cj"
        "qVrayES1VUhqW7oiX02vZ4vp7vCwyNdp4tf50rl+pzfobz9YlaWQTgkv0TqPEwoj+BEkQvoffP69n/30x91O33mVpi2jU8QjGMAs"
        "pYJ0tSurorKoPSQeDQ9Jni/7icmXeb9jXHGTz+9KJY92h+uynfT3alwknQhAD22pE4HulrgNH+CFIG23txbzRWL0g51BdyuVsgqh"
        "UsTjoCmolsp4ISrnau/QBetCmnXKOhwePl7Ml8KH8fV4a6tti/zi+F+2mAc+HG3xdD0o6mfzhREUjQLi4PF4jCsuRqOHO1Wn27LV"
        "el1Yk/QIVJW6ICvUiR9SeweoQUJ0qcqEXebTZV52urvf+vb3lREXb/5t0q51PhPomvSQHGskKEEhNbGROhm8GE+m7Vavk7amkxnQ"
        "96Gsy7IqcS0EYbxqVZQrPegEx5UKsVjlyrnOzofZ4LFKtqytHz3brssqmE7wKtADMcA464OczQsTSPVR8BIh87xuqRbqmC+WSQro"
        "qmJdo6+4WRhtqQO4A+gKfiV9qqSv027W21o7I5nyUuiQbSEAoBTNwwlfW+/Gk7lCRBeRFQIsOD09xVlJlhBP6gq/13XBr7W11abE"
        "GBXJk6bTrJdk20FmSiU4B4VbPD1RRkgr8C7g7gKEMEav1gV4iMzASs7Eu6urS5wCrmqd0F2oA7kSnoJ4wGQjAlKKHBGckpqhQ95O"
        "cDr8RNAq+NK7ta2XZAUmuby5my1y0JHS8nw5Mn9zfLwuChyhQIMAl8XBoSgKZl0t8TawSwlyLTwRmBCiJLzwpD+yy+DwlK4UNXUu"
        "4wqqsvrd7/90eX0HXRJEge4kDr09OXGITiUYxo9+R5XGuLpeC2kUi4ZjSaadYNnZWB8jZR0rKDEozHhb54v89Hz06j9v/vr876UP"
        "hpqjINimy+fn51Ad2kDGGxKLZOEzCigVziVa14qjBiJ/zFKQzH2FSMhPU2SXpsZZwuZmfPP67cuTi5sXr88mkxn05YUyoXGf2E1R"
        "VdVodN7v9RAyBJMmHUlV3hVlrXXf+5LI7QkZ11gI9YRyUCJN0FhwcHUzvjw/P0OY04vJ2c31tCpRlvYpd9EaqZWnhgAm6oqV8ptX"
        "rz/55GmWtC3aqxRGFaQihMZIAecrW0XeSEIiJFrBAAFlvlzOZvPJYvXVP1/eXF9fXV7NlrWTLU9DykRAHFPDkDvgADZ2ZyXOe3Vy"
        "ui5XCcYnyCpIXUIkWTu1dpWlfYkuKBJ4Wa0mk2m5Lk4vL5dFjY5cjC7Gy/I2r4lNIC0djjkv4JNoEENDuBtiAGOKF3yHnE7ORxWz"
        "XQsPK+FeZovFpC7KwRY6lM9m03xVXt6eX9zNR7fT0xHGSMEmQEpkjsPaWDXBNXHALI5CtMPYB7qG5oIUqbFgufaffefTn3/xRarD"
        "Go4hE23C3fTy7mZ6N16fXI1Ori8W82o6nd6uVwUPIeU0j3pFPkGfoMoYgkjPwRGKsCG6D/ePICIAi7xgpfQ9jTf3+Wff/cmPfjjL"
        "i7OryQnm9ejk5PjsdjIrsSVRixMIASuRdUhYKB+lwy0jQ2W7YOzIYQlmx5sRf/9w/yiwddH3rG+4oRM2w7iCxoJywuBoWsC0jPgz"
        "v8EESJb2F5SAyUZ2yiElowdxSt40mirpNSofIhM0Q6MoaRqHiIeqyHgpcU1rj6XPnNRa83WEnBI6mh4bA9/K7+nk6BD0r3nDPz1/"
        "D1fjEnnAyMavaZck1H3UvGT2oQ6yGUqZQykXz33vxrjOqI0rsW5ds3U03iSQs5ERJtl8EaulvhKE0UNFfFGxOkqIusKmRzdYupb+"
        "8/RUtPDiXhVYIZRn46cq3h0gUq8kzRPxXtb3IEfb1kyIyPDAttsAE6LReq4ACykxSTSFxWLZGRlSQdZDNxmmEzLntWrDOhnriYN7"
        "M2RjZ4ieNJ8t9ZXyDJqXG5qcMk6IhmQ8w/iMd+0krcB/LXrmowu8O38D84akDd/vuY/SyAVZ3dRoyRtKuL/ZGNPE2HQxvkVeBl/y"
        "8hzeRzUWFfcTAOCj64c4mfG5IjADMyCQSKm9khseGtfxbNDwGEITCyylhCkER9em5lj3ke45HdPAsS7EouhTGcdq3O6Zm6RjWj5A"
        "Cmqzaubuxnms14hLCGItTRXLxDQCDe+kEsP/T8W87+B4Hsy0JPrI4rjC0LrGSt1YgbiXOQYg/dlBylPcOvTDRBFt5MFuzn8URJlv"
        "MKZnitkr4m4XMONsvIt4zdPivXjhvo3Rbxse2EBrvzRcFNM1ps1/YvFVgvkQHY2zonXbxiVb0D6iGw4HXtnuWxJ9p9FZFGPUn2Jp"
        "eBMR4hHYMDyqxZFpohOa0GPTQTXYDKIhR/SjuxFiLAnxHmCsSBXZJO+B5sTNxhAj+zgar+6bP8h8VKbcGEQI/yejuKy9+zA2u6lW"
        "NOM4LgWx8/8FAwUWxtD4YjcAAAAASUVORK5CYII="
    ),
    "jester_a": (
        "iVBORw0KGgoAAAANSUhEUgAAACYAAAAjCAIAAAB3ku9KAAAJXklEQVRIx31XW48cVxE+dS7dc9/x7njtjR2TECQrsZNAeEQgIQXE"
        "AzzAA2/8AsQjPwSJH4CE+BkgBBIKSEYIYnFxwAkb72ad9e7OzM709LnU4avTY8eEiNZ4tt1z+lTV91V9VYcOrh9Y41iloL0hazgb"
        "ZspOaZNVNHUVM2lWZF1USuekcxz33UApteJ1ywunvSOVFauc8bB84eKcE3N5sH2Sy2WIrFaGo1eWiJ3CvebsSMdEORpr1NMry0cT"
        "pVs3b1w16op179z/x4Wr2GrLOZHCR4lPz62n7c1zO8hDm7LuG0cZsVhNxma4S61WWutEkTIi1kz4G1yyw0g3TDV58fqv7/35whkm"
        "BBIUaQkF+2GZ0VwuMULUfcvm5Xfca3zdeuFlyh7uRYlYOxg0poUDuFTQijmKa/2sJ9Ekxadm3Vpdm17I4ABbITC9xe25mD4xDOjE"
        "EnVPsNQaMIUPXiRFEqK8jDWz2SzG9fL8DMZ6CQ7npfFrCyd7fSEXa4hLdLncl2DyM+bwX2O2vMgPLGtKGErC4Bg7mpkzd87mfPfu"
        "3YPRdBrJsLpU6czlRZWDyUGbkCnG9CyIT13Y1lpbNv/sywKliuqUgiSmc0GxzamXadarDxdzH3hTmVXlyIKxlOBiNkHpr37t7U3T"
        "/O7ePUvJWU7YKSWJTJsOZCBpCscFCJBKJYPwXJnJeIq9hHuNNVIZLgEK66qrZyfn/dq4GinV1P1qE1qthZLd2fU7d76UNsFFbWJq"
        "NyvkuwOwkpC0BbMz8j9XZjaj8YApsayXf1UmF7JV+eTRw7Be5Hb5hZv9H3zvGz/+4Y+mZvj4waOpnbx+98v1+MrR8cl3vvntYVU/"
        "+OBBQljCQOb/qqr8NMptXkmWIPrxeELwHdALvwq12ddVZtura1frV+++9PbXv/jWm5+/tj+8uT/52x/uDeZh0PJkPEZ6xJROPjp8"
        "/+MPva1gLqE+Sf//KPHQDMd7yCirXVbWstlT1YycSf4FU404L5vzQc/79lGzPB72TCT65Tt/XJwvm/c/MI+O1OEHV87nN8iuwvIs"
        "r+G3ZD9EC0mJPOJtlPScdTG5O93TVKpYSfVU2l6o1Bi1Z+qpqY+fnMWRspVvlvybX90//OvJMIx62fncnm7ml5vVYr0aR7pNg7Gt"
        "lhwDUQTEIIg/qdFPmaQXb76SVWCRSYvcUUbbyJ/L1RDZ2cas0om9rK/1L+aXvE4vu9m+ndTDfo4eFLSUl9Gvfes5Dnu1rfvzFA+V"
        "/xh2n+NSTD7jMiszHU3lXvzQormKXqD6ZTf0TTNy7rrtTVR1+nh1tNwsNuF6bzoZTN/8/nd33njt/ff+pZt25nqzejCA6Deb1+rp"
        "t/Zfubq79+DJSTIiFJ8Zpd1QrA1b0VOVLJxLp6lR6/aacVNTDQMPsrvSn93JO2exsUqf5ubSat/rp3pgnyxjTrujQUx+p7/zSn3l"
        "INf79e5fqiu/jefFogDJnZ4XXYOCaEKAItsoUgkV6b5SvCo1YzJBZD2p2tirVX9vvHNE4cnI9aeDtJnnJ6fs/Udt2yQOF8thzDtV"
        "DQqHPr21f3Mcn+G67Wko6O7eIn68UorHKEgtmpZWsLpQccp6HMS31tF5au8bv6z17fPmFz/56ZHxt6OuY3xj58ZY12s7vD2ZjbNU"
        "+iaGyxQadAO9VR9AZ6BNeau9KPoUulaIBonmjP6XRXg/2qzOaT0VvbTHanVcc1PRwUZdHY/nzXzN8YzMrqHT9rLfr5x1SMCNQfIB"
        "xzxUplZ6g91oq3OcpbmI9DNbyWlTZzaJFcN6bKKp2qqqjO5TPgsxOqPqEZnY07xx6n5aLnXA+HARad53YX3e+vhSb4i26Vk5qxbs"
        "3z09aoCX0V3uoEAh0UnoUwYa4NCVAat0FpFla6oYsSRp54AFQxVQNTYTi9aj3T1uV0ChAudKWBga13Ousi6XOgsoEr+cS4+V2pCW"
        "mLcFCvvIDDwBlyKu8qOwBiDQDCiQbkm1HLFPAtkp9ZBjCc+Nh3mQoUB5WmZz4OxQUw2otG5DOOL2cL24u3vt+HD+yLdJy/YQXwS2"
        "San0TmXGo7ESpLW4LRgE0A2t7AoYLUucJaSCKtktWozea0S/ae39XtXfRXG7GpvNA+wto9WvTa/t1H1w8mo9+crOwVtXD1LYnHET"
        "LDScBbIyv4BnWBTYsb/LDimd0AMRHFu4hp6IOAJyC5Xrgyi4UqD20K9uWPswXs79BqlemWpf92aKXwfaO+Nb/b1eNfj54f13wwIR"
        "9ZJQa0ajEYoDcxLrCqmEfg4c0UDFvhaUMU/m0lujUUnQj10z6kanVuUL36xz8CCaaED2Vj2auPrh+mId43FOPzv6+wPe6KIJpb1I"
        "kUDoTMJgodAnDEtiCXRlXskxePzVMvhJJkQ02LzVEV0w31B+bNBf426gGknKcToY/Xs1/+dq8Z7yDy4fr7JwSeKtvCjjFvKFhVgk"
        "o2QQwBQes2Qk5mnVDVUxCPhScpCqbBSmLowrsAkoMgpr4f1EV5XSu+OdP61Of784+VDFZWJBLWGJkfCK3MhYNts/AI4sEwjIypYh"
        "DNmbCquNZKsSdjXmMbxaYRLE22yoIJxFP4CRNsOQJ9n066qJYZ78JUrqmZZjQmeEVZSP0E4xLgti8oNMdyqQihK6iCGXUUYXUsGo"
        "gi7JTCpMlrllSw/Q0Sh8L1kIuZUxCq/ap2NBGTulaDsqYdpivi5sUZlGTZRzA2ocgpu6R500QstyTFL+oMSop0XE2ykZZd79x2TA"
        "BdTKuLo9kEgA1Im7xAeo0dm4HARKHkpIBXrBdDsL4pGMdqgajlrOIDIaYgGAhTWdCysSGyfV4YOvqChuDyZCoi7BF1l3Ii4ygOIw"
        "ITiqSgdgiC4GRaIiDkifiL5YejsWbICOJFkHAGlIDOxEMU6qzOyi4Fx6vhQ6F+JkpFaim8kWPMoRRiY8kX6IPbzlrqmSKzqjy9Gq"
        "0I4dyIk+F7BIUp27TElcZuju/FX6Bks0W0Zxv+2XUpyCjwSDnqxFcMVC2Q3ZEEtjw2a+TKqqqHXQ5IvJ0tq5SFdxWuVurNuma2le"
        "XZem7uyAjWx38OzOMVROLDIHF+HXElJXU8lYUXyfLQ5chdcOGKNkeZSs7s4j29A/+XxqiJXZR+BG+RFOGk/bKXHngBOt61CxniyX"
        "SLTogAiJLbKSqIqmp7ZNCmgWyiWzxCUJWXbDEVV3MaHc/gPMrgXikgvrYgAAAABJRU5ErkJggg=="
    ),
    "jester_b": (
        "iVBORw0KGgoAAAANSUhEUgAAACYAAAAjCAIAAAB3ku9KAAAJEklEQVRIx5VXWY8c1RW+5y61dldvM+PZbWN7xsbGxhDFEQSUWCJR"
        "XvlveUKIh/yFiMBTHkAJibAJkWwHZGM8eOmZcben11rulnOrZnraE4jE1aimqvres37nO6dgbWORWWoJBc6IpQCMEAIApFzGGGst"
        "3hSUiML6I9kOkuWA4lpudb7PR3fznrQUt5XbKW7W1uJxatwVH6k2hNFKVCWTcgiUbWnAt4ev5heKZnMLH6WUI6s4gUGRXfATCLih"
        "lnqMcLA+I54A4RF+eDWUac5PyGR+TIFY4twU6B5D0wjRQBT+RqkBKDhVlHiFJtpoqQ2w0Pdr4BFtl0S8SIXP+NWo/W0+DDU0KJd4"
        "WjAqDTGWEsC4EeucqaLlVNaTOhBWOeSey6AaZwXZlGyDhRjZJDdDalwUpOHAX/OidS9aYv5Gvfn72rrN1WuiFXphoeXN9sY3+bBQ"
        "GjC+1ppy0TJLxyoXOnUAr9KHa1oGrS5tnKlf+u2mZQ3COtS7zpNlyUSmm168RaPVqBECHxKzsNha8+PHe130z4tCMHaaZ88xRphR"
        "BpRTBhg/qMBR/geuTR2NnwU6saxj+atRs2Ho/emBAvJWuJAp2ZWZUsoXQmszrNtX3zi7vH2aLjU3z62r0aT31Vdw+9vWru3aIvHr"
        "bJpr6rBDSsfwzDwkMbDMUB/hVf1xw9JpPlLqiZG1qL4Wt9BcDazu1XxCB3py6Z1rb7//7rm3Lwen43CRQ+Tzxdr5i6+svb4VFcI+"
        "+oF45Fa6C1woMAJxighlHBiziFAXTGDtZscAnXlpCPBCp2maGV0USmWFZWyx3vxFvLAS15I3z1+8eSNejBWzhZyOJoMoiBhYRbSK"
        "RP3KdXv/8XpKMKIPsgnWiYelggikMJOP4EQvFywc1oPzvdArmk21kvijtplRfqaaaDPQkWenF5d5PeBUTibD8bif5ynRBdomPCE4"
        "jdpnROD3P7vlxdGjPFWZ0hhU6hMHf6K1QxS6zZrttilDXsU6yO1yDsbjyhhpjGfIKREybXamw2dNYdZbrqy5KXWA0ToKgijysZwY"
        "CWrtjSiKdj77597goBU3mSapNYVLqJohFh2hM+xWgMaKHHmwSETDIgnAkuejsxOdj+UUTi8IQQejFy/G+ThV1girGWZGWS+TUOiA"
        "KFvE4V4j7A1H+mDwh8bachTmNLPlquCKfMIpoMPHuaRKh8gJaJovTgFtGk6UVnB4IE2njGgx9aiREavVQqxaDAcrCnJmc1Nm+def"
        "/+3W/mMvzzLufzfqIxPCkUuzhUWINXRcl3izJ7MG8NjSOuVnmgvD0WiiEERWBIL7ApGX5zlHvKgAlUmZSoVk46ED/ee9jz766M0r"
        "V3UvQ+w8KvOcgq2VKas4VrtcthLiqO5wLeWQSrkA3hVeT0Hl6dQySIKANWrh9mZx0N95svPgWa+7uz8ej8O41koSITBcHmdRPelc"
        "v3HjrZu/vfXpXxcyggSbqeKHYkLKwM4Qy5USRByDWPn8Mo+ahFsuiMzu0HTZiHd09GU2JXu9Jz/cv1v0BiklOv/PDjzYe/b+e7+5"
        "GK+gRGT5ZCnYuHgOqVWfXpz0d7Z49LB4jp0JC3/mJRKqo3mklZnKXaOYVqFXfyWsr7aay+ODKYeHljQzqPcn69vna7ChpsbnZLVT"
        "O7O+2mg0siwL/MDzPGkNgg35eXX7fP3r3Qcm/dwMkPPmWxSWCqvVEzNXlzYIZJrl0xQT9sXw2YCaEKmHe9eTpXVNH8d2aeVU0uk0"
        "ktpiO2kkMeW+T6lWbOPsJexWHNPGmZKy+49//6l//xlHfjTczlGBmcPq4Sula5QPrPpy2hvKfHcy3Bn2vxn1ejIzuYqfjicTDIkj"
        "FYV7KUfwS41tsiYpK+9tYSziHJWc8iJfI+zI/yB2lkUsbCBJpkOJhjINNjUShZNCCW37cPBCcDulk4NChAJ5MS/4OAWklpHm7fVV"
        "PIwSwGOgidwffJEd3B2PLHYSTRW4toEVWcXyWCWKCSyJMjW1JKGi4KSpICckBYk5R9blksfCq/Un/oXzWFNBHPu1BKIE0+mF7aLA"
        "Es4IICb1vWePvnjx1DIqjMrJXFhnXgoCEvu+NEuWt5joqkwq1fL9Vc8b5mkf6IDY70jhW9PJNPu+m7z1rkoiS6nykyJczhif5MC5"
        "2RvsIQI2NjY+vvOvLtNhQSijvqayrMsKpBTmvbQk1gTBkgB/wVTTkJ7JQs4RE/d89YCodWACs7ffe3Tv3rk3rmlkd5kjApF67j94"
        "+JeP//z0+c729vbW1tbf79xBUZjFDEhkiHwZMLC0vKbnmounzCzulvFEkZCL1Sh51YYYVZErK9U4APbra96ls2EcN5ub/X7/008+"
        "uXz58q9e397v9f744Qe7z/cD4sY+UdYHMur8IHJSpbbHKhXn2EkQU8JCu7AeUHzE4cpXNiZ0ZXNt+Xdvr1x9081nxHBKX3SffPDh"
        "h93n+9iVAlMVHlQT0EsqT62sG3bsuYRjUPuWufEVMBmuvaFd1b6COOizMkNbF7ZXV1Y6nU632711+/Z0MmGuPbnhx5luuRtly0Gn"
        "UomJOKnSzhE/MjWqxCEIk1HQamaoGESiuwh3Z5CG6hQ+ZqhGGwwp7tVlj2Ro29EINFPJT6ixL/UaKzQZY3Xqo6m3bDg+opO4KV44"
        "waVoLD8cDZ1w5yP2M7TAicKaREMVzCTjlZOfvwxCDBtoNSNaFzR372LAkNKrAeNQgWHlzUsMxOcay8lVjSYVlGaTg4MVMpvFKQwV"
        "ID2Xjc+6PcapN6ocAI4YFU5Id1PB//FGl/PnvMqjYwGOPdaU1rKiossyvAECh815BaaCZPGSl7kFTyO9gxs4LcnLw9TBE69ln5tr"
        "bdXwoFR6fF7R2Xs3XB6pq+JhypITtASOKWNOBBcU3HCDqMUoWVdIFXAqDT/qNwH4WbmvMlpqx88itNLVuqskCRpjAlVhw09m102B"
        "pQdVf638qxI2+4Kc+Y1Xt7+aYI+851NKG9ohLqVI/O7jpbSrIg/yo1+cla+mrIQqXPQn4lFpEuZ4tsJGxkPHgBR/rBnAyuIVa5Sf"
        "f3zOWUnlTLRnjj6bNU7Gpcdlqxdz+w/fV7kXFdKqAd3+F/vUMOjpbJaJAAAAAElFTkSuQmCC"
    ),
}


def _set_refs():
    global _SETS
    if _SETS is None:
        import base64
        _SETS = {k: cv2.imdecode(np.frombuffer(base64.b64decode("".join(v)), np.uint8), cv2.IMREAD_COLOR)
                 for k, v in _SET_B64.items()}
    return _SETS


def _game_box(buttons):
    """(середина окна игры по ширине, верх окна, высота окна) — по трём кнопкам TAP TO TRADE."""
    xs = [b[0] for b in buttons]
    ys = [b[1] for b in buttons]
    h = (max(xs) - min(xs)) / 2 / _W_SCREEN_H
    return sum(xs) / len(xs), sum(ys) / len(ys) - _W_BUTTON_Y * h, h


def _set_region(x0, y0, x1, y1, h, bounds):
    if bounds:
        x0, x1 = max(x0, bounds[0]), min(x1, bounds[2])
        y0, y1 = max(y0, bounds[1]), min(y1, bounds[3])
    return int(x0), int(y0), int(max(x1, x0 + 1)), int(max(y1, y0 + 1)), h


def set_icon_region(buttons, bounds):
    """Где искать кнопку аксессуаров: левый край экрана (кнопки стоят столбцом у самого края)."""
    cx, top, h = _game_box(buttons)
    left = bounds[0] if bounds else cx - 0.89 * h
    return _set_region(left, top + 0.08 * h, left + 0.30 * h, top + 0.85 * h, h, bounds)


def set_grid_region(buttons, bounds):
    """Где искать предметы в окне аксессуаров: левая часть экрана (сетка ячеек стоит слева от персонажа)."""
    cx, top, h = _game_box(buttons)
    left = bounds[0] if bounds else cx - 0.89 * h
    return _set_region(left, top + 0.06 * h, cx - 0.15 * h, top + 0.93 * h, h, bounds)


def set_buttons_region(buttons, bounds):
    """Полоса внизу окна аксессуаров с надписями EQUIP / BACK / EQUIP VANITY."""
    cx, top, h = _game_box(buttons)
    return _set_region(cx - 0.45 * h, top + _S_BTN_TOP * h, cx + 0.45 * h, top + _S_BTN_BOTTOM * h, h, bounds)


def set_info_region(buttons, bounds):
    """Карточка выбранного предмета в окне аксессуаров (название и картинка, справа от персонажа)."""
    cx, top, h = _game_box(buttons)
    return _set_region(cx + _S_INFO[0] * h, top + _S_INFO[2] * h, cx + _S_INFO[1] * h, top + _S_INFO[3] * h, h, bounds)


def set_info_changed(before_bgr, after_bgr):
    """Сменилась ли карточка выбранного предмета между двумя снимками set_info_region. Нужно, чтобы понять, дошёл
    ли клик по ячейке, когда надпись EQUIP / UNEQUIP уже стояла от прежнего предмета: клик дошёл — справа другое
    название и другая картинка. Снимки разного размера считаются разными."""
    if before_bgr is None or after_bgr is None or before_bgr.shape != after_bgr.shape or not before_bgr.size:
        return True
    d = cv2.absdiff(before_bgr, after_bgr).max(axis=2)
    return float((d > _S_INFO_STEP).mean()) >= SET_INFO_MIN


def _set_work(img_bgr, game_h):
    """Снимок в размере образцов (как экран 1080p, уменьшенный вдвое): (картинка, во сколько раз уменьшили)."""
    f = 0.5 * _S_REF_H / game_h
    w, h = max(1, int(round(img_bgr.shape[1] * f))), max(1, int(round(img_bgr.shape[0] * f)))
    return cv2.resize(img_bgr, (w, h), interpolation=cv2.INTER_AREA if f < 1 else cv2.INTER_LINEAR), f


def _set_peaks(small, tpl, rels, count):
    """Лучшие места образца на картинке при каждом размере из rels: [(оценка, x, y центра)], по убыванию оценки."""
    out = []
    for rel in rels:
        t = tpl if rel == 1.0 else cv2.resize(tpl, (max(4, int(round(tpl.shape[1] * rel))),
                                                    max(4, int(round(tpl.shape[0] * rel)))),
                                              interpolation=cv2.INTER_AREA if rel < 1 else cv2.INTER_LINEAR)
        if t.shape[0] > small.shape[0] or t.shape[1] > small.shape[1]:
            continue
        m = cv2.matchTemplate(small, t, cv2.TM_CCOEFF_NORMED)
        m[~np.isfinite(m)] = -1
        r = max(3, t.shape[0] // 2)
        for _ in range(count):
            _, v, _, (x, y) = cv2.minMaxLoc(m)
            if v <= 0:
                break
            out.append((float(v), x + t.shape[1] / 2.0, y + t.shape[0] / 2.0))
            m[max(0, y - r):y + r + 1, max(0, x - r):x + r + 1] = -1
    return sorted(out, reverse=True)


def _chroma(img_bgr):
    """Цвет без серой части (из каждого канала вычтен наименьший): кнопки левого столбца полупрозрачные, и серый
    фон под иконкой бывает и светлым, и тёмным (в тёмном месте простая сверка давала 0.71 вместо 0.91) —
    а сама цветная иконка от фона не зависит."""
    return cv2.subtract(img_bgr, cv2.merge([cv2.min(cv2.min(img_bgr[:, :, 0], img_bgr[:, :, 1]), img_bgr[:, :, 2])] * 3))


def find_set_icon(img_bgr, game_h, offset=(0, 0)):
    """Кнопка аксессуаров (синяя шляпа) на снимке set_icon_region: (оценка, (x, y) её центра на экране или None).
    Кнопка есть, если оценка >= SET_ICON_MIN."""
    small, f = _set_work(img_bgr, game_h)
    peaks = _set_peaks(_chroma(small), _chroma(_set_refs()["icon"]), _S_ICON_REL, 1)
    if not peaks:
        return 0.0, None
    v, x, y = peaks[0]
    return v, (int(offset[0] + x / f), int(offset[1] + y / f))


def _has_gem(img_bgr, x, y, game_h):
    """Есть ли у ячейки с центром (x, y) значок камня в левом верхнем углу: доля ярких цветных точек там."""
    c = _S_CELL * game_h
    x0, x1 = int(max(0, x - c)), int(max(0, x - 0.28 * c))
    y0, y1 = int(max(0, y - c)), int(max(0, y - 0.25 * c))
    if x1 - x0 < 3 or y1 - y0 < 3:
        return False
    hsv = cv2.cvtColor(np.ascontiguousarray(img_bgr[y0:y1, x0:x1]), cv2.COLOR_BGR2HSV)
    return float(((hsv[..., 1] > 110) & (hsv[..., 2] > 120)).mean()) >= _S_GEM_MIN


def find_set_pieces(img_bgr, game_h, set_id, offset=(0, 0)):
    """Предметы сета на снимке set_grid_region (окно аксессуаров открыто). Для каждого предмета сета:
    (предмет, оценка, с камнем?, (x, y) центра его ячейки на экране или None, сколько таких ячеек видно).
    Если предмет лежит в нескольких ячейках, берётся ячейка с камнем, среди равных — с лучшей оценкой.
    Предмет найден, если оценка >= SET_MIN_SCORE (иначе место — None)."""
    refs = _set_refs()
    small, f = _set_work(img_bgr, game_h)
    out = []
    for piece in SET_PIECES[set_id]:
        cells = []                               # (с камнем, оценка, x, y) — по одному на ячейку
        best = 0.0
        for v, sx, sy in _set_peaks(small, refs[piece], _S_REL, 6):
            best = max(best, v)
            if v < SET_MIN_SCORE:
                continue
            x, y = sx / f, sy / f - _S_DY * game_h              # центр ячейки на снимке
            if any(abs(x - c[2]) < _S_CELL * game_h and abs(y - c[3]) < _S_CELL * game_h for c in cells):
                continue                                         # та же ячейка при другом размере образца
            cells.append((_has_gem(img_bgr, x, y, game_h), v, x, y))
        if not cells:
            out.append((piece, best, False, None, 0))
            continue
        gem, v, x, y = max(cells)
        out.append((piece, v, gem, (int(offset[0] + x), int(offset[1] + y)), len(cells)))
    return out


def read_set_buttons(img_bgr, game_h, cx, offset=(0, 0)):
    """Надписи внизу окна аксессуаров на снимке set_buttons_region; cx — середина окна игры на экране.
    {"open": окно аксессуаров открыто, "back": (x, y) надписи BACK или None, "equip": (x, y) надписи EQUIP или None,
     "unequip": на месте EQUIP красная надпись (UNEQUIP — выбранный предмет уже надет),
     "dots": на месте EQUIP белые точки «...» (окно только что открыто, ни один предмет не выбран),
     "equip_other": на месте EQUIP зелёная надпись другой ширины (не EQUIP)}.
    Надписи узнаются по цвету и ширине: EQUIP — зелёная, BACK — красная посередине, EQUIP VANITY — жёлтая,
    UNEQUIP — красная на месте EQUIP. Под надписями игра показывает строку последнего броска («$ 5,126 | HAND 15 |
    TAILS | x0.68») — её сумма зелёная и стоит прямо под EQUIP, а строка заходит на нижнюю половину надписей.
    Поэтому сначала находим BACK (красного в строке броска нет), а остальные надписи читаем только в верхней
    половине его строк — туда строка броска не достаёт."""
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    h_, s, v = hsv[..., 0].astype(np.int32), hsv[..., 1].astype(np.int32), hsv[..., 2].astype(np.int32)
    mid = cx - offset[0]
    gap = 0.03 * game_h
    closed = {"open": False, "back": None, "equip": None, "unequip": False, "equip_other": False, "dots": False}

    def runs(mask):
        cols = np.where(mask.sum(axis=0) >= 2)[0]
        out, start, prev = [], None, None
        for c in cols:
            if start is None:
                start = prev = c
            elif c - prev > gap:
                out.append((start, prev))
                start = prev = c
            else:
                prev = c
        if start is not None:
            out.append((start, prev))
        return [((a + b) / 2.0, (b - a + 1) / game_h, int(a), int(b)) for a, b in out]
        # (центр по ширине, ширина в долях высоты окна, первый и последний столбец)

    def near(found, where, tol=0.07):
        found = [r for r in found if abs(r[0] - (mid + where * game_h)) <= tol * game_h and r[1] >= 0.02]
        return min(found, key=lambda r: abs(r[0] - (mid + where * game_h))) if found else None

    red_mask = ((h_ <= 8) | (h_ >= 172)) & (s > 150) & (v > 170)
    back = near(runs(red_mask), 0.0, 0.05)
    if back is None or not _S_BACK_W[0] <= back[1] <= _S_BACK_W[1]:
        return closed
    rows = np.where(red_mask[:, back[2]:back[3] + 1].sum(axis=1) >= 2)[0]
    if not len(rows):
        return closed
    r0 = r1 = int(rows[0])                       # строки надписи BACK: первая сплошная полоса красных строк
    for r in rows[1:]:
        if r != r1 + 1:
            break
        r1 = int(r)
    n = min(r1 - r0 + 1, max(4, int(_S_LABEL_H * game_h)))
    top = slice(r0, r0 + max(2, (n + 1) // 2))   # верхняя половина строк надписей
    y = int(offset[1] + r0 + (n - 1) / 2.0)

    def point(r):
        return int(offset[0] + r[0]), y

    green = near(runs(((h_ >= 45) & (h_ <= 85) & (s > 120) & (v > 150))[top]), _S_EQUIP_X)
    unequip = near(runs(red_mask[top]), _S_EQUIP_X) is not None
    yellow = near(runs(((h_ >= 20) & (h_ <= 34) & (s > 150) & (v > 170))[top]), _S_VANITY_X, 0.10)
    equip = green if green is not None and not unequip and _S_EQUIP_W[0] <= green[1] <= _S_EQUIP_W[1] else None
    dots = False
    if green is None and not unequip:            # «...»: три белые точки у нижнего края строк надписей
        low = slice(r0, r0 + n + max(2, int(_S_DOTS_BELOW * game_h)))
        white = (hsv[..., 2][low] >= 185) & (hsv[..., 1][low] <= 60)
        want = mid + _S_EQUIP_X * game_h
        for c, w, a, b in runs(white):
            if abs(c - want) <= 0.03 * game_h and _S_DOTS_W[0] <= w <= _S_DOTS_W[1]:
                rows = int((white[:, a:b + 1].sum(axis=1) >= 1).sum())
                if rows <= max(3, int(_S_DOTS_H * game_h)):
                    dots = True
    if green is None and yellow is None and not unequip and not dots:
        return closed
    return {"open": True, "back": point(back), "equip": point(equip) if equip is not None else None,
            "unequip": unequip, "equip_other": green is not None and equip is None and not unequip, "dots": dots}


# ---------- путь к торговцу (Merchant Failsafe) ----------
# Когда окна торговца долго не видно (персонажа унесло, сервер перезашёл), макро сам возвращается к торговцу:
#   1) кнопка телепорта (жёлтая иконка в левом столбце; нужен геймпасс Teleporter) -> пункт «Fountain»;
#   2) у фонтана игра сама открывает окно COIN GACHA;
#   3) кнопка аксессуаров (синяя шляпа) -> BACK: после этого камера всегда смотрит в одну и ту же сторону;
#   4) закрыть COIN GACHA крестиком;
#   5) путь клавишами (FAILSAFE_PATH ниже) — торговец открывается сам, когда к нему подходишь.
# Здесь — только «глаза»: кнопка телепорта, пункт Fountain и окно COIN GACHA. Кнопки стоят на разной высоте
# (в игре их то 8, то 9), поэтому всё ищется по картинке. Образцы: кнопка — цветная, надписи — карта белизны;
# кнопка уменьшена вдвое, надписи — в размере экрана 720p (dev\failsafe\make_fs_refs.py в папке Mac).
FS_ICON_MIN = 0.75            # кнопка телепорта найдена (на кадрах из видео автора 0.93–0.97)
FS_TEXT_MIN = 0.60            # надпись найдена («Fountain» / «COIN GACHA»)
PATH_KEY_NAMES = ("w", "a", "s", "d", "left", "right", "up", "down", "space", "shift")   # клавиши пути
# Путь от фонтана до торговца: (секунда от начала, клавиша, 1 — нажать / 0 — отпустить). Снят по видео автора
# (23.11.2026, по кадрам): после BACK камера смотрит на табличку PANCAKE STATION; автор бежал вперёд 1.27 с,
# влево 5.63 с (по пути он довернул камеру мышью — здесь камера не трогается, поэтому это одна клавиша A),
# снова вперёд 2.10 с и немного вправо, к самому торговцу — его окно открывается само, когда подходишь.
# Потом автор попросил: «добавить 0.5с W в начале» — первый отрезок вперёд стал 1.77 с.
# В macro_config.json путь можно подменить своим: "failsafe_path": [[сек, "клавиша", 1 или 0], ...].
FAILSAFE_PATH = ((0.0, "w", 1), (1.77, "w", 0), (1.77, "a", 1), (7.40, "a", 0), (7.40, "w", 1), (9.50, "w", 0),
                 (9.50, "d", 1), (10.10, "d", 0))
_FS_TEXT_H = 720.0            # образцы надписей сняты в размере экрана такой высоты
_FS_CLOSE = (0.3926, -0.0074)  # крестик окна COIN GACHA относительно середины заголовка (в долях высоты окна игры)
_FS = None
_FS_B64 = {
    "tp": (
        "iVBORw0KGgoAAAANSUhEUgAAAC4AAAAuCAIAAADY27xgAAAL+0lEQVRYw6VY628cVxW/586dfXodPzZ2YjtOnDhp3QetmjZuU9JU"
        "JRVqaRESQry+IPGBD/17+IKokIAioSL4AkIIRFWlUPUBDSKpUyd24kccv3a9fqz3MXPv4Zx7Z2ZnnbQBMd1uvDuzM+f+zu/8zu9c"
        "+Os772itjdFBoPkIQ22ENvQNHaFBPgSK6EC0b533//4AgNTfHgglwEj6TtJHSWeVJ2W1UllbWzMaORKKQgvUASKFo9EY91QEceD5"
        "/0coaEPJCmFA0l305OQknVd0RbVavXHzOnrrBtuMEMFCaBj+zxh0kVAgdCfD/0S3RAfY/Rb9oAP5WvAYEF1C03Ny4qSUQrlbgNTf"
        "+t6LC/NbUiqjBeWLQaBTyQNTD4YvRAXvD4lIrYIzYmFuA+h3/7xob2ZUcvWd5ZX3L6+i8dFAoEM+yaAQHoDxYVDbh9nYTOfWD06W"
        "pUMCHjAklPTGS68cC5FIgZ4HKrUaxs0+xvLCZgSif+PVQnrhkM7PA2Ch+8r0hURBTY8DPpizdCsF7ohXyN9SDgFs7dDTBKZoAZiU"
        "0ec88osYIpI7JGBaPKObx6HY6Fwo0QcpI5JY5qZ5Gr//T/UTwdL5FSCgSK2M1995tmSwZAQZFToxXCjJNcexSCIRL8jSn7NpEpgc"
        "oHaxqUuiF/1vbwAYXR7Twa67A6+K8+N+BBHDEBSRVARKBMKrGZ03tCYIhaU5nQWUIYQKmhIbEloalTA9bZlxEWHML8smF2hXViFa"
        "Qhdw6j5YWgFkgqtWr7p1ZKS9vATV1lAY5hNyGgyLsDlwqDo6IrM9Xn1fry9tbGwPN00PI21RIzHFpJQxASRJLkIX21OhQOcP5MyI"
        "RkbOvXCpOH3hkWufLP/xD4ubleEA+tDQ0luevzF1qvb6N58cPp4TPmBolma3f/Xm1YX1UUGfwSoHJxGsnHkCvSRrLkwrEoxu8mTl"
        "qMp9gJJlyWG50ciqm+cu+M++PCGz4qmLx8uD+d++fWV5abglRlA3D/euvv79s8PjBS00KbfIm5Gp0sSpYH1rvTzYzGQEs57qFcPA"
        "5CqVfCsYCfnRFJQHlHmEiFwpjY7VNipoCsOTIsyqhaem5YXXHhI5bQMPTzzS/8M3zv3uF1c/nVlshD0TQ/6R8X4tW+5OBjzfE2Nj"
        "2duzt3/wxldGjpU90ixaujbNffzpj9+9OlsKxYAlj60/jIQLRIfKsquJ8EuDrH3p8eClrz+s8ijBB0tTLaFYLn73R899+QWvL7e0"
        "t73J2ot0ASPsocpqr1TKPnN++PDJcitr9lW7rlqtbOj3i0vfeLi3sEwVQKjTuhBibcMu5sruRiEZVFkvj3qZovGElrFIhoSVD+oQ"
        "fu07T156/aiQW7XVjQxSzUC7vn/rxu3rn90gvk6//DQ1Ns9mXLIJEIEMx6eGzk6XsqomXVVT6sBRBO9LW14540cXYa5aWdOGbujb"
        "UjARqYkURmTy3vlXH9vfXlxfWsln/bXKusyqsaNjSpolcaunnGcQLeomkjbt+eL5rz48++k/F9cKCD0sr9CpqIOoJOExsTC3U9FB"
        "09j4ndpZPnM2fPJTUoX5gdzqemWv3hw9Pj46cTxb9Le2Kv2H+2KRc1RAZqjgpRweLT0z3VfK1NmfdJVw0iBTCTJxL0DhVSom3A18"
        "YSSGTj6l/T1Rsb6zP/vZ3GPnHr/4yovl48OQ8zQYI3X/4cGtne3d3V3puvY9Hej0o8eyXhOS9trRjlTfiVXLuFAMqMp23+U/Lcz8"
        "Y62x0QyDMCp4ootury7fPXP6ofKRIZFFioDWYp8tZEaNn5zYrFQqm5to7u1PWK/tNNl6GU6gdQEQdYkIG5XqcGA1m2yK18Sx9z64"
        "+7cPVnqK4YnJzMnJvsmHBvvKhWZ9v6dYVMojk2FlwmlUlGLpwYkTE/M357GOfWNDGYAQtOs9lNrq3XqAJDjCQ2mDcYCYxBWoyCKx"
        "h7X92oFjChpPhGFYr+nqhxuffFwtFm6dmsifmcpMnZsMoBW1h260LeGk2VNvv/Xeq99+cfRMP/FeuD6KsHp3D7HM/RU9I8K4C0el"
        "y6hHRiSSZCeAEH0paVGyIYZ29am1rdNXruidjXaxVKRGiHFbRrcADgOd3t+erd1cGPr1z66tXN9RTU81TGNlf/GT6sJSYKhDURwS"
        "4m7pWmtEFWUnD2OxMMYBFLnrqITZVFJQRhYL+NjZKcqDoj7sKovbtbvULoOlXs1+utsy48sb4uc/mR0cbm9Vd4NmPmwX9oMhbduT"
        "kDrWdkjzNkqQW10cCIqUy5L8Wy8Lzakz2aFj/fRoxckGm3X+YShlSKMDlZuAtaXV2lZBQK6NuZXdwsZuAzBrRNZYyKTVZuToqRYJ"
        "HJMkx9ojXrdxuWfp6YThph8XdOh5e5NTA/MLN/lGrgzo5xSKMWMnj8tcjqSMkLszu7rTyHMfpvhosjF9jrS2HTuJZTCNa9l0wvoR"
        "aQ9lUgcajF0jJBziFikNmP07q+tnnpvu7S3xmBSnr7K6Eew1DmWyJhS6LeZmqu1wnH0ChWNvAzaViW22bxi76YicjJYERWUSPT6e"
        "SJ3/TooCvVBi8/SE//xL5/OlbADanbHhyFJv75X3Ptqubu+th3utwflbdDqPrEF0iZKAscuM3GNMkjgKkRQSSDvrMOSsbWjbVdfM"
        "x5Bk5O6580cOjRzSYEXZiQI/xvg5VR4Zeurcs0fHx3Zqdd00OdOUDoyYBCLuxMm77IwZ1k3bHKpk2HLDqR2So0S5YFhOMXN76e4p"
        "MerZxg5xdqxqYq4/p7LZ6dfOPvGCnvnozuW/3FmoZtqm0OlxaYOYdpHQMdayg8rnjxKAXgClz2Za7e0GRC464pPjQr5YbDb3aL7z"
        "BzJPXDo5ffGw8kO6Mc/oqeO+JjqpZauE+MBQ6AK/sn3o+se3nfPB1EGLKRRLrUbL8NRP3Uq32vQ3oeFLkAea8H2DiR0v2OKmSRid"
        "KdF2ZmEgpc225R0NxyIw/TNXKmZP2+px7R9tLo3yPN0OhAnpO4q02WjbnRDy1Z3+Ek/NMnLSsTdw9eKSRFSn32sOglXEuPHJVr37"
        "aNsdkyK/sqQ2l2seQjRdOcG3uJV68vXtHeuYZH0v5OGOJfXAeNE1pyWTWWJgpIehx5MWuzh+WWBIRvklnKekBVJMXr01+O8rywwF"
        "v5TVQ06eRsz19uzt7LLPCLG+oz3pR533AUN0tJ/FRYNWfWNgDDh4OOXJi+LjCwhtLQtzMzu7tX3XI2KXw9OHLGSJI5QsKoTaVtOi"
        "idY2dvyhK9AD+2eWbcKxlVSoxRrNkzHyBoLdOZAQRx1Plijp2bKy5S/eqDzy9FEyz9IKgbR0aW6Z+Wu1udm5nVq4vTdk0AcBBybR"
        "+7jZeHvASggoD9qSLA7H4BagU0LgJl57gtUPgrD/X5dXysXCoRNFLIAvpWmYqx+ufPj3zfVVDIKQOp82ZbtX0hmXRdeIamkWLdY9"
        "L+rGNhTR5qRwQGE82mO8IRPviEQzeH7x1v4v37w6NK4efXKsbyD//uXZuRkvEOOhKCKb8IDmvwft+nR13FjeOUE0KQWS56W24PfO"
        "nATR/JC0Ef5NUw60gvL+fH15ftXIkGY+DWUSHom+sS4GrQsAeW82sLO7I+KNxqiILFdoPAbR5CD4VGDbh4nnnnuqwEk9V1ohFAVD"
        "xSM9W7SkBQF9QGdBAA5sH3RrJti9OBan9BVKChoIWoBt1lGacRiEMBL1aBY5qA7k/A2bDp6LNNNBR9bd+iMDqT0dxJguUS1F5trZ"
        "QzsmxdsvxBXR5mkSwrFjRy5cVODKyKFCT7MQYSzQ8U4aRFuH7A0960w8lxbe7SNzR99wniR2nHKnrF03RvLNdEYHSeUTKhwKzfy/"
        "eev3gkE2dnvFCr7bhgNESDUvG0G0VcPPZp/L78gIsf7wnZUdICBaceRQZQdX8COyml7S6ggVYuvQQFacJjEAjPmNKa5j6hsDHueL"
        "Fy3dywbhk5BQL6L5zEZDeuOHNhQdbWti9zBMqHjOopGNTHZZ6K+wPJgfHMxoKymxe7EztkuT6XQQSgTjz+Xq0eRmxygfMaM1GWkV"
        "UiiaAPM1/00xeXb7Sprutg+d7WS2tNYdkMWQ/wGQVZZaKTnIjgAAAABJRU5ErkJggg=="
    ),
    "fountain": (
        "iVBORw0KGgoAAAANSUhEUgAAAHIAAAAgCAAAAADr8HNdAAAB7klEQVRIx+1VrXfCQAy/8nhghpoaCsUUCrUp1GY2heoUihncMJMz"
        "KBwKNbcZ+AOYmdsMalPM1KHAlJliQnvJXe/g2q6PjxkiLne5XNIkv6SMHelIR/ov+gKIu74BQZOduQysmeQZZOdSUE5vuxkZzmXM"
        "q56MEtK7nKZ7RFGebpPBs3Tq2XBrHQhWFGVuXV75AK9B+wZAhQDxiMxmrOjBlAsngFBB3Y4DTlXCp4TcX2yAvu5hoBexTnUd8VMN"
        "oExGemSrivc5AiZhoKvhge59PhipMMkaYx8QvxK1ypPghPgYmacX41P2hy6vmxK7lJ/LXzDWtnziO8YWvm1S/yU+x2sOAYsvwTq0"
        "rFAuzAb06kvbjLmq52etR5TUdHBOVNYSy0xcmQFxahn9cwT9iE2AlzwltJCMxpKxs4emxGKGKCtFxr655E1/uUj0OHGM4mVUX4bT"
        "ROCmLF3xUWEnTlVsbnc9Hbko+KiEj/y2usXL6+D4kpzYJ2MBClEzNjx5eHrXCx+UKQo+TUXgbMBnZIKPTnlUqClDMGHe98W1GDka"
        "eVHwUciaa2P3PmxAo7b4M7TxeCcBX4r5ytZGFGNQS+dSqloR/ejNbHoVrA947Qq17l8StS3N9mrd3C7u4V1C4v/ykJTZX5y1iziA"
        "795hjPUVd5gty1GJ+LwAAAAASUVORK5CYII="
    ),
    "gacha": (
        "iVBORw0KGgoAAAANSUhEUgAAAIYAAAAcCAAAAACB75hoAAACfElEQVRIx+1Vr3cbMQz2Bo4FHVpR0IaKgsKKNpKhQ2VBRWFBY0FF"
        "YYcyEhaUkrCiG8pIUIdu5IaMPBLmEk22JP9I7g9Y3zu9l1iybPnzZ0mn1CCDDPIm5RFgL/qdBfMsBoD7r82ZXGQG2QLARzHWAOfM"
        "1UqIpR+tbB7jrrseEPfg5egNQ0bnjRvaujuDduMqgwEsbGpU16zvyKNp2VyWk/OImr1GsfXHAjTuXCPBPSElbdUc4lsK44zHJDA+"
        "O5UJeHa6rQXGKocBcLhgleOd0tgz5qTC4ZbWCz0pDJyqVcZNxU+oCj5xxI5dBsMFibwFaVJoAA+i6JgMAFsDVzA2KochmeTozRyn"
        "LDdOuLG+pgP0Muij4N55bSEw8IfP+RB3I8CyB0ab0S8s2DSL/BBXvOfx9UNIdhW1v/TgAZ/6XpTqKQb/JUtmE6Ja/VTqqwR4zW9a"
        "pJnYM+ekg21auNlTrYQNfGaXHfESk5g1lqIsPPE0+dhTUMzGAYyfbC7YkGs5+RG0T/6/FRPz9vc4Bc/3/ePqyDcDVU1H80KtVEzO"
        "EPWdEza+qHJzc4+vel2vKfSDSvI7pGhFfShLUSqA2mdgnd74rLuMjbX0lYycHKprUcYrJRXqlCu/oGZAW0sJkHLdEow9lQHWtKEF"
        "a80NZJK2L+N98wCjvaDDGLDa8hG42BjXlvxd5wJjKhfJ2hd2Xku5IXVDvQode2ztsrnmQgWPuku5SaUieJYLMRpqKZH8F2cDvc0c"
        "y2kWO6RW8Y06bjpcCpCk77SvkWKF2JkYp30jtVO+vPivQHtLhxyzvVWL1C0KX1dGKKLPW4GsNmOV3IFg1CEn+mAMMsgg/7n8A66a"
        "R7gKRpLzAAAAAElFTkSuQmCC"
    ),
}


def _fs_refs():
    global _FS
    if _FS is None:
        import base64
        _FS = {k: cv2.imdecode(np.frombuffer(base64.b64decode("".join(v)), np.uint8), cv2.IMREAD_UNCHANGED)
               for k, v in _FS_B64.items()}
    return _FS


def fs_menu_region(icon, buttons, bounds):
    """Где искать меню телепорта: справа от кнопки телепорта (icon — её центр на экране)."""
    _cx, _top, h = _game_box(buttons)
    return _set_region(icon[0] + 0.03 * h, icon[1] - 0.10 * h, icon[0] + 0.42 * h, icon[1] + 0.42 * h, h, bounds)


def fs_gacha_region(buttons, bounds):
    """Где искать заголовок окна COIN GACHA: верхняя половина экрана, по середине."""
    cx, top, h = _game_box(buttons)
    return _set_region(cx - 0.60 * h, top + 0.08 * h, cx + 0.60 * h, top + 0.55 * h, h, bounds)


def find_tp_icon(img_bgr, game_h, offset=(0, 0)):
    """Кнопка телепорта на снимке set_icon_region (тот же левый столбец, что у кнопки аксессуаров):
    (оценка, (x, y) её центра на экране или None). Кнопка есть, если оценка >= FS_ICON_MIN."""
    small, f = _set_work(img_bgr, game_h)
    peaks = _set_peaks(_chroma(small), _chroma(_fs_refs()["tp"]), _S_ICON_REL, 1)
    if not peaks:
        return 0.0, None
    v, x, y = peaks[0]
    return v, (int(offset[0] + x / f), int(offset[1] + y / f))


def _fs_text(img_bgr, game_h, name, offset):
    f = min(1.0, _FS_TEXT_H / game_h)            # надписи тонкие — сверяем крупнее, чем иконки (как на экране 720p;
                                                 # экран ниже 720p не растягиваем)
    w, h = max(1, int(round(img_bgr.shape[1] * f))), max(1, int(round(img_bgr.shape[0] * f)))
    small = img_bgr if (w, h) == (img_bgr.shape[1], img_bgr.shape[0]) else cv2.resize(
        img_bgr, (w, h), interpolation=cv2.INTER_AREA if f < 1 else cv2.INTER_LINEAR)
    peaks = _set_peaks(_whiteness(small), _fs_refs()[name], _S_REL, 1)
    if not peaks:
        return 0.0, None
    v, x, y = peaks[0]
    return v, (int(offset[0] + x / f), int(offset[1] + y / f))


def find_fountain(img_bgr, game_h, offset=(0, 0)):
    """Пункт «Fountain» в меню телепорта на снимке fs_menu_region: (оценка, (x, y) середины надписи или None).
    Меню открыто, если оценка >= FS_TEXT_MIN."""
    return _fs_text(img_bgr, game_h, "fountain", offset)


def find_gacha(img_bgr, game_h, offset=(0, 0)):
    """Окно COIN GACHA на снимке fs_gacha_region: (оценка, (x, y) крестика или None).
    Окно открыто, если оценка >= FS_TEXT_MIN."""
    v, pos = _fs_text(img_bgr, game_h, "gacha", offset)
    if pos is None:
        return v, None
    return v, (int(pos[0] + _FS_CLOSE[0] * game_h), int(pos[1] + _FS_CLOSE[1] * game_h))


# ---------- обновление ----------
# Макро сам узнаёт о новой версии: читает update.json из репозитория автора на GitHub и, если там версия новее,
# предлагает обновиться (окна — в macro_gui.pyw). Обновление — тот же zip, что автор выкладывает для скачивания:
# из него берутся только файлы макро (UPDATE_FILES), настройки (macro_config.json) не трогаются, старые файлы
# сохраняются в папке old_version. Адрес зашит здесь; update.json может назвать только имя файла в этом же
# репозитории, а не другой адрес. Версию для выпуска поднимать здесь (VERSION) — см. dev\update в папке Mac-версии.
VERSION = "1.4"
UPDATE_PLATFORM = "mac"
UPDATE_BASE = "https://raw.githubusercontent.com/skibiditoilettungtungsahurheaven/merchant-macro-v1/main/"
UPDATE_MANIFEST = "update.json"
UPDATE_FILES = ("macro_gui.pyw", "potion_macro.py", "platform_io.py", "README.txt", "start_macro.command", "mac_check.command", "mac_check.py")
UPDATE_NEEDED = ("macro_gui.pyw", "potion_macro.py")      # без них архив обновлением не считается
UPDATE_MAX_ZIP = 40 * 1024 * 1024
UPDATE_MAX_FILE = 8 * 1024 * 1024
UPDATE_OLD_DIR = "old_version"


def version_key(v):
    """'1.10.2' -> (1, 10, 2): версии сравниваются как числа, а не как текст."""
    import re
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:4])


def _http_get(url, limit, timeout=15):
    """Скачивает адрес целиком (не больше limit байт). Только https."""
    import urllib.request
    if not url.lower().startswith("https://"):
        raise ValueError("not an https address")
    req = urllib.request.Request(url, headers={"User-Agent": "MerchantMacro-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("the file is too big")
    return data


def check_update():
    """Есть ли версия новее этой. Возвращает (сведения, ошибка): сведения = {"version", "file", "sha256"} или None,
    если обновления нет; ошибка — текст, если проверить не получилось (нет интернета и т. п.), иначе None."""
    import urllib.parse
    try:
        data = json.loads(_http_get(UPDATE_BASE + UPDATE_MANIFEST, 200000).decode("utf-8-sig"))
        part = data.get(UPDATE_PLATFORM) if isinstance(data, dict) else None
        if not isinstance(part, dict):
            return None, None
        ver, name, sha = str(part.get("version", "")), str(part.get("file", "")), str(part.get("sha256", "")).lower()
        if not version_key(ver) or version_key(ver) <= version_key(VERSION):
            return None, None
        # только имя файла в том же репозитории: без папок, без других адресов
        if (not name.lower().endswith(".zip") or any(c in name for c in "/\\:?#%") or ".." in name
                or len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha)):
            return None, "update.json is damaged"
        return {"version": ver, "file": name, "sha256": sha, "url": UPDATE_BASE + urllib.parse.quote(name)}, None
    except Exception as e:
        return None, str(e)


def download_update(info):
    """Скачивает архив обновления и сверяет его с контрольной суммой из update.json. Возвращает байты архива."""
    import hashlib
    data = _http_get(info["url"], UPDATE_MAX_ZIP, timeout=60)
    if hashlib.sha256(data).hexdigest() != info["sha256"]:
        raise ValueError("the downloaded file does not match update.json (the update may still be uploading — "
                         "try again in a few minutes)")
    return data


def read_update(data):
    """Достаёт из архива файлы макро: {имя: (байты, права)}. Берутся только имена из UPDATE_FILES (в корне архива
    или в одной папке), остальное — картинки, __pycache__, настройки — пропускается. Файлы .py проверяются на то,
    что это рабочий Python, чтобы битое обновление не сломало макро."""
    import io
    import zipfile
    out = {}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for i in z.infolist():
            parts = i.filename.replace("\\", "/").split("/")
            name = parts[-1]
            if i.is_dir() or name not in UPDATE_FILES or name in out or len(parts) > 2 or ".." in parts:
                continue
            if i.file_size > UPDATE_MAX_FILE:
                raise ValueError("%s is too big" % name)
            out[name] = (z.read(i), (i.external_attr >> 16) & 0o777)
    missing = [n for n in UPDATE_NEEDED if n not in out]
    if missing:
        raise ValueError("the update has no %s" % ", ".join(missing))
    for name, (body, _mode) in out.items():
        if name.endswith((".py", ".pyw")):
            try:
                compile(body.decode("utf-8-sig"), name, "exec")
            except Exception as e:
                raise ValueError("%s in the update is broken (%s)" % (name, e))
    return out


def install_update(data, folder=None):
    """Ставит обновление из архива в папку макро: старые файлы — в папку old_version, новые — на их место.
    Сначала всё проверяется и записывается рядом (.new), и только потом файлы меняются местами: если что-то
    не так, папка остаётся как была. Возвращает список заменённых файлов."""
    import shutil
    folder = folder or HERE
    files = read_update(data)
    old = os.path.join(folder, UPDATE_OLD_DIR)
    os.makedirs(old, exist_ok=True)
    try:
        for name, (body, mode) in files.items():           # 1) новые файлы рядом
            with open(os.path.join(folder, name + ".new"), "wb") as f:
                f.write(body)
        for name in files:                                  # 2) копии старых
            if os.path.exists(os.path.join(folder, name)):
                shutil.copy2(os.path.join(folder, name), os.path.join(old, name))
    except Exception:
        for name in files:
            try:
                os.remove(os.path.join(folder, name + ".new"))
            except OSError:
                pass
        raise
    for name, (body, mode) in files.items():                # 3) замена
        dst = os.path.join(folder, name)
        keep = (os.stat(dst).st_mode & 0o777) if os.path.exists(dst) else 0
        os.replace(dst + ".new", dst)
        if os.name != "nt" and (mode or keep):              # право «исполняемый» у файлов запуска на Mac
            os.chmod(dst, mode or keep)
    return sorted(files)


def restart_macro():
    """Запускает окно макро заново (после обновления). На Windows — новый процесс (этот вызывающий закрывает сам),
    на Mac — на месте этого процесса: окно Терминала и выданные ему разрешения остаются теми же."""
    import subprocess
    import sys
    gui = os.path.join(HERE, "macro_gui.pyw")
    if os.name == "nt":
        subprocess.Popen([sys.executable, gui], cwd=HERE, close_fds=True)
    else:
        os.execv(sys.executable, [sys.executable, gui])


# ---------- конфиг ----------
def load_buttons():
    if os.path.exists(CONFIG):
        with open(CONFIG, encoding="utf-8") as f:
            return [tuple(p) for p in json.load(f)["buttons"]]
    return None


def save_buttons(btns):
    with open(CONFIG, "w", encoding="utf-8") as f:
        json.dump({"buttons": btns}, f)


# ---------- главный цикл ----------
def main():
    buttons = load_buttons()
    print(__doc__)
    log("Калибровка загружена." if buttons else "Нет калибровки — нажми F7 три раза (см. выше).")
    running = False
    calib = []
    next_scan = 0.0
    for k in VK:
        key_pressed(k)  # сброс

    while True:
        time.sleep(0.05)
        if key_pressed("F10"):
            log("Выход.")
            return
        if key_pressed("F7"):
            px, py = pio.cursor_pos()
            calib.append((px, py))
            log(f"Кнопка слота {len(calib)}: {px},{py}")
            if len(calib) == 3:
                buttons = sorted(calib)
                save_buttons(buttons)
                calib = []
                log("Калибровка сохранена.")
        if key_pressed("F11") and buttons:
            save_debug(buttons)
        if key_pressed("F9"):
            if not buttons:
                log("Сначала калибровка (F7).")
            else:
                running = not running
                next_scan = 0
                log("СТАРТ" if running else "ПАУЗА")

        if not running or time.time() < next_scan:
            continue
        next_scan = time.time() + SCAN_INTERVAL

        if OPEN_KEY:
            press_key(OPEN_KEY)
            time.sleep(1.0)

        region = scan_region(buttons)
        img, off = grab(region)
        res = find_potion(img, buttons, off)
        if not res:
            log("Зелья уровня нет (или окно торговца закрыто).")
            continue

        slot, pos = res
        log(f"Level Potion в слоте {slot + 1} — покупаю!")
        for n in range(CLICKS_PER_BUY):
            click(*pos)  # клик прямо по колбе
            log(f"  клик по колбе {n + 1}/{CLICKS_PER_BUY} ({pos[0]},{pos[1]})")
            time.sleep(0.5)
        log(f"Готово. Следующая проверка через {SCAN_INTERVAL} сек.")


def test(path, pts):
    img = cv2.imread(path)
    buttons = sorted(tuple(int(v) for v in p.split(",")) for p in pts)
    res = find_potion(img, buttons)
    print("Результат:", res)
    if res:
        cv2.circle(img, res[1], 25, (0, 255, 0), 3)
        cv2.circle(img, buttons[res[0]], 12, (0, 0, 255), 3)
        out = os.path.splitext(path)[0] + "_result.png"
        cv2.imwrite(out, img)
        print("Сохранено:", out)


# Образцы названий товаров (со скринов, см. name_feature)
_REF_META = [('epic', 10.1), ('epic', 10.062), ('epic', 10.077), ('epic', 10.091), ('epic', 9.85), ('epic', 9.812), ('epic', 9.769), ('epic', 10.8), ('epic', 9.85), ('epic', 9.812), ('epic', 9.769), ('epic', 10.8), ('flip', 12.25), ('flip', 13.083), ('flip', 12.5), ('flip', 11.778), ('flip', 12.25), ('flip', 13.083), ('flip', 12.5), ('flip', 11.778), ('flip', 12.25), ('flip', 13.083), ('flip', 12.5), ('flip', 11.889), ('fortune', 10.211), ('fortune', 11.143), ('fortune', 10.583), ('fortune', 10.7), ('fortune', 9.947), ('fortune', 10.786), ('fortune', 10.167), ('fortune', 10.3), ('heads', 9.706), ('heads', 10.154), ('heads', 10.7), ('heads', 10.0), ('heads', 8.947), ('heads', 9.067), ('heads', 9.167), ('heads', 9.4), ('heads', 9.444), ('heads', 9.067), ('heads', 9.167), ('heads', 9.3), ('large', 12.312), ('large', 14.273), ('large', 14.222), ('large', 12.0), ('large', 12.312), ('large', 13.083), ('large', 14.111), ('large', 12.0), ('large', 12.312), ('large', 14.273), ('large', 14.111), ('large', 12.0), ('luck', 9.1), ('luck', 9.125), ('luck', 9.0), ('luck', 10.0), ('luck', 9.1), ('luck', 9.062), ('luck', 9.0), ('luck', 10.0), ('luck', 9.1), ('luck', 9.062), ('luck', 9.0), ('luck', 10.0), ('money', 10.833), ('money', 11.071), ('money', 10.583), ('money', 10.8), ('money', 10.833), ('money', 11.143), ('money', 11.545), ('money', 10.7), ('pliers', 8.176), ('pliers', 8.538), ('pliers', 9.0), ('pliers', 8.444), ('pliers', 7.579), ('pliers', 7.667), ('pliers', 7.75), ('pliers', 7.9), ('pliers', 7.579), ('pliers', 7.667), ('pliers', 7.75), ('pliers', 7.8), ('roll_luck', 10.765), ('roll_luck', 11.231), ('roll_luck', 11.8), ('roll_luck', 11.111), ('roll_luck', 10.889), ('roll_luck', 11.214), ('roll_luck', 10.583), ('roll_luck', 10.8), ('roll_luck', 10.889), ('roll_luck', 11.214), ('roll_luck', 10.583), ('roll_luck', 10.8), ('scroll1', 11.0), ('scroll1', 10.533), ('scroll1', 11.636), ('scroll1', 10.9), ('scroll3', 10.421), ('scroll3', 11.286), ('scroll3', 10.75), ('scroll3', 10.9), ('scroll3', 10.421), ('scroll3', 11.286), ('scroll3', 11.727), ('scroll3', 10.9), ('scroll3', 10.421), ('scroll3', 10.533), ('scroll3', 11.727), ('scroll3', 10.9), ('small', 12.375), ('small', 13.167), ('small', 14.222), ('small', 12.0), ('small', 12.375), ('small', 14.364), ('small', 14.333), ('small', 12.0), ('small', 12.375), ('small', 14.364), ('small', 14.222), ('small', 12.0), ('super', 13.0), ('super', 14.182), ('super', 14.111), ('super', 11.889), ('super', 13.0), ('super', 14.182), ('super', 14.111), ('super', 11.889), ('super', 13.0), ('super', 14.182), ('super', 14.111), ('super', 11.889), ('ticket', 10.842), ('ticket', 11.786), ('ticket', 10.308), ('ticket', 11.3), ('ticket', 11.706), ('ticket', 13.333), ('ticket', 12.9), ('ticket', 12.111)]
_REF_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAMAAAAuQCAAAAAB5Pm/WAAAgAElEQVR4AczBvdEjqQIAwFbVhIJBKBiEgkEoGISCQSgYhDLGG2mk"
    "/fl2t27vWdf98H9aweHfaUWenHb090pTuz96EJaZ/VYr3g5frGBHX4XlpXa/akWenHZ0a8XL4c9Ko3Z/8nBiZr/VirfDFys4/Cos"
    "b3n6ohV5ctrRrRVvO/ritKNLaWr3R4/TZWa/1Yq3w18Jyzd5+lkr8uS0o1sr3nb0xWlH/+xxuszst1qRp38hLGamFfL0s1bkyWlH"
    "t1bIk5Md/ey0o3/2ICwzu7QiT047urUiT7ewzKw0tbus4PBSmtrdwmJmtCJPT6cdvbQiT047urVCnjjt6Kk0tWMFTzMrTe1eTjt6"
    "Kk3tRhL3g7DM7NIKcTvt6NaKPN3C8pYnVnC4lOYpT09hMTNakSdOTzO7tCJPTju6tUKeOO1IGl7ytIKnmZWmdpcVXHZEaWpKLseD"
    "sMzsaSRxr+Dw1oo83cLykScrOJCGpzy9hMXMaEWerOBlZrQiT047urVCnjjtKA1vea7gaWalqR0reJmZ0nw8CMvMnkYijuDw1orb"
    "QVj0SivyZAUHadCrb8JiZlohTytwCIteaUWenHZ0a4U8OdlRGnqlFXly2tGlNLUzEoewmFlp5GkFHoRlZi8juRw+WnE7CIteaYU8"
    "reAgDb36LiwfebKCA2nolVbkyWlHt1a87UgaeqUV4nba0aU0tTOSuAnLzEpTO1bwICwzu42Ew0crbgdh0SutkKcVHKShV9+F5a12"
    "rOBAGnqlFXly2tGtFW8HadArRhK3044upamdkcRNWGZWmtqxggdhmdltJA7ftCJPt7DoFa3I0woOadCr78LyVjtWcCANvdKKPDnt"
    "6NaKl8MlDXrFSOJ22tGlNLUbibgJy8xKUztW8CAsM3sZyeXw0Yo83cKiV1ohTys4SEOvvguLmZWmdqzgQBp6pRV5ctrRrRXydEuD"
    "XjGSuJ12dClN7YwkbsIys9LUjhU8CMvMXkZyOXy0Ik+3sOiVVsjTCg7S0KvvwmJmpZEnKziQhl5pRZ6cdnRrhTzd0qBXWiFupx1d"
    "SlM7I4mbsMysNLVjBQ/CMrOnkcS9gsNbK/J0C4tetUKerOAgDXr1TVjMTCvyZAUOYdErrciT045urZCntzT0Sivy5GRHlKZ2RuIQ"
    "FjMrTe1YweN065WRxL2Cw1sr3g5h+ciTFRxIw0uensJiZlohT1bwMjNaIW4nO3pphTy9peEtT06XmZWmdqzgZWZKUztW8DjdetWK"
    "PDnt6NaKt0NY3vLECg6X0jzl6SksZkYr8sTpaWaXVoib045eWiFPH2l4ydPlxMxKU7vLCi47ojS1YwWP063XVsiTkx29tOLtEBa9"
    "lla7pxUcXkpTu1tYzIxWyNPltKPbSOLGuaOXVsjTd6VRu1tYZlaa2r2cdvRUmtqxgoe/FRa9+q95+Fth0av/mof/00mv/pWR7Egr"
    "O/oXVjCzP3loAdlvheZWty9OevWL0Lz16YuR7EgrO3oryVv2RWjqdllh1u1PHi0FHH4rLLe4fVGCOf0iLG+zTz8byY60sqO3Vrz1"
    "6mdhydOlhDn90WMIgcNvhWVvl7r9nbDs7ZL06mcj2ZFWdvTWiukSgrj9JCx5+kcPWuHwW2GJ278RljxdRurVz0ayI63s6K2VHV3S"
    "ELefhCVP/+hBKxwuYclTWPJ0C0vcPk45NOSJk15dSkPtbmHJ02WkXl1KQ+0uI9mRVnb01sqOLmmI22UFdkQaLr2ygpld0kDtLq3s"
    "aCQ7PmiFwyUsu/ew5OkWlrh9nLaAXScnvaKUgNrdwpKny0i9opSA3TtGsiOt7OitlR1d0hC30CSXmUnDpVdWMDNSC9izohVTwnzQ"
    "CoenVvQaVu/bLSzdU984zY2idk56pZSwJ327hSVPlBJ6pRSTFObsjGRHWtnRWyu7d1Iq4paGTkh636EU3ZysYGZSCZMUdu+0Qick"
    "D1rh8DLCnEbc3sJyixunPLFC7Zz0ygp7Vt+FpW4Mu3dW6JWWwsyMZEda2dFbK2RSMesOqYlbKkmewpKnywp7VkaamZbCjrRiZkrz"
    "oBUOt5EQt7ew3OLGKU+sUDsnvbJCr34QlrfasUKvaGVmRrIjrezorRVvB6URN2HJU1jydFmhV4w0M1rZkVZ2RGketMLhNpIdfROW"
    "uH2c8sQKZnbSq5Ne/SAstzxx0itamZmR7EgrO3prxVOvLqURN2HJU1jydFnBzFYwM1rZkVZ2RGketMLhNhIz+whL3D5OeWIFMzvp"
    "1UmvfhCWuhnyxEmvaGVmRrIjrezorRUye7uURtyEJU9hydNlBTNbwcxoZUda2RGledAKh5dSAuL2Fpa4fZzyxAqzTye9KiX06gdh"
    "yVNY+pyUEnpFKzMzkh1pZUdvrezevZVG3EIp8hSWPF1WMLNSwsxoZUda2RGledAKh5cVtiBPb2GJ28epzi0NtXPSKyvMun0XljyF"
    "ltSOFWbdQkszM5IdaWXX6dbKjj5SC/LeaZh1C0udGyuYmZF2nUIpO9LKjijNg1Y4vKzQ5yBPt7DE7eOk17ConZNeWcHMvgtLnjjV"
    "jhXsaAUzM5IdaYXDrZUdfZMGeabhQFjUjhXMzEh2NJIdaWVHlOZxuuUpLHkKS55uYXnLk9MtT5z0ilY89eolLHnipFe04qlXl9J2"
    "pBUOt1Z29F1YXg5PJ3a0gplRmqeZ0cqOKM3jdMsztCRPYdl1egnLW56c6g5Nni4nvSKE0Oh9ewlLnkgt9IpQCnXv7RJSm3WH1My6"
    "PbWyox+kFsxuekotzLqtYGaE1Kh7b7SyI0rzaG59h0LfNOb0Eoq3vjnlGYrqqQRzegqFvr01fbuUMKdLKPTtFopKKPTtKaXd/agE"
    "c3orYU5KsLtLKPTtKaXdEYqHv3fK03/Nw9875em/5oHTjn5rJLe4fbWCuH21gtvhF6cdMZI83U4vtfuzNPTqTx6FZke/NZJb3L4q"
    "QfWLFdzq3L447YiR5Ol2epnT3L4oc3sKxZz+5HG67Oi3RnKL299ZwVvtvjjtiJHk6Xb6yNPPwqrdP3sElh391kjydtn+0gqip2VH"
    "PzvtiJHk6XYSXcLI08/CMrN/9MBpR5eQ7Ckkc7uNJE9vIbnN7ZJMLwVzu60gbpfTjkjBpXs67YiR5Ol2criEladLCi4dKTS7z01I"
    "9nQJiT1dQrJnCsz9wGlHlzTMrDS9uo0kT2+lueXpsmb1ciJPtxXE7XLaESO5xO1y2hEjydPt5HAJK0+XFVwOtOKSJ2no1aUVdnRJ"
    "w8wr0OsDpx09hbGz0qLtNpI8vZXGzi3ZO2PNikXo3fa2grhdTjsKI8wqtT0rTjtiJHm6nRxoKeRJamFWpezehTDsvJGGXpVCiC3t"
    "OkmDXbe1PXDa0cvaXSqHj5HU7TJRmj1rScnMWLPiZPbpmxXU7TL2rMIys1TS7JPTjhhJnm4nGSXJU0plzq40tRPWntUlDb0qzd65"
    "pNTnlIa963bywGlHLyu4HD5Gcoub0tROWGbGmhUnhx+s4K12wjIzVnBw2hEjydPt9JGnkcRNaWonrNo9paFXpamdsOwoDTPj5IHT"
    "jl5Cajh8jKRul4nS1E5YZsaaFSeHH6zglvcmrDo3VnBw2hEjydPt9NKnyUjiJoRRO2HV7ikNvSpN7YRlR2mYGScPnHb0ElLD4WMk"
    "eXorTe2EZWasWXFy+MEK9pY4XMKqc2MFB6cdMZI83U4m+nQZSdwuZ+2EVbunNPSqNLUTlh2lYWacPHDa0csKLoePkeTprTS1E5aZ"
    "sWbFyeEHK4jbyeESlpmxgoPTjhhJnm4nh4+RxO1y1k5YtXtKQ69KUzth2VEaZsbJA6cdvazdW3D4GEme3kpTO2GZGWtWnBx+sIK4"
    "pZJmn4RlZqzg4LQjRpKn28nhI6USN6mk2glrz+qShl6VpnbCsqM0zIyTR2DZmU0YO48Qou02kjpdNkrTO2HsnbFmxRIitrcVxE0r"
    "aieMMCtG2JEVxM1I6txeTg7fpJE3paidsOy8kYZelRJ6J4y9szTMjJPH6bajNMysNL26jeQWN6W55emyZnVpxSVPtxXETStqdxnJ"
    "U68urajdSMzs5eTwTRputRMW8iQNveL0kidpmBknj9NtR2n0OYXUenUbyS1uSjNns/vcLmtWl5Aa8nRbQdyE1OauSKmg7unSitql"
    "VMzs5eTwTUhCMae5UVKSJ2noFSUldp+bNMyMk8dy21lqebus3t1acsub0tQ57Oxl7OploU63RfS0iC6pIW9PLemdMOzsZRH9KDWz"
    "urWkTlIzq0spiC6pmRWLh79Wmtr91zz8tdLU7r/m4a+Vpnb/NQ//ryX6d0Y6XJbo3ygtT3/0ILD9XvC2/WKJfhW8bb8YKdos2XYL"
    "3rZfBNtTaXn6o4c0iNtvteJ2+MUS/ao0tzx9NZKZWUGvbiN52dEvzpk9lZanP3qUUIjbb7VCd6l+0VS/Ko25pdDn9MVIZmYFvbqN"
    "ZE+Kuqcvzpk9pdS3P3qcLnH7rVbs6N8ojYNWOHwxkplZQa9uI5mZFczsi3Nm/+xRSCluT0V3abu7tdJ391FCDYW+PbXdPYXiUt1K"
    "4yCFEg5PodC3p5HMzAp6dRup7knRZkYoLtWlhLInfUupb08lYE6EQg2Fvh9oJW5PS3Q5Z3ZrJW7fjHSkQdyelugpDezoVhqHy0iH"
    "p7DI09NIZmYFvbqNdHgKa2aE5XK4jOQpbqXl6Wkk1I7SiBZ5PtBK3J5WmLO30Pd2a2Xu6mOkuWdJU3ZZossIoU+mW2kcLiMdlEQn"
    "BbsykplZQa9uIx0uLaSZGdLsJc1dGcnsTErLE6kkObS961Yac89U9n6glbg9raDXkQ4frdjRx0hmbsWOLkt0OandN6VxuIx00Iod"
    "GcnMjGRmVtCr20iHywpmZgW9jmRmRjKzp9LyRGkcaRC30rBjaTzQStyeQhh2cPhohe0SXUaKmzBElyUyQph1+640tkvdm1bsyEhm"
    "ZiQzs4Je3UbaLmHnjSVvwrJ7F9bMnkrLUxhB3lsoJW6lEe3SeKCVuL2E5XL4aIXtEl1GOlyWvLFERjKzH5TGDsgTrWyRlsLMjGRm"
    "Vtizuo3EdokuS3Q5qZ1zZk+l5SkN8kQrcSuNuJUSPNBK3F7Ccjl8tGJHHyMdLivolSUykpn9oDSONMgTrcTt6ZyZkczMEn2MZGYf"
    "S3Q5qZ1zZk+l5SkN8kQrcSuNuDHSA63E7SUsl8NHK3NXHyMdLivM2VkiI5nZD0rjCC2EPNFK3ZMQxsyMZGaWurfbSHNXH0t0Oamd"
    "c2ZPpeUpDfJEK3Erjbgx0gOtxO0lLJfDRytx+2akw2WJLktkJDP7QWkctJInWrEjI5mZkczMCnp1G+nw3RJdTmrnnNlTaXlKgzzR"
    "StxKI26M9BBSSnF7KgIpHD5a6bv7GKnumUIRXZZICWX3uYvuVhoHrfTdSansGFIJfXdGMjMr6NVtpMN3S98zhbbnnJy7z43S8hRK"
    "SH33kFKKW2nEjZEe0iBuT0tkpMNHK3b0MZKZW7GjyxJdTmpfoltpHLTC4bLE0jhcRjIzK+jVbaTDdyvodSQzu5zUjtLyRGkcaRC3"
    "0ogbIz1aSMxtd5ZICmF3t1boLtVlpCqkUPd0WaJLCWXPvadbaRyEVMLhkkIIqe/ukkKbmRRar24jHb5Loe2ZQt3TpYQyd99KyxMh"
    "ldBtOqURN0Z6nG4zs0SXc2a3VtwOl5GONIjb0xI9pUHc3krjcBnp8BQWebqdMyOsXt1GOvwgLJfDLQ3iVlqenkYys6fSiBsjPYK3"
    "TbBdgu0WvG2XkQ6B7SXYXgLbR8B2CbaXwPYWbJdguwXbj4LL9hbYBNtLwPYS2C7Bw98b6fCf8/B/Kk3t/pUVxM3J4e+FZWZ/9EBY"
    "O/q9FdwOX5Smdr8Iy9PMfrWCuDk53NLw0qs/CYuZ/dHDiR393gpuhy9KU7tfhOVtZl+sIG5ODrc0vNXui5PDJSwz+6PH6bKj31vB"
    "7fB3wvI2sy9WEDcnh1saPmr3s5PDP3ucLjv6vRXE7V8Iy46kQa9+toK4OTnc0qBXSlO7n50c/tmDsOzokoZeKY3avawgbrew7JiG"
    "mV1KU7uXkcTtFpYdkYZePbWidk8riJuTwy0NekUrancZSdw4vewoLDN7Kk3tnkYStxXi9iAsO3pKQ69KU7vbCuJ2C8tbr5Smdozk"
    "KW4vYdkRaegVpXnKEyuIm5PDLQ0zu7SidkbyFLfTy47CMjNK81Q7RhJHcDkehGVHT2noVWlqd1tB3G5heeuV0tTOSF7i9hKWHZGG"
    "XinNLU9WEDcnh1saZnZpRe1Gcov79LKjsMxMaW61M5K340FYdvSShr6b2r2t4OVAWMwsDXpVmtoZiTx9E5YdSYNelUbtWpEnK4ib"
    "k8MtDXqlNLVrhTytIG5ODpewzKw0etWK2hmJuK3geBCWHb2k4VK7jxW8HAjLjkhDr0pTu1bI03dheZuZ0tSOVuRpBXFzcril4aN2"
    "rciTFcTNyeESlpmVple0Ik8jiZsVeBCWHd1KQ+0+VvByICw7Ig29Kk3tWpGnH4TlNjNKUztakacVxM3J4ZaGt9ppRZ5YQdxODpew"
    "zKw0vaIVeRpJ3FjBg7Ds6FYavfpmBXG7hWVHpKFXpaldK/L0g7C8zOxSmtrRijytIG5ODrc0vPSKVsgTK4jbyeESlpmVple0Ik8j"
    "iRsreBCWHd1KQ+0+VhC3W1h2RBp6VZratSJPPwjLjtIwM0pTO1qRpxXEzcnhloaZvbVCnlhB3E4Ol7DMrDS9ohV5GkncWMGDsOzo"
    "JQ2X2n2sIG63sOyINPSqNLVrhTx9F5YdpWFmlKZ2tCJPK4ibk8MtDXr11oo8WUHcnBwuYZlZaXpFK/I0krixggdh2dFLGr2WpnZv"
    "K4jbLSxmlga9Kk3tjESevgnLjqRhZkqjdq3IkxXEzcnhlga9emuFPK0gbk4Ol7DMrDR61YraGUncWMHjdJuZNPRaGrW7reDtEJa3"
    "XilN7YzkJW4vYdmRNOiV0tzyZAXiduLwkga9+hjJLW5Olx2FZWZKc6udkcSNFTxOt5mloVdKU7vbCt4OYbnNjNLUjpE8xe0lLDsi"
    "Db2iNE95YgXi5mRHT2nQq29G8hS3y4kdhWVmlOapdowkbqzgcbrNLA29Uhq1e1nB2yEsO6ZhZpfS1O5pJOJ2C8uOSINeXVpRu9sK"
    "ceO0o6c06NUPRhK322lHwjKzp9LU7mkkcWMFD38tLDv6r3n4a2HZ0X/Nw/9ppJn9O6U5SIPa/bVWdvRnD0qibr+VilvdfjbSzH5V"
    "kqdd/ao0B2lQu9twm92ftLKjP3s0IRG33yrNLW4/K2FOv2rF05769kVpDtKgdrfTbc7ui6Zvl5R292eP01Pcfqs001Pd/korJkJQ"
    "5/az0hykQe1uJ3sTwq7TT8KSp3/2OD3F7bdKc/g3WnEgLGr3s9IcpEHtbie9MhKHn4QlT//sQSvE7TLSzIy0o7fSHN7Ckmca4nYZ"
    "aWYvJzN7a8Xh6VS7S2nk6ak0B2lQu9tJryjN4WmFXl3S8HJohbhdVrCjlzE7K/TqQSvE7TLSzIy0o7fSHN7CsncIZp8YaWaX0BJ7"
    "Z7dWHJ5OtaOUwN67ojQHaVC720mvKM1BKpK9ZdLwcmiFuDESZt0uI2ySPeuDVojbpaTQeyl7dm+lObyFxdyK2ScjzYxQis7ubq04"
    "EEpRO6WEPaUwM0pzkAa1u530itIcUkm6kPS+QynmtrtW9EoopaP0vjESXQozP2iFuD21smsLvfooTXaZCMuu00h6ZaSZCaWYdfum"
    "FRmh2b2zwp7VSLtOSnOQBrW7ncyOVGbWipmlFsQtLHm6tLLrFFITt7DUuRlp72ykXR+0QtyeWnHp1UdpnnZEWPLECr0y0sy0wuEH"
    "rXjLEyv0ykgclOYgDWp3O73NTCs7Ig1xC0ueLq0Qd2nELSx6ZaSZGYkHrRC3lzTI0zeluczsEpY8sUKvjDQzrXD4QStuh8tJryjN"
    "QWkO0qB2t9OtV7SyI9IQt7Dk6dIKcZfm8LRCr4w0MyPxoBXi9pIGefqmNJm9XcKSJ1bolZFmppVdpx+0Qk2Jw+WkV5TmoDQHaVC7"
    "28ns2But7Ig07DrDkqdLK8RdmsPTCr0y0syMxINWiNtTKok8fVOaw1tY8sQKvTLSzLSyZ/WDVvQeSnK4tBR6RWkOSnOQBrW7nfTq"
    "rZUdkYbed1jydGmFuEtzuLSiV0aamZF40Apxe2rFTL1vH6U5vIWlzs0KvTLSzJQSHH7QioPS5OmyQq+EUhyU5iANanc76dVbK7tO"
    "0hC3sOTp0gpxpxbyJCx6ZaSZGYkHrRC3p1Z2XKFXH6U5vIVF7azQKyPNjNIcftCKg9LIEyv0ykgclOYgDWp3O+nVWyvELQ1xC0ue"
    "Lq0QtzTELSx6ZaSZGYnH6dYrI81sBTt6K80tbmG51Y6RZkZpXg63VhwIi9pZwcvMKI08OenVy0mvPkrzciAsT4dWiFsabnlipJkZ"
    "icfp1isjzSyVtKO30tziFpaXvDdGmhkhGC6HWysOlzTUTgipoPeNkJo8OenVy0mvPkIY2HW6pOFyaIW4SVqwq70x0syMxKO5zUkJ"
    "c5LS7t5CcauEpbtUTyXM6aUEdndLaXdPJczpEgrm9BSKvmnM6aUxp+8advdSArtLieqpBLt7KWFOUuLhr4UlT/81D38tLHn6r3ng"
    "7NUfjORpR1+dHH5jBZe4/WoktRNW7T5OT4c/S8OO/uhRaL36g5E87eirRvUbK7j0bW5fjKR2wqrdx+mp0n1V9nQJxe7+6HGiV38w"
    "kqcd/a0V3OL2xUhqJ6zafZzeDl+tnf2zRyhFr/5gqC7bX1u7uqQWty9GUjth1e7j7N0ltT2rH6UWZvbPHlIqvXpJJlLQvQ3ZRwrm"
    "Lvb0VOieCub2sWZ1SaPP6RIS5nYZSe2EVbuPs1eX0vSKFNgTKRW721NI9vRUMLdLCuYWkrkfOHv1smbFCuJ2G7KPkeS97Ojp5PB0"
    "olcfa1aXNMzskgbydBlJ7YRVu4+zV5fS9IoVmBkreJpZGnZ0CQu1u7Sidq2o/YGzVy8r7BxamHV7G7KPkexdW9p25uRAKYFo+1iz"
    "uqRhZqkR6h57Z4ykdsKq3cfZq0tpepVamHWEnbeQmlnZ0rAjWgp1j70zWrERbA+cvXppKcTUzOxjhOppYiR71pKSHTk5SCVNsu/W"
    "7pOUypxdGvauWhAxktoJq3Yf5+yTlMqcPaUyZ28p1LmlYWaXNOxIKmn23YK6t1bsjcQDZ69upcXUzOxjJE87YiR5EpYdOTk4Ofxk"
    "BXFbQdykYWaMEDGS2gmrdh8nBycHK4ibNMwsDTO7pGFHYdkRrahdK2rHyQNnr26lbSHv7WMkdbM3RpInYdmRk4OTw09WsLc0+0Qa"
    "dW6MNPs0ktoJq3YfJ5M0+2QFcZOGmaVhZpc07CgsO6IVtWtF7Th54OzVrTTE7ZuRZt1uI8mTsOzIycHJ4SfLFoKZXdLI02UkeRpJ"
    "7YRVu49zb5fZsYK4ScPM0jCzSxp2FJYd0YrataJ2nDxw9upWGuL2zZB9jCRPwrIjJwcnh5+sWaVhZpc08nQZSZ5GUjth1e7j7NXH"
    "CuImDTNLw8wuadhRWHZEK2rXitpx8sDZq1tpNZQ5u48h+xhJnoRlR04OTg4/WbMKodl1k8bcFSPUvY2kdsKq3cfZq48VxE0aZpaG"
    "mV3SsKOw7IhW1K4VtePkIVi9b08hlZyamX2MkD1tjKROwtg7c3KwhOiyfaxZsYK4ScPOaCFiJLUTVu/b29mrjxFC3qS2Z5VamHUj"
    "DTsKI+yMlnadWlE7Th5Kw+Fpzao0M/sYydOOGMmtdpwcaMWlVx9rVqwgbtJw2xEjqZ2w7Ojt7NU3pXmJ22UFeZKGHTGSpx3Ritpx"
    "8mgpoM8ppdKrkIrZt9tInvbs20j6btS5cXIgpIZefaxZkVKZswtJKOhzIoVWO2HZ0dvZq29Capize1rBnF0adkQKDX1OtKJ2nDyW"
    "l1mVYlYs8nYbwa1OI8l7ED0toqeFWX2sWV1Ss7NLaqjTUxh1EgbR2+rdDxZm9TICO0vNzi5hoE6XlvSOxcNfG0me/mse/tpI8vRf"
    "8/DXRpKn/5oHSsvT743kFrefhUXtfnF6iduvWskTpeXpNpJb3P4gDfL0Jw+UlqffG8ktbj8Li9r94vQSt1+1kidKy9NtJLe4/UEa"
    "5OlPHtJwidvvjGRm/8ZJr6xgZl+0kidKy9NtJDMzkh19kUbt/tFDGi5x+52RzOzfOOmVFczsi1byRGl5uo1kZkayoy/SqN0/eqA0"
    "4vY7I5nZv3HSK8Ka2Ret5InS8nQbycwuS/STsKjdP3qgNOL2OyOZ2b9x0ivCmtkXreSJ0vJ0G8nMLkv0k7Co3T96oDTi9jTSQWl5"
    "uo1kZh+tuOUpLGrn9BK320mvCGtml9NL3GglT5SWp9tIZnZZostInvIUlkue0iBPpOFpZpcV3B4ojbg9jXRQWp5uI5nZRytueQqL"
    "2jm9xO120ivCmtnl9BI3WskTpeXpNpKZXZboMpKnPIXlkqc0yBNpeJrZZQW3B0ojbk8jHWn06mMkt7jRSp4oLU/hf8zBu7EmN8+o"
    "0aerOhQYDAUGQoHBUGggFBoIhQZCoXH6sl/NRTOl0fk/Q2st6AE7je9tiA5LSIOppMFUqsFwS8CHJa+ppMFUqsFwS8CHJbKgB6AT"
    "LJGVxmWncVk0LlMPwAe04jb11Bmdj6m8WgHDLQEflsiCHrDT+N6G6LCENJhKGkylGgy3BHxY8ppKGkylGgy3BHxYIgt6ADrBEllp"
    "XHYal0XjMvUAfEArXhui8zGVND6GWwI+LJEFPWCn8b3NqxqXqSeXqVSD4ZaAD0teU3m1AoZbAj6gsaAHoBMskZXGZUN0WDQuUw/A"
    "B7TitSE6H1NJ42O4JeDDElnQA3Ya39u8qnGZenKZSjUYbgn4sOQ1lVcrYLgl4AMaC3oAOsESWWlcNoKInHsAACAASURBVESHReMy"
    "9QB8QCtuU4HofEwljY/hloAPS2RBD9hpfG9D9KlU4zL15DKVajDcEvBhyWsqaXwMtwR8WCILegA6wRJZaVw2RIdF4zL1AHxAK25T"
    "geh8TCWNj+GWgA9LZEEP2Gl8b0P0qVTjMvXkMpVqMNwS8GHJayppfAy3BHxYIgt6ADrBEllpXDZEh0XjMvUAfEArblNPndH5mEoa"
    "H8Mt0QmWyIIesCE632yIDovGZSppMLUVMNwS8GHJayppfAyHE3xYAjp7ADrBElnQA3Yal0XjMvUAfEArblNPndH5mEoaH8Mt0QmW"
    "yIIesCE632yIDovGZSppMLUVMNwS8GHJayppfAyHE3xYAjp7ADrBElnQA3Yal0XjMvXYvKrBcEvAhyWvqbxaAcO5RQdkQQ9AJ5dW"
    "vDZEB2Slcdk8WgHD4QQf0IrbVNL4ZioQnZtOsEQnWAI6uZw8Fo3L1GPzqgbDLQEflrym8moFDOcWHZAFPQCdXFrx2hAdkJXGZfNo"
    "BQyHE3xAK25TSeObqUB0bjrBEp1gCejkcvJYNC5TD/6F4Zb8xxz8C8Mt+Y85+P/kgx78K0toBRtO/pws0vitA5BVjV9bwuvkJz7o"
    "wd/I4pbG3y2hFWw4eenkEZ3fkQVp/NbBBqrxa0t4nfzEBz34G1l8SeMnS2gFG05eOvnSg59sOLnIIo3fOjaXavzaEl4nf0YWX9L4"
    "yRJawYaTl04+evCjDSf/7NhcqvFrS2jFvyCLaqATovOjJbSCDScvnRAdfNCDH204+WcHyKIaF51EBx/Qg8cSWvGSRTWdpHHxQQ8e"
    "U2nFSxbVAJ1E5zacHtyW0Ao2nLx0ksZlOD24TKUVsHlUQxZp3HzQg9tUWrGkFQfIoho3nUTHBz14LaEVL1l8iQ4+6AFM5daKhyyq"
    "ATqJDvjgZgksoRVsOHnpJI3LcHrAVG6t2DyqIYs0wAe3HsBU2hQu5wGyqMZNJ9Hx0YMvS2jFSxZfooMPesBUHq14yKIaoJPo4IOX"
    "JSyhFWw4eemE6MBwejCVV6vNoxqySAMfvHrAVL6cB8iiGg+dRA168GUJjxOQBWnohOj4oAdMBUv+IotqoBOi4wN6MBxLWEIr2HDy"
    "0gnRwQc9GA6WLKEVbDi5yCINHxCd4fSAqdCKJZwHyKIaD51cevCxhMcJyKIaoJPo+KAHw8GSb2TxJQ180AMYjiVLaAUbTl46+ejB"
    "cCxhCa1gw8lFFmn4IDowHEum0gqWwAGyqMbLB9CDjyU8TkAW1QCdRMcHPRiOJd+RxSsN8EEPYDiWLKEVbDh56eRLDxiOJbCEVmw4"
    "ucgiDR9EB4ZjyVRaAUs4QBbVePmA6PxlCa14yaIaoJPo+KAHw7HkO7J4pHHxQQ9gOJYsoRVsOHnp5BEdGA6WwBJaseHkIos0fBAd"
    "GI4lU2kFLOEAWVTj5QPowccSWvGSRTVAJ9HxQQ+GY8l3ZFENnaQBPugBDMeSJbSCDScvnRCd13CwBJbQig0nF1mk4YPowHAsmUor"
    "YAkHyKIaD51cevCxhFa8ZFEN0El0fNCD4WDJN7Kohk7SAB/0AIZjyRJawYaTl07S+BiOJSyhFWw4ucgiDR9EB4ZjyVRaAUs4QBbV"
    "eOiM7oMefFlCK16yIA2dEB0f9ICpYMlfZFENdJIGPqAHw7GEJbSCDScvnaTxMRwsWUIr2HBykUUaPiA6w+kBU2kFLOHYvNJAJ9F9"
    "QA9eS/hyIosv0cEHPWAqj1Y8ZFENdEJ08MHLEpZAKzZw8tBJGn+ZyqsVbC7VkEUa+ODVA6bSCljCsXmloZPo4IMevJbw5UQWrzTA"
    "Bz2Aqdxa8ZBFNUAn0QEf3CyBJdAKNlTjppM0vpnKrRWXDVRDFmmAD249gKm0ApZwbF5p6CQ6+IAePJbw5UQW1XSmcfNBD25ToRUv"
    "WVQDdEJ0LsPpwWtJK2BTjZtOiM53ptKK16YayCKNmw96cJtKK2AJB39MFtX4rzn4Y7Koxn/Nwf+nqWn8Oz44QSf04I8Nr8bvHeAK"
    "vfgldV69+NHUNP7OlVt1/s4HJ+iEHrwmrwx+Z3g1fu8YiEIrfskHr1b8yCWTvxvOrZIofuKDE3RCD16bV2bwk0EUF9UKfu/Y3Frx"
    "Sz5Ibr34I8NJQISexY98cIJO6MFrQxWIVE9+IAtL/tmxubXil3xw8m8M5wRkQQ9+5IMTdEIPXhuiw1Q4+YEsLPlnBwyHVlympsFU"
    "OHn54OSLLCx10orL1DQeG9L4MpyT26YHFx9gyc0HJ+iEHrw2RAd8cHJbEp2LTh4nw6EVlyVU4zEzYEl0DhgOrbhMTYOp1ZOXD06+"
    "yKJKhIwEpqZxkaFQZbyGc3Lb9ADcBaqqAz44QSf04LUhOuCDE9RRqjDQyeNkOLQCpgLZi8uUAqWyHzAcWnFxlQj3yuCLD06+yIIs"
    "nIyEqWmAuBNQwWs4JyDu9AB3qUQlDfDBCTqhB68N0QEfnKgrgSgRJe5kUcFwaIW4B+ARBUyFQCXtgOHQitvw6kOi8+ED45KALKon"
    "U4kOU9NA3Mle/GU4BsigImBJZWdq9QQfnKATevDakAGopzGcNHQIrZCFJZfh0Ep00ApZ9CyYWmVMrX7AcGjFbTiX6Hz44FYNkIUl"
    "sCQ6TE2D4XDyneF8sQSWRIepcIIPTtAJPXhtvqTB8GqATlohC0suw6GVD2iFLIgOU9NgKhwwHFrx0AmW/MUHlzQusrAElkSHqWkw"
    "vBrfG87r5LIhOuCDE3xwgk7owWvzig4MrwbopBWysOQyHFr54OS2JDpMTYOpcMBwaMVDJ1jyFx8YVHGRhSWwJDpMTYPh1fjecOiq"
    "cHLZEB3wwQk+OEEn9OC1IQOoAoZXA3RSPWVhyWU4tPLByW1JdJiaBlPhgOHQipu6giV/8cHJF1lYAkuiw9Q0GF7Z+c5wIsSVk8tQ"
    "iQ744AQfnKATevDaEJ0vw6sBOokoWVhyGQ6tfHByGU50mJoGU+GA4dCK23BSI4oPH5x8kUXPgiXRYWoauAsn3xnOCT6w5LIkOog7"
    "J/jgBJ3Qg9eG6HwZXj1BJ62QhSWX4dDKB5YgC6LD1DSYCgcMh1bchldbEp0PH5x8kQU9YEl0mJoG+ODkO8M5wQdYAkuiw1Q4wQcn"
    "6IQevDZE58twaIVOWiELSy7DoZUPaIUsiA5T02AqHJtXdJiaxhKq8cUHr1bI4tUDmJoG+OBx8hrOCciCHrCERxrgAyxhQ3QeG6Lz"
    "4YPHCcjidjIcWqGTlyUwNQ2mwrF5RYepaahrNb744NUKWTysCpiaBogwuZy8hnNy0UkPEFGHXlWA6MASNkTnsSE6HyITqJ5cdHI5"
    "GQ6tQBlCdaqAqWkwFY7BKxNcMkG1gi/ivDrIIrh0bi6ZPFyggpdqBTeXTC7iEMVDnCgYkMljQCbfDKCChwtUoAqdmwsVPFwyQRUO"
    "/pgsLPmvOfhjsrDkv+YAdnR+Yyq3avxsw8kvLOHSir+bSg+Q1YOPze3k93RSjd86HEZ0fmMqt2r8bEDnF5ZwiSKLn0ylB8jqwcfm"
    "1iH4mVdyEaeC3zo2EJ3fmMqtGn9qCa9W/GQqPUBWDz42X05+tsr4Z4e4E53fmHQuxR9b1bnoaMVPptIDZPXgY0dw0VHZ+Z4OSeOf"
    "Hah6dB5KAioEXybGhwpZTiU3h+DmQBYfKzsXnZHJRRTI4jKVHiCrBx87OhcfRAdUoBJQdSqoRJRKbg5kcVEhC1GyDmBH57GyA0to"
    "xWtifEzFalGN24aT2wai87Gyc9FJGhedgCWXqfQAWT342NG5+CA6sATSgCXc0tBJNS6ygB5chtOD4fQ4gB2dx5IyGZK9+DIxPqZS"
    "1YdWT2DDCbgLNIqPlZ2LTtLQAdJrVhkwlR4gqwcfOzoXH0RHh2SfUlaIDrJDoZNqwFDpNasMGE4BQnEAOzqPodLFSeNjSueWwFQq"
    "u6tGJmw4QV0TjG9WRYKqZwY6qeoMoQFT6QGyevCxMxJUPTNUPTOGSs9CJ2lcdFIN1DWjhtCrGE4VoHAAOzovH1zS+JjKrRowFUuQ"
    "RTXYcMKGkx8soRVLaAU6SQOmNGAqPUBWDz42nLDhhCW0Ap2koZM0LjqphiyqAcPpwXB6ABsOYEfn5QOwKj6m0guqgKlYgiyqwYYT"
    "Npz8YAlVaEYCOnsWMDUjmUoPkNWDjw0JmpGwhFagkzR0ksZFJ9WQRTVgOD0YTg9gwwHs6Lx8AK34y9TsxWsqliCLarDhhA0nP1gU"
    "IqRx0WnJZSqWTKUHyOrBx67ikgEsoRXoJA2dpHHRSTVkUQ0YTg+G0wPYcAA7Oi8fQCv+MjE+pmIJsqgGG07YcPKDlR2dpHHRacll"
    "KpZMpQfI6sHHjs7HElqBTtLQSRoXnVRDFtWA4fRgOD2ADQewo/Py0cUzg4+J8TEVS5BFNdhwwoaTH6zsiAyqF+jM6sCUXsVUeoCs"
    "Hnzs6HwsoRXoJA2dpHHRSTVkUQ0YTg+G0wPYcCCsiOIm6qaDND6mGLcCptITZFYZbDhhIY1L8bGyA0toBTopA4Y0YCo9QFZE8WVH"
    "52OKWIGOyo4OyV6ATqohU8qAodWT4fQANhz4AE5uKzs+SONjKrdqwFRePYANJzCcS3Q+VnZgCa1AJ69qwFR6gCyq8WVH5y8+eLTi"
    "sgRL0Ek1YCq3asBwegAbjqECRCaqHh1RJ6N4TeVWGcVUogb0LGDDCYgOIDofKzug6pmBKOJAZAIqowfIohpfdnT+IjqAzOC2hMxA"
    "J9UAlQFEJjCcHsCGY/HIjjvZgQVWvKbw6slUrCY0bgsatwVk52Nl56KDMi46gJ7cZPYEmdD4siL4zgKy85gCZeigjItMoCeXoUQA"
    "Cw7+2FQs+a85+GNTseS/5uCPTcWS/5oD8GHJr03l1YofyYIe/M3m0Yq/G24J+LDkNZVXK35DJ1jyOwfgw5Jfm8qrFT+SBT34m82j"
    "FX833BLwYclrKq9W/IZOsOR3DnRyacWvTCWNf2NDdFhCGj8Zbgn4sOQ1lTSYSjV+orMH/+hAJ5dW/MpU0vg3NkSHJaTxk+GWgA9L"
    "XlNJg6lU4yc6e/CPDsAHtOJXppLGv7EhOiArjZ8MtwR8WPKaShqXReMHsqAH/+gAfEArfmUqafwbG6IDstL4yXBLwIclr6mkcVk0"
    "fiALevCPDsAHtOI29QQflrymksbHcF6WyIIesHm04rUhOiArjcvm0QoYbgn4sOQ1lTQui8ZlKjdLZHGxRCdYAjq5pXFZwusAfEAr"
    "blNP8GHJayppfAznZYks6AGbRyteG6IDstK4bB6tgOGWgA9LXlNJ47JoXKZys0QWF0t0giWgk1salyW8DsAHtOI2FYjOx1RerYDh"
    "loAPS2RBD9hpfG9DdFhCGkwlDaZSDYZbAj4seU0lDaZSDYZbAj4skQU9AJ1giaw0LjuNy6JxmXoAPqAVt6lAdD6m8moFDLcEfFgi"
    "C3rATuN7G6LDEtJgKmkwlWow3BLwYclrKmkwlWow3BLwYYks6AHoBEtkpXHZaVwWjcvUA/ABrXhtiM7HVNL4GG4J+LBEFvSAncb3"
    "Nq9qXKaeXKZSDYZbAj4seU3l1QoYbgn4gMaCHoBOsERWGpcN0WHRuEw9AB/QiteG6HxMJY2P4ZaAD0tkQQ/YaXxv86rGZerJZSrV"
    "YLgl4MOS11RerYDhloAPaCzoAegES2SlcdkQHRaNy9QD8AGtuE0FovMxlTQ+hlsCPiyRBT1gp/G9DdFh0bhMPblMpRoMtwR8WPKa"
    "Shofwy0BH5bIgh6ATrBEVhqXncZl0bhMPQAf0IrbVCA6H1NJ42O4JeDDElnQA3Ya39sQHRaNy9STy1SqwXBLwIclr6mk8THcEvBh"
    "iSzoAegES2SlcdlpXBaNy9QD8AGtuE09dUbnYyppfAy3RCdYIgt6wIbofLMhOiwal6mkwdRWwHBLwIclr6mk8TEcTvBhCejsAegE"
    "S2RBD9hpXBaNy9QD8AGtuE09dUbnYyppfAy3RCdYIgt6wIbofLMhOiwal6mkwdRWwHBLwIclr6mk8TEcTvBhCejsAegES2RBD9hp"
    "XBaNy9Rj86oGwy0BH5a8pvJqBQznFh2QBT0AnVxa8doQHZCVxmXzaAUMhxN8QCtuU0njm6lAdG46wRKdYAno5HLyWDQuU4/NqxoM"
    "twR8WPKayqsVMJxbdEAW9AB0cmnFa0N0QFYal82jFTAcTvABrbhNJY1vpgLRuekES3SCJaCTy8lj0bhMPfgXhlvyH3PwLwy35D/m"
    "4P9CZxq4dP6vlrTiy2r8mSUnB9/IoDoXdW6R4BrJbUTxZfKojs40dBDB300w/tSSVrymNC4yqA6oc8vgb3SeHHyI41RPwAe3Huio"
    "IgpcOh+bRxo605AhPfmZi0PQ+TNLWvHa1UAcJw3wwa0Hf7ejH6AkF1mkSPYCH1VAJEO7ak9YVnxsSKA6OtNAJfiZTElQTv7MklY8"
    "dKaBLCAN8FEFZPB3m/OAXY2LrDSdpIGP6DxGJjMSlhUfm2o8dKbxS0toxebkzyxpxWNzArKANMBHdH5jcx6wq/GhMw18ROc23JIZ"
    "ybLiL5tqPHSm4YPoDO8xvAevJa147WqyqvHQSXRuw+nBbSptSisem5ObLNIAH9F5DO8xFUum0orLPg/Y1fjQmQY+onMbbsmMZFnx"
    "l001HjrT8EF0hleJVEVyW1JWPDaJktVBXYSKANyFqkgYDiW04rE5uckiDfARncfwKhGqUCgrYOcxcAIquOlMAx9ZZIKOnsxIlyiX"
    "zmtTjYfONHwQneFkqWDJzV2Czm1DgFcDnZWI9ESdQqUHOiRQoRWPzclNFmmAj0oygeFkoUKASitgc2we1bi5R4APIKJgEHgwrWSo"
    "JY9NdagCnWn4IDrDq6e7WPIYDkYCmzRklRXu2fERXdx74B7B1LIaTisem5ObLNIAH0BGFcPpwVQsWdIK2BybRzUuOtMAH1x6wHDz"
    "yKmtlk1pxW1zqwY60/BBdIb3gOGWvJYAJ7CrgSzSdKaBj+g+6AGjgqmWsKQVj83JTRZpgA9uPRhOD6ZiyZJWwOaAXY2XTtJ4DacH"
    "TLVkRi5pteTktrlVA51p+CA6w3vAcCz5sgRO2NVAFmk6eUT3wctyqiUsacVjc3KTRRpffPRgOD2YiiVLWgGbA3Y1HjIle/GSoT1A"
    "pGpUsCJYcnLbVIcq0JmGD6IzvAcMx5IvyuSEXQ1kkaaTR3QfPCJqqiUsacVjc3KTRRpffPRgOD2YiiVLWgGbA3Y1buJePfkY3oPH"
    "jGRZseTktqnGQ2caPojO8B4wPHvxl010djWQRZrOSi6ZPsgCophqCUta8dic3GSRxhcfPRhOD6ZiyZJWwOaAXY2bD9K4iFQhQ3tw"
    "E49iRbDk5LapxkNnGj6IzvCIkqGW3ERIdJLGxhIfRJdZvbjpkIjiNrUHMqUVj83JTRZpgFCIew+G04OpZcWSVsDmgF2NiyxI4+Ij"
    "OsPpwW1GwpJWS05um2o8dKbhg+gMp8dwLLktodUSTthUk0U10JnGwwc9uE3FcgmteGxObrJIA1w6PujBcHow1RKWtAI2Bx+yeET3"
    "wa0HjxkJLJvSitumGg+dpPkgOsO5WfJYwuOEzaMa6OQWHYZz6QFTubXisTlBFo80ndyiw3B6MNUSlrQC9nnwIYtHdBF1Iqu4jQou"
    "MtSSx6YaLx9pPojO8EjXiOIhMgSMhI0xq1cBKoOMKpChRFaBTOk1pBWPzQmyeKSJqEP2guH0YKolLGkFU8+DD3EemaBKJi+t4ubS"
    "eQ0qeIlnipPJ8B6qUXy4QOeyqzEqeIiTyU2VKG4uUS6d1/AeMHhkgjhkAqpEoRoFLh3YnAf/I8N78Eu7Gv/GrsYf2mkH/yPDe/BL"
    "uxr/xq7GH9onB78gi0s1fsMHlzSWRIepafwf6Tz5ovPkezqB6PzdrM7Bhwi3BGRxqQYiqVSBVvEh7lzSWBIdXDP4mXJL/pDOk5fo"
    "OEEEqALEHYjO37lkHnzo5FINkMWlGri3TQ9YPfkYzi2NJdH5tc2tFX9G58nLByfoBKIDw7lE5xdc7QAnuIgA6tkLWfSCBPemIwK0"
    "io/h1bkkS6Lza5sMSP6QzpOXe08QYRIdGF4dqvgFVztgiPGhk1bIwpKbe2Nm8IPh1Xgsic6vbXrw53SevFyNx5LowPBq/IarHTDE"
    "+NBJK2SdvNwbM4MfDK/GY0l0mJoGg1jQg9e25CELkwGtuEyFk9uGNC6yuJ28XI3HkujA8Gq8hvQF0dmQBvjgUJwgeemkFbKsipt7"
    "Y2bwg+HVeCyJDlPTYEgqUpE8diTJRRZRivYsUBWIBHQmlQmiIxHh5OVqPJZEB4ZXTx5DUpEKXCQNUNdjc2vFQyetkIUlN/fGzOAH"
    "w6vxWBIdpqbB8GpMTeOxIY2LLIjOpgdsS9itkIWlzhN80MoHJy9X47EkOjAcWnEbXo2pcE5N46Lz2Nxa8dBpCbJIqA4+kky84+Qw"
    "HsNJiIQl0WFqGgyJZGoaDx1SRS9kEVFseshQS9it1LVn6cxe7j0R95OXq/FYEh0QdxKqw5BIplZPdYyLzmNza8VDRwNkcakGPsBS"
    "R2NWrJPHcC49YEl0mJoGgw5T03hNBVohC0vY9JCFJexWPjhBJ63cG6Dz5OVqPJZE56KTSxoMMZiaBkOMi84Dhhhfhlfji47GN6sn"
    "bEsuw6vxWBIdpqbBoMPUNL7Z9JCFJWx6yOLRygevVu4N0HnycjUeS6LzZWoaDDGYmgZDjIvOA4YYL3XJzhcdjZdIsnrCtuQyvBqP"
    "JdFhahoMOkxN45tND1lYwqaHLJJLLx8kt17uDdB58nI1Hkui82VqGgwxmJoGQ4yLzgOGGK+paXzoaLyGGKsnbEsuw6vxWBIdpqbB"
    "oMPUNL7Z9JCFJWx6yMKSmw9OXu4N0HnycjUeS6LzZWoaDDGYmgZDjIvOA4YYjymZyRdXabxEktUTtiWX4dV4LIkOU9Ng0GFqGo8R"
    "BZsesrCETQ9ZWHITHdmLm4801PXk5Wo8lkTny9Q0GGIwNQ2GGBedBwwxHpsefAyvxjerJ2xLLsOr8VgSHaamwaDD1DQe2xI2PWRh"
    "CZsesrDkIQtLbj5o5YOTl6vxWBKdL1PTYIjB1DQYYlx0Hnzo5NEKWUAar5kBTIWTx/BqvIZXY2oaDOfSg9fm1gpZPFoBm1srYHM5"
    "AVncTl6uBujkcTKcS3RgiMHUNBhigKsdfMjg0QsZQAavkQm4gvFwrc7LtTquGTC0gEheQ7j0QhbJpRcwhEsvYAhUB2RwM16uBqjz"
    "MFy5ZABOgGt1cAJwtYP/lUHnV2RhyZ9zNf6Uqx38rww6vyILS/6cqBp/yNUO/lcGnV+RhSX/gs6TP+RqBx9TseQynEt0fkMnl2rI"
    "6gHs6PzCElrxp1YZP1tlXGRxO/mlg4+pWHIZziU6v6GTSzVk9QB2dH5hCa34U6uMn60yLrK4nfzSwUunMakGDCc6F52tuMnqwccS"
    "LLnJ6sFv+CD6KuMPrTJesnoAG0jjIsuS3xh+8NJpTKoBw4nORWcrbrJ68LEES26yevAbPoi+yvhDq4yXrB7ABtK4yLLkN4YfOzof"
    "Uxow/OShsxVTGj9YgiU3WT2AHR1YZVOx5LGhFa8pbTg9eKwyHlPpwWNlX2W8ZPXgscq4yLLksaPjgzR0WnIZfuzofExpwPCTh85W"
    "TGn8YAmW3GT1AHZ0YJVNxZLHhla8prTh9OCxynhMpQePlX2V8ZLVg8cq4yLLkseOjg/S0GnJZfixo/MxpQHDTx46WzGl8YMlWHKT"
    "1QPY0YFVhixLXj5a8ZrSkNUD2NBktgJZlgw/AR9NB2m8ZPXgscq4yLLksaEVSzAm1bgdOzofUxow/OShsxVTGj9YgiU3WT2AHR1Y"
    "Zciy5OWjFa8pDVk9gA1NZiuQZcnwE/DRdJDGS1YPHquMiyxLHhtasQRjUo3bsaPzMaXx8EF0YAmWvIaf3JZwq4asHsCODqwyYErj"
    "yxJIA6Y0YPgJOzqwyqZiyfATdnRglfGzVcZLFpywoRVLsGRK43bs6HxMaTx8EB1YgiWv4Se3JdyqIasHsKMDqwyY0viyBNKAKQ0Y"
    "fsKODqyyqVgy/IQdHVhl/GyV8ZIFJ2xoxRIsmdK4HTs6L52WfOzo/Gj4yW0Jltxk9QB2dGCVAVMa3yzBkikNGH7C5taKqTxO2NGB"
    "VcbPVhkfw0/Y0IolWDKlcTt2dF46LfnY0fnR8JPbEiy5yeoB7OjAKgOmNL5ZgiVTGjD8hM2tFVN5nLCjA6uMn60yPoafsKEVS7Bk"
    "SuN27Og8JsY3Ozo/Gn5yW4IlN1k9gB0dWGXIohrfLMGSKQ1ZcMKOzmMqljw2tGKV8ZLVg8cq42P4CRtasQRLpjRux47OY2J8s6Pz"
    "o+EntyXY/yMO3m1s23EFis4NrFBoKBQZDIUGQ5HBUGQwFBkMRcZbn9r3/KqAut2n8cZILrI8gB0OrFJkUY0flqDJlIYsOGCHc5sd"
    "TW4bWrFKecjy4LZKeRt2wIZWLEGTKY3Li0ef3DwYximcnww7+LAETS6y4IAdDizhpMnDBqdUYHZOHpxsAK1AFpcDsMEplYcsD2Bz"
    "acXs3A7Y0IolaDKlAcNePPrk5sEwTuH8ZNjBhyVocpEFB+xwYAknTR42OKUCs3Py4GQDaAWyuByADU6pPGR5AJtLK2bndsCGVixB"
    "kykNGPbiL1mlfG5K41+Q5cF3DXvxl6xSPjel8S/I8uC7hr34S1Ypn5vS+N958ZesUj43pfG/8+I/12c4/99e/Of6DOf/24vHEKCc"
    "0+SUwedkcPOiz3C+MDlF8l0yyvnZhHJOQ7hE8qkXj9mBVE5LgHA+J4tbK/oM5wubkwffJSuVny0hldMSLh586sWjCyfJhCUOlWDi"
    "/EFWBaeAPsP5wq6ALL5pYKncRgUnY6RyWuKcsviEyYuf9OkBi8ZtycEfZKXy6DOcL+xU/oUNqVxkpXLbqZyWHHxpyauTvPXpAYvG"
    "bcnBH2Sl8ugzHDoJ24HuCgAAIABJREFUIlDVST7sVD70KhFIEKmCToJIVSdBBKo2pHKRlcptp3JacvChAykCSSc5LXntarz16QGL"
    "xm3JwR9kpfLoMxyWHGADNBeNDzuVh6zwYXBAnx6waGDDY8kBNkBzQyoXWancdiqnJQcflpBqA1rtVE5LXrsaH6RbBCwaAsUUpfiN"
    "rHROBX2Gw5IDbFCeC6W4rXIoTrLCRxcO6NMDFg3p5jlFKRuU1kJSuchK5bZTOU1pgBSwpNJtFFo7ldOS167GQ1Yqjz7BA3Y1fiOL"
    "Wyv6DIclB9jwAGSl8ugTPABZ4TD7AX16wKL1Gc5pV7PhAchK5SIrldtO5c2GBywa2NCEncppyWtX4yErlUef4AG7Gr+Rxa0VfYbD"
    "kgNseACyUnn0CR6ArHCY/YA+PWDR+gzntKvZ8ABkpXKRlcptp/JmwwMWDWxowk7ltOQlFLeFUnwQMw8Qit/ISudU0Gc4LDnAhgcg"
    "K5UPAta1kBUOsx/QpwcI1SflCULZ8ABkpXKRlcptp/JmwwMWDWxowk7ltOTF267GDzY8+IysVB59hsOSA2x4ALJS+WFYK2SFw+wH"
    "9OnBpU/w4GLDA5CVykVWKredypsND1g0sKEJO5XTkhePIb0abzJEPPiMrFQefYbDkgNsVHkNkuQ2y7uJtEJWOMx+QJ8eXES6eXCx"
    "UeU1pKdykZXKbafyZsMDFg1saMJO5bTkxWN2qvHWJ3jwGVmpPPoMhyUH2ADNRePDTrUBrZAVDrMf0KcHDxseXGyA5oZULrJSue1U"
    "3mx4wKKBDU3YqZyWvHjMTgVUcjIEoviMrFQeYpmw5AAbWVGjgg+DQiAKWeFg4iCW2SU49V5kAb1D1IAKLrJSORmjopKTEWKZsGhg"
    "QxNGBaclLx6zc/EAZKXyFVmp/GzJATY8+EWf4VxkhfPD7K24DGvFn2SlcloChHPa1bgtGtjQ5G3Ji8cQLhmcZjlfkVHOz4Yo2PDg"
    "FzIyuMgK54chXlyse/EnGeWcJqcMThPlNlGwHsnbkBd/hQ0PPicrnP+dF3+FDQ8+Jyuc/50X/40+U8HE+W8tacWH1fieJQcvfpBB"
    "OaduXCLBeiSXEcWHya2cPlPpgwj+NEH5riWteExpnGRQDnTjksEf+jx48SaGUZ6ADS4e9FFFFJg4b5tbKn2mIkM8+Z2JQeB8z5JW"
    "PHY1EMNIBWxw8eBPO/wFneQkixRJL7BRBUQyulvXhKXF24YEyukzFboEv5MpCZ2D71nSilufqSALSAVsVAEZ/GlzvGBX4yQrtU9S"
    "wUY4t5E5uyYsLd421bj1mcqnltCKzcH3LGnFbXMAsoBUwEY4X9gcL9jVeOszFWyEcxmmyYxkafGPTTVufaZig3CGeQzz4LGkFY9d"
    "TVY1bn0SzmUYHlxmp01pxW1zcJFFKmAjnNswj9nRZHZacdrHC3Y13vpMBRvhXIZpMiNZWvxjU41bn6nYIJxhVSJVkVyWlBa3TdLJ"
    "cugmQkUAZkJVJAyDElpx2xxcZJEK2AjnNqxKhCo6lBaw8zUwAiq49JkKNrLIhD48+/A0iTJxHptq3PpMxQbhDCOrC5pczCRwLhsC"
    "rBr0WYmIJ90ounjQhwRdaMVtc3CRRSpgo5JMYBhZdCGgSytg89rcqnExiwAbQGQVgxiiTC0ZXZPbphyqoM9UbBDOsPI0E01uw0BJ"
    "YJOKrNLCLB0b4WLmgVkEs5fWMFpx2xxcZJEK2AAyqhiGB7OXFktaAZvX5laNU5+pgA0uHgxTi5y91dIprbhsLtWgz1RsEM4wDxim"
    "yWMJcAC7Gsgitc9UsBFuAw8YFcyuCUtacdscXGSRCtjg4sEwPJhdE5a0AjYv2NV49Ekqj2F4wOyazMglrZYcXDaXatBnKjYIZ5gH"
    "DEOTD0vggF0NZJHaJ7dwGzw0Z9eEJa24bQ4uskjlgw0PhuHB7JqwpBWwecGuxk2mpBcPGd0DRKpGBSuCJQeXTTlUQZ+p2CCcYR4w"
    "DE0+dCYH7Gogi9Q+uYXb4BZRs2vCklbcNgcXWaTywYYHw/Bgdk1Y0grYvGBX4yJm5cnbMA9uM5KlxZKDy6Yatz5TsUE4wzxgWHrx"
    "j004uxrIIrXPSk6ZNsgCophdE5a04rY5uMgilQ82PBiGB7NrwpJWwOYFuxoXG6RyEqlCRvfgIhbFimDJwWVTjVufqdggnGERJaNr"
    "chEh6ZNUNprYIFxmeXHpQyKKy+weyJRW3DYHF1mkAkIhZh4Mw4PZNWFJK2Dzgl2NkyxI5WQjnGF4cJmRsKTVkoPLphq3PlOxQTjD"
    "8BiGJpcltFrCAZtqsqgGfaZys4EHl9nRXEIrbpuDiyxSARPHBh4Mw4PZNWFJK2Dz4k0Wt3AbXDy4zUhg6ZRWXDbVuPVJqg3CGcZF"
    "k9sSbgdsbtWgTy7hMIyTB8zOpRW3zQGyuKX2ySUchuHB7JqwpBWwjxdvsriFi3QjsorLqOAko2ty21TjYSPVBuEMi7QeUdxEhoCS"
    "sFFmeRXQZZBRBTI6kVUgU7yGtOK2OUAWt1SRbpBeMAwPZteEJa1g9uPFmxi3TOidTB69iouJ8xhU8BDLFCOTYR69R/FmAs5pV2NU"
    "cBMjk0vvRHExiTJxHsM8YHDLBDHIBHonit6jwMSBzfHiLxnmwad2Nf6NXY1v2qkv/pJhHnxqV+Pf2NX4pn3w4hOyOFXjCzY4pbIk"
    "HGZP5b/U58GHPg9+1icQzp9mOS/eRLgkIItTNRDJThX0Kt7EjFMqS8LBega/61ySb+rz4EOfB4gAVYCYAeH8ySTzxVufnKoBsjhV"
    "A7O28YDlydswLqksCedzm0srvqfPgw99HtAnEA4M4xTOJ6zrC4zgJAJ0Sy9k4QUJZq2PCOhVvA0r55QsCedzmwxIvqnPg0fvmSDC"
    "JBwYVg5VfMK6vmCI8tYnrZCFJhezxszgF8OqcVsSzuc2HnxfnwcP68ptSTgwrBpfsK4vGKK89UkrZB08zBozQ1Yr/jGsGrcl4TB7"
    "KgxigQePrclNFioDWnGaHQ4uG1I5yeJy8LCu3JaEA8Oq8RjiC8LZkArY4NUxguTRJ62QpVVczBozg+nFP4ZV47YkHGZPhSHZkYrk"
    "tiNJTrKI6nTPgt4FIoE+k8oE6SMR4eBhXbktCQeGlSe3IdmRCkwkFejWX5tLK2590gpZaHIxa8wMfjGsGrcl4TB7Kgyrxuyp3Dak"
    "cpIF4Ww8YGvCboUsNPs8wAatbHDwsK7cloQDw6AVl2HVmB2O2VM59fnaXFpx61MTZJFQDjaSTMwxcii3YSREwpJwmD0VhkQyeyq3"
    "PqQKL2QRUWw8ZHRN2K26dc/qM73MPBGzg4d15bYkHBAzEsphSCSzl2c3lFOfr82lFbc+GiCLUzWwAZp9NGbFOrgN4+QBS8Jh9lQY"
    "OMyeymN2oBWy0ISNhyw0YbeywQF90sqsAX0ePKwrtyXhnPrklApDFGZPhSHKqc8XDFE+DKvGhz4aPyxP2JqchlXjtiQcZk+FgcPs"
    "qfyw8ZCFJmw8ZHFrZYNHK7MG9HnwsK7cloTzYfZUGKIweyoMUU59vmCI8ugm6XzoU5ObSLI8YWtyGlaN25JwmD0VBg6zp/LDxkMW"
    "mrDxkEVy8rJBcvEya0CfBw/rym1JOB9mT4UhCrOnwhDl1OcLhiiP2VN565NWXIYoyxO2Jqdh1bgtCYfZU2HgMHsqP2w8ZKEJGw9Z"
    "aHKxwcHDrAF9HjysK7cl4XyYPRWGKMyeCkOUU58vGKLcpmQmH6x3TW4iyfKErclpWDVuS8Jh9lQYOMyeym1EwcZDFpqw8ZCFJhfp"
    "I7242EilWz94WFduS8L5MHsqDFGYPRWGKKc+XzBEuW08eBtWjR+WJ2xNTsOqcVsSDrOnwsBh9lRuWxM2HrLQhI2HLDS5yUKTiw1a"
    "2eDgYV25LQnnw+ypMERh9lQYopz6fPHWJ7dWyAJSecwMYHY4uA2rxmNYNWZPhWGcPHhsLq2Qxa0VsLm0AjanA5DF5eBhXYE+uR0M"
    "4xQODFGYPRWGKGBdX7zJ4OaFDCCDx8gErINys17Ow3o51jNg9AIieQzh5IUskpMXMISTFzAEygEZXJSHdQW6cVOsc8oAjADr5WAE"
    "YF1f/C0D5zOy0OT7rCvfZV1f/C0D5zOy0OT7pHflm6zri79l4HxGFpr8C30efJN1ffE2O5qchnEK5wt9cqqGLA9gh/OJJbTiu1Yp"
    "v1ulnGRxOfjEsBdvs6PJaRincL7QJ6dqyPIAdjifWEIrvmuV8rtVykkWl4NPDHvx6FOZVAOGEc7PZHnwtgRNLrI8+IINwlcp37RK"
    "ecjyADaQykmWJl8Y9uLRpzKpBgwjnJ/J8uBtCZpcZHnwBRuEr1K+aZXykOUBbCCVkyxNvjDstcN5m9KAYQe3PlsxpfGLJWhykeUB"
    "7HBglc6OJrcNrXhMacPw4LZKuc2OB7eVvkp5yPLgtko5ydLktsOxQSp9anIa9trhvE1pwLCDW5+tmNL4xRI0ucjyAHY4sEpnR5Pb"
    "hlY8prRheHBbpdxmx4PbSl+lPGR5cFulnGRpctvh2CCVPjU5DXvtcN6mNGDYwa3PVkxp/GIJmlxkeQA7HFilyNLkYYNwblMasjyA"
    "DU1mK5ClybADsNH6IJWHLA9uq5STLE1uG1qxBGVSjctrh/M2pQHDDm59tmJK4xdL0OQiywPY4cAqRZYmDxuEc5vSkOUBbGgyW4Es"
    "TYYdgI3WB6k8ZHlwW6WcZGly29CKJSiTalxeO5y3KY2bDcKBJWjyGHZwWcKlGrI8gB0OrFJgSuPDEkgFpjRg2AE7HFils6PJsAN2"
    "OLBK+d0q5SELDtjQiiVoMqVxee1w3qY0bjYIB5agyWPYwWUJl2rI8gB2OLBKgSmND0sgFZjSgGEH7HBglc6OJsMO2OHAKuV3q5SH"
    "LDhgQyuWoMmUxuW1w3n0qcnbDudXww4uS9DkIssD2OHAKgWmNH5YgiZTGjDsgM2lFbNzO2CHA6uU361S3oYdsKEVS9BkSuPy2uE8"
    "+tTkbYfzq2EHlyVocpHlAexwYJUCUxo/LEGTKQ0YdsDm0orZuR2ww4FVyu9WKW/DDtjQiiVoMqVxee1wbhPlhx3Or4YdXJagyUWW"
    "B7DDgVWKLKrxwxI0mdKQBQfscG6zo8ltQytWKQ9ZHtxWKW/DDtjQiiVoMqVxee1wbhPlhx3Or4YdXJagyUWWB7DDgVWKLKrxwxI0"
    "mdKQBQfscG6zo8ltQytWKQ9ZHtxWKW/DDtjQiiVoMqVxefHok5sHwziF85NhBx+WoMlj2AE7HFjCSZOHDU6pwOycPDjZAFqBLC4H"
    "YINTKg9ZHsDm0orZuR2woRVL0GRKA4a9ePTJzYNhnML5ybCDD0vQ5DHsgB0OLOGkycMGp1Rgdk4enGwArUAWlwOwwSmVhywPYHNp"
    "xezcDtjQiiVoMqUBw178JauUz01p/AuyPPiuYS/+klXK56Y0/gVZHnzXsBd/ySrlc1Ma/zsv/pJVyuemNP53Xvzn+gzn/9uL/1yf"
    "4fx/e/EYApRzmpwy+JwMbl70Gc4XJqdIvktGOT+bUM5pCJdIPvXiMTuQymkJEM7nZHFrRZ/hfGFz8uC7ZKXysyWkclrCxYNPvXh0"
    "4SSZsMShEkycP8iq4BTQZzhf2BWQxTcNqpLbqOBkjFROS5xTFp8wefGTPj1g0bgtOfiDrFQefYbzhZ3Kv7Cr8ZCVym2nclpy8KUl"
    "r07y1qcHLBq3JQd/kJXKo89w6CSIQFUn+bBT+dCrRCBBpAo6CSJVnQQRqNrlJBdZqdx2KqclBx86kCKQdJLTkteuxlufHrBo3JYc"
    "/EFWKo8+w2HJATZAc9H4sFN5yAofBgf06QGLBjY8lhxgAzQ3pHKRlcptp3JacvBhCak2oNVO5bTktavxQbpFwKIhUExRit/ISudU"
    "0Gc4LDnABuW5UIrbKofiJCt8dOGAPj1g0ZBunlOUskFpLSSVi6xUbjuV05QGSAFLKt1GobVTOS157Wo8ZKXy6BM8YFfjN7K4taLP"
    "cFhygA0PQFYqjz7BA5AVDrMf0KcHLFqf4Zx2NRsegKxULrJSue1U3mx4wKKBDU3YqZyWvHY1HrJSefQJHrCr8RtZ3FrRZzgsOcCG"
    "ByArlUef4AHICofZD+jTAxatz3BOu5oND0BWKhdZqdx2Km82PGDRwIYm7FROS15CcVsoxQcx8wCh+I2sdE4FfYbDkgNseACyUvkg"
    "YF0LWeEw+wF9eoBQfVKeIJQND0BWKhdZqdx2Km82PGDRwIYm7FROS1687Wr8YMODz8hK5dFnOCw5wIYHICuVH4a1QlY4zH5Anx5c"
    "+gQPLjY8AFmpXGSlctupvNnwgEUDG5qwUzktefEY0qvxJkPEg8/ISuXRZzgsOcBGldcgSW6zvJtIK2SFw+wH9OnBRaSbBxcbVV5D"
    "eioXWancdipvNjxg0cCGJuxUTktePGanGm99ggefkZXKo89wWHKADdBcND7sVBvQClnhMPsBfXrwsOHBxQZobkjlIiuV207lzYYH"
    "LBrY0ISdymnJi8fsVEAlJ0Mgis/ISuUhlglLDrCRFTUq+DAoBKKQFQ4mDmKZXYJT70UW0DtEDajgIiuVkzEqKjkZIZYJiwY2NGFU"
    "cFry4jE7Fw9AVipfkZXKz5YcYMODX/QZzkVWOD/M3orLsFb8SVYqpyVAOKddjduigQ1N3pa8eAzhksFplvMVGeX8bIiCDQ9+ISOD"
    "i6xwfhjixcW6F3+SUc5pcsrgNFFuEwXrkbwNefFX2PDgc7LC+d958VfY8OBzssL533nx3+gzFUyc/9aSVnxYje9ZcvDiBxmUc+rG"
    "JRKsR3IZUXyY3MrpM5U+iOBPE5TvWtKKx5TGSQblQDcuGfyhz4MXb2IY5QnY4OJBH1VEgYnztrml0mcqMsST35kYBM73LGnFY1cD"
    "MYxUwAYXD/60w1/QSU6ySJH0AhtVQCSju3VNWFq8bUignD5ToUvwO5mS0Dn4niWtuPWZCrKAVMBGFZDBnzbHC3Y1TrJS+yQVbIRz"
    "G5mza8LS4m1TjVufqXxqCa3YHHzPklbcNgcgC0gFbITzhc3xgl2Ntz5TwUY4l2GazEiWFv/YVOPWZyo2CGeYxzAPHkta8djVZFXj"
    "1ifhXIbhwWV22pRW3DYHF1mkAjbCuQ3zmB1NZqcVp328YFfjrc9UsBHOZZgmM5KlxT821bj1mYoNwhlWJVIVyWVJaXHbJJ0sh24i"
    "VARgJlRFwjAooRW3zcFFFqmAjXBuw6pEqKJDaQE7XwMjoIJLn6lgI4tM6MOzD0+TKBPnsanGrc9UbBDOMLK6oMnFTALnsiHAqkGf"
    "lYh40o2iiwd9SNCFVtw2BxdZpAI2KskEhpFFF4IutAI2r82tGhezCLABRFYxiCHK1JLRNbltyqEK+kzFBuEMK08z0eQ2DJQENqnI"
    "Ki3M0rERLmYemEUwe2kNoxW3zcFFFqmADSCjimF4MDuaw2gFbF6bWzVOfaYCNrh4MEwtcvZWS6e04rK5VIM+U7FBOMM8YJgmjyXA"
    "AexqIIvUPlPBRrgNPGBUMLsmLGnFbXNwkUUqYIOLB8PwYHY0WdIK2LxgV+PRJ6k8huEBs2syI5e0WnJw2VyqQZ+p2CCcYR4wDE0+"
    "LIEDdjWQRWqf3MJtcPNgdk1Y0orb5uAii1Q+2PBgGB7MjiZLWgGbF+xq3GRKevGQ0T1ApGpUsCJYcnDZlEMV9JmKDcIZ5gHD0ORD"
    "Z5LKrgaySO2TW7gNbh7MrglLWnHbHFxkkcoHGx4Mw4PZ0WRJK2Dzgl2Ni5iVJ2/DPLjNSJYWSw4um2rc+kzFBuEM84Bh6cU/Nhzs"
    "aiCL1D6pBDJtkAVEMbsmLGnFbXNwkUUqH2x4MAwPZkeTJa2AzQt2NS42SOUkUoWM7sFFLIoVwZKDy6Yatz5TsUE4wyJKRtfkIkLS"
    "J6lsNLFBuExJ5dKHRBSX2T2QKa24bQ4uskgFhELMPBiGB7OjyZJWwOYFuxonWZDKyUY4w/DgMiNhSaslB5dNNW59pmKDcIbhMQxN"
    "LktotYQDNtVkUQ36TOVmAw8us6O5hFbcNgcXWaQCJo4NPBiGB7OjyZJWwObFmyxu4Ta4eHCbkcDSKa24bKpx65NUG4QzjIsmtyXc"
    "DtjcqkGfXMJhGCcPmJ1LK26bA2RxS+2TSzgMw4PZ0WRJK2AfL95kcQsX6UZkFZdRwUlG1+S2qcbDRqoNwhkWaT2iuIkMASVho8zy"
    "KqDLIKMKZHQiq0CmeA1pxW1zgCxuqSLdIL1gGB7MjiZLWsHsx4s3MW6Z0DuZPHoVFxPnMajgIZYpRibDPHqP4s0EnNOuxqjgJkYm"
    "l96J4mISZeI8hnnA4JYJYpAJ9E4UvROFiQOb48VfMsyDT+1q/Bu7Gt+0U1/8JcM8+NSuxr+xq/FN++DFpzaXVnzKBqdUGDjMnsp/"
    "qU9acevz4Gd9ckrlT9b1xQ+dS3LaXFpBz17FL8SMUyoMHKxn8IfOpYpv6ZNW3Po8OHWo4tQnp1T+ZF1f/LC5tAI2l1bIOmYGvxjG"
    "JRUGzhdm5+TBt/RJK259HoAsCOfUJ6dU/mRdX0DvzqVDN1oB2wtIes+cGTAyeRtWzilh4Hxu9Aqgim/pk1Zces/k1CfhnPpwTsmf"
    "zOoF9NH40CetgK3JxawxM2B58jasGo+B87mNB9/XJ624WFduS8I59dH4gg1eQB+NN1mtgK3Jxazxh2HVeAwcZk+FYZw8eGw8eGwu"
    "rTjNDrQCNqcDkMWtFRfrym1JOKc+Go9h1ZaQuiGVU5+vDr07VdxktYI+NbmYNXoVPflhWDUeA4fZU2EYiVQkt01GcttU0T0L+qDo"
    "raDPhK4JskgRaMXFunJbEs6pD09uw6qNLuWGVCTQ52tz0+QmqxWy0ORi1pgZslrxj2HVeAwcZk+FYdWYPZXbhlRum3A2HrAJZ7dC"
    "Fpp90gpZqAxoxcW6clsSzqlPWnEZVo3Z4WBYNaDP1+amyaVbbwV9Jicv6R2JoKeRQ7kNI4EMGDjMngpDIukm6Vw6JgWRsCOKPiJg"
    "RxQ7I2WhKX206tY9MaMVF+vKbUk4pz5JKIdh1ei9ezKsGtDna3PT5NInrYDNpRWywAOYFevgNoxLKgwcZk+FgQPDOHgMAzxgawIr"
    "ArYmbDxkoQm7lQ1a0SetuFhXbkvCOfXJKRWGVQPrCsOqAX2+gD4aj2HV+NAnrbj10ZjlbE1Ow+DgNnCYPRUGDgzj4B8bD9iawJJw"
    "NjcPWdxa2aAVfdKKi3XltiScN+sKw6qBdYVh1YA+X0AfjVs3SedDn7TiJubMcrYmp2Gkchs4zJ4KAweGcfCP2SOKrQksItjJJVIW"
    "ycnLBq3ok1ZcrCu3JeG8mXkyrBpYVxhWDejzBfTRuM2eyluftOIfs5ytyWlYNR4Dh9lTYeDAMA5+WBLO1gRWBGxNbrLQ5GKDVvRJ"
    "Ky7WlduScN5scDCsGlhXGFYN6PMF9NG4TJFU3vqkFZcuAbOcrclpWDUeo6czeyqMno4ZnlxGFMweUeyMZHYP2BnJRRaaXGzQij5p"
    "xcW6clsSzgczPBlWDawrDKsG9PkC+mhcNqTy1ietuAxRmOVsTU7DqvEYVo3ZU2FYNWZP5bY1YeMBm3A2HrAJ5yILTS42aEWftOJi"
    "XbktCefD7KkwrBpYVxhWDejzxVufPDRlcarGT2aHg9uwajyGVWP2VBjGyYPH5tIK2FxacZodaAVsTgcgi1srLtYV6JPbAX0C4cCw"
    "amBdYVg1oM8XbzJ4RMrgVM5PrINys17Ow3o51jNg9AIieQzh5AXs5OTFyTrgBQyBckAGNy8uvWdCN24K3YAMwHo59O5gvRyk9xd/"
    "y8D53NbkX+jz4Jus64u/ZeB8bmvyL/R58E3W9cXfMnA+tzX5F/o8+Cbr+uJtdjQ5DeMUDqxSfreESzVkeQA7nE8soRXftUp5yPLg"
    "tko5yeJy8KkXb7OjyWkYp3BglfK7JVyqIcsD2OF8Ygmt+K5VykOWB7dVykkWl4NPvXj0qUyqAcMI59RnKy6yPHhbgiYXWR58wQbh"
    "q5RvWqU8ZHkAG0jlJEuTLwx78ehTmVQDhhHOqc9WXGR58LYETS6yPPiCDcJXKd+0SnnI8gA2kMpJliZfGPba4bxNacCwg1ufrZjS"
    "+MUSNLnI8gB2OLBKpzQ+bGjFY0obvXGzQSq32fHgttJXKQ9ZHtxWKSdZmtx2ODZIpU9NTsNeO5y3KQ0YdnDrsxVTGr9YgiYXWR7A"
    "DgdW6ZTGhw2teExpozduNkjlNjse3Fb6KuUhy4PbKuUkS5PbDscGqfSpyWnYa4fzNqUBww5ufbbiNKXxwxI0ucjyAHY4fZKKLE0e"
    "NlrxmNKQ5QFsaDJbgSxNhh2wofVBKr9bpZxkaXLb0IolKJNqXF47nLcpDRh2cOuzFacpjR+WoMlFlgeww+mTVGRp8rDRiseUhiwP"
    "YEOT2QpkaTLsgA2tD1L53SrlJEuT24ZWLEGZVOPy2uE8+qQaNxuEA0vQ5DHs4LKESzVkeQA7nD5JBaY0PiyBVGBKQxYcsMOBVTo7"
    "mgw7YIcDq5TfrVIesuCADa1YpcCUxuW1w3n0/6MOjo0gOXKF3X4dUaZASFMgpCkQYAoEmJICTEkBppTwqqq7ORzembfkBoV/z1n0"
    "4GFBOrCFWbyFHdy2cOuBbE/gTEcXNYElg48tUBNYMpANB5zpwO65lFmEHXCmA7snf7V78iYbDjhhNLsnsGRwe53pvOmaxdeZzpvs"
    "WVzCDm5bmMVNtidwpqOLmsCSwQ9bmMWSAYQdcHIbzVIeB5zpwO7JX+2efIUdcMJodk9gyeD2OtN50zWLrzOdN9mzuIQd3LYwi5ts"
    "T+BMRxc1gSWDH7YwiyUDCDvg5DaapTwOONOB3ZO/2j35CjvghNHsnsCSwe11pvNYTH440/lZ2MFtC7O4yfYEznRg90Q2PfhhC7NY"
    "MpANB5zpPJYyi8cJo9k9eZPtyWP35CvsgBNGs3sCSwa315nOYzH54Uwjkk7rAAAgAElEQVTnZ2EHty3M4ibbEzjTgd0T2fTghy3M"
    "YslANhxwpvNYyiweJ4xm9+RNtieP3ZOvsANOGM3uCSwZ3F686eLhSRiXdP4k7OBjC7O4yYYDznR08ZjF4+RRE1jKxRM4uY0G2dwO"
    "wIJLTd5kewInt9Es5XHACaPZPYElAwh78aaLhydhXNL5k7CDjy3M4iYbDjjT0cVjFo+TR01gKRdP4OQ2GmRzOwALLjV5k+0JnNxG"
    "s5THASeMZvcElgwg7MW/ZPfk15YM/gHZnvxdYS/+Jbsnv7Zk8A/I9uTvCnvxr9BFTX5tyeAfkO3J3/fiX6GLmvzaksE/INuTv+/F"
    "/xMsPPmvvPh/goUn/5UXX4tLFiDBxZtfC+GWBaud31hcsvh7LDx5C/EGTMEbMOUy+QVT7xdfJ5dZgC4uo/m1pdw84ezBr8nmMou/"
    "x8KTt6WjAQsYDYQBPfiFsNEvvgxUZwG6qiB5mDg/W+pcquHswS+ZNJdq/h4LT95UkouoyWggLBuSX1CpfvEnFrMAXel8LR3NT5Ye"
    "fJw9+KXN4J+w8OQvlo4Gwmbxey+l+LKYBehK52vpaH6y9ODj7AEiBSLdoBSPLZPiodCtFBeRbqW4KIV2g3JR8+Qvlo4GwmbxphTK"
    "pVspLsrr7MGXxSxAVzpfS0fzk6UHH2cPCBuNrnTYcvDYQk1ussFz6WggbNbZg8vSQ3Y6bOHmyV8sHQ2EzeJt6SGby6yzB5ctr7MH"
    "XxazAI1MoblJyGyQRmgeSwc0t7MHhI1GVzpsOXgsoR0aZNOZoZNGzGbtnoCEDNnpsKVB8OQvlo4GzLwEaFh6yELo2WcPLlteZw++"
    "LGbxtnQ0YDEL0OW59OCxFEjncvaAsNHoSoctB1+6YBaya3LZDF0wi1vYLGSnw5YDLDz5i6WjedtCTVh6gC5POHtw2fI6e/BlMYu3"
    "paMBi1mALs+lB4+lQDqXsweEjUZXOmw5+NIFs5Bdk8tm6IJZ3MJmITsdthxg4clfLB3N2xZqwtIDdHnC2YPLlpfQvMmqbD6WjuYi"
    "zUWXp9A8lg5obmcPCBuNrnTYcvAHMWsmuyaXzdAFs7iFzQJpYMsBFp78xdLRvImsmrD0AF2ecPbgsuXFH3Sl87V0NH/Q5cnX0oOP"
    "sweEjUZXOmw5+MECBrsml83QBbO4hc3ibcsBFp78xdLRfMiuCUsP0OUJZw8uW158LTSdr6Wj+YMuT76WHnycPSBsNLrSYcvBI3Cw"
    "yCrZ3Vmm1SViOotb2Czethxg4clfLB3NW1AULD1AlyecPbhsefF1QjpfS0fzB12efC09+Dh7QNhodKXDloPHZoDFLGSD59LRQNgs"
    "bmGzeNtygIUnf7F0NG+bwWXpAbo84ezBZcuLrxOqILmICs4PYlV8LT34iE4IG42udBXBeZi4KJKNbPA0cS6qTXJRzTaSi0l3WXjy"
    "ppIgCibZyUVFOrksPUCXJ5w9uJi8+Dp5jAYsZvE7Sw/+LGw0utLDRvMHXemAbPDka+nBx9mDx1nTwpO3paPRxa0Hl6WjuS09QJcn"
    "nD14vPhaPLwB0yx+J2TyZ6be6Eo39eYPapWAbKqSr5DJx2rnsdrVsnhbOhoJHpNLyOQRMkEtC1Y7iBQv/h260vkV2TX5J5aO5u8J"
    "G/3i36ErnV+RXZN/Yulo/p6w0S/ghINf08VHOv82XTzS+b2lMIvfenFyOfg1XXyk81tLZ/HP6eIjnb8K8+SyFGbxW68tXA5+TRcf"
    "6fzW0ln8c7r4Sucvwjy5CTS/9zq5HfyaLsp5NL8Txiz+OV2UAxqk8zMLPPkbXoIsOLjIoifIopw3XdTkBzMyuZnhRahXGDTMJpTZ"
    "wBJmwxIG7J58yKInf9BFTcCCzuRiRiYXM6HBi1Dw4hbKbB5LBixh8AJOOLjIhnRkU5M3XdTkS02E7iwgDE8zmarCbRZbGA1sYTSc"
    "cCyUYnKRQKHa+dBFTUDMSAc1EbqzMBNuniyFWUCIQuHNZcvopVC8gBMObhb0kND24k0XNfnQEG7tBWF0izAJ4TaLLYwGtjAaTijl"
    "dnBZyiOdN13UBDSEdDSEW3tJKDdPlsIsCBVu5Q1sKZTbCzjh4CYbMjc1+dBFF5dONIQqVGkvwoBsqjWEbKrZwmhgC6PhBBwC0mFp"
    "JxD04E0XNQELKktDqEKV9pJQsqlmKcyCpWRjQnnDFnAIeAEnHDzC6Nb24kMXb+lYUFmoKZ6EQWZzWcosLlsYDWxhNJzgCSdwIJse"
    "QFgP3nTRBYiSjgWVhYTiSRieXJbCLMyEWWgIo2ELnnDCCzjh4C0M6MGXLt7SsSAdCMOTMPDktpRZXLYwGtjCaDjhACzgQDYkF+vB"
    "my4+2gsL0oEwPAnDk8tSmMVSMhu2kA5bGA0nvIATDt5kQ2fypYsuLlVYkA6E4UkYeHJbyiwuWxgNbGE0nHBwOeFANh89eNPFo6sK"
    "LEgHwvAkDE8uS2EWS5kFbIHRbGE0nPACTjh4C4P24ksXNXmzIB0Iw5Mw8OS2lFlctjAa2MJoOOHgcsKBbEhunbzpogvo5GJBOhCG"
    "J2F4clkKs1jKLGALjGYLo+GEF3DCwUM2lx586aImbxakA2F4Egae3JYyi8sWPIEtjIYTDi4nHMimBz/RRU2+LEgHwvAkDE8uS2EW"
    "S8ls2EJ5s4XRcMILOOHgYUGh7cWHLmryZkF5I6F4Egae3Jbi1cAWGI2GMBpOOLiccCCb9uLPdFGTLwvKGwnFkzAyG1gKswgVZqEh"
    "jIYtjIYTXgoLJhTIpodsavKhi5q8aQiVmNJehIEnt1DBuyAMvAmB0XDCweWEA5bSzqX40EVNvjSEStRoL8yErG6WwixYijchlDds"
    "YTSc8Dp56wG6qClLejZvuqjJh5lw60wIA08eSwFP2MKlBUbDCQeXEw6QJdx6Nm+6qMkfNIRbZwJhgFcvhVkQxqNnA1sYDSe8Tt56"
    "oIseIJuezUMXNfkyQ2gygTDw5BEq0LNZCs1cwmg44eBywgHIQoDuyZsuavKDGUKTycVMoL2WwiwgVKCZzWULo+GE1+ZjyIKeIAt6"
    "8tCgnB/MyOQWCl58LGE2sITZLGE2bBhcNgxusqAnXxqU82dmZPIRiheh4MVtCbN5bBjAhhf/4178j3tBGIzml3Txkc5vyR7Nf2Ep"
    "jx78H2aD2wk1+b1XoAKj+SVdfKTzO2I2mv/CUt4ym5+pyeBm0MXvvTYCjOaXdNE8yvkdXcziv7CU5iLM4mdhPZu/4QVhMJpf0sUs"
    "/gNd4Mk/t7QmoAs8+UkYjOY/e4GYMZqLKUxQw5uHLmbxBzUgi4saEzUmZgLd7ZjC5LLIgkUlCyp5M4XJD0trArrAEzAFvIFQgaKS"
    "BZVcJIB2HlElAbS/AF2M5mImHIhZefPQxSy+xAzIosCCiRoHYdx6sBQOQDaesKWSBZXFRTGFSTcfS2sCusAT1BTwatjCLZ0TagKi"
    "AbRTXHaVBFDzBehiNDcLDsJ68KGLWXwt5dEDLHgchHHrwVI4ANl4whbeegCyefPkY2lNQBd4whZunrCFWzon1AQseJsFbOFR8wXo"
    "YjQ3C3qa9eBDF83NC7bQE8x6gAWQSSMazIZmKRyAbDxhCz3BrAcgGy/YePKxtCagi1nIEjJhUY6E9gSaE2pCqDBAFrOALeUQSr8A"
    "XYzmpqakSDkfunjzhC2dCWF4YgGVxUUXo7kshQOQjSds6UwIwxMxYxacePKxtBMQYzSyqSxYWhPCenA7oSaEkQ66yGzYkg5L4QXo"
    "YjQPXUBNvnTx5glb0oEwGG0Bs7jpYjSXpXAAsvGELelAGIy2gFlw4snHUj5GI5tZwNKaENaD2wk1IawHoAs8YUs6LIUXoIvRPHQB"
    "NfnSBZ68bUkHwmC0BczipovRXJbCAcjGE7akA2Ew2oIPTz6WcqvJRTazgKX0IKwHtxNqQlgPQBd4wpZ0wIIXoIvRPHQBNfnSRWbz"
    "tiUdCIPRFjCLmy5Gc1kKByAbT9iSDoTBaAvI5lLNx9JOoIuLbGYBS+lBWA9uJ9SEsB6ALvCELemABS9AF6N56AJq8qWLWXxsSQfC"
    "6NkWMIubLmZxWQoHIBtP2JIOhMFoC5jFT5bW5Es2s4Cl9CCsZ3M5oSaE9QB00ZmwJR2w4AXoYjQ3Cy41+dLFLD62pANhPcACZnHT"
    "BZ7AUjhAF3jClnQgDEZbwCx+srQmX7KZBSytCWEwGjihJoT1AHQxC9iSDljwAjNhNDcLJiY9+dDFLD62dDmh0gMsYBY3XeAJiBkH"
    "ZgKesCUdCIPRosEsfrK0Jl+y6UyWUhPCYDRwQk0IoyZqyixgSzpgwUsxBe9uELOahDGLN13M4mOJtBPSPcECZnFTU7IosGBiCnjC"
    "lnQgDEYjoVlcuvlYWpMvCaWSRWeCmTDp5oSaYCZM1ChvYEs6YMHr5C0dltaEMBjNQxez+FrKrSZgAbN4yAZ6gAUfnrAlHQiD0cAW"
    "bp58LK3JD1u4eXKxANI5oSZgwePgtiUdsOB18pYOS2uCaDCahy5m8SXIgswGLGAWb7KEHoAuZsPGE7akA2EwGpBQGDRfS2vyg2DG"
    "oHnognROqMlF2NCzuW1JByx4BW9VYNIJiJHNQ4xsfhCDKi6qkM2HCZ2AGNkQVEFQBahCNhcTcH4w6eTPVHE+xKCKgE4eAZ08TKoA"
    "VV78j3sBJxz82lI+evCvO3mk83tLmcXvvRQWHPzaUt6qnd/Sbv4bJ4/K4q8Uipsp3vze6+R28GtLeZvF753p/DdOPg7+aguj+Rte"
    "CgsOfm0pWVy6+b2ze/JfOCu5mFYlP9vCaP6GF3DCwa8tZRb/yQkH/4XTk4sF6fxsC6P5G17ACQe3LYwGXaN5W8os/rCUiyeXsANO"
    "z5NHOrDLuegaDbqouRRq8ljKxZOv05OLBenAFi6jQRePWSxlFpelXDy5hB1wAp4v4ISDW6h4taqN5m0ps/hS0wLNKiBsgmUtEaAq"
    "gV3ORddo0EW7itLeDagKoJ58nZ5cLEhHZHUj4l2oKRR4s5RZgJoWaFYBYRNMBM8XcMLBw4L0LYzmbSmz+JBND2TTAwgDDsACOLjt"
    "ci66RoMuYLKAWSB7Fsj25Ov05GJBOhakY0FNYAujuSxlFsimB7LpAYQBRxieL+CEg4dI0FpZfCyluHljqlmFbHoAYVQWILIqi9su"
    "56JrNOiivZEQZmGqs0B2l/NxdnMR8WosSEckaG+2MJrLUmZhqlmFbHoAYWSVyPJ8ASccfGyBmnwt5W0WS5kFsukBhOHJ40znscu5"
    "6BoNuqgJLGUWS5kFsunBx8nHAViQDmxhNFsYzWUps1jKLJBNDyAMT+D0fAEnHHxsgZp8LWUWb0uZxSV0AGF48jjTeexyLrpGgy5q"
    "AkuZxVI+evBx8kjnYjGayxZGs4XRXJYyi6XM4hKGJ2EHtxNewAkHH1ugJl9LmcXbUmZxCR1AWGXxOCuL2y7noms06KImsJRZLKV4"
    "tPNxdnPJ4mIxmssWRrOF0VyWMoulzOISVlmEHdxOeAEnHHxsgZp8LWUWb0uZxSV0AGEHHycc3HY5F12jQRc1gaXMYimz+NnpyR8s"
    "RnPZwmi2MJrLUmaxlFlcQgcQdnA74QWccPBQ08royddSZvG2lFkgIQwg7ODjhIPbpr0J0dGgi5rAUmaxlFn87PTkDxZVCezOgi2M"
    "5rKUWSxlFkgIAwg7uJ3wAk44eFiQvnvytZRZvC1lFsimBxB28HHCwW0Lo9nCaNBFTWAps1jKLH52evIHC9KB3RPYwmguS5nFUmaB"
    "bHoAYQe3E14nHwdsYTRbGM3bUmbxIZuHJ5ewg48TSAe28DYadFETWMoskM3Dk6/Tkz/Zwq0msIXLLJYyC2Tz8OQSdnA74XXyccAW"
    "RhOi3sVjKbP4kACFyuISdvCxREgHQoVu0NGgi5rAUmaBhAhQWXydnvxJqNBNJRCiwCyWMgskQKGyuITNbuCE18nHAVsYDbqoyWMp"
    "s/hBNj14hB18WZDOxYJ0dI0GXdQEljKLy1LowQ+nJ39mQTpvuoBZLGUWN9n04BGGJ3DCS/koUChABIqHQjd/olA8RIovEbq5iNCN"
    "SAEiUIBCNxflUvyg3fyZCN28iQDdKHTzUCgeInQDCi/+x72QDZ78mgVfs/iXyeatJv+HxSxuYbP4vReywZNfs+BrFv8y2bzV5P+w"
    "mMUtbBa/90I2ePJrFjCa/2ALNfnHZIMnoCudv7CYxd/wQjZ48msWMJr/YAs1+cdkgyegK52/sJjF3/ACLDy5WcBodKXzZgGj+YMu"
    "mMUtbBay08O4pcMWasJSeoDFLGSDJzddXA6+ZIMnoCudmy6YBeji1gPCZnELA3rwOHtYwOgXYOHJzQJGoyudNwsYzR90wSxuYbOQ"
    "nR7GLR22UBOW0gMsZiEbPLnp4nLwJRs8AV3p3HTBLEAXtx4QNotbGNCDx9nDAka/AAtP3paORlc6bxYwmg/ZNWEpPSAM6MFlCzW5"
    "bKEmLKUHWMBodMEsZIMnnD14kw2egK502EJNWDoasJjFLWwWoAtmnVCTywnpYfACLDx5WzoaXem8WcBoPmTXhKX0gDCgB5ct1OSy"
    "hZqwlB5gAaPRBbOQDZ5w9uBNNngCutJhCzVh6WjAYha3sFmALph1Qk0uJ6SHwQuw8ORtKVCTLwvePOGEmlzOHhAGB48t1OSyhZqw"
    "lB5gAaPRBbOQXZPL2YM32Xylw5aDy1I4wGIWt7BZgC5PQDZ4wtmDy5YXYOHJ21KgJl8WvHnCCTW5nD0gDA4eW6jJZQs1YSk9wAJG"
    "owtmIbsml7MHb7L5SoctB5elcIDFLG5hswBdnoBs8ISzB5ctL8DCk68t1OTLAkbzdkJNLmcPCIODxxZqctlCTVhKD7CA0eiCWcjm"
    "rQdvssGTry0Hl6VwgMUsbmGzAF2egGzwhLMHly0vwMKTry3U5MsCRvN2Qk0uZw8Ig4PHFmpy2UJNWEoPsIDR6IJZyOatB2+ywZOv"
    "LQeXpXCAxSxuYbMAXZ6AbPCEsweXLS/AwpO3pUBNvixgNG8n1ORy9oAwOHhsoSaXLdSEpfQACxiNLpiF7Jr8RDZ48rWFmrAUDrCY"
    "xS1sFqDLE5Bdk8vZg8uWF2DhydtSoCZfFjCatxNqcjl7QBgcPLZQk8sWasJSeoAFjEYXzEJ2TX4iGzz52kJNWAoHWMziFjYL0OUJ"
    "yK7J5ezBZcsLsIDR3JaOPiGdNwsYzYds8FxKDwiDg8cWanLZQk0LoAdYwGh0wSxkgyd/Ihs8+eGsaQGjAQsYDYTNAnTBrBNqcjl7"
    "cNnyAixgNLelo09I580CRvMhGzyX0gPC4OCxhZpctlDTAugBFjAaXTAL2eDJn8gGT344a1rAaMACRgNhswBdMOuEmlzOHly2vE4+"
    "DrCYBeiCWdwsYDR/0AWzuIXBwccJ6VxOSF9KD7CA0eiCWdzC4OBLNnjyJ7pgFm9L6QFhs7iFAT14nD24bHmdfBxgMQvQBbO4WcBo"
    "/qALZnELg4OPE9K5nJC+lB5gAaPRBbO4hcHBl2zw5E90wSzeltIDwmZxCwN68Dh7cNny4n/ci/9xLy4no/m1MN7S+dedvB38ngWk"
    "81sv2AKj+bUwPtL5nS2M5p87+RrNX4R5crEgnd97bQQYza+F8VaT3zphNP/cyVfP5mdhntyE5v/H6+Q2ml8LI5Nb81snjOafO2Fw"
    "2TCan4V58je8BDaM5hLKbAgFLx5hpPMHWZTzkNUTNmOJQMNsQpkNoXiBWSaYZfKhUc4PJxxcThjNJZTZXEKRhkzMyOShQTk3WT1h"
    "05MXcMJoLrKkZ7OUzOYRRjofaiJQ7Vxkc7CU4+RtNFuYBUvxhLB2UZHO5KYmQrXzdcLB5YTREKLQ7Q1LuXliQToXNRGodkA2NZdC"
    "zRdwwmhuW5jF0szmLYx03tSURzogm0LhOHkbzRZmwVI8IYxGgM4E1JRbOh8nHFxOGE0Yj/JmKTdPLEgHNIRbl4NsKOVSL+CE0dw0"
    "pFxNZvERRheXTnTRiRikg2zAIVUCHBK2MAuW4glhUIUq6aCmnSDWg48TDi4njGYLDiaUt5qSTTUWpIOa0okYNUE24BDwAk4YzWMp"
    "JZLZfITxli6h1ETM6AGywZPbCaO5bGEWLMUTwihvLEgHXe0FujqTtxOSi8FoCxiNhjCLMDy5WJAOFrQXuuhMZIMnnPACThjNw0yA"
    "WXyF8Zaui/YC2fQA2XDwOGE0ly3MgqV4QhieYEE66OriYvTg7eQrnS1kNixlFmF4crEgHQmlJogZPZBND+CEF3DCaN6WQnnzFUY1"
    "lypd1ARk0wNkw8HjhNFctjALluIJYXiCBelIKB89eDt5JDhsYTSwlFmE4cnFgnQsoCagix7Ipgdwwgs4YTRvSyGz+QojnYcuagKy"
    "6QGy4eBxwmguW5gFS/GEMDzBgnQklC5unbydkIBz28JoYCmzCMOTiwXpqCk1AV30QDY9gBNewAmjeWgIMIuvMNJ56KK9QDY9QDYc"
    "PE4YzWULs2ApnhCGJ1iQDrqoyU9OOPjaglfDUmYRhicXC9LBgpogZl2ObHoAJ7yAE0bzWFqIZDYfYaTzUFNqggU9QDYcPE4YzWUL"
    "s1BTPCEMT7AgHXRRk5+ccPAVBqPREGZhJpkNWJAOFlQWuqgJsukBnPBSWDChAFkyaymZzVsY6bzpoh0JSAfZcPA4YULBFrwxBU8I"
    "wxMsSAcNqeTSzccJB3/YgjchtBeEkdWNBemgIVQiQU2QTQ/ghNfJx2hkSc8Og1m8hZHOm4bwqAnIhoPHUi6jCePSCJ4QhidYkA5o"
    "CLcefJxw8IelPNoLCAMy24J0QEN4pINsegAnvE4+RrOFWbAUT97CSOdDA4HuyUU2HLwtBUbDUmivpZ4QhidYkM5FA4HuyccJBz8s"
    "EWi8uIQKdKYF6Vw0EOhyQDY9gBNem4/ZLGE2hIIXDzMy+YMGPXnIgsHHBmYDS/Ai1AtCyQQzynlo0JM/bBj82RK8+AglEzMyeWjQ"
    "k5ssGMCGF//jXvyPewGy8eTXZPNWk3+dBY9Z/F4YB7/3wkQUT35NNm81+S0xsvnnLHhUd/IXqmRzUSH5vZeEAp78mmyaWzm/pYvR"
    "/HMWNBehJn9hwWj+s9fJzZNfk80s/gNdjOafs2A0sLQmf2HBaP6zl4IEnlwk8IYF7bzJZhY/LCp5hLSDqoeIULSDGt6wyALUmKjh"
    "zYdpOz9YMBpYSk0uITC5LEQoKsGUyUMNb24SZLGg/QXIxpOLLmbBli7nTTaz+BBhUUlxWVpTUR1buNUEC0YjG0/AgokaXs1NMW2n"
    "mw8LRgNL4QA0BGYBJ4+aEMbBRVHDuxuQTRYL2l+AbDy56GIWbEnnQzaz+LDgMRpYWvOEHlu41QQLRiMbT8CCN08usnl48mHBaGAp"
    "HCCb2yw4edSEMA4uW7jVBGTz9QJk48lNdmeys5oP2czibYkw0KC9YCktXrSEwmwaLBiNbDwBC/CSRZeDmeAlC08+LBgNLO3ZaMhs"
    "2J2JhMJsGsI4QJZQzhJ6gGwoZwm8ANl48jipImbxJZtsoBqWdjmqhicshcwG1JTRXCwYjWw8AQsym1CpCRZkNmGVxZsF2YBJTdSU"
    "0XDiCUthNJcwDpBNVWImHCCbqsRMeAGy8eRxcpvFl2wenrC0JiAbT1gKBw9djOZiwWhk4wlYMBrYUhMsGA1sqcmbBR81WQqj4cQT"
    "lsJoLmEcIBtPIIwDZOMJhPECZOPJ21JgFl+yeXjC0pqAbDxhKRw8dDGaiwWjkY0nYMFoYEtNsOCjJm8WvKXD0h7cltZkKYzmEsaB"
    "BXgCYRwgG08gjBcgG0/eloJX8yWbbKAaltYEZFOVLIWDhy5Gc7FgNLLxBCwYDWypCRaQokBN3izI5tIFS3twW1qTpTCaSxgHFuAJ"
    "hHGAbDyBMF6AbDx5SCiM5g+ymcXb0pqAbLqcpfTgoYvRXCwYjWw8AQtGA1tqggXtBFDOmwWj+VjaswFZUpOlMJpLGAdmgicQxgGy"
    "8QTCeAGy8eRxcpvFl2xm8ba0JiAbT1hakzddjOZiwWhk4wlYMBrYUhMsGM1PLBjNx1IYDSfUZCmM5hLGAbLxBMI4QDaeQBgvQDae"
    "PE6qgll8yWYWb0upCbLxhKXU5KGL0VwsGI1sPAELRgNbaoIFo/mJBaP5EDNGw0lWsRRGcwnjANl4QqhwgGw8gTBeChJkUSCyOis0"
    "s/mQzSzeQoUJEpUFS+HgoQv//6iDY2PHcixAlMmIa8oRYAoEmAIBpkCAKRBgCgSYQuFfko9VPTPds7UbX5nMcw61a4epDdQuHexY"
    "hVxz8XKOH7VLx1ft2mFqg1pDO+fQq4voeSx6nFOIrQ306vH0cRJ5Kosdo/kRW1l+1O4tHczM5S1PrELtPtpA7dLBjlUQ21sbftQu"
    "HV+1+2gDtWMVenW57fCyCmJrA716PH2cRJ7KYsdofsRWlq88ccpxm5nLR2xWQZ6sZo6B2qWDHau4xXYry1ft0vFLmEFyvOTJKvTq"
    "coueMcZBbG2gV4/uRyOqcejW8iOqcXxFxRleatD86JyBqJyhnoWcNbcaZ3jpbuP4ytk4/qIGzUdUziBnzUvOWMstqnGQs4f/cQ/s"
    "U/y92H6U5f9/M7uN5r+o3Sr+2SPTT/H3YvtRln8UcY7/exE1u63B8m8y57jlag3/7PHEKv5ebD/K8o/yLMv/vTx9reLf7FCWP/B4"
    "YhV/LzbtuJ3jH+VZlv97eVKQq1X8mx3K8gceT6zi78Xm8n+SZ1n+7+XpJNRuFf9mh7L8gYfareLlSTrEbsNHbC6/1Y423PIsS69X"
    "7d7aULtV0KvRMCP1inS8PbGKrzyd5GWHsvDESajdWxtqt4qXJ1bx8iTFRBsPtVvFy4xoZ+XobfiIzeVHhFwx1kKe7aj5yjW7rbHU"
    "bhX0ajTMaDWjnYWIeU4+7RwfeTrJy3bGEjHPyaedI9fMYiy1WwUR85x82jl40qJirIfareKtdqvMrA0fsbn86NWPC3l6ucPrJbcA"
    "ACAASURBVNjBSajdKujVaJjZxyro1Wg7lOUjTyd52aegV6Pt0AZ2KMutdqugV6PtUBaefnmo3SreandOaOf4iM3yMpZerYGaL+Tp"
    "NBY513YWarcKejUaZjTkahX0Ws7Jua7TvOXJGkuueRVmRFsnRz+rsUNZbrVbRfSIck7OdZ3Gk3aIzkPtVvFWu9tJvmL7UZZejYZe"
    "L+TpJG95luVWu1XQq9EwI6F2q6DXC3k6yVueaEPtVhGbC7G52KEst9qtIjYX8nQST9IhNg+1W8WPHZzkKzaXt9hcXno1mjyd5C3P"
    "stxqtwp6NRpmJNRuFbF9neQtTz/SITYXYnOxQ1lutVtFbC7k6SSepENsHmq3ih87OMlXbC5vsbm89Go0eTrJW55ludVuFfRqNMxI"
    "qN0qYrO8neYtT5aXdojNhdhc7FCWW+1WEZsLeTqJJ+kQm4fareLHDk7yFZvLW2wuL70aTZ5O8pZnWW61WwW9Gg0zEmq3ithc/kWe"
    "TvIVmwuxudihLLfarSI2F/J0Ek/SITYPtVvFW64ZJ/mKzeUj17zWED2inCNPJ3nLsyy32q2CXo2GGQm1W4Vc8+Vf5OkkX7G5EJuL"
    "Hcpyq90qYnMhTyfxJB1i81C7VbzV7naSr9hcfvRqNLG5kKeTvOVZllvtVkGvRsOMhNqtgl4v/yJPJ/mKzYXYXOxQllvtVhGbC3k6"
    "iSfpEJvH00tZbrWnY2Zt+IjN5UevflzI00ne8nSSlx0+RsOMhNqtgl6NJs+yfOTpJL/16q0N7OAk1G4V9OqtLDxJh9g8nl7GWuRc"
    "01FzbsNHbC4/chXBchrydJK3XEM7BzuwIoyGGQm1WwU15zVEbsdHnk7yW67ZbY2FHtlp56jdKqg545x28CQdYvN4ejuJJ+kQuw0f"
    "sbn8VruTvOXpJD9m1gZ2cFKvRsOMhNqt4uWJVXzl6SR/9cRJ3vJEG2q3ipcnVvHyJB1i88g+Fpnlls/xI7P8FsHyFsHyI3MOstuK"
    "cA6yhQiWl+y2fEWw/FV2W94icI4Ilpfstrxkllvm4X/cQ2xG8w/y9JaO///F9laW/2LH5Z89xGY0/yBPb+n4/19sb2X5L3Zc/tnj"
    "6Taaf5AnbfivdjjJ/4PYjNYr6fg3sVfxBx5Pt9H8gzxpw3+1w0n+H8RmtF5Jx7+JvYo/8BCb0fyDPEfzf7DDSf4fxF7FbWbS8VdP"
    "t9H8Hz3EZjT/IM/R/B/scJL/B7FXcZuZdPzV0200/0cPsRnN2/Mkah/NV56j+YjtRzqI7dbGzF5WodeyEHsVt5l9rOI2s5dVfMVe"
    "xW1m0hHbW1k83UZz23G51e4tHeTpx0NsRvP2PInaR/OV52g+YvuRDmK7tTGzl1XotSzEXsVtZh+ruM3sZRVfsVdxm5l0xPZWFk+3"
    "0dx2XG61e0sHefrxEJvRvD3dRvNbnt7SEXsVt5nTQexVvO1wkluvZSH2Km4zcxF7FbeZ00Geo/mIvQq9kg5PVqHXshB7FW87LvKk"
    "DWbmIs/R3HY8xGY0b0+30fyWp7d0xF7FbeZ0EHsVbzuc5NZrWYi9itvMXMRexW3mdJDnaD5ir0KvpMOTVei1LMRexduOizxpg5m5"
    "yHM0tx0PsRnNR2xG81ueo/mIvYrbzFzEXsXbDie59VoWYq/iNnM6iL0KvfoazUdsb2W5PU9y65V0xF7F246LPEdzm5mLPEdz2/EQ"
    "m9F8xGY0v+U5mo/Yq7jNzEXsVbztcJJbr2Uh9ipuM6eD2KvQq6/RfMT2Vpbb8yS3XklH7FW87bjIczS3mbnIczS3HQ+xGc3b0200"
    "v+U5mo/Yq7jNzEXsVbztcJJbr2Uh9ipuM6eD2KvQK+n4F7FX8cvzJLdeSUfsVbztuMhzNLeZuchzNLcdD7EZzdvTbTS/5Tmaj9ir"
    "uM3MRexVvO1wkluvZSH2Km4zp4PYq9Ar6fgXsVfxy/Mkt15JR+xVvO24yHM0t5m5yHM0tx0PsRnN2/OkPBnNV56j+YjNaMycDmKv"
    "4m2Hk9x6JR2xV3GbOR3EXsVt5nT8i9ir+OXJKvRaFmKv4m3HRZ60wczpIM/R3HY8xGY0b8+T8mQ0X3mO5iM2ozFzOoi9ircdTnLr"
    "lXTEXsVt5nQQexW3mdPxL2Kv4pcnq9BrWYi9ircdF3nSBjOngzxHc9vxeHprgx1OovbRfOU5mq883cryEnsVP56s4jYzV+xV3GZO"
    "B7FX8bYDq/iKvYrfYnsrC7Hd2mDH5Va7t3SQ52huOx5Pb22ww0nUPpqvPEfzladbWV5ir+LHk1XcZuaKvYrbzOkg9iredmAVX7FX"
    "8Vtsb2Uhtlsb7LjcaveWDvIczW3Hw/+4h/9xD/TK5R/Fpg0vvTrJn6mddPydXr2N5u/kKR0vO9rw3z3MEFz+UWza8NKrk/yZ2knH"
    "3+nV23GK/5B7SMdLcPx3j5m9XP5RbNrw0quT/JnaScff6dVpemAV/6520vGHHp3IXN4q66Bylo/YtOGlVyf5qJzlIzLO8lVZuZOO"
    "l8pZfuvVSWpE5vJWOctLrplxnEXlLG+RWcdbjrOonOWBXrm8PWmD3OOM4SM2bXjp1UluESZrWIiIjrEstwiToZIOESZrWL56dRJy"
    "D2URYTKWRfTsbTR2GM0tIjrtnOPW6ypZD2usB3rl8rbDGMeTNvyITRteenWSW+2c4CT06uMkt9p9pUOeHOEkX706yS1Ppxy1ezvl"
    "6NXLsRo7jIbo2dsYB72uMb2c9ECvXD52GM2TNvyITRteenUSakfq2Uno1cdJbrX7Soc8Kav2k3z16iS3PF306uuiV7ey3HYYDTP7"
    "sQp69eOkB3rl8rHDGJuyfMX2FyfRq5PQK5cfMzsJvSIdtZOO2knHv+jVSaidi1656BXpqJ10vOwwGjuMhh1WQa9OYmY80CuXj+j5"
    "CGX5Jba/OIlenYTaufyYmVXolbKonXRE7lY7/qpXFiK49BynLaJW0lE76XjZYTR2GA0zWwW9OomolQd65fIj14x0/BLbX5xErwzk"
    "4EJU5MBFr1yonXTIk3XW8luvfpwxzOwkt9pJR+2k42WH0dhhNOSaz2r06iTUzgO9cvmRa0Y6fonNOl5yOIle/XIRtbJODi565ULt"
    "pENUlbUMX70y6jqcwcxOcquddNROOl52GI0dRnPr1Un06iTUzgO9cvkxs1s6folNG156dRK9snwUUaulnV656JULtZOOlynCacuP"
    "Xp002/E2s5PcaicdtZOOlx1GY4fRED1bhV6dhNp5oFcuP2Z2S8cvsWnDS69Oolcn+ZrZSeiVi165UDvp+OgVlx+9OslXr05yq510"
    "1E46XnYYjR1Gw8xWQa9OQu080CuXjx3GmpTlKzZteOnVSfTqJF8zO4mZcdErF2onHT9q5/KjVyf5pVcuekU6aicdLzuMxg6jYWar"
    "oFcnoXYem8BhDOwY48R2xvAjNm146dVJRK2Ocmo9hZk5aWa3C7U7CKSjVpJenXL86NVJfumVQyAdauewGjuMRsxwEKyCXp2E2nk8"
    "fbXBzNrgSRt+xKYNL706CVErS8RJRM+s7OVC7b7SUTtLhJN89eokv0St3k5biNzdRmOH0ZBr9rbaQa9OQu08nr7aiFqNcajdGstH"
    "bNrw0quT3CLrrGUg18w4OXMhss5aUaUjclSsZfjq1Ul+i6yzluElcsdo7DCaW46ojHOWW69OQu08pq+xotOOWw9r+DEZy0vNTvPR"
    "w1jecqWdXJ3mbTJWdMXLxBp+q9lp/sVkLF8Ta9DDGt6i0463mp2GXHn4H/fwP+7h1quy/JPYTvK2w+VP7ZCOv9Orj3T8p9hO8qce"
    "cqihLP8ktpO87XD5Uzuk4+/06mOs5T/EdpI/9dCrW1n+SWwnedvh8qd2SMff6dWP0fyH2E7ypx7ERln+SWwnedvh8qd2SMff6VU5"
    "bjNO8u9iO8mfeqDnUJaXyNZBdZYfsZ3kbYfLWw634S2Hl7N85HCrIR236naWX3pVltsOl5fqdpZb5O4MZyGH4S2H2/CWw5Ld1nm4"
    "9aosL7Vrg9hW8SO2k7ztcHmb2S0dL716Gc1Hrz7SQWy3VfzSq7LcdrjcYruN5tarl1Www+VtZrd0vPSqmG6jPdx6VZa32OeUnqOt"
    "40dsJ3nb4XKLGavJ/Yzh1nORO6ccxAyajnSoNdrC8UuvynLb4ULPYbUZxxgiplM42OFCz2K1Gc4Ybr06wm20h1uvyvLxpNSsLF+x"
    "neZtciFyX6fJNa+xUKOJnkmHyP0cTc+kQ6/a8C96VRYRk4tc83Jaz2E0YjvJ2w4XerVO6yGvsdCrhQhrPNx6VZaPp7eyfMX2Fxd6"
    "VZbbDpevHdKhV2247ZAOvWrDv+hVWdSOS2wnudVuNGI7ydsOF3pVltsOF3pVFrXj4darsnzkmjlt+SW2v7jQq7OaXDOXj+iZdOhV"
    "G247pEOvzmr+qlfnEGGNJbaT3Go3GrGd5G2HC70qy22HC70qi4jJw61XZfnRKyf5LTbLW+ZCr5wmV1yIsKJn0qFXbbjtkA41C805"
    "funV7RzWILaT3Go3GrGd5G2HC70qy22HC70qy22Hh1uvyvKjV07yW2wnedvhQq9+udCrsuyQDr1qw22HdLz0yip+6dUtHW+xneRW"
    "u9GI7SRvO1zoVVluO1zoVVluOzzcelWWjxnBSX6L7SRvO1zoVTs+FjO0c+yQDr1qw22HdLxE6E47fvSqHctHbCe51W40YjvJ2w4X"
    "elWW2w4XelWW2w4Pt16V5eN5iFOOX2I7ydsOF3qOto4fsZ2EHdKhV20d7JCOHzNLx49eleUrZpxyiNyNRmwnedvhQq/aOsQMF3pV"
    "ltsOD7deleXj2YZeleUrtpO87XC5xbaKH7GdhB3SoVdOwg7p+DGzdPzoVVl+61VZdjAasZ3kbYcLvbKK2nGhV2W57fDoyGEd45Bz"
    "bUOOvtbwI7aTvO1wucV2lttaxGagkg6ROwOVdMjZLYd0/OhVWX7r1ToqbR3UnIczsMOFHN1ZIltroFdlue3wePpKh9q1QWyr+BHb"
    "Sd52uNxiCi+jETNwBOkgZuAQ0qFXL0c5fvSqLL/1LNxOOV56ZRXscLnFFDhWc+tVWW47PJ6+0rGDNohtFT9iO8nbDpePPJGOl16V"
    "ZYd0vPSqLGpPB7FRlt96VZZ/MTOj+RHbKtjh8pGn0Xz0qiy3HR7V1zoq1iGys3xVhrfK8BEZw1sO66gMbzmsQ+ThpWIdv+Wwjn+R"
    "g7P8iOwsVIaPyM7ykcM6bpWH/3GPp7d0/KPYq3iJTRv+TJ6U5e/U7qsN/2GHVfyhx9NbOv5R7FW8xKYNfyZPyvJ3avfVhv+wwyr+"
    "0AO1k46XmdPx72Kv4iU2bfgzeVKWv1M7ZaF20vFvdmA0xF7F35j58uOB2knHy8zp+HexV/ESmzb8mTwpy9+pnbJQO+n4NzswGmKv"
    "4m/MfPnxQO2k42VmLmovyy+xV/ESmzYQ28dJbjt8pIPafZWFPL2c5Kt2ykLtpCNPH6sws5fREHsVL7G9Xd5m9pHOA7WTjpeZuai9"
    "LL/EXsVLbNpAbB8nue3wkQ5q91UW8vRykq/aKQu1k448fazCzF5GQ+xVvMT2dnmb2Uc6D9ROOj52XHlSll9i+60NxB7N7XmSr9pJ"
    "B7WTjjwpS2za8C9qpyzU3gZPRnN7Mho7rOIl9ipuO6zCzE5ym9lJ9MoDtZOOjx1XnpTll9h+awOxR3N7nuSrdtJB7aQjT8oSmzb8"
    "i9opC7W3wZPR3J6Mxg6reIm9itsOqzCzk9xmdhK98kDtpONjB0bzF7H91gZPRnN7MpqP2kkHtZeFPCkLeVKWv6jdVxs8Gc3tyWjs"
    "sIqX2Ku4bcnb8yS3mS+3XnmgdtLxsQOj+YvYfmuDJ6O5PRnNR+2kg9rLQp6UhTwpy1/U7qsNnozm9mQ0dljFS+xV3Lbk7XmS28yX"
    "W688UDvp+NiB0fxF7FW8xKYNnm5t+NpxUTvpoPaykCdleekVJ/mqnbJ8PRnN7clo7LCKl9iruG3J2/Mkt5kvt155oHbS8bEDo/mL"
    "2Kt4iU0bPN3a8LXjonbSQe1lIU/K8tIrTvJVO2X5ejKa25PR2GEVL7FXcduSt+dJbjNfbr3yQO2k42PHlSdl+SX2Kl5i0wZij+ar"
    "Vy5qJx3UXhbypCxfW/JVO2X5ejKa25PR2GEVL7FXcdthFWZ2ktvMl1uvPFA76fjYceVJWX6JvYqX2LSB2KP56pWL2kkHtZeFPCnL"
    "15Z81U5Zvp6M5vZkNHZYxUvsVdx2WIWZneQ28+XWK4+nH5fbzFzUXpZfYq/iJTZtILaPk+jVVzqo3VdZYtPGzE7yVTtl+SVPH6u4"
    "7cBoiL2K2w4/TnKb+XLrlcfTj8ttZi5qL8svsVfxEps2ENvHSfTqKx3U7qsssWljZif5qp2y/JKnj1XcdmA0xF7FbYcfJ7nNfLn1"
    "yuPpaxVmTge1k44fsVfxEps2fPTK5W2HVeg1HS8zO4nay0Kebun4pXbK8he1u11+PBkNsVfxkSdl+Zj5cuuVx9PXKsycDmonHT9i"
    "r+IlNm346JXL2w6r0Gs6XmZ2ErWXhTzd0vFL7ZTlL2p3u/x4Mhpir+IjT8ryMfPl1isP/+Me/sc92EEb/ouZ23CLjcufyvMkf2tm"
    "X5e/MXMb/syDHbThv5i5DbfYuPypPE/yt2b2dfkbM7fhzzzYQRv+i5nbcIuNy5/K8yR/a+axvEyX/9Ajog1/5sEO2vBfzNyGW2xc"
    "/lSeJ/lbM7fhFtvlP+ygDX/mQVWjDR9dQ421/DZzG26xcXnJ2e0MLzW8neGlhrfIJ6GGtzN8zdyGW2zDOOTso2EH66xFVIxDzj6a"
    "lxq+Hm4zt+Hj6cLMbfht5jbcYuPy0qvbSV5m9naSlx1+nIQd3lbxNXMbbrGRDr36uLDDbTRiIx169XF5mdnXw23mNnxMAzW34beZ"
    "x3KLjgtZDrezLNTsJZ/kZcfylk/CjuVlDV8zt+EW29JOlsNLdqFHxDlrEBvp0Os5XoaFmTkH2cNt5jZ8Pb204beZ/XZh5jbcYrt8"
    "5XmSlx1lueV5EnaU5V/N3IZbbBdmbsMttsvLzG24xUY69Dqal6cLMzMasT3cZm7D1xPHGH6b2fESuDDzGG4xXd6C3E9xsKMstzxP"
    "wox2OP5i5jHcokuYuQ232C4vM7fhFhvp0OtoXp4uzMxoxPZwm7kNX0+U5a9mbsMtNi7M7Ovy0quPCzvKcsvzJC8zM5rfZvZ2kpeZ"
    "23CL7fIycxtusZEOvY7m5enCzIxGbA+3mdvw9URZ/mrmNtxi48LMvi4vvfq4sKMstzxP8jIzo/ltZm8neZm5DbfYLi8zt+EWG+nQ"
    "62heni7MzGjE9nCbuQ1fT5Tlr2Zuwy02Lsw8ho+DGWOROy7sKMstz5O8BHJdzdfMY3g5XmZuwy22y8vMbbjFRjr0OpqXpwszMxqx"
    "PdxmbsPXE2X5q5nbcIuNCzO34beZ2yBPXNhRllueJ/mqfRVfM7fht5nbcIvt8jJzG26xkQ69jubl6cLMjEZsD7eZzxnLyzSQYyy/"
    "zdyGW2xcmPmcNXzN3AZ54sKOZaxc5ZN81b6Kr5nb8NvM54yVq+zyMnMbbrGRDr2es0Z02YWZGY3YHm4zM5qXpwszt+G3mdtwi40L"
    "MzOar5nbIE9c2EEbtXOSr9pX8TVzG36bmdHyxOVl5jbcYiMdemWV2LgwM6MR26OiBmudhacLM691lq+Z23CLjQs1cDC8zLzWWXni"
    "Qo0ca4nIJ3nJgTjD18xt+K0GTtSzNC8zr3UWsZEOOUc+Q6BhZkYjtsfT1yp4ujAzo/mauQ232Lh81M5JXmZmtDxxeZmZ0fI8ycvM"
    "jOa3mdvwr2rnJB8zMxqxkY5b7ZzkY2ZGI7bH9HUapoIerOGrx1hu0VF85IripQdr5IripQdrRFe89GANv/VYw7+qmdN89GANoqMd"
    "t5o5zUcP1iC6h/9xD//jHm61r+KfPWnDyw6j+UMzW8XfmdlbWf67J0bz3zzswCr+2ZM2vOwwmj80s1X8nZl9jeY/PaXj5Ukb/qvH"
    "DrdV/LMnbXjZYTR/aGar+Dsz+2UV/+EpHS/B8d89nl5W8c+etOFlh9H8oZmt4u/MbDXMYBX/4Skdf+gR9GwVL7k7BbVyih9P2vCy"
    "w2g+cj/FLzOM4Sumcma2ipdaneK3ma2C6NkqXmp1ipfchcMYbNryUavVvOV+CmpdzQO9WsVL5G4VenXa8uNJG152GM1LzRGWdhCd"
    "zDmneclVtkRYBT0iWIzlY2aruPVqFfSIYGmHPL2NxpM2vPSIYClueVqlR4TRHujVKt7y5KJXJ/l60oaXHUZz6zm8rHbI08dJbrWG"
    "H6tgZm9tHR8zW8WtV6vQc3hb7cjT22g8acNtZh+rHfJkZS/rgV6t4i1yt1qucdry9WQdL5XR0HOsha4sIrvl7KyGXp2BnK1Cz7GW"
    "2/A1s1VQa1iFHdais8aK3BnHWTxpA70yDp10yBPjiMoDvVrFR2xWxBrLL09/MRp2jHHwtMbykWvmotZwEma2CjucMfzVzM5CDmss"
    "vTIatdOG2KTj5UkbxGaMIzbpkCdtHbXzQK9W8RG1uo3mt6e/GA071nGrtOGlhshczOyMgZmtQq3hrDP8NrMfayyerLHwpA2xScfL"
    "kzaITVlErcY48iQdaueBXq3i64k1lt+erOMlh9Go3S9toKrh5WJmq7jNbBXUGmjW8WNmb8NaeNKG25M2xCYdL0/aELVSltuTsuRJ"
    "OtTOA71axdcTayy/PWnDyw6j0SvreFtL5G4dkbmY2SpuM1vFLefIGOP4mNlZGMfLkzbcnrQhNul4edKGPFGW25Oy5Ek61M4DvVrF"
    "j9rdRvPbkza87DAadmjDj6jVGEftXMxsFbeZreIt58iU5WNmq/jlyRgHT9oQm3S8PGlD9ExZRO5WO/IkHWrngV6t4iO2JWKN5Zcn"
    "bXjZYTTs0IYftXMRtXIxs9MWuWarIJ9DbMryMbNV/DIzo5EnbYietXXcnrRBbMY4YpMOeZIOtfPI1Ow0FiJ3l5mdtnw9acPLDqNh"
    "ZmN5WdROoWZc9BxOowerkPtamJTlY2ar+G2HNZictvBkrHN40gbRM2OJTjrkSTrUzuPpKx2Ru5P0HE7y9aQNLzuM5tZzeCtL7uHr"
    "Qq3hxyrs8HHa8jGzVfw2s4/TltvTbbXjSRtuM/s45ZAn6VA7j6evdNTOhV6dcvx40oaXHUbz0rPgKIeYwUG43HIPDmIVZhAc5fgx"
    "s1X8Rc+CoxwvW2A0T9rwMiNwJLc8SYfaeWxf5aiVhFqR/NiM4WWG1XzUSvIWk7bkLnnJnXLUeoqXWkl+69lq/kWtJL/MsBqbtnz0"
    "7BRvuVMOufPwP+7hf9zDbWaXfzazdLzscPlTM0vH39rhbRX/3Q6X/+qhZhEu/2xm6XjZ4fKnZpaOv7XD2znF3+iheMss/9Uj1+x2"
    "+WczS8fLDpc/NbN0/K0dLCK0dfyHmV3+0OPp7fLPZpaOlx0uf2pm6fhbO7iYmTb8h5ld/tDDbWaXtx0ut9q14cfM0vGyw+WjV1bx"
    "o3ZO8iNPo5lZOl5mpg2/7eBCntrwUjuruPXq7STscPnoVVne8jSamRnt4Tazy1uueY2l5yjn+DGzdLzscHnrOTinHUQXgdWOl5qz"
    "c0RIB9EjOKv5ZQcX8tSGW8/BOe3Qq7eTsMPllqsIi+KWp3NEcM7DbWaXj9qVZYfLLzNr67jtcLlFzHOQ2zrkuRChnYXcw0KEdIjc"
    "ncNpftnBhTy1QUR3kNs6as5YTsMOF3Ku/j/q4Nhabh1bFGD1WgwFBkLZBkOBgVBgIBQYCAUGQqHxyT59JM0d6T59c6r2lpLDLQYm"
    "gZfbCIcvpTmnlRx+GEGvbis53GKonRh6JUbetMI8SQt5M0LetMI8/YeVOBBD7cTQKzH0Slo4vK3kwErUboTDLQYOMfByG+Hw7XLr"
    "1U8j/HS4xVA7MfTqW1rmSVrm6TZC3rTCPP2HlXyr3Qh6JYZeSQuHt5UcWIkDMdRODL26reTlNsLh2+XWq59G+OlAS2FvhF49oiDM"
    "k7TM022EvEnR7H361UreZre3EercpNRsZ1o4vK3kkFrgQAy1E0Ovbit5uY1w+Ha59eqnEaa34MAI9pYSvZKSKKYwT9IyT7cR8kZq"
    "RN2mH1ZiYna3EfL2WIkjLRzeVnKI4XYghtqJoVe3lbzcRjh8u9x69dMIeXus5MAIajeCXonhdqRlnqRlnm4j5O0tBjv7YSUO30bI"
    "22MljrRweFvJIYbbgRhqJ4Ze3Vbychvh8O1y69VPI+TtsZIDI6jdtxh6JS3zJC3zdBshbx8XzuljJQ7fRtArMdyOtHB4W8mBlTgQ"
    "Q+3E0KvbSl5uIxy+RIm+m179NELeHis5EFHU7qNE6JW0zJO07F03I+TtI0o4p4+VOHyLKHolhtnNtHB4W8mBlThoKdRODL26reQV"
    "aEndpltpzt1i9umHEfL2WMnhFsPsHnsrEWYnNfMktZTUTQl5k5JHCef0sRKHH2KYndT0SmopqdvESg60SE5aMvskhl7dVvK6fOzs"
    "VppzWsnhhxHy9ljJ4RbDR6/E8DFPtxE+8qYVH+f0sRKHH2L46NVtBHbGSg630nw53GLo1W0lr8vHzljJgZWo3ccIeXus5PClFbe8"
    "EcOtzmWeHjFwjJA30nKr3U8rcfhVaczTRwx2xkoOXy7M0yOGXt1W8grfJoKJwN4+guktmL6k5DbdUnLbO5geKWEG0yPc9vZTYPpV"
    "Spg+UsJEMH0Jt+mRkr3dgpf/cS//417+T2nN05dW8va3YvTq9y6Pnf0fVtKrf/UKb9MfpTX73h6t1D39pRi9+r3L28ne/ltK01tL"
    "ZvevXpe3wx+lRe0erdjZX4rRq9+7fKvdf2slb3/pFVHcDn+UFrV7tGJnfynG3nX7nWtXjyh71+2fWsnbX3qJ4Xb4o7So3aMVO/tL"
    "MTin37nm6RGDvP1TK3n7Sy+0wuHtonYuIVa+zAAAIABJREFUaveRFrV7tGJnj7Tc8vaWltvhSwy3I0avHq1gnn665ukRg7zRCnr1"
    "KM2jV1bSq0dp2NmX0s4pBud8oRUOb0PUzrV3nz7SonaPVuzsFqntnVLd0y1SkFLd0y1SY+qp9YqUSkxm99M1T48Y5C2lEpidSWlu"
    "c3ZW0qtbRMGu7I3S+pQafb7QCocvMWrnmqcf0qJ2j1bs7LaSXkfY2W3JjLCz2+V2zoteEYNz+g/XPD1ikLcYvuWtNOzstpJekZZv"
    "50Rpvr3QCocvMfYm5umHtNjbIyU7UyJ23TuMnd3CJIyd3S5m3ztS6xUxOKf/cO3dJ0P0OYnRJ6KQt5RK1D3dVtIr0podqXFOlMZJ"
    "CV5ohcOXGB7z9ENafrEzrdjZbcl+unZ2u+gVMXpFDM7pP1zULi1qR4zaURp5o5W8PVbSK9LqFWlxTpTGQWm80AqHb61w+EVa1O7R"
    "ip1pxQ+9Ii2Pnd2ueXrE6NWjFQ6/unyZJ9Kido9W8kYreXuspFdW0qtHaedEaef0GPFCKxy+tcLhF2lRu0crdqYVpi+zE6ntTezs"
    "ds3TI8bseyNKSid7+3axN2ZHWtTu0UreaCVvj5X0ykp69SjtnCjtnB4jXmiFw7dWOPwiLWr3aMXOtGJnP62kV66d3a55esTgnB4j"
    "ULtvF7X7SIvaPVrJG63k7bGSXllJrx6lnROlndNjxAutcPiSWkrM2f2QFrV7tGJnWrGzbyVi1725dna79u4TMTinRxCldt+uXff2"
    "LaLUjigp5Y1W8vZYSa9Ear0itZTOidLO6THihVY4fInhMU8/pEXtHq3YmVbs7NsIO7tdO7td9IoYnNNHjNp9u+bpFzFqR2nkjVby"
    "9lhJr0irV6TFOVHaOT1GvMTwmKfbRe1c1O4jLWr3aMXObivplSUzAr2OsLPb5adzilE7F7X7ds3TL2L4ljdasbPbSnpFWr6dE6Wd"
    "02PEK6J47Lo3F7VzUbuPtKjdoxU7u7UUsxMqJYLZI8XObi2F2xScU2pzM/bu07drnn4RhWBv6kaJ2HVvVtIrUkvJbVI3Sjunx4jX"
    "5VvtXNTORe0+0qJ2j1bs7JGWW94eK+Gc184eMdyOGJwTrWCefrrm6R9W0qtvK+mVlfTqURp29qW0c3qMeIVvexPsTbC3b8HeHikx"
    "vYXb9BZue4fpkZLbTIm9kZLb9FOY/iHY27dgb4K9PVJym76ktLdHePkf93Jbibz9UYydfbkc/k5aOPxOK9569e9GULt/83Jbibz9"
    "UYydfbkc/k5aOPxOK9569e9GULt/8+LyyNsfxGBnjwuHv5MWDr/TCr2W5jZP/3Qhb3/nxeWRtz+Iwc4eFw5/Jy0cfqcVei3NbZ7+"
    "6ULe/s7LbSXy9gcx2NnjwuHvpIXD77RSu1tpzNM/Xcjb33m5rUTe/iAGO3tcOPydtHD4nVZqdyuNefqnC3n7Oy+3lcjb24jaaaVX"
    "HzHY2ePC4bGSt3PSio9e3WL4duDyJW8frdTurbR5EsOXA5cveTPinG6teOvVLYZvh5fbSuTtbUTttNKrjxjs7HHh8FjJ2zlpxUev"
    "bjF8O3D5krePVmr3Vto8ieHLgcuXvBlxTrdWvPXqFsO3w8ttJfL2NsKtdj/E8KsDK+XtNuKcPkqjV2KwM2nhwCVv/6EVeqU05kmM"
    "nUkLBy7k7TbinG6t1O5W2jyJwc6khZfbSuTtbYRb7X6I4VcHVsrbbcQ5fZRGr8RgZ9LCgUve/kMr9EppzJMYO5MWDlzI223EOd1a"
    "qd2ttHkSg51JCy+3lcjbRyvU7ocY7Oxx4cBKPs7prRW3XokxT7e0cHisRN5+aMVbr24x2NnjcuBC3m4jzkkr1O5W2jyJwc6khZfb"
    "SuTtoxVq90MMdva4cGAlH+f01opbr8SYp1taODxWIm8/tOKtV7cY7OxxOXAhb7cR56QVancrbZ7EYGfSwsttJfL2NsKtdj/EYGdf"
    "LgdWIm8frVA7pfVKDHYmLRy+rETePlqp3Q8x2NnjcuBC3m4jzkkr1O5W2jyJwc6khZfbSuTtbYRb7X6Iwc6+XA6sRN4+WqF2SuuV"
    "GOxMWjh8WYm8fbRSux9isLPH5cCFvN1GnJNWqN2ttHkSg51JCy+3lcjb24jaW6FXHzHY2ePCgZXI20crtVMavRKDnUkLh28r5e2j"
    "ldr9IsbOpIUDF/J2G3FOt1ZqpzTmSQx2Ji283FYib28jam+FXn3EYGePCwdWIm8frdROafRKDHYmLRy+rZS3j1Zq94sYO5MWDlzI"
    "223EOd1aqZ3SmCcx2Jm08Lp8y5sR1E4rvfqIwc4eFw6Plbydk1Z89OoWw7cDly95+2ildv8hLY/Dl5XImxHn9NaKW69uMdiZtPC6"
    "fMubEdROK736iMHOHhcOj5W8nZNWfPTqFsO3A5cveftopXb/IS2Pw5eVyJsR5/TWiluvbjHYmbTw8j/u5X/cixHM059d1O6xkl79"
    "pRHm6XdG+Nar/3bJ2+Oidv/qtSTM059d1O6xkl79pRHm6XdG+GGe/sslb4/E9u9el8c8/dlF7R4r6dVfGmGefmeE2dES8/RfLnn7"
    "S6+ghHl6RLErSuD0cVG7x0p69SXKrn5oyey+peY0wjw9otjVTyPME1HCPD2i2NUjNWEyO4M+fSlhV2+pORFldi+0Yp4eqRS90ord"
    "u4+L2j1W0qtHSSl01S0VCnvu7hGh6CKZJ0pKQde3jxHm6daKeaKkFHR9E8Nbr1zU7lFSJHuqbjH0WlKK3fsLrZintxgctLJ79+2i"
    "do+V9OoWLXn0vonhy85uUcLHPDHCW94+RpinWyvmSSnJW+9bDG+9clG7WynJW52bGNSSsPsLrZint9RC7VFinn646NOjJb0iWtob"
    "4ZzEmEjJrhOtMJGSeRIt7e1Wt48R5okoYZ6sZG+C3ndqwWR2LmpHDPYmyJsYmKTEC62Ypy9pUSP2rH64/KJXrLR7x6XOLbUTpSQO"
    "Ugs7Y4R5MkLv269GmB0t2bOKlvTKCGqXFnl7XNROWuw6pUXexGCfW2m80Ip5+pJGcuvVT5df9IqV6nRb1O6RKIWDEcwTI8wTI8xq"
    "+2mEb71yoXZc1C4t8va4qJ20OCdpJOckBnlTGi+0Yp6+XW69+unyi16xkm+1e6zkcTDCPN1GmCdGYGc/jfBROy5qd7uoXVrk7XFR"
    "O2lxTreLc4pB3pTGC62Yp28XaveLi9o9VtIrl59qJy0fByPM022Eebq14pG3jxHezulxUbvbRe3SIm+Pi9rFwDndLs4pBnlTGi+0"
    "Yp6+XW69+umido+V9EoaSe/eNmkk51YKByPM022EeXqkaNh1+jLCrNjeLmp3u6hdWuTtcVE7aXFOt4tzikHelMYLrZinL2kkt179"
    "dFG7x0p6xUpq9xEtOSelcTDCPN1GmKe3lAzO6csI8/TDxe4dF7VLi7w9LmonLc5JGolzikHelMYLrZinL2mpu8Tu3Q8XtXuspFes"
    "pHYfpXGgNA5G2LPSIpknyp6kxTl9GWGefoiW9MoIaqc0s0+3i9pJi9mntKhzi0HelMarEcme9E0qxWGE3btvF7V7rKRXlJLm9uhb"
    "aXSk4CBK2JNIzJNS9kbhnL6MME8/rWRPCr1vXMw9Jxe1ozTmloK8iUHelMbr8i1vqRS9KiXZ2beL2j1W0qtbKcnbOaUWvh2IEj7m"
    "yUq+9L59GWGefioleet9u11us08Xtbu14kvvmxjkTWm8Lt/yVhoHWrHr9HFRu8dKevUokRJT3aQWTITDLUowpWSetCQlprp9jDBP"
    "vyiRElPdHkOwe3dRu0dLKTGdbjHIm9J4Dd/qFoUTJXD6GPTp0ZLZfYnC6S01+hTF6RGFuluyq0cJTj+1ZFf/oQSnH1oyO4M+fSlh"
    "V29RqJsovPyPe/kf9yItHP5shLw9VnL4WyPk7Tdi+HJO/yoGDv/qNQgc/myEvD1WcvhbI+TtN2L4Mjn9l9TM7pESpn/1urwd/myE"
    "vD1WcvhbI+TtN2LY2y0ldW7/kJZ5+luvy9vhz0bI22Mlh781Qt5+I4Ze3UZQu39Iyzz9rRdp4fC2kgMrUbuPEfL2WMnhSyvO6Vtp"
    "7Owjhl6NkLfHCGr3LYZePWKo3aM05/RoxdvOYujVx8U5vcXImxHy9iItHN5WcmAl594+RsjbYyWHWxQpmdSN1KSEWbdHibC3lORN"
    "CSmxZ/URQ68eMdROalIyqZtWPGafYtizukURzNk9YkykZM7+Ii0c3lqkc0vNPv0wQt5IqSWHWwx7I/JGjImUnNMtWjIJ5E0rptuu"
    "PmLo1S2iqF1EsbeU1LmVCHvrkxg4EFFM0u7TLQYmodcXaeHwpTSnoVc/jZA3YuBwi6F2YuSNGHnTinMiLeTtQt604px+FUOvbiOo"
    "3Qh6NYJeScs8PWLgwEocjHC4xcAhhl5fpIXDl9I8evXTCD8dGOFwi6FXH60wT9IyT7cR8qYV5/SrGH44MELeiKFX0jJPjxg4xHA7"
    "GEHtxNArMfAiLRy+pGioc/tphJ8OjDA9Qq8eUaTEPEUJ83QbIW9StMnppxg+Zp8YIW/E0CtpmadHDBximN0koqidGHolBl6khcO3"
    "C3n7xQjTW3BghG+9kpIUUmKeWmGebiPkjdRSUrfpI4bbxOxuI+SNGHolLfP0iIFDDL16xFA7MfRKDLxIC4dvF/L2ixHy9ljJgRG+"
    "9UoMvWqFeWqFebqNkLfHCOzsI4bb4dsIeSOGXknLPD1i4BBDrx4x1E4MvRIDL9LC4Utpbnn7xQh5e6zkwAiHH0bIG2mZp1aYp9sI"
    "efu47Owjhl79NELeiKFX0jJPjxg4xHA7GEHtxNArMfAiLRy+lKbvNmf30wh5e6zkwAizTx8j5E2JME8pmnlipCRvH5edfcTQq59G"
    "mH0SQ6+kZe/TLQYOKbXEwQh1bmLolRh4hdRQt4koMbth9umHEfL2WMmBlsLsbhMj1E0J5kladiU15E1KbsPOPmLo1U8lwuykNmcn"
    "tZTUuYmBAytx0pLDLYZeiYHX5WNnrOQQA4cfRsjbYyWHWwxf8maEb/MkLT/kTSvedvYRQ69+EcOXvD1GUDsxcGAlH4dbDL0SA6/L"
    "x85YyYGVHH4YIW+PlRzeLm95I4bbkZZ5uo2gVyPkjbTcavcthl79h5UwT19GYGcxcPhycU5vMfRKDLzCt4lgIph+CKa3YHoLb9Mt"
    "JbcpmG6BvQXTI9z29i0le/sP4TF9CY8pJUxfgr29pWRvUsLL/7iX/3Ev/6e05ulLK3n7WzE4p9+5PHb2f1hJr/7VK7xNf5TW7Ht7"
    "tFL39JdicE6/c3k72dt/S2l6a8ns/tXr8nb4o7So3aMVO/tLMTin37l8q91/ayVvf+kVUdwOf5QWtXu0Ymd/KQbn9DsXfSLK3nX7"
    "p1by9pdeYrgd/igtavdoxc7+UgzO6XcuakcM8vZPreTtL73QCoe3i9q5qN1HWtTu0YqdPdJyy9tbWm6HLzHcjhicE61gnn665ukR"
    "g7w9VkLtKM2jV6TVq0dp2NmX0s4pBud8oRUOb0PUzkXtPtKido9W7OwWqe2dUt3TLVKQUt3TLVJj6qlxTimVmOy5t2/XPD1ikLeU"
    "aAl9Tkpzm7MjrV7dIgp2ZW+U1qfU6POFVjh8iVE7F7X7SIvaPVqxs9tKeh1hZ7clM8LObpfbOS+3c4rBOcWo3bdrnh4xyFsM3/JW"
    "Gnb2SKtXpOXbOVGaby+0wuFLjL2JXff2kRZ7e6RkZ0rErnuHsbNbmISxs9vF7HtHapxTDM4ppb19u/bukyH6nMSgblHIW0ol6p5u"
    "LUWvSIs+pcY5URqnW0svtMLhSwyPefohLb/YmVbs7LZkP107u130ihicUwzO6T9c1C4takcM8lYaeaOVvD1W0ivS4pzS4pwojcNt"
    "xAutcPjWCodfpEXtHq3YmVb80CvS8tjZ7ZqnRwzOiVY4/OryZZ5Ii9o9WrEzreTtsZJeWUmvHqVxUBqH24gXWuHwrRUOv0iL2j1a"
    "sTOtMH2ZnUhtb2Jnt2vXvRGDcyJKSid7+3axN2ZHWtTu0YqdaSVvj5X0ykp69SiNg9I43Ea80AqHb61w+EVa1O7Rip1pxc5+Wkmv"
    "XDu7XfSKGJzTYwRq9+2idh9pUbtHK3amlbw9VtIrK+nVozQOSuNwG/FCKxy+pJYSc3Y/pEXtHq3YmVbs7FuJ2HVvrp3dLnpFDM7p"
    "EUSp3bdr1719iyh71y1KSnVPWpm7ukVqvRKp7V231FLqc1Iah9uIF1rh8CWGxzz9kBa1e7RiZ1qxs28j7Ox27ex20SticE4fMWr3"
    "7ZqnX8Qgb6WRN1qxs0davSItziktzonSONxGvMTwmKdHjNq5qN1HWtTu0Yqd3VbSK0tmBHodYWe3y0/nFKN2Lmr37ZqnX8TwLW+0"
    "Yme3lfSKtHw7J0rjcBvxiigeu+5NRKmdi9p9pEXtHq3Y2a2lmJ1QKRHMHil2dmsp3KbgnFKbm7F3n75d8/SLKAR7UzdKxK5701L0"
    "itRIiUndKI3DbcTr8q12LmrnonYfaVG7Ryt29kjLLW+PlXDOa2ePGG5HDM6JVjBPP13z9A8r6dW3lfSKtHr1ZYSdfSmNw23EK3zb"
    "m2Bvgr19C/b2SInpLdymt3DbO0yPlNxmSuyNlNymn8L0D8HevgV7u8XevgSmLykx3cLL/7iX20p5+7OV8vbWSu3+Vlo7+53SvO3s"
    "36WFw796ua2Utz9bKW9vrdTub6W1s98pzdvO/l1aOPyr1+WRtz9bKW9vrdTub6W1s98pjXmSFg7/LcY8/aXX5ZG3P1spb2+t1O5v"
    "pbWz3ymNeZIWDv8txjz9pZfbSnn7s5Xy9tZK7f5WWjv7ndKYp8fl8E+luc3TX3m5rZS3P1spb2+t1O5vpbWz3ymNeXpcDv9Umts8"
    "/ZWX20p5e2ulV2LM008r5e2tldrdYvhyeKzkrXa30nzs7LGS2zl9lMY8PS6Hx0reaqc0t3mSFg6PEd5qd4vh28ttpby9tdIrMebp"
    "p5Xy9tZK7W4xfDk8VvJWu1tpPnb2WMntnD5KY54el8NjJW+1U5rbPEkLh8cIb7W7xfDt5bZS3j5Kc5unn1byQ+1uMebpcTl8G1G7"
    "W2nzdEtrZ1zI2y9KY56khQMr5e3WSu2Uxjzd0sKBlc7p1krtbjHm6XF5ua2Ut4/S3Obpp5X8ULtbjHl6XA7fRtTuVto83dLaGRfy"
    "9ovSmCdp4cBKebu1UjulMU+3tHBgpXO6tVK7W4x5elxebivl7aM05ulXK+XtrZXaKc1Ph8dKbrVTGvN0S2tnj5U4px9K8+3wWClv"
    "t1botTTm6ZYWDqx0TrdW6JUY8/S4vNxWyttHaczTr1bK21srtVOanw6PldxqpzTm6ZbWzh4rcU4/lObb4bFS3m6t0GtpzNMtLRxY"
    "6ZxurdArMebpcXm5rZS3j9KYp1+tlLe3VmqnNObp24W8GVE7pTFPt7R29m3EOX2Uxjz9tFLebq3Qa2nM0y0tHFjpnG6t0Csx5ulx"
    "ebmtlLeP0pinX62Ut7dWaqc05unbhbwZUTulMU+3tHb2bcQ5fZTGPP20Ut5urdBraczTLS0cWOmcbq3QKzHm6XF5ua2Ut7dWeiXG"
    "PP20Ut7eWqndLcY8fbuQNyNqdyttnsRgZ99GcE5vpTFPP63EOWmldrcY83RLCwdW4py0UrtbjHl6XF5uK+XtrZVeiTFPP62Ut7dW"
    "aneLMU/fLuTNiNrdSpsnMdjZtxGc01tpzNNPK3FOWqndLcY83dLCgZU4J63U7hZjnh6X1+XbOWmlV2LM008r5e2tldrdYvhyeKzk"
    "rXa30nzsjMuXc/oojXn61UputXuL4bZzWjg8RrjV7i3GPD0ur8u3c9JKr8SYp59WyttbK7W7xfDl8FjJW+1upfnYGZcv5/RRGvP0"
    "q5XcavcWw23ntHB4jHCr3VuMeXpcXv7HvfyPe5HWzn5jxDn9/0vLzv5KjHl6a8XjnP5TWjsjhl791msQO/uNEef0/y8tO/srMebp"
    "rRWPvev2i9RiZ8SYdfut14Wd/caIc/r/l5ad/ZUY8/TWirlF0vv2U1p2Ripz+r3XIHZ2C3uT0t7eRpzTt2B6xN6STUoeeyMl00da"
    "dvaRkr1JyXRLaboF0y3GPL21onalJOdEMN1i2HVvKdnbLSV7u6U0CdOLtHZGDPOktF69jTinb5ed3WLMU0mV0jzOiZXk7UtadvZR"
    "mtppxTmxUt647OwWY57eWlE7I5wTKzmQlts8xdCrWytqdxuRt5UOL9La2S2GeZamV28jzunL5bEzMWYfelWat3Ma4Za3t7Ts7K00"
    "j9qNOCdWytvlsTMx5umtFbVjxDmt5HFIy22eYuiV0jzOyYg8Eo4Xae3sFsM8S5t1extxTl8up2FnYmxJr9FSnyX0vltRt7ZPb2nZ"
    "2VtpsytRuxH73FqRt8vJ2JkY8/TWitppkc5pJedgnmLYdW8x9Cpa0lM4JyN2OlsyX6S1s1tqsWeKXn0ZcU5fSqpa2ZkY9jRnabPP"
    "aOmcRvS+rXR4S8vOHqnpUxR1j3BOK/WqtF5p0bsY8/TWitpFS85ZSuq1NA5p2Rkx9Kq0uaeWZt1G6LU0XqS1s0e0xO7dlxHn9EMY"
    "+9ximCdK61VqcU4j6qalc3qkZWeP0mZHidpLSee0Ut4up9vYWYx5emtFn0rY515J3kY4Z1p2Rgy9plJqpxXnNELeVvIirZ29xaBX"
    "HyPO6YcLO4thniitV604pxG+HB5p2dmjNF9qN+KcVsrb5cvOYszTWyu+nNNK8ubiSMvOiKHX0tROK85phLyt5EVaO3uLQa8+RpzT"
    "l8vbzmKYp1tpbrUzwpfDIy07e5TmS+1GnHMlebt82VmMeXprxeOcWEneXBxp2Rkx9Fqa2mnFOY2Qt5W8SGtnj2iJXn2MOKe3EU6G"
    "ncUwT7fS0PtmRN0e0yMtO3uUNrvH3kbsc6TauZwee4sxT2+t6JO9sZK8uTjSsjNi6LU0tdOKcxohbyt5kdbOHjH2jtmnLyPO6e3S"
    "q7TsLIZ5IopN3xjR+/ZDWnb2KG326Uu0dLaUN5defYkxT2+tqN2XleTNpfa07IwYeo0StdOKcxohbyt5EWOf2620OZtefRlRu7fL"
    "OcXQqxjmidJ69WWE2v2Qlp09oqVZt2RjRC0pb0Y4J2kTY9bt0YrafWnFOcNwSMs+NzH0qrTed2qx6zRC3lby4mJnxDBn06svI5zT"
    "4+Jw2ZkY5onSevVlBHn7lpadvZWmV213jEDeuDikkYlhnh6tqN3HSvLCIS12JoZelab2VpyTEfK2ktflbWcx5qk0vXob4S3vy5ed"
    "xTBPlObtnIzwOLyl5W2eSvOoHSPI2+3y2JkY5unRitp9rORxIC3mKYZeKc3jnIyQt5W8Lm87p5HmKZXSq7cR3vIOw2nYWQzzRCrF"
    "Y9cppZacpre0vM1TSlH0uTfSSPJ2C8Oue6O0eXq0onYfKbXkNN1KM08x9EpKJfS5NyPkbSWv5m33VMzJ/yMO7m01zXFFjT4foFBo"
    "KBQaCoWGQpHBUGgwFBkMRcZ9f/aurj5Tt1FTGKDXUs3kocpjAoazKEeMTECNAlRGAiZMvi0emYAqmTxM8OKxKOcmlslNFS9+MGHy"
    "EKMcMTK5qOLFxQQvTPjwZ2z5BFk6kn/Vhz9jyycsYyT/qg+hVOcXZPfiDxym81s06MVDg0cv/uYwHQjNwS99JITq/ILsXvyBw3R+"
    "iwa9eGhQgIzkbw7TgaU5+aXPAarzC7J78QcO0/ktGvTioUEvZDOSnx2m808+C5Xq3CwLjCwesnvxTYVKQBRHJEGUWyWIgvPtMJ0v"
    "KlQCIslNqwAVKgENevHQoBeyGQmoUAmILrwqUankZpDFRSRRqfzAsurczkhkM5KH7F5820J1QINeZh2WcasOy6AXXw7T+bKF6oBG"
    "43ZGAluoDmjQi4cGvZDNSGAL1QENLtUJzcFFNvjkoqsTmuMDy6pzO+kp2714yO7FQ4wyqZyggSPSMRXHJNMxFUe8eB2m81paiUzQ"
    "cC/EbCQsLdQnaNCLhwa9kM1IWCrgeGlAJk5oDlDFoNwBDUel8gPLqnM7TJfdi5fsXjw06EuhgQaX6oTmYItPCM3Bdud1mM7rMF12"
    "Aw16IZuRcJgsGmjQi4cGvZDNSDg8RmrAdCA0ByzjlgPQ4PGBZdW56aLQXrxk9+IhQooZDTTAkyTKiy0+IcqLjTuPw3ReZ2bJzlka"
    "9EI2I2XpTHTlLA168dCgF7IZKUtnIYuRaDAdCM0By2qCWg7QYKDGB5ZV5xEK9OIluxd/sUUDDZgORDps8QmRDlt88jhM53V6IZuR"
    "GvRCNiM16IVsRmrQi4cGvZDNSA16IZuRcJgOhOaAZdXBFg006GWLDyyrziOUGsUX2b34YRk00GAkl1CfbPHJFgoEnzwO07npkgKE"
    "kcjuhexeaFCAMFKDXjw0KEB6oUEvkJDpHKYDoTkIzVlgiwa6RoHGB5ZV5xFKdb7J7sUXqWXQQINeXEJzEuKTA8UlJ4/DdG4aQAEz"
    "4YxEo4EGxW2mBr14aFBcRqFBL2CLTw7TgdAcbMkB2KKBrg5ofGBZdR6hVOeb7F68ZPeyRQMNenEJ5TIdDtP5yWE6Nw2YzuswWTTQ"
    "oBcPDXrx0KAXDw16AVt8cpgOhOZgSw7AFg10dUDjA8uq8wilZvJFdi8eItFLTRto0ItLSAGecJjOTw7TuWmQnrwOk0UDDXrx0KAX"
    "Dw168dCgF2iUO4fpQGgOtuQAbNFAVwc0PrCsOo9QoBcv2b14aNAL2Q006MUl0nkdpvOTw3RuGvTiy2GyaKBBLx4a9OKhQS8eGvRC"
    "NiPhMB0IzcGWHIAtGujqgMYHllXnZlYovXjJdi9uGvQSswYa9OIS6byWlid/OUznJmbuxWtpITlBA/fipkEvHhr04qGBe8lmJBym"
    "A6E5MMMdNckJujqg8YFl1bkdZgW9eMlmJDcNetmigQa9uEQ6X0Jz8JfDdF6H6XzZQnVAA6brL5V1AAAgAElEQVRz06AXDw168dCA"
    "6bIZCYfpQGgOWFad0ByArg5ofBYqOJlw3NGVnjxkkwV4aZClQgMNenEJSS7loCYJmbwOWYAXmFXB5LaF6oDoIgsmiK705KZBLx6i"
    "GCk6s8CMZBKaA8TM0fIEdHVA43N4jIQzEtmM5CGbx0gNHg006MUllJtPYBkwndfhMRLYAjRuW6jO7XBrXA7TuWnQi29bgF5ctlCd"
    "0ByABuCTi64OaHyERwFSgFB8ER4FwqMAobhFObCkBgiX4ovwKC7CpbgJUNyEW3ERKB5C8YNwKW4CFALFRbgUNyku8uEPRTqwrDr/"
    "qg/LgMYvHJ/8gWWN37MMnzwOXxp/c3zyjz4sAxq/cHzyB5Y1fs8yfPI4fGn8zfHJP/ogEtD4heOTP7Cs8XuW4ZPHgQGoNf7mVA3+"
    "yQc40PiF45M/sKzxe5bhk8eBBixr/M2Bxj/5AAcat5WJ6uTL8clLlUsmsDIXTFg8MlHlkslrWePL4jYB1QmoTkCVSybL8MnjQAOW"
    "NUCVSyaqBg1QnYAql0wuqjw+wIHG7fhkWePL8clrGRefwPF5oMHh4ZNlXHzyWtb4crg1YFkDljVgGRefLMMnjwMNWNaAZVx8sgxo"
    "wLIGLOPik8syHh/gQON20jFtfDk+eakBmp5w0g2GSFQhkp4sS6AyeSxrfDlVgFexrAHLGqgKoD5Zhk8eBxqwrIGaJqhP1LRqAMsa"
    "sCyBygSWJSDyAQ40bodb48vxyU8ONDjQgGX4ZFkDljVgWeOxrPHl+ASOT5Y1YFmD4xM4PlmGTx4HGrCswYEGxydwfHJZ1oBlDVjW"
    "gGUNWPYBDjRuW4DqfDk++YtsaHCgAWbik2UNxKwDZo3HssZLtjuwfbKsgZh2OO7A9skyfPI40AHTDofqcNwLjk8uyxqIWQOWNWBZ"
    "A5Z9gAONxzJ88u345IdlQIMDjdvxybIGhy+Nx7LGYxkvnyxrcHwCh4dPluGTx+HhEzg+gQMNjk8uyxocaMCyBixrwLIPcKDxWIZP"
    "vh2f/LAMaHCgcTs+Wdbg8KXxWNZ4LOPlk2UNjk/g8PDJMnzyODx8AscncKDB8cllWYMDDVjWgGUNWPYBDjQey/DJt+OTl1lHNjQ4"
    "0LgdivSCA51b8VjWeCzDnUvBsnI/PoHjzqVgGT55HOhAcTk+gQMNjk8uyxocaMCyBixrwLIPcKDxWIZPvh2fvJY1ONDgQON2AJ/A"
    "gcZPljUey/DJaxk+j0/g+OS1DJ88DjS+HJ/AgQbHJ5dlDQ40YFkDljVg2Qc40LhFZVQNvhyfPEKkwYEGBxq3k04VoKaNnyxrPETC"
    "Jy+R8Hl8Aqdq8FiGTx4HGl9O1YCTnnB8clnWQE0bsKwByxqw7AMcaNyOzwONL8cnjwMNDjQ40Lgdn7yWNX6yrPHl+OTb8Xl8Agca"
    "j2X45HGg8eVAg+MTOD65LGvAsgYsa8CyBiz7GCyYlagsn0u08eVkcqlcohMWNDjQuJ1MwIFlE6jktWxycziZgHM7mcsnsEQnUImq"
    "+eRxoPFliU5YPoGTSSXLGrBsAsIEljVg2efw8MkyfLKs8eXw8MkyHg0ONG6HWwOWcfHJaxmPBodb43YAn1yWcfEJHJ88DjS+LePi"
    "EziAT5Y1YBkXn1yWNWDZJ3ikY0o6poMvwSMdUx4DAga3UwV4FaZc0nmZ8hgQ3Aa3ANK5mHJJByKdR8DgmymXdCCAdEwHYMolnYvp"
    "AEw//KnjEzg++Vd9+FPHJ3B88q/68L+m4ZPfs2wkry3AdH4ttBe/9uF/TcMnv2fZSF5bgOn8Wmgvfu0TXDz5T2qe/Pc0fPJ7lo3k"
    "tZmgAoOfLRlcRJL/j8/hMpL/pDGd/56GT37PspG8Nh2WQeNnoY1/9jExGAmIZcIq56UxnZcJUM5llat6weIxQRUo56Xhk28mlIMJ"
    "5aDqBajC5LJsJK9NBxWTxsWEclBV8XIwoZyLCeVcDBcDrw8aMBLQmA4nBy+N6bxCgRxcTg5bI5HNo4EtoDovDZ98CyUHhFIdlo0E"
    "bEEvYNlIXpvOJbRxCaU6LANyQCjVuYSSg8uma8DIDxowEtDwBKvJS2M6L1PQHFxOTVFPFQWRZIiIApUkNw2fvERUqKwy1eqwbCQi"
    "opCVsGwkr03nEtpARIVK0lQka0Io1UFEhcoq2ExRyPqgASMBDS6NbxrT+UF2Di4HfMKmw7KRaPgEZOfgpuGT17KRaPiETYdlI9Hw"
    "CZsOy0by2nQuoQ1sjUR2DghtXEKpDstGouETtpADQj9owEhAlwCNbxrT+SbsnAUcyh02g1o2Eg13LjsHNw2fvJaNQsInbDosG4mG"
    "OwQdlo3ktRlclnTEbCSyc0Bo4xJKdcR0FBo+YUvlhNAPGjCS2zJofNOYzrctwHQ4ObhsIceykWjwysFNwyevZdx8wqbDspFocKsO"
    "y0by2sJtJBowEtk5ILRxCaW6xnRAwydsOpfQDxowktsyaHzTmM63LcB0ODm4bCHHspFo8MrBTcMnr2XcfMKmw7KRaHCrDstG8trC"
    "bSQaMBLZOSC0cQmlusZ0QMMnbDqX0A8aMJLbMmh805jOzWymgK7pcHJwEaCQAg13HsVNwyevZaOAAjYdkAINdy4Fy0by2gwuBRow"
    "Etk5ILRxCe2UBjUKDZ+w6VxCP2jASG7LoPFNYzo3WyMBjelwcvA3Gj75iYZPXstG8tp0Xho+eS0byWvTeWnASGTngNDGJbQXGjAS"
    "DZ+w6VxCP2jASEAta0nW5KUxnZutZLLQ6XBycFlMXiKinvygUeXJbdlIXioKnoCGT17LksFj03mJqI1cojkgNGtCaNYUMR0ZqE/Y"
    "dC6hHzRgJKAxPZQcvDSmc7MFnQ3T4eTgsul8szWSHzRgJLdlI/kiG6YDGj55LYPGY9P5ZmvkFnJAKDkglOqwbOQBn7DpXEI/JgZe"
    "DmKZJpaDl0YmUKmq0mtBJpwcXEyKh4Nq4XzTAC9wUPWySm6yKzMBsUwV56Kq0nhsOt9UC4FyMLEcYEI5qBYCmWA4l9DP4dGL18nB"
    "S4NbDgjtxevk4CabR+MS2osvGtyq8zg5uMnOwbfQXtxCG49N5y+hvXidHPwltPGz0E/wmMUravJS41YTlsziFTW5iBgXpXFZMosv"
    "sngMHlGTm6yafFsyi9uSwSMY/GXJLF5Rk78sGfxsyYc/s+lcQhv/rg9/ZtO5hDb+XR+QXZ1fCB3Jf0821fktGjl4LOM2kr+TXR3Q"
    "wCe/9AnQ6vxC6Ej+e7Kpzm/RyMFjGbeqWfxEllYHNHIWv/Q5QHV+IXQk/z3ZVOe3aOTgsYwsVHAv/iKb6oBYJr/2CdDqXJQqEKni"
    "ETqSbwrJTasQCkS4VQEiJF9kU50vIlSBCMlFJLkoJBeNHDyWMR0zYSSgkFw0qFmFCFVcRKjiIpKgJB+QXR3QIAfY8skjdCTfDtW5"
    "aOTAZIItbiOBLfTiJZvqfLHFdFjGSGBLL+BQnYtGDh7LmA6hjAS20ADZXHKggU8uy5jOJbQXWxofkF2diwY5bOGTR+hIXodbddBI"
    "D3xii8dIQrn04iGb6jxscZtO6EhgSy8Ot+qgkYPHMqYDoSPZwq0hm0sONPAJtriMBEJ5tA/Irs5Fgxy2chaP0JG8DoOgOmgUgk9d"
    "4mmKey1jFqsGD9lU52ErHdPphNYoltGLw4CoDho5eCxjOiyVkWxhBORAg5pVaOATXYKL1kwIhbGE/IDs6lxkaaWoT16hI3mZTJZV"
    "Bw0qybSVnrpkJKHuxZbGQzbVucnCEzVmhTKSLT6x5ROWuqORg8cypqNLGGkmPm1BQzbVAQ18YisrWZKzCMWnLfiA7OrcdAmUO6/Q"
    "kfygRI1CgxyALZ/I0pGEzoIlI7nJpjo3W+mA6XQzGcmWXhwGl6iORg4ey/DElBq1hV6EMlI21QENfIrZdFjGSELpxRY+ILs6Dw3w"
    "yZfQkfxwgOpokAOw5ZNljCSUV+Mmm+rcbPGaTuhItvTi8KqORg4ey3iNZAu94ECTTXVAA5+2mA7LGEkovdjCB2RX56EBPvkSOpLX"
    "4VEdDXJwscVlOoTyaDxkU52bLV7TCR25hV4cXtXRyMFjGbeRwBZ6wYEmm+qABj5tMR2WMZJQerGFD8iuzk2XgE++hI7kEcqAoDoa"
    "5OBiC3AvCJ3FJXnIpjo3W+ncqgitETIdDoNbFRo5eCzDE6qALfSCA0021QENfNpiOixjJKH0YgsfkF2dm0aVpiev0JE8Dj6RTXU0"
    "yAGoUeAFhLoXP8imOjdb6clLl4wlveDgk5dGDh7LmM5rC72wxXTZVAc08Kmm02EZIwmlF1v4gEaN4mIrc+GTV+h0HoeRaFAdDXIA"
    "tnzyCmU6P8imOjddkrMQCgidJr0glJEgBRo5i9sypvNaxkgNaMimRoEGPrHlWSytmYTSiy184EB1QIPMhU9eoYzkdqBxoDoa5ABs"
    "+eQVCr34JpvqPGzhk1UOhAK9gAMNiQ4a5OC2jOl82ULfQEM2VAcNfGILphgjIZRebOFzeFRHIwe28MkjlEevw6s6GuQAbPEaSSi3"
    "xkM2jxzY4jYdCIVeXA636qBBDm7LmM6XLdwaIBtyoIFPsMVtJITSiy18Do/qEpIDMfPJI5RHLyUYBNXRIAcgZjxGIrKEQfKQzSMH"
    "Imp4VgESQi8uSlCzCrCVg9sypvNFZAmD5GKLHGjgE0RM8ayCUHqxhc/iUS5GJqhm8lDlMQHDWZQjRiagRgEqIwETJt8Wj0xAlUwe"
    "JnjxWJRzE8vkpooXP5gweYhRjhiZXFTx4mKCFyZ8+DO2fIIsHcm/6sOfseUTljGSf9XnQA5+QVfnj5xe/B6NxssWt+r8jQa9uERN"
    "fu1zIAe/oKvzR04vfo9G42WLBGEmP9OgFxfD+bXPgRz8gq7OHzm9+D0ajZctGtiiFz/RoBf/6KMYg4ssZqkxi4euzg8B6VzEJoaD"
    "Kbd0QK0mP5xefFtCTVCrCcgaXALSuWg0XrZoILp6AQHpgJqSpLMknYsaeHIxnCXU/MCSwUWDkRr04qGr8002+OSiq7OYEMrNJ7CM"
    "xg+nF9+2UB1s0QDZjcsBn1w0Gi9bNEB2L+BADsAWlxxs8clFA0ZyWTLYQo4PLBlcNBipQS8eujpfNLhUBzQAnxymy2Y6HKZzmM7r"
    "9OKhQS9bNGzRwBYNNOhm1QGNxssWDZDdCw0evWxBL2CLT9jCzSewjFuODywZXGTpLLWcxUNX54ssQOiABkk6Jz1lMx1OehI6ndfp"
    "xUMjZ6lpQ00b2KIhZjnVmAkajZctGoiuXmgkoPRSU3oBW3zCliqQ8oRlJAjzA0sGjwNU54uuzs/MOqBBL+CMRDbT4YwEtjuv04uH"
    "RgNkN9BoYIuGLRrYooFG42WLBrbohUYDDXqhQS9gi0/YkgNCc8Cy6mCLDywZPHQJ1fmiq/OXJSI5QGMkl5OespkuS5OLTud1evHQ"
    "SC7aQKOB2UxskSBCA43GyxYJwkzUtIHoylka9AK2+ISdmRCaA5ZVB1t8YMngFUp1vujq/GUL0EBX53aYLpvpsnlN53V68dDg0UCj"
    "gVkHW7waaDRetrhVB1s0QDYjNegFbPEJ2x0IzQHLqoMtPrBk8ArNwTddnS8a9KXQQFfnEQr0QjZM5yenFw8NevHQoJdZB1s0vmg0"
    "XrZovGzRANmM1KAXsMUnbHcgNAcsqw62+MCSwUOXpCdfdHVeYpZTTWigq3NTFWAWsjQ9+cnpxUMjZ/GQpR3TDrZofNFovGzReNmi"
    "AbIZqUEvYItP2JkJoTlgWXWwxQeWDB4HqM4XXZ3Xsupgiwa6Orczki9nJD87vXhoNH443aw62KLxRaPxskXjZYsGyGakBr2ALT5h"
    "Sw4IzQHLqoMtPiwlJyBLZ6l2vmjkLG7LqmMmNNDVuZ305HXSk5+c9OSmkbP4clKkOtgiZ/HQyFncbNF4ia6cpaYzS4NewBafsCUH"
    "SyUHLKsOtvgQSnVAg5G6Ol806MVtWXVCoYGuzu0wnddhOj85TOemQS++HKA62IJePDToxc0WjS8a9NKgFxr0Arb4hC052EIOWFYd"
    "bPE53Hqh0UCDXjw0eDSW8Wqgq3M7vHxCKJfpvA6PkXCA6twO+ORxgOqABr242aLxwwGqczuQgy0+gWVcfALLqoMtPsFtFrIGqDGL"
    "hyweAzVeA8Qmt5NcFJ9gysWTV/CYBQHU5BaQziOAmoAsZnFTY/BDADW5BaSzJB0w5ZIOmNYENT78mTMS2OKTf9eHP3NGAlt88u/6"
    "8GfOSGCLT/5dnwP45D9p9OIP2OrF7znQeNji5ZOfaYzkH30O4JP/pNGLP2CrF7/nQONhi5dPfqYxkn/0UTV88p80evEHbPXi96ha"
    "42GLdGDl5GcalZN/8sEWPvlPGr34A7Z68ZuWNR628AnsnPxMgxz8kw+28MlFdYJV8tLoxcuEixeIcZuweGSiyiWTl61evEy4eIGY"
    "F4h5AYvbhKXSeNjCJ7BzAiZcvDBVKr0wHDDhMQFVHh9s4ZOLrV7snLw0evEK5TISZHOpDofHdGxx8cnLVi9eoVxGguyRIHs6yObW"
    "4EDjYQufwM4JbOHSi1AuIwnpQCi36sAyHh9s4ZOLrVmsnLw0evEyBdQzkQ1JTThViKQnthKoTB62evEKKSArkT0SZE9HVAGRBgca"
    "D1v4BHZORBYFOiuXaMIsQjoQmoDQgWUJiHywhU8utrj45KXRi7/Ipjqyqc7tTGdZA2w1wFYvbrZ68QoGEAxkjwTZ01nagWUNDjQe"
    "tvAJ7JxokAMNcqAxkktIB0I6sLQDyxqw7IMtfHIxE6icvDR68YNIUB3ZVOd2prOsgZh1QFcvbrZ68QomsBjIHolITGfpAMwaHGg8"
    "bOEORE40Kie6JAcaI7mEdJAlHVjagWUNWPbBFj55bKEXXzR68UMoVEc21bmd6SxrcPjSi5utXrxCueVA9khCmc4yHg0ONB62ePQC"
    "jV5cdg00RnIJ6cimOrC0A8sasOyDLXzy2EIvvmj04odQqI5sqnM701nW4PClFzdbvXiFcsuB7JGEMp1lPBocaDxs8egFGr247Bpo"
    "jOQS0pFNdWBpB5Y1YNkHW/jksYVefNHoxWvJEAmqI5vq3A6FZ8GBzq142OrFK5jcCmQxQkbB0sGt4EDjYQt3oACNXlx2DTRGcgnp"
    "yKY6sLQDyxqw7IMtfPLYQi++aPTiFdKRTXVkU53bAaYDBxo/sdWLVzD4FtJDOrC08+VA42ELn7w0enHZNdAYySWkI5vqwNIOLGvA"
    "sg+28MlFLcUynZdGL14hHdlURzbVuR1PqgA1bfzEVqbzCAbfQnpIB5alJw81bTxs4ZOXRqYjS3OgMZJLSAc16cDSDixrwLIPtvDJ"
    "xVbXhU9eGr14hXRkUx3ZVOd2pvOy1fiJLXLwCAbfQnpIB5YxndeyxsMWPnlpkAMNcqAxkktIB0I6sLQDyxqw7GOqZDpgq4uaT14a"
    "XlyyCHHEqI5sqnM7mYADtiZQycsW5UAWJgVkcQlxowOqlgk4sKzxsIVPXmJWjlimo+FFFiEdMClApQPLGrDsc7g1wFYvdk5eGjxG"
    "EsqtOrKpzu1wa4AtLj552eLRCzSAkVxCoToX2dwasKzxsIVPvm3h0gs0gJGEdC6yuVQHljVg2Se4DUBtFpHOS43HLJbwGMiCwe1U"
    "AV6FKZd0Xmo8ZoEsYBaXJcDgIovbAEwHDzXS+RbcZoEswJPF5CKL2wBMB2D64Q+d6cCZzr/rwx8604EznX/XBw2f/A9p+OT3LBvJ"
    "awswnf8jtHEJ7cWvfdDwyf+Qhk9+z7KRvLYA0/k/QhuX0F782idEfPKfZNXkT2j45PcsG8lrM0EFBj8LbVxEkv+PzwGf/CfZOfgT"
    "Gj75PctG8tp0WAaNn4U2/tnHxHxyE8uEVc5Ndg6+mQDlvFS9YPGYoAqTbxo++WZCOZhMLqpegCpMLstG8tp0UDFpoAqUg6qKl4PJ"
    "5KIKlHMxXAy8Pmj45KYxHU4ObrJz8C0UyMHL1khk82hgC3rxRcMn30LJAaG9gGUjAVvQC1g2ktemcwltYAuoDsuAHBDaC1gG5OCy"
    "6Row8oOGT24a0xWryU12Dr6ZgubgoqSap4qCSDJERCEreWn45NsSKqtMsxKWjUREFLISlo3ktekgsqSJqCVUkqYiWRNCeyFimlBZ"
    "BZuuJjLrg4ZPbhrTQxsv2Tn4iewcXE4OLpsOy0ai4RM2nZeGT36i4RM2HZaNRMMnbDosG8lr02EZNA0YiewcENq4hPZCA0ai4RM2"
    "HZbBBw2f3HR5hjResnPwF2Hn4HJycNl0WDYSDXcIOi8NnzyEm4RP2HTEdJRIuEPQYdlIXpsBZkXXoGYiOweENi6hvdCgRqHhEzYd"
    "lsEHDZ+8lkHjJTsHf9lCDi4nB5dNh2Uj0eBWnZeGT24avHzCpmtMh8OrOiwbyWsLt5Fo+ARk54DQxiW0FxrTAQ2fsOmwDD5o+OS1"
    "DBov2Tn4yxZycDk5uGw6LBuJBrfqvDR8ctPg5RM2XWM6HF7VYdlIXlu4jUTDJyA7B4Q2LqG90JgOaPiETYdl8EHDJzddAjResnPw"
    "Mpsp7BxcTg4umw5IgYY7l+Kl4ZObhju3AjZdYzoccOdSsGwkr83gUqDhE5CdA0Ibl9BeaEwHNHzCpsMy+KDhk5sGl8ZLdg5etkYi"
    "OweXk4PLpvPS8MlPNHxy05jOt03XmA4HfPJaNpLXpvPS8AnIzgGhjUtoLzSmAxo+YdNhGXzQqPIENDyXNF6yqzy52RqJ7BxcTg4u"
    "m85Lo8qTHzR8chNRmcVLRdHpoLJ88lo2ktem89Ko8lyiOSC0cQnthYjKrEB9wqbDMvigASMBjemhjZdsmM7N1khk5+BycnDZdF4a"
    "MJIfNHzyWjaSL7JhOqDhk9eykbw2nZcGjNxCDghtXEJ7ActGHvAJmw7L4GNiMBIQyzSpSh5LNBMcVAtnlXNZ5Vy2TB4uBoXzTSOT"
    "i4Nq4bxkV2YCYhQ4F1UvXpvOSwwKgXIwqUoI7QWoFgKZsOmgCp/DZSTfTg5eGlwal9Be/M0WXo1LaC++aHCrziW08ZKdg5ct6MXf"
    "bDp/Ce3F6+SA0F7cQhuPTefxCS6efIuavNS4DC5LZvE3W5KL0rgsmcUXWTwGlyWDl6yavNRgFn8TDP6yZBavqAlLZnFbMngEg8eH"
    "P7PpXEIb/64Pf2bTuYQ2/l0fkF2dXwgdyX9PNtX5LRo5eCzjNpK/k10d0MAnv/QJ0Or8QuhI/nuyqc5v0cjBYxm3qln8RJZWBzRy"
    "Fr/0OUB1fiF0JP892VTnt2jk4LGMLFRwL/7y/4iDe2PJkZ1ht09F0BQIMAVCmgIhTUkBpkCAKSnAFAqXZNXu3j1n/t6OL+6sJZtW"
    "QLyKP/dKsFYuRjeIdPNIG8UXg+Jm3QgNIty6ARGKD9m08iFCN4hQXESKi0FxsazBYzkzcBdGAQbFxZKe3YjQzUWEbi4iBUbxAtmt"
    "gCU1wFdMHmmj+HLSysWyBi4TfHEbBWxBmzfZtPLhixmwnFHAFm3gpJWLZQ0ey5kBaYwCtnAAsrnUwJKYXJYzg0uaNlsOXiC7lYsl"
    "NXwRk0faKN5Obq1gWZHExBePUaRx0eYhm1YevrjNIG0UsEWbk1srWNbgsZwZQNootnA7kM2lBpbEBF/cRkGapgDHC2S3cvNVw1fN"
    "5pE2ireTQdIKlo0Q05ZEuRHRy5nN6sFDNq08fFXgNoO0Hs1ytDkZkK1gWYPHcmbAMhnFFkZCDSzp2Y0lMbElhBijIK1lLKFeILuV"
    "m2WXWEze0kbx5jJZ3gqWdFHlq6JsySjSIpotBw/ZtHKTRRTmzE5jFFti4ismLIvAsgaP5czAljDKXWL6ggPZtAKWxMRXdbGkZpNG"
    "TF/wAtmt3GwJdARvaaP4wcgejSU1AF8xkWWjSJsNS0Zxk00rN18VgNsMdxnFFm1OBpdsxbIGj+VE4UaP3oI2aYySTStgSUxxnwHL"
    "GUUa2mzhBbJbeVhCTD7SRvHDCbRiSQ3AV0yWM4o03g5usmnl5ou3GaSNYos2J2+tWNbgsZy3UWxBG044ZNMKWBLTFzNgOaNIQ5st"
    "vEB2Kw9LiMlH2ijeTh6tWFKDiy8uMyCNt4ObbFq5+eJtBmmjtqDNyVsrljV4LOc2CtiCNpxwyKYVsCSmL2bAckaRhjZbeIHsVm62"
    "BGLykTaKRxoDklYsqcHFFxDRkDabW3GTTSs3XxXcuknrkTIDTga3bixr8FhOFHQDW9CGk1GyaQUsiemLGbCcUaShzRZeILuVm2W3"
    "VRRvaaN4nMRENq1YUgMwpyEaSItofpBNKzdfFcWbLRlLtOEkJm+WNXgsZwZvW9CGkwPZtAKWxDS3GbCcUaShzRZeYNmjufiqWsTk"
    "LW0Gj5NRWNKKJTUAXzF5S2MGP8imlZstqdkIDaRNF21IYxRIg2XN5racGbwtZ5SRHMimR4MlMfEV0bKsZ5GGNlt4wQmtgCVVi5i8"
    "pTGK2wkHJ7RiSQ3AV0ze0kCbL7Jp5eGLmKwOIA3QBk44kFSwpAa35czgYwu6gQPZ0AqWxMQXM5YzCtLQZguvk0crljXwRUweaTy0"
    "T95asaQG4IvHKEjjdvCQzaMGvrjNANJAm8vJrRUsqcFtOTP42MLtAGRDDSyJCb64jYI0tNnC6+TRKik1EPeYPNJ4aBvJIGnFkhqA"
    "uHPrWYgsYVA8ZPOogYg5Ud2ApKDNxUh6dgO+anBbzgw+RJYwKC6+qIElMUHEjahuSEObLbwWjw5xqsCsiocZjwk4waIDcaoAcxow"
    "GQW4MPmyeFQBZlTxcCGax6KDm3gVNzOi+cGFyUOcDsSp4mJGNBcXonHhxe/xFRNk2Sj+Uy9+j6+YsJxR/KdepNHKn5CtzW84mcG/"
    "Yok2D0se2vziZAaQVoM/9ZIUWvkTsrX5DScz+Fcs0eZhSQMyil+czACW1eRPvU6glT8hW5vfcDKDf8USbR6WaCObUXx3MoO/81qY"
    "tHLzanCqeSEbk5oAACAASURBVMjW5osJXYAYgUiBGLcuEIPgy8kMPkzoAkSKm3UDJnQBlmjzsEQb2YwCTOgCxBbRXZh0cXOo5iJS"
    "mHS9YHkrt3MUshnFQ7Y2X7bQClii7a6wnFsrLAdtPk5m8LGFVsDy4HaOArbQCliizcMSbWQzCthCK2DJpZW0GlxkQ0wutpS0Gi9Y"
    "3srtrCjZEc1DtjYPcdqla4IlgYjiJoFLVeAmgUTzdjKDt2VdyATLiEbcR8GyxmKCJdo8LNFGNqNgmUAQbQlVBGk1wAyHjgAsA5Ou"
    "Fyxv5XYyQ7Y2b7K1eViiy+AASy6tpNVgS0xIq8GO4O1kBm8nM2QfYIk2shkFJ5PFAZZo87BEG9mMgpPHKEuYAaTVgOXcagCWPF6w"
    "vJWbLRrT5k22Ng8RStw5wBKiKLKj2RITsqPZRPA4mcHbOatl12xLtJHNKFk2C1s12xJtHpZoI5tRsmw2shiFJTOAtBqwvCeY1wBL"
    "Bua8YHkrjzRAmzfZ2vzkiwMsYQaQFbAlJmQFbInJ42QGb6c2shlliTayGWWJNrIZZYk2D0u0kc0oS7SRzSg4mQGk1YDlreCLAyzR"
    "9sULlrfySKNH8yFbmx+WwwGWjOKSFpMtMdlCgxCTx8kMbrakAWEUsrWRrY0lDQijLNHmYUkDoo0l2iApMziZAaTVIK1mgy8OsDUa"
    "LF+wvJVHGq18ka3Nm9DL4QBLtLmk1SQlJic0l5o8TmZwswQamAXnKCwPsKS5zbJEm4clzWU0lmgDW2JyMgNIq8GWGoAvDrClgOUL"
    "lrfySKOVL7K1eVii7YsDLNHmksZlBpzM4JuTGdwsYQZvJ5PFAZZo87BEm4cl2jws0Qa2xORkBpBWgy01AF8cYEsByxcsb+WRRs/i"
    "Q7Y2D0u0ze0AS7S5pDQQBScz+OZkBjdLKoq3k8niAEu0eViizcMSbR6WaINlR3AyA0irwZYagC8OsKWA5QuWt/JIA7R5k63NwxJt"
    "ZB9giTaXrODtZAbfnMzgZok2HyeTxQGWaPOwRJuHJdo8LNFGNqPgZAaQVoMtNQBfHGBLAcsXLG/l5t4Y2rzJjmhulmiL+wGWaHPJ"
    "Ct6WdRQ/nczgJu4RzduyRmqCJRHNzRJtHpZo87AkomUzCk5mAGk1cCcCc6kJthSwfMHyVm4nsxNt3mQzipsl2r44wBJtLlnBR1oN"
    "fjqZwdvJDD620ApYwgxulmjzsESbhyXMkM0oOJkBpNWA5a2k1QBsKWD5WpgQVMEZga2K4iGbaiDakmoTDrBEm0tKcekAcymo4u2k"
    "GogG926Y3LbQCogtqmGC2KoobpZo8xDDKbFZDe4Uk7QaIO6BdRRgSwHL18ljFJyjkM0oHrJ5jLLkcYAl2lzSuMUElgMzeDt5jAK2"
    "AAe3LbRyO7kdXE5mcLNEmy9bAG0uW2glrQZgCcTkYksBy5fwaEAaEJoP4dEgPBoQmlt2AEt6gHBpPoRHcxEuzU2A5ibcmotA8xCa"
    "H4RLcxOgEWguwqW5SXORF78pK4DlrfynXicQk/9lqc1v8KXNv3PCwcMXbzH5znIUf+t1AjH5X5ba/AZf2vw7Jxw8fPEWk+8sR/G3"
    "XmZOTP6XpTa/wZc2/84JBw9fVACrJt9Zdk3+zgtfxOR/WWrzG3xp8++ccPDwRUxg1+Q7S2rwd174IiYXswnexZulNm8uXKJBPHrB"
    "hMWjCjMuVbz50ubNhUs0iEeDeDSwuE044eDhi5jArgm4cInGzagBOAG4cKniYsbjhS9icvGlza7Jm6U2b2lcRoHsWZtWOHnMwBeX"
    "mLz50uYtjcsokD0KZM8A2dwOOOHg4YuYwK4JbOGiTRrUAFIUSOMyg8tyHi98EZOLr9msmrxZavPmBlhUITva6Cm2uhGpKHwV0FU8"
    "fGnzltJAdSF7FMiegZgBIgeccPDwRUxg10Rk0WDaLLHqCaQokFZAdQHLCxB54YuYXHxxicmbpTY/yaYV2bQCy5nB8gPwdQC+tLn5"
    "0uYtGUAykD0KZM9gmQLLDzjh4OGLmMCuiSU1sNQGy1FcUhRIUWCZAssPYPkLX8Tk4i7QNXmz1OYHkaQV2bQCy2QGyw8QdwVsaXPz"
    "pc1DsiewGMgehciaxbIBuB9wwsHDFxFA1sSya2I5urEcxSVFQZYosEyB5Qew/IUvYvLYgjYfltr8kAatyKaV2zmD5QecfGhz86XN"
    "zZK3GsgeRYoCy3kccMLBwxcPbbDUBktqYDmKS4oim1ZgmQLLD2D5C1/E5LEFbT4stfkhDVqRTSu3cwbLDzj50ObmS5ubJW81kD2K"
    "FAWW8zjghIOHLx7aYKkNltTAchSXFEU2rcAyBZYfwPIXvojJYwvafFhq87ZkiCStyKaV20kT1XCCcmsevrS5WVKTWyO7e6QosGxw"
    "azjh4OGLCKABS22wpAaWo7ikKLJpBZYpsPwAlr/wRUweW9Dmw1KbtxRFNq3IppXbCcwATjj4xpc2N0tq8Cab1hQFlikfJxw8fBGT"
    "N0ttsKQGlqO4pCiyaQWWKbD8AJa/8EVMLuYlXhW8WWrzlqLIphXZtHI7o+gGzO3gG1/a3ERWDz5soSkKLFM+Tjh4+CImb5ZVgeXs"
    "wnIUlxQFc1FgmQLLD2D5C1/E5OJLbRGTN0tt3lIU2bQim1Zu5wzefB1840ubt2TwJUVTFFimfJxw8PBFTN4sqYGlNliO4pKiQIoC"
    "yxRYfgDLX25GVYCbqZjH5M0ymks1KYE4rcimldtZBQTgawJdvPmK5lJNSgDVXFLCUcCsuQUsk4OHL2LyJu4diGuDZTTVpCiQEoAw"
    "geUHsPx1cjvgBG12Td4seYwijVsrsmnldnI7AF9cYvLmi4c2aVxGcUmDVi6yuR3A8oOHL2LyZQsXbbAERpGiQBqXGVyWH8DyV3Ib"
    "kDCbrODNnMdslvAYyILB7ewGohs3LhW8mfOYzRIus7ksAQYXWdwG4DZ4mFPBl+Q2G2QBUSwmsIRLFBe3Abi9+E3nDOCcwX/rxW86"
    "ZwDnDP5bL/5fs4zJv7N8FG9bgBn8uTRt/tyL/9csY/LvLB/F2xZgBn8uTZs/90ouUfwv8yj+7yxj8u8sH8XbZoIJDL5bMriIFH/h"
    "dXIZxf+ynMH/nWVM/p3lo3jbKCyHg+/SDv7ey8VhFCBeBauDN8sZvLkAHVxWh1k0LB4TzIAO3ixj8sWFDnChA8yiATOYXJaP4m2j"
    "YOJycHGhA8xMogNc6ODiQgcXJ8Qh+oUljAIsZ8BZgzfLGbylATW4nDV8jUI2jwN8Aa28WcbkSxo1II1WWD4K8AXawPJRvG2US9rB"
    "JY1WWA7UgDRauaRRg8tGLWHUC0sYBVhGgffkzXIGb25gNbicPcWiTAxEiiEiBnRR3Cxj8iZiQle3m7XC8lGIiEF1wfJRvG2US9oB"
    "IiZ0UW4i1RPSaAURE7q6YTPFoPqFJYwCLLkcfLGcwQ+ya3A5ISZsFJaPwjImILsGN8uYvC0fhWVM2CgsH4VlTNgoLB/F20a5pB3g"
    "axSya0DawSWNVlg+CsuYsIUakPbCEkYBtgQ4+GI5gy/CrtnASUfAZtDLR2EZwWXX4GYZk7flo5GMCRuF5aOwjIBEYfko3jaDyxJF"
    "3EchuwakHVzSaEXcRmMZE7Z0TUh7YQmjuC2Hgy+WM/iyBZgBZw0uW6ixfBSWvNXgZhmTt+XcYsJGYfkoLLm1wvJRvG3hNgpLGIXs"
    "GpB2cEmj1XIGYBkTNsol7YUljOK2HA6+WM7gyxZgBpw1uGyhxvJRWPJWg5tlTN6Wc4sJG4Xlo7Dk1grLR/G2hdsoLGEUsmtA2sEl"
    "jVbLGYBlTNgol7QXljCK23I4+GI5g5v7LAFbM+CswUWARhosI3g0N8uYvC0fDTSwUUAaLCO4NCwfxdtmcGmwhFHIrgFpB5c0Wi3p"
    "0VjGhI1ySXthCaO4LYeDL5YzuPkaBVjOgLMGv7CMyTeWMXlbPoq3jfJmGZO35aN42yhvljAK2TUg7eCSRqsljMIyJmyUS9oLSxgF"
    "mFcvqZ68Wc7g5quYLGwGnDW4LCZvImJR/GDZHcVt+SjeTAyiAMvuKG7LR/G2Ud5EzEctsRqQVj0hjVYRt1GJxYSNckl7YQmjAMsZ"
    "adTgzXIGN1+gbJgBZw0uG+WLr1H8YAmjuC0fxYdsmAFYwihuy0fxtlG++Bq1hRqQRg1IoxWWjzohJmyUS9rLxSE6QLzKxWvwZlkF"
    "dJmZaC+ogrMGF5fmEWDWBF8sIRoCzKK9i5vsripAHJrgYtYEj43yxawR6AAXrwEudIBZI1AFTnBJe508tHk7a/Bmya0GpGnzdtbg"
    "JpvHwSVNmw9Lbq08zhrcZNfgS5o2t7SDx0b5KU2bt7MGP6UdfJf2Sh6zecuevJlz6wlLZvOWPbmIOBfj4LJkNh+yeAwe2ZObrJ58"
    "WTKb25LBIxn8tGQ2b9mTn5YMvlvy4vdslEvawX/rxe/ZKJe0g//Wi/8fWdLKH8mGg/87y1Z48QtL3rS5+aIGb1uYwUNS+cYXNfhn"
    "lrTyR7JbeaQxgy8naPPXLGnlxXeWfGgDy7m1ctkCzOBi2co3vqCVf2RJK39gSSuwhUdMHie3Ufwly1ZefGfJhzawnFsrsIVRy2cA"
    "tpTvfEEr/8iSVv7AspXLFt5iArJ5G8VfsWzlBWxhFDdLWvmynJhY0gpbtFk+Ayxb+c4XtPKPLGnlDyxbue1ZsJyYIBsO2MIo/ool"
    "HC9gC6O4WdLKl+XEBNmtsEWb5TPAfPALX9TgSxozwJJWHmnMACxpBU5gFA9LWvlhOTFBNhxAGjPwRQ1kc3BJm8FDNscL2MIobpa0"
    "8rGcmIBsONiizfIZ+KrBL3xBKx9pzABLWrls4TYDS1qBE7R5s6SVH5YTE2TDAaQxA1/U3Nw0hUtMLrI5XsAWRnGzpJWP5cQEZMPB"
    "Fm2Wz8BtIBsOvviCVj7SmAGWtAInjxlgSSucoM2HZSs/LIeYIJuDSxoz8MUfxOQim+MFbGEUN0vetGE5MQHZcLBFm+UzfNWQzUWb"
    "N1/QykcaM8CSVuCEUTwsaeUEbb5YtvKWxiUmyIaDSxoz8AWtcALapBGTi2x4nXyJiSUf2iwnJiAbDtgCzMBlWrbCiTYPX9DKRxoz"
    "wJJWOIFRPCzpseHgJ8tW3tKAmIBsOLikMQNf1ABO0IY0iAnIhtfJl5h8nKDNcmICsuEAtjADXzEtW+FEm4cvaOUjjRlgSSucoM2b"
    "JY+Dnyxb+bIciIlsOLikMQNf1ABO0AaWExOQDS9gC6P45gRtlhMTkA0HX1wmlq1wos3DF7TykcYMsKQVTtDmzZLHwU+Wrfy0nJgg"
    "m4NLGjPwRQ3gBG1gOTEB2fACtjCKb05g1HJiArLh4GN5TCxb4USbhy9q8CWNGWBJK5ygzZslb9p8sWzlG1/UQDYcQBoz8EUN4ARt"
    "YDkxAdnwArYwim9O0IblxATZrXxZTLBshRNtHr6glY80ZoAlrXACo3hYQisnaPNh2co3vqiBbDiANGbgixrACdrAcmICsuEFbGEU"
    "N/PB5QRtWE5MLGnlY3lMsGyFE20evqCVjzRm4AtagRNG8bCkFU7Q5sOylduWUbAcaiAbDtjCKPBFDeAEbWA5MQHZHC9gC6O4WPJF"
    "G1jOrZUvqwOwbIUTbR6++KJNGh+twMnbDCxpBU7Q5s2SVmALHzEB2byNAl/UAE7QBpYTE5DN8eI7S960uSzn1srH8hlcZHPR5s0X"
    "X7RJ4xKVtHLZwm0GlrQCJ2jzYdnKZQuPmDxObqMAX9QATtAGlhMTkM3x4leygYMvvqjBD6uDh2w4+OKLL9rA8phY0sojjRmAJa1c"
    "tjCKN8tWHmkwgy8naHPzRQ3gBG1gOTHBEo4X/zXLVn6LZSsv/nOyW/kdlq28+P/Tlhr8D19o839myQxe/MKNt548zJnNmxuDt5zN"
    "N+ZE8c+21OB/uM/i4gZU8CYLevI3LGfw4hfLeavBZSFG0MHFBYjmInsU31gyin+2pQZ/5CbKxV2AjuBm5tBFFX/prKgXv1hOcevJ"
    "5aQboxUwj+IcBYj4bL6xZBT/bEsN/mhTk8umQYTRDeJOtwgz+EsnNV78Yjna/HASky2tYKkN5yjAXfmFJaP4Z1tq8Ee7JrcdAWkw"
    "CtJAWzYz+EsnNV5cTmLyWI42H74YBfhC21IbTmqAu/ILS0bxIZsZgCUzeKS1ctlSg8tJDb7smvxkyShIa+WypQZYHsBJTEA2M3gs"
    "GS8uJzF5LEebD1+MAnyhbakNJzVYVPELS0bxIZsZgCUzAHMMajZsqQGyLKJ5k2Ux+cFdGAVprVy21ADLAozusUSErsltyXhxOYnJ"
    "YzkBTG6+GAX4QtsyojkriuyJC0TzYckoPmQzA7BkBpgbAUTDlhqYOaP4kE1MvrgLEQ1prVy21ABL6MKEsG6HVm7L6mVAUgHdsJzb"
    "oBt8MQrwhbYsiyJHYdZhi7ZZzZslo/iQzQzAkhmQRs3msaUGy6koPmQTkzeRpHtwSWvlsqUGWNIRpEFHLaOV23JeJ19iwnLeaoAv"
    "RgG+0IYtwCjOUbKJ2MzgzZJRfMhmBmDJDEjj4GNLDZZz8INsYvJmCTW4pbVy2VIDLBkFaTAKtrRyW87r5EtMvpzUAF+MAnyhzQ/n"
    "KNmjYEfwZskoPmQzA7BkBqRx8LGFSw1+kk1Mfkjj4JLWymVLDbBkFKTBKNjSym05LwOSCujmy0n3wBejAF9o82Ee3bJHwY7gzZJR"
    "fMhmBmDJDEjj4GMLtxr8IJuY/CDuFQVprVy21ABLRkEajIItrdyW8+JyEpPvTuDAF6MAX2jzYXmA7FGwI3izZBQfspkBWDID0jj4"
    "2AJhwsEPsonJT5aMgrRWLltqgCWjIA1GwZZWbst5cTmJyUNoLifdA3Ob1Yh7zeZNzAbIHgU7gjdLRvEhmxkgtpgBaYzibQuouYxu"
    "PmQTk58sGQVprYAtaoIloyANRsGWVm7LeXE5icljyeByUoPLSUy2tPIlGYDsUbAjeLNkFB+ymQHLYQakwSgeW0DbklF8yCYmP1ky"
    "CtJaQTYzAEtGQRqMgi2t3Jbz4hfLeavB5eTRyq9kE7GZwZslb60gmy8zAF/ctGFLDS4nNfiyawKWfBkF+OIxA7BkFKTBKNjSym3J"
    "ePELscVl0M3FlgARzUdGcbNF26zmzZK3VsCWwEAWMwCR5KINW2pwOanBl12Ti+EGVNANiCSX0Q1YMgrSYBRsaeWS0uPFr8S5TD5c"
    "gCq+eDUPF4jmQ5y3Di4uMBEnmtviEg0uHVxcqviyu4KbGVDFx+IyuYkTDS4QDS4dXE5qvPjPbWnlt5xd88V/bksrv+WcwYvvtvAY"
    "xcOXNh9nDf6C7Jj8C2nE5H+kKLfl1OCHFOVv7R7w4rstPEZxc7NoqgEToSH4E2Yek38hjZj8gZh0cHEzOiC4iblMqOYvuXT1i++2"
    "8BjFRTa3GcDywxIO/kQaMfkX0ojJH/gaxUU2bwc3X9y0+WuWM17YmsXHZnBrLikDkJwBLD+QZQcgGcF3acTkX0gjJn/gaxQ3ASTh"
    "4LKF0bhTg79kOeOFr1F87B78kKKA7KqA5QekHWAiVXyXRkw+TOgCxOjiJgZUA2nEBIfgi4uP4oslHFzOrmh80QomVDuXABMguFnO"
    "eOFrFB+7Bz+kKCAbtFl+QNoBKcqv0ojJx3JqAL5o5bYcmAGkERPZoM3HCaP4YgkHlzMm4ItW2MKMk8sBaYA2F8sZL3yN4mP34MOW"
    "tAKyQZvlB6QdkKKQDH5IIyYfy6kB+KIVkBSGrBlAGjGRHdF8OWEUXyzh4HLG5CKJwhYa4dIgXLS5WDYvM48CCkQWk1s3vmgFZIM2"
    "yw+RJQcspohR3XykEZOP5dQAfNEKJqt7yIoC0ohpsmLyw9k9m4cIsroHiGRMbhuFLXQDInQDIrMLsITXyZs2y/kYhS9aAdmgzfLD"
    "Eg5uvpQ9g480YvKxnBqAL1phCzP4SCNmGjH54YzJx3JgBpBGTG4bhS3MANKICfiiFbCEl5nDgAIRbgmj8EUrIBu0ESkRKPPJ6irM"
    "ZPCWRkw+llMD8EUrbGEGH2l0W89ufjhj8iGCrO4BIhmT20ZhCzOANGICvmgFLOGFr+7BNykyCl+0ArJBmw8Tm+yYwHJtHmnE5GM5"
    "NQBftMIWZvCRxqVnNz+cMflJlsjB5YwJiCwUtjADSCMm4ItWwBJe+BrFLyxH4YtWQDZo83HGRHZMYLk2jzRi8rGcGoAvWmELM/hI"
    "4xGTH86YfLf84HLGBHzRCluYAaQRE/BFK2AJL3yN4rsUGYXIQgHZUcWXMyayYwLLtXmkEZOP5dQAfNEKW5jBRxoVyIrJD2f3bH5a"
    "fnA5u2fji1bYwgwgjZiAL1oBS3jhaxQPAVrYMApIGbRIzuBDyAgkKxpxU97SiODW4C41AVu0QopEAM0ljZjIjmi+nDAKEN6WHVxO"
    "mIV794AtzADSiAn4ohWwbF74GsVjOTWWA6OANGJuYQYfaQc3X8qewUcaH9rAyUcrIJvbDCCNmMgGbT5OGAVs4ePgcvKmDWxhBpBG"
    "TMAXrYDljBdi1TzEnDKZUA2YrC7vqOYj7eDmq7AZfKTxoQ2cXKY4rVzcDJgBpBET3KwqeHPxUYDJ4hYdXBxcqAouW5gBpBET8EUr"
    "YDnjxXebi/IhCfTgh2XKzR2I4COFj9HA5qK2QLm5A7OAZdQE3OnBh69RXCS5RfCRQgS3DbOAZdQE3OkBWM548V/zNYrfYznjxX/N"
    "V1XwO1y6+sV/zRet/I7dA178ajmPg4clxORjizZ/7uTgny2HUfzR8hlctgCtfPiCGfy1LdovfrWcx8HDEmLysUWbP3dy8M+Wwyj+"
    "aPkMLluAVj58wQz+2hbtF79aDtq8yYaYvmZwSdPecnCxrMEvTg7+2XIYxa98zeCSBtontHLxFXM5jOKvbXnxq+WgzZtsiOlrBpc0"
    "7S0HF8sa/OLk4J8th1H8ytcMLmmgfUIrF18xl8Mo/tqWFzfLGjyWj+KL7Bpcls/g750c/BvLR/ErXzP4SXYrWEJMWD6Kv7blxc2y"
    "Bo/lo/giuwaX5TP4eycH/8byUfzK1wx+kt0Klv8fcXBs5UiSM2r04zlpCoQwBUKYAgGmQIApEMKUEGBKCi9JJqura7d35o3wz72Q"
    "DmFz8WdbHjxprclL2Fx8yF6TS5gnv8hekx9ODm4W4AmlMBqQzSUdwmAu2HLwxcKTLyf0AK10LmEwGk5+mIvLlgdPWmvyEjYXH7LX"
    "5BLmyS+y1+SHk4ObBXhCKYwGZHNJhzCYC7YcfLHw5MsJPUArnUsYjIaTH+bisuVx8iUdwng5uMhek0uYJ5SO3nLwogXpfDk5uFmA"
    "J5TCaGTDmtzC5toyml8sPLltoQcXrXQuYTAaTg6QDekQBnNx2fI4+ZIOYbwcXGSvySXME0pHbzl40YJ0vpwc3CzAE0phNLJhTW5h"
    "c20ZzS8Wnty20IOLVjqXMBgNJwfIhnQIg7m4bHkAsmFNvtkCB8hek0uYJx+ye2itCRae3E4ObhbgCaUwGtk9+BLGZTS/WHjy5YQe"
    "oJXOJQxGw8nBRSudS9hcXLY8ANmwJt9sgQNkr8klzJMP2T201gQLT24nBzcL8IRSGI3sHnwJ4zKaXyw8+XJCD9BK5xIGo+Hk4KKV"
    "ziVsLi5bHjxprck3W+AA2WtyCfPkO601wcKT28nBzQI8oRRGI7sHX8J4Ofhi4ckvsnuAFqRD2FxcTg4uWulcwubisuXBk9aafLMF"
    "DpC9JpcwT77TWhMsPLmdHNwswBNKYTSye/AljJeDLxae/CK7B2hBOoTNxeXk4KKVziVsLi5bHjxprck3W+AA2WuCBXhyO3uA1ppg"
    "4cnt5OBmAZ5QCqORDWvyEgZzwZaDLxaeXEpHA7J7cLFIh7C5uJwcXLTSuYTNxWXLgyetNflmCxwge02wAE9uZw/QWhMsPLmdHNws"
    "wBNKYTSyYU1ewmAu2HLwxcKTS+loQHYPLhbpEDYXl5ODi1Y6l7C5uGx58LswXg5etLh48pMWpPPl5JYOYdxGA7K5pHMJmwu2wMHN"
    "wpNLKU89eLHg4snLycFFK51L2Fxctjz4XRgvBy9aXDz5SQvS+XJyS4cwbqMB2VzSuYTNBVvg4GbhyaWUpx68WHDx5OXk4KKVziVs"
    "Li5bHvzrLDz5h7Y8+NdZePIPbXnwf0iLHvwkGw7+/2n1gAffaXEbzZMFa/K2BU9epAbfWEAP/pIWPfhJdg9eSvHk44TR/JkWPXjw"
    "nRa30UAYTz24bAE8uWj14BsL6MFf0qIHP2jRA9jCSzovJ09z8UdaPXjwnRa30UAYTz2ALcwV5gloDL6zgB78JS168INWDy5beEsH"
    "ZPM2F3+i1YMHsIW5eNKiBx9hpKNFD9gymjBP0OrBdxbQg7+kRQ9+0OrB0/YFYaSDbDhgC3PxJ1pwPIAtzMWTFj34CCMdLXrAltGE"
    "eYLa5DcW0INbKZ6gRQ9eSvEEtOgBnMBcvGjRgy9hpINsOIBSPLFgTWRzcCn15EU2xwPYwlw8adGDWxjpgGw42DKaME8s1uQ3FtCD"
    "WymeoEUPLlt48kSLHsAJo3nTogdfwkgH2XAApXhiwfLN0yjhks5FNscD2MJcPGnRg1sY6YBsONgymjBPTCey4eDDAnpwK8UTtOgB"
    "nLx4ghY94ITR3LR68CUM0kE2B5dSPLHgh3QusjkewBbm4kmLt9EQRjogGw62jCbM02JN2VxG82YBPbiV4gla9ABOmIsXLXpwwmg+"
    "tHrwVsolHZDNwaUUTyygB5zAaEpJ5yIbHicf6WhxG00Y6YBsOGAL4ImJa/WAk9G8WLAmH6V4ghY94ATm4kWLnhsOftHqwVspkA7I"
    "hoNLKZ5YsCZwwmgohXRANjxOPtK5nTCaMNIB2XAAW/DEIl2rB5yM5sWCNfkoxRO06AEnjOZNi5eDX7R68BEGpCMbDi6leGLBmsAJ"
    "o4Ew0gHZ8AC2MBffnDCaMNIB2XDwYeJo9YCT0bxYQA9upXiCddqq/gAAIABJREFUFj3ghNG8afFy8ItWD34JIx1kc3ApxRML1gRO"
    "GA2EkQ7Ihgewhbn45gTmCiMdkA0Ht7B0tHrAyWheLFiTj1I8QYsecMJo3rR4G82HVg++sWBNZMMBlOKJBWsCJ4wGwkgHZMMD2MJc"
    "fHPCaAgjHWT34CNw0OoBJ6N5sWBNPkrxBC16wAnMxYsW9OCE0dy0evCNBWsiGw6gFE8sWBM4YTQQRjogGx7AFubiSW1yOWE0hJGO"
    "Fj24haWDVg84Gc2LBfTgVoonFtADOGEuXrToASeM5qbVg6ctc0EYrIlsOGALc4EFawInjAbCSAdkczyALczFRYuP0UAYTz34iE5A"
    "qwecjObFgo/RlHLrAZy8eaJFD+CE0bxp0QPYwi0dkM3bXGDBmsAJo4Ew0gHZHA++0+JtNJcwnnpwC/PkIpvLaN4s+BhNKZdcRQ8u"
    "W3jyRIsewAmjuWn14LKFl3ReTp7mAixYEzhhNBBGOiCb48HvZAMHHxasyZfo5EU2HHxY8DEaCEtHix68lOIJaNGDyxbm4k2rBy+l"
    "4MnHCaN5smBN4ITRQBjpoAXHg3+bVg/+Ea0ePPjXye7BP6HVgwf/l2STzn8ImfwT51w8+I0ab+08mUIuXkwhFy/RyXch7fw12aTz"
    "U0lPnkwhFx8FTP6Hs5c/+I0Fbz24mCqslVzMWLZycQnW4rstPfhrsknnpy1rghgqsLqTJzEDMps/Muv54DcWdHNpBzRoEHwBZy8v"
    "6cnlnIvfbOnBX5NNOj9tloOadoMIBxcxW4D6av6oyAe/sWA0N9l4Qhij4fSEYnI55+I3W3rw12STzk87k6fTE0o5uJT2ANmk80el"
    "PLicpPNiwWhusvGEMEbD6QnFBIuDH7b04LYFDuBkTV4sIB2QTTpYgCdvWnjypZSDS2kPkE06WDBaNvQALTx5KeXB5SSdFwtGc5ON"
    "J4jGysXpCcUEi4MftvTgtgUO4GRNnkIFuifIJh0s8NW8aeHJl1IOLqU9QDbpYEG3CLBcTejlPInGg8tJOi8WJJ08qVquBWjhyekJ"
    "xUS1EzGy+bKlB7ctcAAna3IJFRI6QTbpmMrK5qaV2XyYkQmEkgmySQcLoJcBCRi9nCethwLFSugGC6CdbghjNBctPDlzgTGpdkSV"
    "tZqPLT24bYEDOFkTRIruyYts0jWkB1+0RvMmQrEml5N0QDbpYAG9vERYuSgRDp60Hicf6WDBSzqEMZqLFp6cPK1JtVPtVDsfW3pw"
    "2wIHcLImaEE6b7LJ3NCDL1qjeQsD1uRykg7IJh0swBPCGA2EcfCk9Tj5SOdNNvQgjNFctPAEtA7gnIuTdEp7cNvSg9sWOICTNUGL"
    "ubjJ5imdX7RG8+UEDuAkHZBNOlgwGghjNBDGwZPWQ4FiJXRz05AeiMbKBWjhCYgs4JyLk3RKe3Db0oPbFjiAkzVBi7m4yeapl/NF"
    "azRf1JSVCw16gmzSwYLRQBijgTAOnrQeXE7S+W5LD5CNJ6haZvMmRjYn6ZT24LalB7ctcAAna4IWKxdvsoFU6cEXrdH8oqbMBaU9"
    "QDbpYMFoIIzRQBgHT1oPLifpfKMhPUA2nhDGaG5aB3CSTmkPblt6cNsCB3CyJmhBOm+y6Z6h+OJDa3bzRcyYC0p7gGzSwYLRQBij"
    "gTAOnrQeXE7S+UU29ADZeEIYo7lpHcBJOqU9uG3pwW0LHMDJmqAF6bzJJh0sGM1NC0++lMJcUNoDZJMOFowGwhgNhHHwpPXgu1Le"
    "0nnawmVNPorJU7VT7Xxs4c0Twnhbk8vJ2wGySQcLRnPTwhPQ4nbwZMHTXIAFo4EwRgNhHFxKefCdCMXFV/OkppDZfBSTJ1FF0/nY"
    "wpsniAa0F2tyUdRg5QLZpINodCY3LU9ApHhauXgSKWhfXCwYDYQxGgjj4FLKgx+CSzZvqpDNF2XxIgZr8WHC21qAGHSarMWLGKzF"
    "JVgLEGMtPnYmTyZc1uIW0MmTKtmAKs5FFedSsh78+/bK5h8p5oN/35Y1+UeK+eC7LbzMxYvFaP6a7HT+hlLS+Q8lg7fdky8lg/9p"
    "94QH323hZS6eTDWb1YBKikLyX6haOn9DKen8ICqdXAyiE5InUROH1fyRSa9+8N0WXubiIpsnTyDs0IKD/6KUdP6GUtL5wWIuLrJ5"
    "O3iy4Gk0f6bl+UDDF7fN5Km5lExAyhMIO5DQA5DK5LtS0vkbSknnB4u5eBJACg4uW5iNGWvyR1qeDyzm4rZ78qVkALLXSgg7oPQA"
    "xNbiu1LSuanQCxClF0+iwGqglHQwSD5MbC4+tODgcvbKRtV6gAqrjUuCCpA8aXk+sJiL2+7Jl5IByIbRhB1QevBflJLOLYw1AQt6"
    "8BQGeAKlpCMbRnM7YS4+tODgcqbztBmwBc+TywGlwGguWp4PLObitnty05AegGwYTdgBpQcUE4rJl1LSuYWxJmBBD0BKmE1zKSUd"
    "2ZnNxwlz8aEFB5cznafNANFohEuDcBnNRat5qFouYHHZOE/dWNADkA2jCZsQckDgIsrq5lZKOrcw1gQs6AEq0T15KyVdJdL5cnZ7"
    "8yKCRPfkcqbztBmAVjcgQjcg4r0ALXicvI0GtvAyFxb0AGTDaMJ4OniyGGxPbqWkcwtjTcCCHrAFT26lpJeSzpcznVsY4MnTmc7T"
    "ZgBankAp6YAFPQAteKgaTFhcRICCubCgByAbRiPC01LzRmShKpO3UtK5hbEmYEEP2IInt1K6tb2bL2c6NxEkuieXM52nzQC0PIFS"
    "0gELegBa8MCie/JNicyFBT0A2TCaDzVv7QbCRvNSSjq3MNYELOgBW/DkVsqlvZsvZzq/SIgcXM50njYD0PIESkkHLOgBaMEDi7n4"
    "jdZcWNADkA2j+UZ2OhA2mpdS0rmFsSZgQQ/Ygie3Ul7S+XKm813YweVM52kzAC1PoJR0wIIegBY8sJiL70pkLkSCAcjOtfiolaDd"
    "QNhoXkpJ5xbGmoAFPWALntxKWYlEOl/Obm9+CVsr4ez2Rk17AFqeQCnpgAU9AC14YDEXLwK0sGEuoGTSIuXJl50JCA1ho3kpJZOn"
    "BjNZDmjQA0okE2gupaQjO7P5OGEuQHgL7eWwEV+YdU9AyxMoJR2woAeg1TywmIuXMNYMA+YCSknfgic/WIwmbDQvpdxGAye3HoBs"
    "njyBUtKRDaO5nTAXsIXbwZMFT6O5aHkCpaQDFvQAtDwfiK7mRdRYKg6rAZXoZZ2ruZk4T6ICTfJWym00cHJxMXpwMVXAEyglHUx1"
    "reTNxOYCVIKn7ORJ1IS1kictT6CUdMCCHoCW54PvNpfBTQroyZfQwVsJmdxKuM0GNpehAYMnM8AXEMpywIye3Czm4iLFUya3EjJ5"
    "0fAFhLIcMKMnoOX54N9mMRf/jJbng3+bqHTyT5iq54N/X8ngn9iC54PfhfFy8KIF6byUwmj+my0Hf0eYJz9ZePKyBQ5uFuDJ/7Jl"
    "9IPfhfFy8KIF6byUwmj+my0Hf0eYJz9ZePKyBQ5uFuDJ/7Jl9IPvwmAuPmSvaQGeUDoXf7IFDv5amCc/WXhyKR29hR5ctCA9zJM/"
    "2zL6wXdhMBcfste0AE8onYs/2QIHfy3Mk58sPLmUjt5CDy5akB7myZ9tGf0AZK/JSxjMxZtsWBMsPKF0Lthy8F9sOfg7wjz5nUU6"
    "35w9uGilQxjMxZ9sGf0AZK/JSxjMxZtsWBMsPKF0Lthy8F9sOfg7wjz5nUU635w9uGilQxjMxZ9sGf0AZK/JSxjMxZvsHlwsPKF0"
    "Lthy8F9sOfhi4cmldDQgm5d0CPOELaP5sEjnm7MHF610LmFzwRZ+58nLlgcge01ewmAu3mT34GLhCaVzwZaD/2LLwRcLTy6lowHZ"
    "vKRDmCdsGc2HRTrfnD24aKVzCZsLtvA7T162PE5u6RDG7QDZPbhYeELpXFtG86S1pkU6ty0HXyw8uZSOhhN6cAvzLIXRfFikc9sC"
    "BxctSOcSNhdsgQNkQzqEefKy5XFyS4cwbgfI7sHFwhNK59oymietNS3SuW05+GLhyaV0NJzQg1uYZymM5sMindsWOLhoQTqXsLlg"
    "CxwgG9IhzJOXLQ9A9pr8ZssBsntwsfDkP1mkc9ty8MXCk0vpaDihB7cwLqP5xSKdb84eoAXpXMLmgi0HF9lrcgnz5GXLA5C9Jr/Z"
    "coDsHlwsPPlPFuncthx8sfDkUjoaTujBLYzLaH6xSOebswdoQTqXsLlgy8FF9ppcwjx52fIAZK/Jb7YcILsHFwtP/pNFOrctB18s"
    "PLmUjoYTenAL42U0HxbpfHNCD9BK5xI2F2w5uMhek0uYJy9bHoDsNfnNlgNk9+Bi4cl/skjntuXgi4Unl9LRcEIPbmG8jObDIp1v"
    "TugBWulcwuaCLQcX2WtyCfPkZcsDkL0m32yBg4vsNcHCk/9kkc5tCxzcLDyhFEbDCT24hXnCltF8WKTzzQk9QCsdwjy5bDm4yF6T"
    "S5gnL1segOw1+WYLHFxkrwkWnvwni3RuW+DgZuEJpTAaTujBLcwTtozmwyKdb07oAVrpEObJZcvBRfaaXMI8edny4LswXkbzJJtL"
    "Oj9pcUnntoW3NcGCy1ylowHZvKRDmCeXLQc3i3ReSnnqwYsFF08uWw4ustfkEubJZcvoB9+F8TKaJ9lc0vlJi0s6ty28rQkWXOYq"
    "HQ3I5iUdwjy5bDm4WaTzUspTD14suHhy2XJwkb0mlzBPLltGP/jXWXjyj2wZ/eBfZ+HJP7Jl9IP/Q1r04CfZcPD/T6sHPPhOi9to"
    "nixYk7ctePIiNfjGAnrwl7TowU+ye/BSiicfJ4zmz7TowYPvtLiNBsJ46sFlC+DJRasH31iwJn9Nix78oEUPYAsv6bycPM3FH2n1"
    "4MF3WtxGA2E89QC2MFeYJ6Ax+M6CNflrWvTgB60eXLbwlg7I5m0u/kSrBw9gC3PxpEUPPsJIR4sesGU0YZ6g1YPvLFiTv6ZFD37Q"
    "6sHT9gVhpINsOGALc/EnWnA8gC3MxZMWPfgIIx0tesCW0YR5gtrkNxasyUcpnqBFD15KwRO06AGcwFy8aNGDL2Gkg2w4gFI8sWBN"
    "ZHNwKfXkRTbHA9jCXDxp0YNbGOmAbDjYMpowTyzW5DcW0INbKZ6gRQ8uW3jyRIsewAmjedOiB1/CSAfZcACleGLB8s3TKOGSzkU2"
    "xwPYwlw8adGDWxjpgGw42DKaME9MJ7Lh4MMCenArxRO06AGcvHiCFj3ghNHctHrwJQzSQTYHl1I8seCHdC6yOR7AFubiSYu30RBG"
    "OiAbDraMJszTYk3ZXEbzZgE9uJXiCVr0AE6YixctenDCaD60enArBdJBNhxcSvHEAnrACYymlHQusuFx8pGOFrfRhJEOyIYDtgCe"
    "mLhWDzgZzYsFa/JRiido0QNOYC5etOi54eAXrR68lQLpgGw4uJTiiQVrAieMhlJIB2TD4+QjndsJowkjHZANB7AFTyzStXrAyWhe"
    "LFiTj1I8QYsecMJo3rR4OfhFqwcfYUA6yObgUoonFqwJnDAaCCMdkA0PYAtz8c0JowkjHZANBx8mjlYPOBnNiwX04FaKJ2jRA04Y"
    "zZsWLwe/aPXglzDSQTYHl1I8sWBN4ITRQBjpgGx4AFuYi29OYK4w0gHZcHALS0erB5yM5sWCNfkoxRO06AEnjOZNi7fRfGj14BsL"
    "1kQ2HEApnliwJnDCaCCMdEA2PIAtzMU3J4yGMNJBdg8+AgetHnAymhcL6MGtFE/QogecwFy8aEEPThjNTasH31iwJrLhAErxxII1"
    "gRNGA2GkA7LhAWxhLp7UJpcTRkMY6WjRg1tYOmj1gJPRvFhAD26leGIBPYAT5uJFix5wwmhuWj142jIXhMGayIYDtjAXWLAmcMJo"
    "IIx0QDbHA9jCXFy0+BgNhPHUg4/oBLR6wMloXiz4GE0ptx7AyZsnWvQAThjNmxY9gC3c0gHZvM0FFqwJnDAaCCMdkM3x4Dst3kZz"
    "CeOpB7cwTy6yuYzmzYKP0ZRyyVX04LKFJ0+06AGcMJqbVg8uW3hJ5+XkaS7AgjWBE0YDYaQDsjke/E42cPBhwZp8iU5eZMPBhwUf"
    "o4GwdLTowUspnoAWPbhsYS7etHrwUgqefJwwmicL1gROGA2EkQ5acDz4t2n14B/R6sGDf53sHvwTWj148H9JNun8h5DJP3HOxYPf"
    "qPHWzpMp5OLFFHLxEp18F9LOX5NNOj+V9OTJFHLxUcDkfzh7+YPfWPDWg4upwlrJxYxlKxeXYC2+29KDvyabdH7asiaIoQKrO3kS"
    "MyCz+SOzng9+Y0E3l3ZAgwbBF3D28pKeXM65+M2WHvw12aTz02Y5qGk3iHBwEbMFqK/mj4p88BsLRnOTjSeEMRpOTygml3MufrOl"
    "B39NNun8tDN5Oj2hlINLaQ+QTTp/VMqDy0k6LxaM5iYbTwhjNJyeUEywOPhhSw9uW+AATtbkxQLSAdmkgwV48qaFJ19KObiU9gDZ"
    "pIMFo2VDD9DCk5dSHlxO0nmxYDQ32XiCaKxcnJ5QTLA4+GFLD25b4ABO1uQpVKB7gmzSwQJfzZsWnnwp5eBS2gNkkw4WdIsAy9WE"
    "Xs6TaDy4nKTzYkHSyZOq5VqAFp6cnlBMVDsRI5svW3pw2wIHcLIml1AhoRNkk46prGxuWpnNhxmZQCiZIJt0sAB6GZCA0ct50noo"
    "UKyEbrAA2umGMEZz0cKTMxcYk2pHVFmr+djSg9sWOICTNUGk6J68yCZdQ3rwRWs0byIUa3I5SQdkkw4W0MtLhJWLEuHgSetx8pEO"
    "FrykQxijuWjhycnTmlQ71U6187GlB7ctcAAna4IWpPMmm8wNPfiiNZq3MGBNLifpgGzSwQI8IYzRQBgHT1qPk4903mRDD8IYzUUL"
    "T0DrAM65OEmntAe3LT24bYEDOFkTtJiLm2ye0vlFazRfTuAATtIB2aSDBaOBMEYDYRw8aT0UKFZCNzcN6YForFyAFp6AyALOuThJ"
    "p7QHty09uG2BAzhZE7SYi5tsnno5X7RG80VNWbnQoCfIJh0sGA2EMRoI4+BJ68HlJJ3vtvQA2XiCqmU2b2Jkc5JOaQ9uW3pw2wIH"
    "cLImaLFy8SYbSJUefNEazS9qylxQ2gNkkw4WjAbCGA2EcfCk9eByks43GtIDZOMJYYzmpnUAJ+mU9uC2pQe3LXAAJ2uCFqTzJpvu"
    "GYovPrRmN1/EjLmgtAfIJh0sGA2EMRoI4+BJ68HlJJ1fZEMPkI0nhDGam9YBnKRT2oPblh7ctsABnKwJWpDOm2zSwYLR3LTw5Esp"
    "zAWlPUA26WDBaCCM0UAYB09aD74r5S2dpy1c1uSjmDxVO9XOxxbePCGMtzW5nLwdIJt0sGA0Ny08AS1uB08WPM0FWDAaCGM0EMbB"
    "k9aD70QoLr6aJzWFzOajmDyJKms1H1t48wTRgPZiTS6KGqxcIJt0EI3O5KblCYgUTysXTyIF7YuLBaOBMEYDYRxczOTBD8ElmzdV"
    "yOaLsngRI5svJrytBYhBp8lavIjBWlyCtQAx1uJjZ/JkwmUtbgGdPKmSDajiXFRxLiXrwb9vr2z+kWI++PdtWZN/pJgPvtvCy1y8"
    "WIzmr8lO528oJZ3/UDJ42z35UjL4n3ZPePDdFl7m4slUs1kNqKQoJP+FqqXzN5SSzg+i0snFIDoheRI1cVjNH5n06gffbeFlLi6y"
    "efIEwg4tOPgvSknnbyglnR8s5uIim7eDJwueRvNnWp4PNHxx20yemkvJBKQ8gbADCT0AqUy+KyWdv6GUdH6wmIsnAaTg4LKF2Zix"
    "Jn+k5fnAYi5uuydfSgYge62EsANKD0BsLb4rJZ2bCr0AUXrxJAqsBkpJB4Pkw8Tm4kMLDi5nr2xUrQcgutq4JKgAyZOW5wOLubjt"
    "nnwpGYBsGE3YAaUH/0Up6dzCWBOwoAdPYYAnUEo6smE0txPm4kMLDi5nOk+bAWh5nlwOKAVGc9HyfGAxF7fdk5uG9ABkw2jCDig9"
    "oJhQTL6Uks4tjDUBC3oAUgLLm0sp6cjObD5OmIsPLTi4nOk8bQag1QiXBuEymotW81C1XMDisnGeurGgByAbRhM2IeSAwEWU1c2t"
    "lHRuYawJWNADVKKbdp5KSVeJdL6c3d68iCDRPbmc6TxtBqDVDYjQDYh4L0ALHidvo4EtvMyFBT0A2TCaMJ4OniwG25NbKencwlgT"
    "sKAHbMGTWynppaTz5UznFgZ48nSm87QZgJYnUEo6YEEPQAseqgYTFhcRoGAuLOgByIbRiPC01LwRWajK5K2UdG5hrAlY0AO24Mmt"
    "lG5t7+bLmc5NBInuyeVM52kzAC1PoJR0wIIegBY8sOiefFMic2FBD0A2jOZDzVu7gbDRvJSSzi2MNQELesAWPLmVcmnv5suZzi8S"
    "IgeXM52nzQC0PIFS0gELegBa8MBiLn6jNRcW9ABkw2i+kZ0OhI3mpZR0bmGsCVjQA7bgya2Ul3S+nOl8F3ZwOdN52gxAyxMoJR2w"
    "oAegBQ8s5uK7EpkLkWAAsnMtPmolaDcQNpqXUtK5hbEmYEEP2IInt1JWIpHOl7Pbm1/C1ko4u71R0x4Qop5AKemABT0ALXhgMRcv"
    "ArSwYS6gZNIi5cmXnQkIDWGjeSklk6cGM1kOaNADSiQTaC6lpCM7s/k4YS5AeAvt5bARX5h1T9iCJ1BKOmBBD0CreWAxFy9hrBkG"
    "zAWUkr4FT36wGE3YaF5KuY0GTm49ANk8eQKlpCMbRnM7YS5gC7eDJwueRgNb8ARKSQcs6AFoeT4QXc2LqLFUHFYDKtHLOldzM3Ge"
    "RAWa5K2U22jg5OJi9OBiqoAnUEo6mOpayZuJzQWoBE/ZyZOoCWslF1XzBEpJByzoAWh5PvhucxncpICefAkdvJWQya2E22xgcxka"
    "MHgyA3wBoSwHzOjJzWIuLlI8ZXIrIZMXDV9AKMsBM/4fc3BsJEmSK1DwlVmKAiJEARGigIAoICBKEBAlCIiSxM/Kquruvdv5djNH"
    "7Ln3BHR5PvinWcziz+jyfPBPE5VO/oSpej745y0Z/IkteD74qzBuBzddkM5tKYzm72w5+E+EefKvLDy5bYGDNwvw5P+zZfSDvwrj"
    "dnDTBenclsJo/s6Wg/9EmCf/ysKT2xY4eLMAT/4/W0Y/+CkMZvEhu6YFeMLSWfzKloP/RJgn/8rCk8vS0VvowUUXpId58mtbRj/4"
    "KQxm8SG7pgV4wtJZ/MqWg/9EmCf/ysKTy9LRW+jBRRekh3nya1tGPwDZNbmFwSxeZENNsPCEpbNgy8Hf2HLwnwjz5K8s0vnh7MFF"
    "VzqEwSx+ZcvoByC7JrcwmMWLbKgJFp6wdBZsOfgbWw7+E2Ge/JVFOj+cPbjoSocwmMWvbBn9AGTX5BYGs3iR3YOLhScsnQVbDv7G"
    "loMvFp5clo4GZHNLhzBP2DKaD4t0fjh7cNGVziVsFmzhrzy5bXkAsmtyC4NZvMjuwcXCE5bOgi0Hf2PLwRcLTy5LRwOyuaVDmCds"
    "Gc2HRTo/nD246ErnEjYLtvBXnty2PE7e0iGMtwNk9+Bi4QlLZ20ZzZOumhbpvG05+GLhyWXpaDihB29hnkthNB8W6bxtgYOLLkjn"
    "EjYLtsABsiEdwjy5bXmcvKVDGG8HyO7BxcITls7aMponXTUt0nnbcvDFwpPL0tFwQg/ewjyXwmg+LNJ52wIHF12QziVsFmyBA2RD"
    "OoR5ctvyAGTX5C+2HCC7BxcLT/6dRTpvWw6+WHhyWToaTujBWxiX0XyzSOeHswfognQuYbNgy8FFdk0uYZ7ctjwA2TX5iy0HyO7B"
    "xcKTf2eRztuWgy8WnlyWjoYTevAWxmU03yzS+eHsAbognUvYLNhycJFdk0uYJ7ctD0B2Tf5iywGye3Cx8OTfWaTztuXgi4Unl6Wj"
    "4YQevIVxG82HRTo/nNADdKVzCZsFWw4usmtyCfPktuUByK7JX2w5QHYPLhae/DuLdN62HHyx8OSydDSc0IO3MG6j+bBI54cTeoCu"
    "dC5hs2DLwUV2TS5hnty2PADZNflhCxxcZNcEC0/+nUU6b1vg4M3CE5bCaDihB29hnrBlNB8W6fxwQg/QlQ5hnly2HFxk1+QS5slt"
    "ywOQXZMftsDBRXZNsPDk31mk87YFDt4sPGEpjIYTevAW5glbRvNhkc4PJ/QAXekQ5slly8FFdk0uYZ7ctjz4KYzbaJ5kc0nnX+ni"
    "ks7bFl5qggWXWUtHA7K5pUOYJ5ctB28W6dyW8tSDmwUXTy5bDi6ya3IJ8+SyZfSDn8K4jeZJNpd0/pUuLum8beGlJlhwmbV0NCCb"
    "WzqEeXLZcvBmkc5tKU89uFlw8eSy5eAiuyaXME8uW0Y/+MdZePJHtox+8I+z8OSPbBn94H+F7B78npODB38hi3JuGtwygVC8eFoy"
    "my8bGDzJoid/ThazuWhQzpsZmfyK7B4PfpAQgWrnYsHNE8yE9uKyKvl2AgcXWUIP/pzsHoCECN3tXNRE6M7iF06OB7DaeZLQzoDO"
    "BCy4eWJWZVpZYFTz7QQOLrKhB39MQnsAuugyOhOwoFDai793Ug/g7MGTmHqrGDVBQqu4VBPmqSGzMPPihxNIB2RDD57E6ORJlSpU"
    "q3gxIRswwbkEODfZnQmI0m1GOqhpJaZ4gmo2JmSDCdlcLHgAZw9uogm6qAkWpPMS5snSWSy8+eHkcgBh0AMQFaOzC7AgS1SrqgEV"
    "E7Kr2cJo4ISDm+wefOgiHSzaCw3xhLCJmJApYkI6TycP4OzBN13UBAsq6eYS5snSWRpeKMXHSSkHyKa0B4gZT+UNFhTKxRPUlBLB"
    "kzA8gZOa3GT34EMX6WCRDoRlNmEpysVNuIzmcvJQWEygm5suaoIFl6xuCPOUEK8lEwnx5O3kWDoaXeW7B+iCApHyxgK6EcETlnan"
    "GoxmC6ORzcGL7B68KBKdiZilA2F4EkY3CnSjMIvLyePkrQc3C9JBF41AOoR5hc6SyFrayCxeTkafHLJ7yO4BuqgQTgaIAAAgAElE"
    "QVQJukjHAjwJwxMJnQVLGc1SRnPCwYvsHtx0AelgQToQhidhzCIMZrEURgMnj5O3HjzpoiYXE8cCPCEMmLV01tJZW0ZzO+E4OWT3"
    "kN0DdFETdJGOBekQhidLmQUsHQ1bRnPCwYvsHtx0QU3AgnQgDE/CmAVLmQVbGA2cPICTHrzpoiZfLPAEwjxhZS2dxZbR3E44Tnru"
    "npse6KImoIt0LEgHwjxZytto2MLok4M32T140wXpWJAOhOFJGLNgKbNgC6OBkwdwMpoXWUJNvljgyUUawmYtncWW0dxOOGTTTDY9"
    "0EVNQBfpWJAOhHmylLfRsIWxhIM32T34EA3SsUgHwvAkjFmwlFmwhdHAyQM4e/AiSyhvvljgyduqZOkstozmdsLBCT1k0wMsSAdd"
    "pGNBOhDmyVK8eSpAlowls3iT3YMvukjHIh0Iy2zCmAVLmQVbGA2cPICzBzcJpb14UknAAk9ejGqWzmLLaG4nHFjQQzY9QBc1QRfp"
    "WJAOhHmipuXNx5ZSDj5k9+AimoAu0rFoLzTEE8KYBUuZBVsYDZw8gLMHTxIKXUCnhBQgiic3My/QaO8to7mdcMCJp2x6gC66QLS9"
    "sCAdNMQTllLeJtlcLICDD9k9AAkpQLS9kNB2QvCEMGbBUmbBFkYDJw8gcJ5k81ZTQrlVFreFN7A02yqb2wkHBI5seoCE8tReYEE6"
    "hOEJZkK2SWZz2UI6H7J7ALp4SQcsKJTKgjBmwVJmwRZGAycPvsnmrSZqItCdxU0ii0uoUN68nHBwk00PQAKluxKwIB3C8ARMRSjw"
    "5rKFgy+y2wskQOmmElAToTsLCGMWLGUWbGE06KoH3yR4awfUoJI30yyeQvDmbcHkJkE7T2q086RGJZiSxVMI3rxs4eCLLOnBkxrt"
    "vJlSyZMpWRCCNyzwhpPjwT9DWNKDb7J78LtOjgf/jC0wmm+ye/C7To4H/ytCJr9pac0HP6gC2TyJccsGTMD5GwGdXMSgiv9CyOQp"
    "uDgvqpDNL6gxHyA0NwkFvJqLLm6jQUJgNhdpfjqhJhfZkM6fE5PJRTbQs7kIZuDV/ILZfEDI5LaFp3QuuriNRvZoC0YD5yx+OKEm"
    "F9mQzp9bWhPQxW00sIWndH7BggeETG7Kk0k5oGvyVCB7tGiMRiK7+eGEmoCaQjq3RRa3RZYEWbwssrio4Q2EVPKyOhsQAdSoLNhS"
    "CUE5mDIxbQckyOIiGg8ImfywtAega3Zzkz0a2aORmPzFCZUFFkA6IMIiiwJkkyVBZgMiLLIo0MVoYEs6L6uSD11UFmwyYWlNCGNi"
    "2l4iEmQ2F10PCJn8sLQHoItZ3GSPRvZo/s0J9AALIB2w4HYAsnlJByy4HaCL0cCWdF5WJR+6GA1sL2BpTQjjZZhxSeei6wFhPfi2"
    "tAegiwYGIHs0skerTUJh8HFO0x5gNpekQ6gwMKNnIxvKWZIOWDBA4wBdjEaWeDUvq5K3UGE0smQWsLQmhMFsDToLlqRz0fUwVHHo"
    "4mZGJqArUcGrkZ0N4qikGUVX83ImIgM1GVvSYWmXo6aMRjaVxZbKQk3KQZdXi1lmy2YWL2aZvKgp6SCbWcDSmhBGZosZnrAlnYuu"
    "x8lLTW5b0rnoOgiD0cgGevB0ks45i5cT7xiE9diSDktrAroYjWw8YQs9WFoT0MVoZOMpm1m8nHjysoUegGxmAUtrQhgHIBtP2JLO"
    "RdcDwjh4k80svuhiNB+rnXMWnLN4OfFeDMPZkg5LawK6GI1sPGELPVjK22hk4yl7NG8nnnzoYjSymQUsrQlhHIBsPGFLOhddDwjN"
    "5EXMmMUXXVQWb0pxzoJzFi8nXhqp5WxJh6U1AV2MRjaesIUeLAXnqRrMMmWP5u3Ekw/RyGwsZgFLa0IYByAbT9iSzkXXA0Imbxa0"
    "F1900Zm8SAPnLDhn8XLiKZsuZ0s6LK0J6GI0svGELfRgKT34srNkjeZtiydfZOMJO6thaU0I4wBk4wlb0rnoekDI5M2C0XzTxWje"
    "thecs+CcxcuJp2w8YUs6LK0J6GI0svGELfRgaU2+bQFG87Eq+SIbT9iSDktrQhgHIBtP2JLORdcDQia3EBFG86TGxEwYzU0iu+Hs"
    "TM5ZvJx4opEJW9JhKTVDRGaBbDxhCz0Qs5ogMXlSUxjNx6oETMFbTfGELeksaW8I4wBk4wlb0rnoeoCJc9sCeAOFmk5MKW9uskcD"
    "Szoxb15OPCGqYEs6hAozpHsCsvGELfQANZ0gcXALo7z5WJWAmeCtRmXBkk5WZwJhHIBsPGFLOiAaD75t4e0AXTwdvMkezWUpHHyc"
    "ePKyJR2w4FKTi2w8YQs9AF08HdzCevBtVXLRxW00l6XALC5hHIBsPGFLOmDBg2/CRwPCU/MhzZMAzYfQvAk0F+GpeRIaEKC5CE/N"
    "LawH35aUcxFuzZNwaZ4EmovQgEADZvPBP8RUMvlm1pPfZTof/EO2pPNTyOR3mc4H/yssRvObTs8HP4kAxU2EWzegQDcXkeIHEbq5"
    "iNDNf8FiNBflUryIQPFLp+eDnyyA0Tzp4jYLZAOzuIQOfggjnYsF6fwXLEZz2QI1edFFTX7p9HzwQ6i4WIE36KId6AYUiWoHRIof"
    "wkjnYkE6fy5URoNaNUF7cwkKUW9+QVUe/LCFoQGMBl3U5ItsevBvwkjnYkE6f+6E0WAxmi2M5rKY6JrFr4Q9uFgcfNvCaNA1mpcl"
    "A1gykO3JT2GkAyeQzm0L1OSiaxZLmcWTbMATZMMBhJHO7Uzniy5qooua6KIHsGQshR7IhoNb2ANQ04NvWxgNuryBAkwcWDKQyFIo"
    "PsKoLDiBdEBBBW0vQJd3mWpWASoKmlWwRA4grLK4nel8qFpVoqsqkRAGsMRVlHZERWY3l7AHcMLBty2MBl1cavKxZHCRTQ8+woAD"
    "TiAd2MJotjAadFETXfQAlgxk0wMIO4Cwg7cznY8tjAZds7gsGcBSZm8uPcLw5BL2WKBQMHnbnQXo8iZob5BworpM3KQQzeIlbJoe"
    "cFaudGALo1G10aCLmuiiBxLCADUZQNgBS+Tg7UznRU0rC9A1i8uSASzxbjUlq0TDk0vY4+Tt4G335KJrNEuZBbJn71ksGaED2Z68"
    "hB0WB5zpuxzYwmjQNRp0URNd9EA2PYDQAYQdcMLB25nOiy5qctE1i8uSASwZQBiewOnJJezBxeLgw4KafNFFTV5kzyJ0INuTl7DD"
    "AjhglwNbGA26qImuWaCLHsjmpQcQhufpyceZzhddo0HXLC5LBrBkAGF4Aqcnl7AHF4uDN1WrSr7ooiYvElmEDmR78hJ2qCkcsMuB"
    "LYwGXVWJrlmgix7IhuLSDpiq5+nJx5nOF13ehS7vApYMYMkAwvAETk8uYQ8uFgdvWxjNN13U5IfQgWxPXsIOOOGAXQ5sYTToGg26"
    "ZoEueiCbHnw7PU9PPs50vuiiJrqoCSwZwJIBhOEJnJ5cwh5cLA5ualpZfAvRrOJm4kDoQLYnL2EHnHDALge2MJoQHQ26ZoEueoCa"
    "DL6d3erJx5nORc0bdFETXdREQhjAkgGE4QmcnlzCHlwsDm4WpPPDUmbxsmQAoQPZnryEHXDCAbsc2MJotjAadM0CXfQAlgy+nYAn"
    "H2c6F4vRoIua6KImuugBLBlAGJ7A6ckl7MEPW3gZDbq41OSvwrh48hJ28LbLuVhwqclF1yzQRQ9gKU89uIUdfDvTuVhwG81lKZdZ"
    "XJYMIAxP4PTkEvbghxBevEGCSyV/Zcolixe1yVt0clHjUslFwhskaAdMeWrnFnbwLagC1Lh5cwnh4s3FxAFTsoCVBajKg39M2MEP"
    "FqP5Tafng3+GKdXFDxaj+U2n54N/Rhie/GQxmt90ej74HyG7Jr8pbNaD/xGya/KbwmY9+IulQDpPuniqCUsHuyaXsybfllKTJ9ng"
    "yR+TXZPLyW00EAbU5FfCZj34i6VAOk+6eKoJSwe7JpezJt+WUpMn2eDJH5Ndk8vJbTQQBtTkV8JmPQCLWXzRBbMAXZ68LB3N31kK"
    "pMMWwJM/JrsmH0tHA2Gz0JXOrz0Ai1l80QWzAF2evCwdzd9ZCqTDFsCTPya7Jh9LRwNhs9CVzq89AItZ/GAxC9DlycvS0fydpUA6"
    "bAE8AV089YAwXmYBumDWWROW0gPCZvGyGXxbOhpdMAtd6YBsfhrN09IHYDGLHyxmAbo8eVk6mr+zFEiHLYAnoIunHhDGyyxAF8w6"
    "a8JSekDYLF42g29LR6MLZqErHZDNT6N5Wvo4+ajJky6YBejyXEpNWDrYNXmxmMXL0kNXOmyGLk84a3LZDAiDAyxgNLo8AV3psBkQ"
    "NouXzeBFF8wCdHkCumAWsmvCUmrCUnpwWfo4+ajJky6YBejyXEpNWDrYNXmxmMXL0kNXOmyGLk84a3LZDAiDAyxgNLo8AV3psBkQ"
    "NouXzeBFF8wCdHkCumAWsmvCUmrCUnpwWfoALGbxcUI6386a/HTWhKWjeVp6gAWMRpcnnDW5bKFmGBxgAaPRxUs6bAaEzeJlM/i2"
    "dDS6PAFd6YDsmrCUmrCUHlyWPgCLWXyckM63syY/nTVh6Wielh5gAaPR5QlnTS5bqBkGB1jAaHTxkg6bAWGzeNkMvi0djS5PQFc6"
    "ILsmLKUmLKUHl6UPwGIWL0upyU9nTX46a8LS0TwtPcACRqPLE86aXDYDwuAACxiNLk++yAZPPjaDb0tHowtmoSsdkF0TllITltKD"
    "y9IHYDGLl6XU5KezJj+dNWHpaJ6WHmABo9HlCWdNLpsBYXCABYxGlydfZIMnH5vBt6Wj0QWz0JUOyK4JS6kJS+nBZemDH8KAmjzJ"
    "Bs+l1OSnsybflh586PKEk5ceEAYHWMBodMEs3mSDJ/9iKTUtYDQQNuuEdEB2TVhKTVhKD24PfggDavIkGzyXUpOfzpp8W3rwocsT"
    "Tl56QBgcYAGj0QWzeJMNnvyLpdS0gNFA2KwT0gHZNWEpNWEpPbg9+CGMl1k8hc3iX+lK5/9lMYu/t/TgRTZ48kV2TZ50pfOx9OBF"
    "dk0uZ00+wmY9+CGMl1k8hc3iX+lK5/9lMYu/t/TgRTZ48kV2TZ50pfOx9OBFdk0uZ00+wmY9+IfIrskPsmvym8JmPfiHyK7JD7Jr"
    "8pvCZj34XyG7B7/n5ODBX8iinJsGt0wg1Ivbktl82cDgSRY9+XOymM1Fg3LezMjkV2T3ePCDhAhUOxcLbp5gJt1ZXFYl307g4CJL"
    "6MGfk90DkBChu52LmgjdWfzCyfEAVjtPEtoZ0JmABTdPzKqwLMDMi28ncHCRDT34YxLaA9BFl9GZgAWF0l78vZN6AGcPnsTUW8Wo"
    "CVhUcakmzJOFN6zO5tsJpAOyoQdPYnTypEoVqlW8mJANmOBcApyb7M4EROk2Ix3UtBJTPEE1GxOywYRsLhY8gLMHN9EEXdQECU3n"
    "JcyTpbNQzeaHk8sBhEEPQFSMzi7AgixRraoGVEzIrmYLo4ETDm6ye/Chi3SwaC80xBPCJmJCpogJ6TydPICzB990URMsqKSbS5gn"
    "S2dpeKEUHyelHCCb0h4gZjyVN1hQKBdPUFNKBE/C8AROanKT3YMPXaSDRToQltmEpSgXN+EymsvJQ2ExoZsXXdQECy5Z3RDmKSFe"
    "SyYS4snbybF0NLrKdw/QBQUi5Y0FdCOCJyztTjUYzRZGI5uDF9k9eFEkOhMxSwfC8CSMbhToRmEWl5PHyUsPXixIB100AukQ5hU6"
    "SyJraSOzeDkZfXLI7iG7B+iiJugiHQvwJAxPJHQWLGU0SxnNCQcvsntw0wWkgwXpQBiehDGLMJjFUhgNnDxOXnpw00VNLiaOBXhC"
    "GDBr6ayls7aM5nbCcXLI7iG7B+iiJugiHQvSIQxPljILWDoatozmhIMX2T246YKagAXpQBiehDELljILtjAaOHkAZw8+dFGTLxZ4"
    "AmGesLKWzmLLaG4nHCeH7J6bHuiiJqCLdCxIhzA8WcrbaNjC6JODN9k9eNMF6WCRDoThSRizYCmzYAujgZMHcPbgTZZQky8WeHKR"
    "hrBZS2exZTS3Ew7ZDZNND3RRE9BFOhakA2GeLOVtNGxh9MnBm+wefIgG6VikA2F4EsYsWMos2MJo4OQBnD14kSWUN18s8ORtVbJ0"
    "FltGczvh4IQesukBFqSDLtKxIB0I82Qp3jwVIEtG6CzeZPfgiy7SsUgHwjKbMGbBUmbBFkYDJw/g7MFNQmkvnlQSsMCTF6OapbPY"
    "MprbCQcW9JBND9BFTdBFOhakA2GeqGl587GllIMP2T24iCagi3Qs2gsN8YQwZsFSZsEWRgMnD+DswZOEQhfQKSEFiOLJzcwLNNp7"
    "y2huJxxw4imbHqCLLhBtLyxIBw3xhKWUt0k2Fwvg4EN2D0BCChBtLyS0nZDyhjBmwVJmwRZGAycPIHCeZPNWU0K5VRa3hTewNNsq"
    "m9sJBwSObHqAhPLUXmBBOoThCWZCtklmc9lCOh+yewC6eEkHLCgUTyCMWbCUWbCF0cDJg2+yeauJmgh0Z3GTyOISIlLevJxwcJNN"
    "D0ACpbsSsCAdzMQTMBWhwJvLFg6+yG4vkAClm0pATYTuLCCMWbCUWbCF0aCrHnyT4K0dUINK3kyzuIV487ZgcpOgnSc12nlSoxIw"
    "zeIpBG9etnDwRZb04EmNdt5MqeTJlCwIwRsWeMPJ8eCfISzpwTfZPfhdJ8eDf8YWGM032T34XSfHg/8RFozm96x2HvykCtk8qfKS"
    "DQFV3CKbL6qQzUUVnP+CWSaX4OK8qEI2v7Ik8wFCcxPMYDYNWHDr2chuKpuLrNl8sYBZXMJgNH9M1AYX2VwGzUXMYDbN3wvt+YCQ"
    "yW0Lt5qABbcDdDHabAC6Dn6wgFlcwmA0fyysB6CLF09gKU81+QXT+YDQnjwpTyE1AQsmlwJds7CoCWjxgwVUFhAGo3kyBW8upu2E"
    "wORmCpPLIgswbeclrAcX5WnhCUs6IaQmoOqYwgQ1vHkynQ8I68G3pTUBC0Zz0xhgwWiR4icLwBPUFEYDiil4NbC0nRCYxUVNYRbI"
    "xhNYWpOX0HI+ZOMJW9IhtCdg5pjCBDW8movpfEBYD74trQlYMJqbxgALRptOfrIAPGELMBo4uXkCS3kbDWzhMgvZeAJLa/ISOF9k"
    "4wlb0oGQCVjwkycX0/mAsB58W1oTsKChJ6CrZ5vNBmmWlPNmwViZsAUYDZxkwqIclsLADEYjS7xgdyayKIelNXkJnA8NmQVsSQfC"
    "ehAqDMyATDZdDlj0w1DFoYuXpTUBCxKRTBCzbJWBUphAJy8WHIssdqOMRjQqC7akw9IuR00ZjWxmwYknbEmHJZm8BM6LihijgS3p"
    "QFgP1JTRakplEUY6YMHj5CWdl6U1AQtGW3AAsoEerHbOWRqDFwuOpTXZSTAaXcwCtqTD0pqALkYjm1lw4glb0mG18xY4L0uB0cCW"
    "dCCsB1gwGl3MArakAxY8IKwHX048+aKLWbxtL10H6GI0TxYchPjGCUaji1nAlnRYWhPQxWgL3jyBwNmSzlvgfOgCT9iSDoT1AAtG"
    "o4tZwJZ0wIIHhPXgTcwymy+6mMXb9tJ1gC5G82TBQWhZpgaj0cUsYEs6LK0J6GK0BWRzqQZCM7ek8xY4H6KBJ2xJB8J6gAWj0cUs"
    "YEs6YMEDwnrwpqtn800Xs3iR5aXrAF2M5smCgzAYbcFodDEL2JIOS2sCuhitIcziI6zn7kzeAueLbDxhSzqIWQ+wYDS6mAVsSQcs"
    "eEBYD14sOPhJF7O4yR6NrgN0MZonCw7CYLQFo9EFnrAlHZbWBHQxGtnM4iMMmMVH4HyRjSdsSYelNQELRqOLWcCWdMCCB4T14GYm"
    "HNxMYZqis3iRPRpd5a1rFjcLDsRsFhaMBl105lLSYWlNQBejkU1n8iZmMIuPwLlI4K2meMKWLl9KTTATRqOLWcCWdMDMH2DK5ElN"
    "YXIpzIRpSk1eRGyChHqrDl4sOEBtggWjgaVULjoTltYEdDEaCaUSipsFlcVHSBagC281KgsWgi86E8yE0ehiFrAlHTCdD75t4aUH"
    "WHCpyZvZ4OkEevBiwcGLBaO5LOXiCSytCehiNLCFyyyeLBjNl7AegC5uo3myADy5WDAaXcwCtqQDpvPBN+GjAeGp+ZDmSbg0b0Lz"
    "JjRPwlNzEWguQnMRnpqbBaP5ImqDi3BrXgRobkIDQnMRaAjt+eAfYsFovpkNftfSmg/+IRaM5pvZ4Hctrfngf4XFaH7T6fngJ+HS"
    "vAi35iJA8yQ034RLcxGg+S9YjOYiXJo3geaXTs8HP1kAo3nSxW0WyAZmcQkdfDuBdC4WpPNfsBjNZQvU5EUXNfml0/PBD6pWqEMC"
    "uugCskEM0VlcTJxvJ5DOxYJ0/pyqjQZRAetMQBQEuppfOKse/LCFoQGMBl3U5IvsWfybE0jnYkE6f+6E0WAxmi2MBl3URNcsfuGE"
    "BxdV58kgRU0YDbqyipuRiEonYtn8cALpQIiSzs0EOrmIZWNCNk9iQDYQVVxUnbezKgHRBBMbDbqoia6qBIxUhU4IcJ5M9cHF4uDb"
    "FkaDrtG8LBnAkoFsT344gXTgBNK5bYGaXHTNYimzeJINeIJsTy5hB29nOl90jQZd1EQXPYAlYyn0QDYc3MIewBI5+LaF0aCrgHZg"
    "yQCWDNAmsvg4ge4JZ+VKB0JICNobdHW5aHQ5YJpIdE9kd08g7ODt/6iDYyNZVkRBoKci0hQETEHAFARMQcAUBExBwJQUNrOqu6v6"
    "zcx/M/dvxO6cc/bqW0shbtKoc5OaiJHm1Jj0kmafLq08cHJ4W0HcpOEyM0aIGCG6hFW7b6fbwdnrmhUriNsK4iYNM0vDjhghCsuO"
    "wuJAK4cvZ6++rSBu0sjTZYSIkeS9XHZsRe0urTwWgU30Ze26kUbeWtp1klrdo8/dUmwp7zB693QSSzk4e12zYgVxC6nFTRpmloYd"
    "hRF2JLQQCaUcrODw5ezVS2ph1o008nQZIWKEvIWW1LlbUbtLK49FYBO9hLGzS2p5G0mehFH3qDOUFFuKwqrd08lRWmTMumbFCjtv"
    "0oibNMwsDTsKy85oIaKVuJ129OXs1UtqZt9II0+XESJGiGhF7VoKtbu08sDJ4VtpZvYjjTx9CStPLUVh1e7p5CgNB2tWrFld0oib"
    "NPIkDTsKy8uOaEXtZ+2+nb36kUbcpJGnywgRI0S0onactbu08sAI4fAlpTJn9yONPH0JrU8tRWHV7mmEcKSSOFizYu0+kUbcpJEn"
    "adhRWEy3jJJS7Wftvp29+pFGnVsaebqMEDFCRCtqx1m7SysPl9IOX1YQt7c08vSppSis2r20cnBysGbFCuImjbhJI0/SsKOw7Ojt"
    "rP2s3bezVz/SMLM08nQZIWKEiFbUjrN2l1YeLqUdnkJqe/btR0olTy8pdLQUhVW7l1YOTg7WrFhB3EoocZNGnqRhR6Ek0ds5Z6vd"
    "t7NXl5A60jCzNPqcQioiRohoRe04a3dp5eFS2uGpNL36MJI8vYwQ0VIUVu1eWjk4OVizYgVxW0HcpJEnadgRI0RvJ2r37ezVpbS4"
    "ScPM0jCzNOyIESJaUTvO2l1aebiE1N1aSPZE34SCpM/tJZlopbPn9tRSOEhBZ82KlMrcyu5zk0aepGFHjNTdqttJndu3s1eX0uYm"
    "pLqnkIoppD4nRohoRe04a3dp5eHDCl7iJg2Xmf3WCjv6cnL4smZ1Kc1lZpc08iQNO2Iktx3dTg5vZ68upXmK22UklzxdRohoRe04"
    "a3dp5eFD8GW7BLftt+CyfQlsX4LtFty2W9gugY3gZbudHN7OLboET9stuG23YCNgI9hYfT78v3JyeDuJ23/orP3h/xsrHP4zrcT9"
    "8P+NFQ7/mVbifvhQmtvMLit4iVsatftnwqJ2t9Jq93/BSJjZLSyXPP0rKzx8KM1tZpcVvMQtjdr9M2FRu1tptfu/YCTM7BaWS57+"
    "lRUeKK12b+fMLkv0aaSDNGr3ISxqRxrU7s+1ErdvJ72yRJeR4vbPrfBAabV7O2d2WaJPIx2kUbsPYVE70qB2f66VuH076ZUluowU"
    "t39uhQdKq93bObPLCmb2NtLhH4TlErc0qB1puO3oMpKXPJGG2460kidKq91LK3H7dtIrS3QZKW5p+GVHlxUeKK12b+fMLiuY2dtI"
    "h38Qlkvc0qB2pOG2o8tIXvJEGm470kqeKK12L63E7dtJryzRZaS4peGXHV1WeJy+HL6cM7ssMQ3yRBq1j3SENXMreZ47egmr11bi"
    "PmcurXak0SvCmpmR7EgreQqL2jl3dBnpoLTavbQSt5cVzOyyRJeR4pYGeQprZpdzR5cVHqcvhy/nzC5LTIM8kUbtIx1hzdxKnueO"
    "XsLqtZW4z5lLqx1p9IqwZmYkO9JKnsKids4dXUY6KK12L63E7WUFM7ss0WWkuKVBnsKa2eXc0WWFB0qr3bcVDm+lEbd/KaxeW8HM"
    "pdXOSa8Ia2ZGihut5CksLzu6jHSE1atvrcTt20mvLNFlpLilQZ7Cmtnl3NHTA6XV7tsKh7fSiNu/FFavrWDm0mrnpFeENTMjxY1W"
    "8hSWlx1dRjrC6tW3VuL27aRXlugyUtzSIE9hzexy7ujpgdJq9zISh7fSiNu/FFavrHBQWu1Io1eENTMjxY1W8hQWtfs2Enr1rZW4"
    "/UijV5boMlLc0iBPYc3scu7ossIDpdXuZSQOb6URt38prF5Z4aC02pFGrwhrZkaKG63kKSxq920k9OpbK3H7kUavLNFlpLilQZ7C"
    "mtnl3NFlhYcPpbkcnpaYBnn6pZU8zx29hNUrKxyUVjvSIM8luowUN1rJE2mQp28nvfrWStwoLU9OekVYM7eSJ9IgT2HN7HLu6LLC"
    "w4fSXA5PS0yDPP3SSp7njl7C6pUVDkqrHWmQ5xJdRoobreSJNMjTt5NefWslbpSWJye9IqyZW8kTaZCnsGZ2OXd0WeHhQ2leekVY"
    "9OofjHT4FlavXkqr3ctIcbuNFNdqveUAACAASURBVDdaydPLSIcv547eWonbywqHb2nU7kNYM7ucO7qs8PChNC+9Iix69Q9GOnwL"
    "q1cvpdXuZaS43UaKG63k6WWkw5dzR2+txO1lhcO3NGr3IayZXc4dXVZ4+H9kJDv6tMLhP7XCw/8jI9nRpxUO/6kVHi4rkKd/y0jU"
    "7n8hDV/y9OVE3EhD7f4DDy0JyNPfGoGATd7+VBq+bKKnE3G7BLb/wGOE4JanvxFa8mPO7g+lwa4tuM0+XU7E7Q88Ggry9BQSe7qk"
    "wNy+pVTQfZnTlxSY21NI9iQkdJcUmNunNNixBFKgdpcTcZMCc/tSMLenFNiTkOzpUjC3h8sK5OmpNGZGasHs07dW2Dv7LQQt0Kfp"
    "kobZZ0qFXSepJPqcPqTBji6lBH1OnIibkajdLQQDdZsupTFzEtqcXQgG6vZwWYE8PZUSzLqFhcOPUAq9+i2Ugh0QN9Jg55bc8rbc"
    "dt7e0mBHtzSYGSfiZiRqdwktYQfEjdKYdSFuoSXswH64rECevpyIOywcfpwuvfptBcx8Im6k4Z/K04802NEtDbW7nIibkajd5XSp"
    "c7nUTmm+xO10qXPp9eGyAnn6ciKmxszeTuSJNNx6JSx2dGmFXknDJU9acTlwIk8/0mBHl5Go3eVE3IxE7S6nmV1GonZKc6vd5UTc"
    "bg+XFcjTl1SSLahzezsRN9Jw65U02NGlFXolDXadaIXZJ1YgTz/SwHQJgdpdTsTNSNROKsnMLqEUtVOaS97b5cTu3eXhsgJ5+pZS"
    "ccnThxNxIw23XkkD3SUFeiUNdnRphV5dViBPP9LwVud2ORE3I1E7pbGnW0hqpzR2755KCcytbw+XFcjTt5SKS54+nIgboaDolTR8"
    "6JU02NGlFXp1WYE8/UiDPb1UTyfiZiRqpzQfaqc0ZvalBAV9e7isQJ6+jeSWpw8jBHVuT2HplTQwfZmdNNjRpRV6dVmBPP1Igx39"
    "ciJuRqJ2SsP0pU9KY2ZvQwh4uKxAnr6N5JanT63Qq6ew9Eoa7OhDGuzo0gq9uqxAnn6kwY5+ORE3I1E7pTGzD6Uxs09h4eGyAnn6"
    "ciKWQq8+tOJyuIWlV9JgRx/SYEeXVujVZQXy9CMNdvTLibgZidpdTsTtR2nM7LeRPBYCNnp3Oc26pcGOPqSB7SnoFWEE26xKkTfS"
    "YEeXVujVZQXy9CMNdvTLid27kajd5cTu3QiiS2nM7GUh7zACj9Nb7aSSzExYOHxKLfjRq0tKhb2FIG6kwY4urdCrywrk6Uca7OiX"
    "06VXI1G7SyqJvSVmn5TGzF5OTBIep7falZTMPlFK0Pv2odBc5mRPtxSUwJzmRhrs6NIKvbqsQJ5+pMGOfikl0KuRqN0tBc1ld3NT"
    "GjN7KUJx6dtjeOtTC/TpVhJ9+m249OlDSfTpKTR2dSmJPl1aoG4/UmFXv5VEn0qiT19awOxuqTC7b6G51O3hv9zDf7mH2wpm9m9p"
    "Bb36cyv40qsvYVG7P/AQEiWY2d8rpITd5/anVvBlTrpbWNTuDzyk4Tazv3f6lqc/tYIPh1tY1O4PPAilYGZ/Z4RAnW7bH1sBdaIU"
    "9s4Ii9r9gQdSSsHMXlKwp0thbj9CKsGec/qleNnTLSR6SG57kgLm9mEF5ImUUjAzwqJ2hET3VLzs6RYSPSTsSQpeHm4rmNnLSGZ2"
    "Oandj9Iws784vczsVhpHGm4zswLy9GEF5Ok2kpkRFrWjNA5Pp5de3UrjSAM7MpKXh9sKZvYSLLt3zlm3t9KItl9aCvQuDLtOlMYW"
    "PG2Cyxa9rYA83UYyM8KidpTG4TJCoE5h2HWiNLZA3ju1wM4uD7cVzOzbyeyMmX0ojcMleZouI9m7T2FRO0pjuiSXvRECh7cVkCdC"
    "aGHuirCoHaVxuIxk7z6FRZ4oDXtTt9KYu7o83FYws2+nl5l9KI3DZQW3uDGSmREWtaM0DpeRUDtK4/C2AvJEaRxuYVE7SuNwGcnM"
    "CIs8URpmdiuNuN0ebiuY2bcUmkve24fSOFxWcIsbI5kZYVE7SuNwCWFQO0rj8LYC9kYIHG5hUTtK43AZycwIizxRGnlvtxBK2tvs"
    "PNxWMLMfabgcfimNw2UQAnFjJLu6DGpHaRyeTmpHaRzeVvAyXbJbWNSO0jhcRjK7yyBPlMbhW0mJ2Xm4rWBmP9JwOfxSGoeX0ogb"
    "I/lRO0rj8HRSO0rj8LaCpx39CIvaURqHy0h+5InSOLyt4PZwW8HMvg3JZc7uQ2kcXkojboxkVy97ozQOTye1ozQObyugT6YfYVE7"
    "SuNwGcnsXvZGaRzeEqnwcFvBzL6dbIGZfSgliGyX0ogbI5nZh9I4PJ3UjtI4vK2APH0Ki9pRGofLSGb2oTQOv5TGw20FM/t2UvtI"
    "ZvbLSKgdpRE3RjKzD6VxeDqpHaVxeFsBefoUFrWjNA6XkczsQ2kcfimNR3NJwZ5UlxLK7nOn0Pac04cUGnMjJOJGCm1Pt93dSuPw"
    "dFI7SuPwtgLy9Cks5q6UxuGSQtvTS98ojcNLSm4p8Di9xU1oycwuJ7X7ZRHcNnm7reC2Z3UrjcPTSe0ojcPbCsjTpzAC4lYah6dF"
    "wKZOlMbhJTWC236c3uJWGmZ2OandX7WCXv1IAzt6KY3D00ntKI3D2wrI029pELfSOHxrxY5eSuPwtgLyfBRvnZCwp0thbn+VAvb0"
    "IySX7iUkuqfC3AiJ7q24zO23kOiERPctBbqXFOjeisvcD//lHqeXXv2tsHyr3R9bwdvh1kqv/sjj9NKrvxWWb7X7Yyt4O9xa6dUf"
    "ebiMRK9eTnH7Z9LA4X92OvydFfL0FJbDrZVe3U6HfyGNHf2Dh8tI9OrlFLd/Jg0c/menw99ZIU9PYTncWunV7XT4F9LY0T94uIxE"
    "r15O5ElpM3srjR39g9NLr26nfyJPn1bI01NYiJtWenU7EbdLaV7idimNHZ2Im1a8PFxGolcvJ/KktJm9lcaO/sHppVe30z+Rp08r"
    "5OkpLMRNK726nYjbpTQvcbuUxo5OxE0rXh4uI9Grbyvk2QozeyuNHd1WoHaXsBxurTAzTsRNKy47YgVq97ZCni5p4HBrpVe3E3HT"
    "CjO7rZAnpbkdbiPRq9vDZSR69W2FPFthZm+lsaPbCtTuEpbDrRVmxom4acVlR6xA7d5WyNMlDRxurfTqdiJuWmFmtxXypDS3w20k"
    "enV7uIxEr76t4NKrT6Wxo9sKLr0SFuKmFWbGibhdSpvZbQVq97aCt8OtlV7dTsRNK8yME3lSGjv61goz4+EyEr36toJLrz6Vxo5u"
    "K7j0SliIm1aYGSfidiltZrcVqN3bCt4Ot1Z6dTsRN60wM07kSWns6FsrzIyHy0j06tsKLr36VBo7ehmJXgkLcXs7EbdLaTO7rUDt"
    "3lagdp9a6dXtRNy0wszeSmNHb6W5PVxGolffVnDp1afS2NHLSPRKWIjb24m4XUqb2W0Fave2ArX71EqvbifiphVm9lYaO3orze3h"
    "MhK9+rZCnq306rc0dvQyEr0SlsMvJ+J2KW1mtxWo3dsKefqtlV7dTsRNK8zsrTR29FtYHi4j0atvK+TZSq9+S2NHLyPRK2E5/HIi"
    "bpfSZnZbgdq9rZCn31rp1e1E3LTCzN5KY0e/heVx+jaz24k8KW1mn9LwVrtLWG55ttKr24m4XUqb2W0Fave2Qp5+a4WZcSJul9LY"
    "0Slul9LY0ctI9JoGHqdvM7udyJPSZvYpDW+1u4TllmcrvbqdiNultJndVqB2byvk6bdWmBkn4nYpjR2d4nYpjR29jESvaeBxetsR"
    "p7hdSmNHf3G65eltBWr3ciJul9JmdluB2r2tkKe/Km1mnIjbUxpucbuUxo6+teKyo8fpbUec4nYpjR39xemWp7cVqN3LibhdSpvZ"
    "bQVq97ZCnv6qtJlxIm5PabjF7VIaO/rWisuOHv7LPfyXe1AaevVvaMWXXv25FXzJ0y0sl8MfeFAaevVvaMWXXv25FXzJ0y0sl8Mf"
    "eFAaevW3hhBkT3v7cyvs6ikFGWG5HP7Ag9LQq791uhz+91aY2dNIOyIsl8MfeBCSpldfQtE3StjdW0qKOXW/lOBL326h+EfVLyvM"
    "7GmkHRGWy+HSzOmpBF/6Rgm+9K359nA79epLGuLGSDt6awW1+4sVfMnTLSz/6PDLCjN7GmlHhOVyuJx69bSCL3FjJF9qD8u3h9up"
    "V19CMzda2NFbK6gdIWBvhKCFvV2SPN3CsjdCwN4IweGXFWZ2SVrYEWG5HC6nXhGCYW+XJG6MhOnSZ1gu0+XhdurV2wpuO3prBbWj"
    "NPSK0jAz0pCnW1hqRyuoHaU5/LLCzAgLOyIsl8Pl1CtKQ69IQ9wYCXm6heVyuDzcTr16WwHbzt5aQe0oRdC7rTTMijDk6RaW2tEK"
    "akdpDr+sMCvCsO2MsFwOl1OvKA2zIjVxYyTk6RaGQLR5uJ169bYC8vSpFdTu6XSJuzRvebqFpXa0gtpRmsMvK/iSp1tYLofLqVeU"
    "5i1ujIQ8fWkFtXu4nXr1tgLy9KkV1O7pdIm7NG95uoWldrSC2lGawy8r+JKnW1guh8upV5TmLW6MhDx9aQW1e7idevW2AvL0qRXU"
    "7ul0ibs0zOppewpL7WgFtaM0h19WmNXT9hSWy+Fy6hWlYVZP22Uk5OlbQEkebqdeva2APH1qBbV7Ol3iLg0z+xSW2tEKakdpDr+s"
    "MLNPYbkcLqdeURp69TYS8vSpFQ+3096yp9DMjRR29RZCaPaWXU6zm0LQwsw+haV2tILaUZrDLyvM7FNYLofLqVeEYOjV20jI06dW"
    "PNxOl7jd0hA3RtrRL6fL4XLq1dMKM/sUltrRCmpHaQ6/rDCzT2G5HC6nXj2t0Ku3kZCnT614FJfm0veeSEPcGGl3c3trLtslmNNT"
    "CTb29CUstaMV1I7SHH5ZYWa/NCk4XE69eirBxp6eRkKevqSAwOP01ivSEDdGQp7+4nQ5vKWBmX0JS+1oBbWjNIdfVpjZX7TicDn1"
    "6ktpmNnTSMjTl1ZQu8fwNjtSUTdaQJ/+Yrhkb6lgV19C0ydKwuwoSfZLC7v6i5Jkl2F2X1LBrp5aQJ++lITZPfyXe/gv93AbyeHf"
    "c+LwvzCSb4cvI5En0mBm/4EHabgc/g2t+Hb4QyN569VtJPJEGszsP/BYgtvh76Qm+HH4QyP5sKPLSOTpEtj+E4/Ty+HvpOESXZq6"
    "/aGRMKvLwq6TkcjTn3gELBxeFqJLS5jVt5YCs26XYPuRmjq9pMaspKZOt2VWn0aizu0SWiJPRiJPpMasvixELwsRy6wuy6VOD5cT"
    "h5dUktknI9H79m0ket/+YgjB3rJbGsw8hGBvuSTJ3vr0YyR2724jkScjkSfSYGa3kiRMs7ucOEqSzEwqyWVvD5cThy8jkScjkadv"
    "IwTy9FsqycvsE2mwd/IyQ/CUpx8jYWa3kciTkcgTaTCzywjBy94ZJ2YImFkpwdPsD5cThy8pFXP2loI6t28n6tyU4KlvSkr6Rijy"
    "RBouFc2lb0pgzu7bSJjZpaWgzs1I5Ik0mNnlREXDgdNtd/Y0En1jz4fLicO3NNiz2L17O3G4jOQpT0ZS50Ya5uykwe4dp0uejISZ"
    "fRsJe7oUHC4jkSfSYGZCKXbvKCU4cLr0Od1GIk+3h8uJw7eQmtvMPpw4XEbylCcj6W4hMTNpMLPLiTo3qSRm9m0kb7t3l5HIE2kw"
    "M2mwp1sKDpwueXoaiblVPFxOHN5Ol9mnDyfq3KRECuSplOBtZtJgZpcTh1sazOzbSL51c7qNRJ5Ig5lJw4cDJ3rfnlJJLtWeD5cT"
    "h7fTpc/pQ0uBPD2NRJ5Ol7m97E4azOxy4nBLg5l9G4m53aovI5En0mBm0mBPXypOHL6FIgXs/nA5cfgWUnOb2aeR6HO6jUSeWgrk"
    "6S0NZnY5cbilwcy+jUSf06eRyBNpMDNpMLMPJw4fSlDwcDlx+JaGvSWzTx9GwuzTZSTyZCTy9JYGM7ucONzSYGbfRsLMPo1EnkiD"
    "mUklmX16O3H4EmyXE4+EgYzpEkqRpxN5bz9KCS7ZpSTypJSgT097Iw1mdjlxuKXBzL6NhJl9GoneN2kws8uJ7La3y4nDl6G7DDxO"
    "bwdCS3adVkCe3lIL3nadSC34kifSYGaXE4dbGszs20iY2aeRMDNpMLPLCr7MunHi8GUkX/bj9HbgxOEyEnVuHxaCyyZ6WQRsdSIN"
    "ZnY5cbilwcy+jYSZfWpJMDNpMLNbSwI2Ik4cvrQkYJv1sbxFLESXljCrv1gudXpLjVk9pcasLgvRLTVm9a0lzOovlllJjVl9WYhe"
    "FqK3hYiH/3IP/+UeGAl5+jekgZn9L5TmS6++lGZHhEWe/hOPQQjI098piYS9yf5Uab7sbVe30uzoktjbf+JxesnT/yyEkuztkojb"
    "HyqN6RaCXfdGaXb0Rx6nlzz9z9LAzEiDuP2h0uzoVhp6RWl29EceGAl5ekqDw+V0OfxIg7j9gxUQt6dW7MgKandbQa8+lWZHLyPp"
    "FaXZEWGRpy8jIU9PpXEwkpmRBmbmgZGQp6c0OFxO+py+tZCI21+UlFzmrm6t2DGVxN52TSWxd93eSrOjl5H0itLsiLDI01MqIWDu"
    "6lYaRyohmJkhYe8+HxgJeXoKLYRshjD27tOPk72z30IoabqkXfdGK3ZNgYRdUyBR9/SjNDu6hdCCXlGaHREWebqlVKZLCHlvlEZO"
    "ZTJ7MpgufT4wEvL0pRUzt2JmH05q9xdpEDdWUDtaQe3CcqtdWNjRj9Ls6FYaekVpdkRY5Ol2kidG0itKc8sTIyFPtwdGQp6+tOJp"
    "Zh9OandbwWVmVlC72wpqRyt2dGvFjggLO/pRmrcd3UqzI8IiT4ykV7eR9IrS0KvbSMjT7YGRkKcvIQyXuqcPJ7W7reAyMyvY2y1R"
    "O1qxo1srdnRJJdnRj9L8qHu6lWZHhEWeGMnebiHoFaWR93ZLBlN2eWAk5OnH6XL45aR2txaEYGZWwPTSJ1qxo1srdnQrzY5+lIa9"
    "3er2VJodERZ5YiRPe4egV5TG4duQyOz9wEjI04/T5fDLSe2+tGJmVkDc3lqxo1srdnQrzY5+lIZefSrNjgiLPDGSp15H0itK4/Aj"
    "Dbc8HxgJefrSitvhl9Mlbk+tmJkV1O5TK3Z0a8WObqXZ0Y/S7Oi30uyIsMgTI+nVp9I4/HK6PDAS8vSlFbuWNGf3IaXCnN2tFTOT"
    "Qtu7bm+t2NGtFTu6lWZHP0qzo99KsyPCIk+MZO+6vZXG4ZeUCo9ESeiTiRBKmrO3Yte9vYUWgl3dSjIz0qBut+nWih3dWrGjW2l2"
    "9KM0O/qtNPLewiJPlJTo0226lcbhJXlJZXqcfsyMNDhoBbX71Iq3mZGGLzu6tWJHt1bs6FaaHf0ozY5+Kw29Cos83U7fDrfSOLyM"
    "5Euej9OPmZEGh8tJ7X5bwVPtfqzgsqNbK3Z0a8WObqXZ0Y/S7OivRtKrsMjTl5HcDrfSOHw73WbmkbxNhMB0Seztt+Rlbz+Sp+kW"
    "AtMtBKZbCEw/QmD6q8TeJPb2JXmabiEwfUueJg//5R7+yz08rZCnf09pvfpfKc3Tjr6tQJ60Qq/+Aw8SWsjT30luqcyO6Q+FkIqn"
    "XTHdViBPSmJ2/4EHp1ue/s5IfszsD5Xm0+G2Ann6Aw9Otzz9z0oKgdm9TH+oNGZ3CQ2H2wrk6Q88ON3y9D8byaV2/0ulMbNLWDjc"
    "ViBPf+DhsgJ5eiqNmUmDHb2NRO3+6nSL21Mr9JqGy444EbcPpTGzlxMHViBPWqFXT2G5HV5GypNW6JU03A4PlxXI01MqIcxMGuzo"
    "baSpT78lw8Tce7u0wuypuOyKgbqnt9KY2ctpyliBPGmFXl1CCM1EN91G6pOS9p49hFRMdA+XFcjTl9JmJg129DZSnv7qxIEV8nRp"
    "xT8Ttx+lMbOX0+G2AnnSCr26pMGOOMXtMpKnXkmDHXF6uKxAnr6UtjfSrqa3kfJ0ScVldrdTNrHC1CetMLtLaMhuQ9x+lMbesxOa"
    "5HBbgTwJoaReXdLY1cRpqpuR6JO9SYMdkTxcViBPX0rztKNPI+XpUprLzG6nw20F8qQVenVJgx3dVojbj9JcZiYsHG4rkKdLab26"
    "pLGj24m4GYnaPaXBjm4PlxXI0480mNlvI+XpSxozE5ZPedIKvbqkwY5uK5CnL6V5O7ysQJ60Qq+k4VPcjETtvqThdni4rECefqTB"
    "zH4bqc+9PaUxM2G5TS990gq9uqTBjm4rkKcvpbG3p129rECelBRCr6SB6VvdjETtvoQmIXu4rECefqTBzH4bido9pTEzYbkd3lqh"
    "V5c02NFtBfL0pTRm9tsK5OlSWq+kwY4+jUTtfoTl9nBZgTx9SUVi7119+j/UwbGVLLfZKMCacyYUGAgFBkKBgVBgIBQYCKWNL5Q2"
    "XvfM3N29FPVTop7DqlXo00tZu6Kkodq+jcbsLmUR2e1I1O2jDXb1uyNRt0sbs5NSGpH9tAp9+lZIw8PlSNTtow0vkf20Cn16KWtX"
    "t9PTT6Mxu0tZRHY7EnX7aINd/e5I1O3SxuwuZUX20yr06XenB6e3ur20sStlEdlPq/iyq9vpluNIdbuMxuwuZRHZ7UjU7aMNdvW7"
    "I1E3ozG7S1luT6ccLqvQp5eydiUdeBTL29wRpFTarpRFZD+1kpKXiD3dFooeI9XtMhqzu5RFZLcjUbePNtjV70ZKqW5aSWl2lzQU"
    "VEsOl1Xo00tpsUnD9jh965M22JWyiOx3o3nZ1bfTrW6X0ZjdpSwiux2Jun20wa7+aJW6XdqY3Us6vOVwWYU+fZTl9vQovkWQEjYp"
    "YftdSt62b8UtwiUlIlxSwnYriPCRErY/KiJcUorwVrxtt4IIHym5bQ//cA+XdKjbf+JIePqfrOLj6aMsOdxGi+y/8XBJh7r9J46E"
    "p//JKj6ePsqSw220yP4bj9NL3f5SWT769PetghxtoE+3suTwtzxOL3X7S2X56NPftwpytIE+3cqSw9/ycEmHuv2FVXb1/8Mqu3o5"
    "ERllyeFvebikQ93+wiq7+v9hlV29nIiMsuTwtzxc0qFuH6c+scquvqQDu/oXR/IWGWX5E7v6aZVdvZyIjLLkcBstspcjeYuMsnz0"
    "iVXcZvdwSYe6fZz6xCq7+pIO7OpfHMlbZJTlT+zqp1V29XIiMsqSw220yF6O5C0yyvLRJ1Zxm93DJR3q9mU0t119SQd2RRtukVGW"
    "HG6jRUZZmB2joW6sghy+rLIr2kCfbmXJ4TZaZJQlh9tokVEWZndLB3b18nBJh7p9Gc1tV1/SgV3RhltklCWH22iRURZmx2ioG6sg"
    "hy+r7Io20KdbWXK4jRYZZcnhNlpklIXZ3dKBXb08XNKhbl9GQ91+SAd29TFaZJTlS2SUhdkxGurGKsjhyyo+nj7KksNttMgoy5fI"
    "KAuz+1gFOfBwSYe6fRkNdfshHdjVx2iRUZYvkVEWZsdoqBurIIcvq/h4+ihLDrfRIqMsXyKjLMzuYxXkwMMlHer2ZTTU7Xer7Opj"
    "tMgoSw4/lIXZMRrqxirI4csqu/pdWXK4jRYZZcnhh7Iwu5+OhIdLOtTty2io2+9W2dXHaJFRlhx+KAuzYzTUjVWQw5dVdvW7suRw"
    "Gy0yypLDD2Vhdj8dCQ+XdKjbx6lPrLKrn1ZBDrfRIqMszO5LWZgdo6FurIIcvqyyq9+VJYfbaJFRFmb3pSzM7qcj4eGSDnX7OPWJ"
    "VXb10yrI4TZaZJSF2X0pC7NjNNSNVZDDl1V29buy5HAbLTLKwuy+lIXZ/XQkPE7fcuDUJ1bZ1e/K8tGnjyN5i4yyMDtGQ91YBTl8"
    "WWVXvysLs2O0yF6O5C0yysLsbunwMbvH6VsOnPrEKrv6XVk++vRxJG+RURZmx2ioG6sghy+r7Op3ZWF2jBbZy5G8RUZZmN0tHT5m"
    "9/AP9/AP93BbxdN/5sTT/2AVvzx9rELdKItd/RceRnN7+munb09/0yq+ze62CnWjLHb1X3gcycvTXykj+fb0N63ih8guq1C3SyL8"
    "Nx6nt6e/UpZLdhl6+JtWwe4uB54uq1C3v+ORcODp7UB2GQW7+2WUxO7hkoQvZejbWxnsThn6djvs7qdV6Dtc0iiib1ahbpTB7j4O"
    "ZG8HMg67uxwufXu4nHh6K63Yc7MKc4ZfVmHO8AdLSiJUt7LYdUlJhNqKIsLcvqxCzOm2CnWzCnWjLHZ1a0XBtqfLiWcril0prbhE"
    "eLicePpYhbpZRY3wy0qJuv2utOJtz42yiCjedkpe6vZlFeYMt1Wom1WoG2Wxq8tKyVtExYmdEnbVWvKy58PlxNNHKc3ec5Tk6duJ"
    "voOWvMyglWIGUlM3ynLpGC4zaIm6fVmFvafLKEnfwSrUjbLY1eVEx8ATp1tMYluFGYj9cDnx9EtZxG5iTt9OPF1W8VI3q+g7UJa9"
    "J2URc+JE38Eq7D39sgpiuzQ8XVahbpTFrqTWxJxoLXnidJl7u61C3W4PlxNPv6Qy3Hb1w4mnyype6mYV0y0VdqUsdnU58XQprbCr"
    "X1bxLeZ0WYW6URa7Uhax3UryxOlSt5dV2KHj4XLi6dvpsuf2w4m+g1Ioibq1lnzblbLY1eXE060sdvXLKn6Z9nZbhbpRFrtSlh+e"
    "ODFneCmtuHSxHy4nnr6dLnNvP4ySqNvLKtRtlMQObzEpi11dTjzdymJXv6zCDrfuYxXqRlnsSlnE9tFx4umX1JSEmA+XE0+/pDLc"
    "dvXTKsy93Vahblahbt/KYleXE0+3stjVL6tQt9+sQt0oi10pi139cOLph5Y0PFxOPP1SlgjFntsPq2DP7bIKdbMKdftWFru6nHi6"
    "lcWuflmFOcNPq1A3ymJXSiv23L6dePpIwuXEo2ChYruk1tTtRI3wpbXkUl1aoW5aS+b2EoGy2NXlxNOtLHb1yyrY1U+rMGdQFru6"
    "nKhuES4nnj6W6bLwOH17Io0i+nYk1O1bGcm36BtlJB91oyx2dTnxdCuLXf2yCnb18HAzfwAAIABJREFU0yrYlbLY1eVIPnYPnHj6"
    "WMVHPE7fnjjxdFmFvsMPB5JLkL0dJIS+URa7upx4upXFrn5ZBbv6aRTJrpTFrm6jSC5Bxomnj1EkhN0fh28ZB7LLKNjdHxwufftW"
    "Brt7KYPdXQ5ktzLY3S+jYHd/cNidMtjdx+HSt9uB7NuBjId/uId/uIfbSd3+A2W59elva8OXur20ITLSgcj+Cw+lUajbX2mF4hZR"
    "/V1t+LKju7Uhsktx2f4Lj1KaW93+bym1ggiklMPf1AYikJLoEWhDZH/L4/RWt/9bWW59YrQc/qY2MDvawOxoQ2R/y8PtpG4vZfF0"
    "OV2evpRFDv/iSMjhZTSRORJy4Ehm91MbmN1tFbOjDZHd2hDZ2yqo20sbPFnFrm6r2JWH20ndXsri6XIy9/bLSIUc/qCV4rKju43G"
    "prjs6KUVInr41gZmd1vF7GhDZLc2RHYrLSXs6G5t8CwtJbuySEkED7eTur2kkVK1OenTl9Mlh9+k1Mp2KdEjMJrbVhC9JAo9ti9t"
    "YHa3VcyONkR2a0Nkl1LadkmpRqANammbPTnZXh5uJ3X7GM2unPTpy+mSw2/KIgeOpE+M5pYdbn1KByL70gZmd1vF7GhDZLc2RHY5"
    "qRurmB1tuNXtdlK328PtpG4fo3nZ1Q8nfbodyWVXlEUOHEmfGA19YjSR3doQ2Zc2fIvs1obIbm2I7HLO7u2cHW1gdm8ndbs93E7q"
    "9pHScumx/XDSp1tJA7syUmG7FPrEaKJHYDSR3doQ2Zc2fOmx3doQ2a0NkWmlRHgrs6MNaoS3k82ePNxO6vbldHn6zcnc2y2NlOzK"
    "kbAVtz4xmshuo4ns1obIvrSBCLceXtoQ2a0NkVnFt9nRBk+/LFKyZ8TD7aRuX06Xp9+cLjm8jGZXjoScllufGE1kt9FEdmtDZF/a"
    "wOx+akNktzZEZhXfZkcbPP2wCup+uJ3U7WM0L7v6qSxyeBnNrhwJOXwbTWS30UR2a0NkX9rA7H5qQ2S3NkRmFdTtWxs8/a4sHm4n"
    "dfsYTfRW7Oqnsth7uo1mV0oa5PBtNJHdRhPZrQ2RfWkDs/upDZHd2hCZkgZ1+9YGT78ri0dxWczNRkqt7D1bKdEjfEsjJdHdWrEr"
    "yqKHlwiMJrLbaCK7tSGyL21gdj+1QY1AGyK7nMztJQJt8PRWvJXG4/RlV5TF0+WkTz+N5tuuKMuXPjGayG6jiezWhsi+tIHZ/dQG"
    "ZkcbIrucvsyONnh6W8WXx+nLriiLp8vp8vS7stz69OVILpHdRhPZbTSR3doQ2Zc2MLvfrWJ2tCGyt1Xcnm5t8PTL6bYrj+LbRkps"
    "l+Ky/S4ltwhfipftlhLbLSW2W0psX1JChN8VIpAS21vxst1SYvuleNk8/MM9/MM9vBypbv+ZNmb3P2nDS2S/HIm6GY3Z/RceFIxU"
    "t7+WEqXtie1va8NLdGy3I1E3rbCn/8KD061uf200H7v629rw7el2JOr2Nzw43er2V1pJaU9v29/Wxp5e0rBVHIm6/Q0PTre6/ZVV"
    "6NP/rI1dvZ144kjU7W94uByJur20wa4u6Yjs2yr06V+dbnV7aWP2slwi43TL4Yc2dvV24okjUbdLG7N7SYfb09sq9Dkas1OWt4fL"
    "kajbS2kp7WmnlEZk31ahT78raCjmjiClVvYszSU6llsOP7Sxq7cTTxyJul3amN0lpTRsTNttFeZuJWLPlEqzUTxcjkTdPtpg17KI"
    "7Nsq9Ol3J544EnUzmj+Tww9t7OrtxBNHom6XNmZ3KYvIOOVwWcXL7JRFZJweLkeibh9tEKFEt31bZe4ISvMSHadqoxipblJqZU+X"
    "NFDdlq2HL21E7EkaimrjSNTt0sbsLmVFt3HaerAKcxNBWURG8XA5EnX7aMNLZD+tUrdLG14i4/T0tkrdLm3M7lIWkd2ORN2+tMGu"
    "pANPtyNRt0sbs7uUFdntRA5WoU8vZRHZ7eFyJOr2pSyXyH5ahT69lEVknL7V7dLG7C5lEdntSNTtSxt+eXo7EnW7tDG7S1m+5WAV"
    "+vRRltvTw+VI1O1LWS6R/bQKfXopi8g4sb3N7dLG7C5lEdntSNTtSxsRXqJ7OxJ1u7Qxu0tZ2N56sAp9+kgDRfVwORJ1+1KWS2Q/"
    "rUKfXsoiMk48/dTG7C5lEdntSNTtSxu7+t2RqNuljdldyiKyb6vQpx/SgYfLkajbR2mKS2Q/rUKfXsoiMk48/dTG7C5lEdntSNTt"
    "Sxu7+t2RqNuljdldyopu+7YKffqppOHhciTq9tGGl8h+WoU+vZRFZJx4+qmN2V3KIrLbkajblzZ29bsjUbdLG7O7lBXZT6vQp9+d"
    "Hpze6vbSxq6URWQ/reKHyDjdchypbpfRmN2lLCK7HYm6fWljV787EnW7tDG7S1luT6ccLqvQp5eyiJwOPIrlbe4IUiptV9JQIvup"
    "FVJyiSA6FooeI9Xt0kpKs7uURWS3I1G3L23s6ncjpVS3Sxuzu6SBolpyuKxCn15KU6KnYXucvvVJG+zqko7I/mg0l119O93q9tLG"
    "7C5lEdntSNTtSxu7+qNV6nZpY3Yf6XDL4bIKffooy+3pUXyLICVst2L7o5Tctm/FLcJLShEuKWG7FUT4kpLtj4oIl5Qi/FLctltB"
    "hI+U3LaHf7gHo6FP/4mysKv/wSq+zO6WDkRGWdjVf+7BaOjTf6Is7Op/sIovs7ulA5FRFnb1n3ucXvr0F9LhWw5/1yrIgSPhiXQg"
    "sr/jcXrp019Ih285/F2rIAeOhCfSgcj+jgejoU9/IR3q9r9bBTnc2vBEOhDZ3/FgNPTpL6RD3f53qyCHWxueSAci+zsejIY+fayy"
    "K9qQw5fRULffteGjT7ey/InIvq2CHG5teCIdiIyysCva8NGnWzp87OpIPh6Mhj59rLIr2pDDl9FQt9+14aNPt7L8ici+rYIcbm14"
    "Ih2IjLKwK9rw0adbOnzs6kg+HoyGPn2s4ja7n0ZD3VjFbXa04elltMgoC7uiDcyO0SL7tgpy4Eh4Ih2IjLKwK9qQw220yEgHdvVy"
    "pNm9PBgNffpYxW12P42GurGK2+xow9PLaJFRFnZFG5gdo0X2bRXkwJHwRDoQGWVhV7Qhh9tokZEO7OrlSLN7eTAa+vSlLMzup9FQ"
    "t1tZmN2R/BAZZanbrQ053EaL7Nsqvszulg5ERlnYFW34EhnpULcvbWB2D0ZDn76Uhdn9NBrqdisLszuSHyKjLHW7tSGH22iRfVvF"
    "l9nd0oHIKAu7og1fIiMd6valDczuwWjo08cqbrP7aTTU7eNIszsSnn4qS91ubcjhNlpk31ZBDj+kA5FRFnZFG3L4IR3q9rs2PBgN"
    "ffpYxW12P42Gun0caXZHwtNPZanbrQ053EaL7NsqyOGHdCAyysKuaEMOP6RD3X7XhgejoU8fq+zqSMjhh3RgV5SF2dGGp5/KUrdb"
    "G3K4jRbZt1WQw+9Gi4yysCvakMMP6VC337XhwWjo08cquzoScvghHdgVZWF2tOHpp7LU7daGHG6jRfZtFeTwu9Eioyzsijbk8EM6"
    "1O13bXicPiKjLOyKNuTwu1V85PBxeunTrSx1u7Uhh9tokX1bBTn8brTIKAu7ejmSW59u6VC3jyP5eJw+IqMs7Io25PC7VXzk8HF6"
    "6dOtLHW7tSGH22iRfVsFOfxutMgoC7t6OZJbn27pULePI/l4+Id7+Id7+JvKEpmTHP5zR6rbf6msXf07D6ykb3+qNbfd/VFZInOS"
    "w1tru/sLR6rbb1Zy69sfjdI3yki7+nceRipsc/sTo7lFRPe7skTmJIe3Nmb3F45Ut9+cXiLm9rtV+kRqbVf/zqMNU0n69CdGE1sq"
    "9Ok3ZYnMSQ5vbczuLxypbr85mZRkz+03q/TpklpM/85j0WOUNGdIiU1hexst5pRGEdmtEOFSlsic5PDWxuw+io2URLgVtsuR6iYl"
    "Ed5Ou4fWktldCtulGGluESmxvRQiXFKKoLAfXlbRpzbsKh08vY02O8oSGclK+g6UJTInOby1MbuPI+VgNLMjpUUWHKluRjO7t1MO"
    "jGZ2UlpkwZHcZm/Dri7JSmoE2thdWuSHl1X0qQ27SgdPb6PNjrJExpHc+qQskTnJ4a2N2X0cKQejmZ2yvDw5Ut1GM7uPUw6MZnZl"
    "eXlyJLfZ27Cry+mlT9rw8fCyij5pw67p8PQx2uwoS2SOpO5V9ElZInOSw1sbs/s4Ug5GM7uyiJyOHBypbqPN7pdTDoxm9rKIeiCH"
    "VfTp0sauOMlxJH3Sho+Hl1XmDFIZUVeq28doMae0kshW0ac0SsypLJE5yeGtjdl9HCkHo5ldWaKGsnGkultLs/vlFDWMkuaMNkSN"
    "YslhFX2ijLQrq6hbWin61oY9WTzcWkt9upQVUTz9MprYUhFzOsnBaGZXlsic5PDWxuw+jpSD0cyuLJG9HWlHSXtuv5zsUJI+tSEy"
    "TnPGKvpEG3aVDp5YRZ/asCtteLiUkfbcLmkUZvfLaF5id05yMJrZlSUyJzm8tTG7jyPlYDSzKyvm9HYkl9l9Od122FsbMSdOcqyi"
    "T7RhV+ngiVX0qQ27kg4PpJWib7dUhujbL6NFSElknORgNLMrS2ROcnhrY3YfR8rBaGZXVtTwdiSXOcMvpwjmdmkjauAkxyr6RBt2"
    "lQ6eWEWf2rAr6fDAkdTtpSyXp19Gm11ZIuMkB6OZXVkic5LDWxuz+zhS3YxmdmWJ7O1IbrP75ZTDRxsi4yTHKvpEG3aVDp5YRZ/a"
    "sCvp8OBI6vbShqiHp19Gm52yROYkB6OZXVki45TDWxuz+ziSuo1mdmWJ7O1I+hzN7D5OOXy0ITJOOVilT7RhV+ngiVX0qQ27kg4P"
    "R6JuL23s7hDZx2izU5bIpEPUGM3slCUyTlHDSxtm93YkQWJ2ZbGrI+NIfRrN7D5OOXy0we5LkoNVYk7asCvpEDVW0Sdt2JV0eKyC"
    "jbmVkXbVhl29jTY7qQy7UkbaUtInqTWzc5LDSxsiXCpHcpmpzC6VwVZ25Uh1S63FnN5OOXyk1tiFurGKiD3bsCvKshX6pA27kg6P"
    "08eeu43oWzp4ehttdpQlMpqW7B0bqbXItCGHlza8PWmDGbu12UklNbrJkeqmtLKrt1MOv6SSGt10KSMxext2dWkGM3bQhl1Jh8fy"
    "y9yl7UkaVG+tzI00RHcbydxe0oiOkXp4Kc1LdIykh1bmdklDdJeReqC0Pb2N1MO3NET31gpzl2ZPLyPp4VKaPbE8/MM9/MM9rILZ"
    "/alVXCL7F23IwZF29XGa3f9tNDn8lA63Pv2LY063067+nUdrdrP39GdWMaU07fC7NuTgSLv6OM3u/zaaHH5Khx3a3qY/OOZ0G2L6"
    "dx6n2U8i+zOrRNYGffpdG3JwpF19nGb3fxtNDj+lw+yORA6/O+b0lx5JSKNEJi1zoozsY5XIlKVPv2tDDo60q4/T7N7SqoFRZD+N"
    "JgeG7i0dZielpU8/pJWEGv5MWjW8PNxWiUxqbc+tlPb0sUpk0qFPpOK2A23IwZF29XGa3Vs6cmA0T5eSsIPR5KClmN7SYXaUpU/N"
    "S2ypDJccNLFdmtsOpKN7e7itEtnlSLsazdPHKpFJhz5RllvdaEMOjrSrj9Ps3tKRA6N5uqyC2RlNDs66faTD7ChLn04vkbXhloPT"
    "ri6n2+xIh4+H2yqRXY606yq7h49VIpMOfTJKyjhid9qQgyPt6uM0u7d05MBonjjSnAhGk6OMVLePdJid1lLdnHY3SmTKMqfAaVfK"
    "SH2zRCUd5mQUD7dVIruMoq/Y3S+rRCcNfTJKVJxmpw05ONKuPk6ze0tHDozmKaW19/Qymh5p7Ll9pMOetCJHSivm1FqqEenQp9tp"
    "V8raPVglMunQJ6N5uK0S2W00+vRlFW99MlJ1Oc1OG3JwpF19nGb3lo4cGM1TG+r2Nprb05d0+MhRlrrRhrrToU+3066U9XRZJTLp"
    "0Cejebissnu4jUafvqzipUZYKarLaXbakIMj7erjNLu3dOTAaJ7aULe30dyevqTDbW5bWepGG+pOhz7dTrsaJT1dVolMOvTJaB6k"
    "tGJOL6PRpy+r2FKSgyPt6nKanTbk4Ei7+jjN7i0dNYLRPLWhbm+judUIH+kQwdwoS91oQ93p0KfbaVereLqsEpl06JPRPGhD3d5G"
    "o09fVomsDTk40q4up9lpQw6OtKuP0+ze0qFPRvPUhrq9jealbh/pMLu3stSNNtSdDn26nXa1iqfLKpFJhz4ZzUNrqUZ4GUVfsbtf"
    "VokslbHnVlqKitPstCEHR9rVx2l2b+nQp5WSp5TW3tPLaHqkoW4f6TC7t5RWzEkb6laG3V1Ou0qt7R6sEpl06JPRPNIoskuQlqir"
    "7B4+VolMOvTJaDKO2J025OBIu/o47e4SpMOcDjxxmhPBaHKUkfoOb+kwu19Ou1NG1OBIUQOnXSlL3yxRSYc+Gc3j9JEjHfpkNE8f"
    "q0QmHfpkNC91ow05ONKuPk4vkUmHjydOt9kZTQ5Ou3pLh9n9cnqJ7HIkcnDalbK8zI506JPRPE4fOdKhT0bz9LFKZLRmTiUZ6DuQ"
    "ythzKy3t7u30EplUhphK8URTCrMzmhycdvWWDrP7pUmNPbdLaUUOTruSipaYM5AOfTKax+GjRlrmZBTZx0qyyyGqy4HsJS1zMors"
    "7fAS1eUQ1SiyW2vMSWtqcNjdW1rm9K0MdvfSmhocorqtRA2XtMzJKB7+4R7+4R7+4R7aENmfW8VLn/7FOTtGy+EtHX36C2WJ7Kc2"
    "vOzqXxwyyuLp33loQ2R/bhUvffoX5+wYLYe3dPTpL5Qlsp/a8LKrf3HIKIunf+dxzi4ds/szq5hdOnj6o3N2jJbDWzr69BfKEtlP"
    "bYjMSd1+04bI/srjnF06ZvdnVjG7dPD0R+fsGC2Ht3T06S+UJbKf2hCZk7r9pg2R/ZWHSzrIYTS7Sgc5vKxidoz2dGsDfbqds2O0"
    "HN7S0aePVfSpLDxd2rAryhKZI+nTSxsio6y6XdLB0+V061NZPN1GQ91YRZ9H0ufDJR3kMJpdpYMcXlYxO0Z7urWBPt3O2TFaDm/p"
    "6NPHKvpUFp4ubdgVZYnMkfTppQ2RUVbdLung6XK69aksnm6joW6sos8j6fPhkg5y4NxVOmb3sYrZMdrT5ZxdOni6nLNjtBze0tGn"
    "j1X0qSw8rWJ2L2WJ3IZdfbQhMsqqWxsic1K3NkRGWTyRjj6VxRPpIKfFwyUd5MC5q3TM7mMVs2O0p8s5u3TwdDlnx2g5vKWjTx+r"
    "6FNZeFrF7F7KErkNu/poQ2SUVbc2ROakbm2IjLJ4Ih19Kosn0kFOi4dLOmb3UpbIvqzi48kqZsdoT5dzdoyWw1s6+vSxij6VhadV"
    "zO6lLLccfmnDR93aEBll1a0NkVEWT1bRJ1Z5soo+MdrDJR2zeylLZF9W8fFkFbNjtKfLOTtGy+EtHX36WEWfysLTKmb3UpZbDr+0"
    "4aNubYiMsurWhsgoiyer6BOrPFlFnxjtgZWyj7JE9mUVsx9Jn1jF7Bjt6XLOjtFyeEtHnz5W0aey8LRS9lGWWw6/tCGyjzZyuJRV"
    "tzZERlk8WUWfWOXJKvrEaA+slH2UJbIvq5j9SPrEKmbHaE+Xc3aMlsNbOvr0sYo+lYWnlbKPstxy+KUNkX20kcOlrLq1ITLK4skq"
    "+sQqT1bRJ0Z7aENkbyci+7KK2aWjT6xidoz2dDlnx2g5vKWjTx+r6FNZeFrF7F7KErkNu/poQ2QfbYjMSd3aEBll8WQVfWKVJ6vo"
    "E6M9tCGytxORfVnF7NLRJ1YxO0Z7upyzY7Qc3tLRp49V9KksPK1idi9lidyGXX20IbKPNkTmpG5tiIyyeLKKPrHKk1X0idEeJyJ7"
    "O3eVjtl9rGJ26eDpcpIdPF3O2TFaDm/pIIeXVfzytApyWn0qS2SOqD7aENmXI7nsijZERlk8kQ5yWjxZRZ8Y7XEisrdzV+mY3ccq"
    "ZpcOni4n2cHT5Zwdo+Xwlg5yeFnFL0+rIKfVp/L/qINjK8iNXdGip9diKDAqFBgVCowKBQZCgYFQykAoND6b7JZm9Eeap+tp76QH"
    "7J58mNODP2zhUhMwpwegCQcgG4YkHJDKCsDtdfIYjRs1kQ2juaUSC3A7eDOnB48TRuNGTW6yeRyAbBiNGwcXc2oCmvSALazgZk4P"
    "/iQbDh5bWIEmHLy5UZO3VFYAbq+Tx2jcqIlsGM0tlViA28GbOT14nDAaN2pyk83jAGTDaNw4uJhTE9CkB2xhBTdzevAn2XDw2MIK"
    "NOHgzY2avKWyAnB78R/34j/uxf9GE2KB2yz+BbdZ/EtbRvN3XvxvNCEWuM3iX3Cbxb+0ZTR/55VMcejF/08cKtQgip9pQixwm8VD"
    "vBe/4zaLH6lBhSms5memUVxEir/1OnvIhpr8/2RDLHNYwc80IRa4zeIhuwe/4zaLH5nDCjeYxc/MV/A7LyMwsZqgWsXFZHGTDbFE"
    "VaujuTiwuGhCLHCbxUN2Dz5Uo7k4i4sYVHFxmwUmiw/zqmoVk1lcHDq4qIpWR4PJ4iYGVVxUo8Fk8eJNsyaYr+CyZTRvsiEWuMEs"
    "LlvowUUTYoHbLB6ye/DhNovLloOLJsTi4jYLthx8mMfikjqLywk9uJhzWQFbRvMmG2JxcZsFW0a/eNOsCWrV3YrKat5kQyxwg1mg"
    "qNBFgSbEArdZPGT34MNtFpctB6CiUMHFbZaiMvkwj8UldRYoBl0UqIl0R8GW0VxUFLq6wS2q26X6xZtmTS5uK1JH85ANscANZsGW"
    "0cjuAZoQC9xm8ZDdgw+3WVy2HCC7Jh9us7aM5ss8FpfUWbDlANk1uZiv4LJlNCC7B5jHAjeYBVteXES8Fhe3Va6jeciGWmBGrxJc"
    "BsjuAZoQC9xm8ZDdgw+3WVy2HCC7Jh9uq1JG82UewcV0Nmw5QLIXDeYruGwZDUL2BPNY4NbMhi0vQHZNbm5cRvOQzccKSB0NyO4B"
    "mhAL3GbxkN2DD7dZXLYcILsmH25cRvNlzm0Wly0HF82aYL6Cy5bRcPbgYh4L3GZx2fICZNfk5sZlNA/ZfKyA1NGA7B6gCbHAbRYP"
    "2T34cJvFZcsBsmvy4cZlNF/m3GZx2XJw0awJ5iu4bBkNZw8u5rHAbRaXLS/YSE1ublxG85ANtcxgBaSOBmT3AE2IBW6zeMjuwYfb"
    "LC5bDpBdkw83LqP5Mo/g0rxtObho1gTzFVy2jIazBxfzWOA2i8uWF7KhJjc3LqN5yIZY5rACUkcDsnuAJsQCt1k8ZPfgw20Wly0H"
    "yK7JhxuX0XyZx+IPWw4umjXBfAWXLaPh7MHFPBa4zeKy5ZVoL4qbW5TLaB6yIZaI6QpQVCbI7gGaEAvcZvGQ3YMPt2K1i3KA7O4K"
    "bm5RoDL5MI/FH7YcIN5FgfkKLltGg4r2AvNY4DaLy5bXCT34cFuROpqHbIgFbiu4bBmN7B6gCbHAbRYP2T34cINZW+AA2VCTm9ss"
    "2HLwYR6LP2w5QHZNLuYruGwZDcjuAeaxwG0Wly2vEzqgC0SFaJMmuMmGWOBWVQ0mDUgHiInGArfoat5kd3DpAlWVWSbGAWKiHV1c"
    "3GbBlkVwM4/FH5wGpIOLalMNW0ZzcRqQKnCbxWXL6+RWE8xXcNkymjfZEAvcYBaXLfTgZh4L3GA0b7K5xeKSOgu2HFw0IRYXt1mw"
    "BQ5u5rH4wQk9+HBbAVtG8yYbYnFxm8Vlyyu59QLTKC4uq3kThwowhSguCUxuahVgCqt5E+dWwcVlNSSTizhUcDGNggQmN7UKfpDA"
    "5MM0ClxW8yYOFVxMo7gkL/7jXvzHvfjfyKYmaBKL/zNNavLvmEMs/s4LNgx+zZW3VfyVbGqCJrF4mLGKf6RJTX7kytts/j+SPbmY"
    "x+JvvVIEismvuPHWzWp+IpuaoEksHm6s4B9pUpMfpfLWzWp+Iik1uYh087deJyyHWPyCG1EuwGh+IpuaoEksHm6s4B9pUpMfpUKo"
    "ALWaH8mmJr/1OhfhRg8QowNUqeLmxiwVTCKai8PiTTY1QZNYPNxYwc2EaMBZ3MToAE1qgipV3FKJEMGE0VwcFhdxpYsOVKniTZVo"
    "3kyiMWHx8gW4dQSa1ERcexU3N2YBqYwGw2ERgGxqgiaxeLixglsqo4GTg4shRq9Ck5qIK7G4pTIL2MJoMBwWgZjxVhNzYgEqqkRX"
    "A1uG4rDixZtsYiGuvcqcWDzcmAWkMhpNbrNANjVBk1g83FjBLZXRwMksMOetJprUxJxexS2VWcAWRqPJbZa4At0VmBMLxJW3iIYt"
    "y4TL8eJNswegSS2zjuDhxiyQFEazhW4URiObmqBJLB5urOCWymjghANOKKAXmtQUs47gkcosYAujOaEQoWdLCsQCzImFmHWDCLNg"
    "C90ozBcX2fQA1KXKicWHG6vAlZ4tKT1gCz2QTU3QJBYPN1ZwS2U0cNIDTnpw06SmOSv4SGUVkMJo2fSALfRANjW5mBMLN1ZAKrNg"
    "C6PZAi8usunBRROIxZcbH6PZwsHlpAeyqQmaxOLhxgpuqYwGTg7gpAc3TaqcWHyl8jV6Cwcgmx7IpiYXc2LhxgpIZRZsYTSc8AJk"
    "04ObJsTiy43HaNjCweWkB7KpCZrE4uHGCm6pjAZODjjpwUOTt1h8pfIYDVs4ANn0QDY1uZgTCzdWAKnMYguj4YQXsKVn86YuEIsv"
    "N1iqzAK2cHA56YFsaoImsXi4sYJbKqOBkwNOqMlNk9sKPlJhNtDAFg5ANj2QTU0u5sTCjRVAKrPYwmg44QVbejY3TSAWX26skJSe"
    "DVs4uJz0QDY1QZNYPNxYwS2V0cDJAZr04KbJLRYfqazgYwsHIJseyKYmF3Ni4cYKcJUVsIXRcMKLVGZxE9dq6wg+3JhFKrUaTWpC"
    "Kj2QTU3QJBYPN1ZwU5dajRsHcNKDmyZUqPUqHqnM4kOTmpBKD2RTk4s5sXBjBaQyC7YwGk54uUEAHaDZq117FQ83ZqEujIYtBBis"
    "QDZJpa1hAAAgAElEQVQdgSa9ipsb1Vyi2UKAwQGcEEAHmvQqce1V3FKZxdcJAQYrkE1HaWBOLNS0GlSYBVsYDSe8Th49ELOamBOL"
    "hxuzIJWIxpxbLBAzaqIJsbi58ZjFFi5hHIAbbzXRpCaYE4tbKrP4cuO2AsSVLpmYEwvUhbdaDVsYDSe8Th49RL0jUJdazc2NWeAq"
    "jAYXherFRVxrIq7E4ubGYxYuSjFPZgGJArHQpCaoS63mLZVZ/MFFoXpxEVeoiTmxAFMRitXAFkbDCa/k0UucXoAaFdxMiQJcWM0l"
    "YfIQ7wVqVHAz5bEaSFaTMLmIQy9QoxegRgVvLkTxg4TJQxx6oUYFb6ZE8ebCakh48R/34j/uxf8otSa49eBfOInFv+MGo/k7L0yA"
    "xS+Z8Fj8VWpNcOvBhyqL3ziJxY9MuHXwV04VoALB33pJCjCLX0nl1rP5i9Sa4NaDD3MOfuMkFj/awq1W8xdbYvFbr5PbLH4hlY/R"
    "/Cy1Jrj14MOcg984icWPtvBx8BdbYvFbLwXE6QhwqQDTXjxSewFqVBQXUya31Jrg1oMPcw4eakwuSRRv4qwGTmKBC724bangIl6r"
    "uZj2AtRQupmgxuTNhV7cvApcKnhxEVdiQWpNSO3BI7UHoKbMAsWUSTeQWhPcevBhzsHDnIPLyQpARJxVDSexYEvX4rYlFhdNRoNi"
    "2otCk9sBmowG1IVedAPZBS4V9eK2JRak1oTUHjxSe3CRzSw4ua0AUmuCWw8+zDl4mHNwOVkBpHJZASexYEssHlticdFkNLK5jdbk"
    "doAmo4GT2ywglVvNFxdJWdUgZjVTI5pHag9AXWYhKUSw6VqQWhPcevBhzsHDnIPLyQrYQi1o4CQWW1Y1jy2xuGgyWl1YJUlHCCkR"
    "NGgyGkmZjSSzgNRa4FrzxUU2s7i4sZxYfKR2AGKMRjYVhRuxILUmuPXgw5yDhzkHl5MVcNIR3E4i1CuKjy0dXMQi2pyIFjNWwJZY"
    "XDQZjSajwS2qILUmpNZ8cZHNLC5uXGLxkcrHaGQzC9gSC1JrglsPPsw5eJhzcDlZASexeJxEJaP52sLHAeaMBk5WwJZYXDQZjSaj"
    "gS2xILUmpNZ8AZqM5qYJs/hK5dYDkM0sYEssSK0Jbj34MOfgYc7B5WSFbIjF4+RtNF9buNUEzBkNnKyALbG4aDIaTUYDW2JBak1I"
    "hReo6Qpuagqz+ErtwIQegGxmAVtiQWpNcOvBhzkHD3MOLicrZEMsHidvFcXHFjqALsCc0cDJCtgSi4smo9FkNLAlFqTWhFR4IWY9"
    "eLjRsqr5SO1BKj0A2cwCtsSC1Jrg1oMPcw4e5hxcTlZICrF4nEALK/jYQk0+zBkNnKyALbG4aDIaTUaDpMSC1JqQCi9S6cHDrceW"
    "WHyk9gC3HoBsZgFbYkFqTXDrwYc5Bw9zDi4nK+AkFo8Tap6s4GNLLL7MGQ2crIAtsbhoMhpNRiMbYkFqTUiFVyr04ObaUVti8ZHa"
    "A8SsViObCgyNaEitCW7U5GFOrebNnOKirICTroVXwUmtVieCx5ZYfJlTUeK6qmFL1wI0GY0mFZgS0ZBaE1LhdQK9oBtSa+LaUTxS"
    "ewCarGpxJTAqCkjtVZgJBw9zWA0Uagp0KysgRXrhEXASC1w7ituWWHypKVHitRpIkV4FmoxGXAmMigJSa0Iq9Tp5xILUmpDag0dq"
    "D0ATZsHJ22guqfQAcw4e5jxGIxuoebICSOWyAk5iAW49uG2JxR9k83ZwS4UDNBkNnLyN5pJaE1JrvoSPBoEGgeYh0FwEGhDemjcB"
    "GhCaD+HRgHBpobkIbw0INCDQ3ASaPwlvzU2ABoTmIrw1bwINAv3iP+7Ff9yL/9EJB+B28C+4sYJ/KWXwt16IAMWvKY/ir044ALeD"
    "L5HiN9xYwY9EuBV/pdDNxWTxt16YAwe/lspbD/7qhANwO/gyH80/c2MFPzLndvBXW5jF77yyC9Oq4FdSicKlVvOzEw7A7eDLfDT/"
    "zI0V/MicCtSqgp9tYRa/8zpjYU4sfiWVWaQyi5+dcABuB1/mo/lnbqzgR+bEwpxY/GwLs/idF7czFrCF0WxhNI9kcpE9i0sq9ODt"
    "hANwO/gyH81jC6NBcxaXVOgBuLECN1bwMD94O2E0mAOjQZPbLFIGt1Towdu5AjdWvLidsQBXGc2mV/NIJhfZswA1LWF1AyccgNvB"
    "l/loHlsYDZqzQMSl6AW4sQK3iuJhPruBE0ajaoWuLsQVClaTMgAFFYTVDZxRpaYVL25nLC7mo9k9+UomF9mzQDY93FgBnHAAbgdf"
    "5qN5bGE0aM4CTXpwc2MFroMvc2IBJ4xmC0OSmsAWZnFJGUAqs3BjBXDCASe8uKhpLC7mBVqTr5RejanOwlSjStS7FpxwAG4HX+aj"
    "eWxhNGjOAs2o4ubGiqwuvsyJhZpWlJpWlIjTq9nCLC4pA0hlFqK+AjjhgBNeXMyJxcWcS02+UplFKrNIZRbIpgeccABuB1/mo3ls"
    "YTRozgLNWTzcWLVX8AdzYmFOLMyJBWxhNFuYxSVlAKnMAtkrgBMOOOEFnHDwsYXR/CGVtx5AKrNANj3ghANwO/gyH81jC6NBcxap"
    "zOLhxmUFfzDndgDmxAK2MJotzOKSMoCUwUU2PeBcAZzwAs7uyU3EhdH8IaVB6QGkMgtk0wNOOAC3gy/z0Ty2MBo0Z5HKLB5uXKKK"
    "L3O6gQmYEwvYwmi2MItLygBSVjfIpgecK4ATXsAZi4c5MJo/JBNNegCpzALZ9IATDsDt4Mt8NI8tjAbNWaQyi4cbbz34MicWD3Ni"
    "AVsYzRZmcUkZQCqzQDY94FwBnPBK0Fg8zJdYVfCVTERcajUqXr2QTQ844QDcDr7MR/PYwmhcdBYqXr24uRGFaUXxMJ/dPEScXs0W"
    "RrOFWVxSBpDKLEw1quBcAZzwOoFYPMyHOjX5SiaQyiyQTQ9k0wNOOAC3gy/z0Ty2MJpUZoEmPbi5sQI3VvAwP/jTFkazhdFsYRaX"
    "lAGkMgs3VgDnCuCE18nHAVsYze7JVzKBVGaBbG4ruLixAjdi8TDnNho0gUnO4pLKZRZurADZK3iYH/zAnEtNLprALFIGF9lcevB2"
    "rgBOeCUfE1xYjXfw5R2AKatBnFsUF1OiUCOKhxq31SAOLHw1F1MuUZgSBWQUD7XJD9S4VHARB1ZjsriIc+nFW0YBCS/+4178x734"
    "j3vxP5JdE1Kpyf9d6sG/pAmz+Dsv/keya0IqNfm/Sz34lzRhFn/ndXIbza+k8hjNz2TXhFRq8tBcwW+kHvzs5NGDv9BcwW+9Tm6j"
    "+ZVUHqP5meyakEpNHpor+I3Ug5+dPHrwF5or+K0Xb6mj+ZXUg0vqaH4muyakUpOH5gp+I/XgZ2dNLpvBT2RzmcVvvHhLHc2vpB5c"
    "UkfzM9k1IZWaPDRX8BupBz87a3LZDH4im8ssfuPFWyo9wG0WmrH4Sj24pI4G3HiLBciuCanU5KG5gkcqPcBtFmDOW01IPcB8Fl9n"
    "TS6bwSWVt1nI5jILTZiFbB41IZXHrBdvqfQAt1loxuIr9eCSOhpw4y0WILsmpFKTh+YKHqn0ALdZgDlvNSH1APNZfJ01uWwGl1Te"
    "ZiGbyyw0YRayedSEVB6zXryljuYtFYjFV+oB5jAazRWAZixAdk1IpSYPzRU8UukBbrMA81k8Ug9NmMXXWRNS6QFuswDzWYDmCkAT"
    "ZiG7JpezJqTSA9xmvXhLHc1bKhCLr9QDzGE0misAzViA7JqQSk0emit4pNID3GYB5rN4pB6aMIuvsyak0gPcZgHmswDNFYAmzEJ2"
    "TS5nTUilB7jNegHms3ikUpM/pfI2C9BcAWjCLGTXhFRq8tBcwSOVHuA2C02YxSMViMWfTm6jAbdZgDmMRnMFoAmzkF2Ty1kTUukB"
    "bvACzGfxSKUmf0rlbRaguQLQhFnIrgmp1OShuYJHKj3AbRaaMItHKhCLP53cRgNuswBzGI3mCkATZiG7JpezJqTSA9zghSbM4pEK"
    "xOIr9QDzWYDmCkAzFiC7JqRSk4fmCh6p9AC3WWjCLB6p1DSfxddZky+3WYD5LEBzBaAJs5Bdk8tZE1LpAW7wQhNm8UgFYvGVeoD5"
    "LEBzBaAZC5BdE1KpyUNzBY9UeoDbLDRhFo9UaprP4uusyZfbLMB8FqC5AtCEWciuyeWsCan0ADd4nVxm8eY2C81YfKUeXFJHA268"
    "xQJk14RUavLQhFk8tvA2CzCHwa4JqQeYw2geZ03+lHpowixAE2ahCbOQDStSqQmp9AA3eJ1cZvHmNgvNWHylHlxSRwNuvMUCZNeE"
    "VGry0IRZPLbwNgswh8GuCakHmMNoHmdN/pR6aMIsQBNmoQmzkA0rUqkJqfQAN3idPHqA2yx+knpwSR3NW+rBz86aPDR5q8kvbAaX"
    "1INL6mgeZ01+dNbky20WP3CbxQ/cZr1OHj3AbRY/ST24pI7mLfXgZ2dNHpq81eQXNoNL6sEldTSPsyY/Omvy5TaLH7jN4gdus178"
    "x734j3vxv5FNTdAkFv9nmtTk3zGHWPydF2wY/Jorb6v4K9nUBE1i8TBjFf9Ik5r8yJW32fx/JHtyMY/F33qlCBSTX3HjrZvV/EQ2"
    "NUGTWDzcWME/0qQmP0rlrZvV/ERSanIR6eZvvU5YDrH4BTeiXIDR/EQ2NUGTWDzcWME/0qQmP0qFKBeo1fxINjX5rde5CDd6gBgd"
    "oEoVNzdmqWAS0VwcFm+yqQmaxOLhxgpuJkQDzuImRgdoUhNUqeKWSkSrmDCai8PiIq500YEqVbypEs2bSTQmLF6+ALeOQJOaiGuv"
    "4ubGLCCV0WA4LAKQTU3QJBYPN1ZwS2U0cHJwMcToVWhSE3ElFrdUZgFbGA2GwyIQM95qYk4sQEWV6Gpgy1AcVrx4k00sxLVXmROL"
    "hxuzgFRGo8ltFsimJmgSi4cbK7ilMho4OQBz3mKhSU3M6VXcUpkFbGE0mtxmiSvQXYE5sUBceYto2LJMuBwv3jR7AJrUMusIHm7M"
    "AklhNFvoRmE0sqkJmsTi4cYKbqmMBk4O4ISCXqBJTTHrCB6pzAK2MJoTChF6tqRALMCcWIhZN4gwC7bQjcJ8cZFND0BdqpxYfLix"
    "Clzp2ZLSA7bQA9nUBE1i8XBjBbdURgMnB3DSg5smNc1ZwUcqq4CUni2bHrCFHsimJhdzYuHGCkhlFmxhNFvgxUU2PbhoArH4cuNj"
    "NFs4uJz0QDY1QZNYPNxYwS2V0cDJAZz04KZJlROLr1Q+RrOFA5BND2RTk4s5sXBjBaQyC7YwGk54AbLpwU0TYvHlxmM0bOHgctID"
    "2dQETWLxcGMFt1RGAycHnNCDmyZvsfhK5TEatnAAsumBbGpyMScWbqwAUpnFFkbDCS9gS8/mTV0gFl9usFSZBWzh4HLSA9nUBE1i"
    "8XBjBbdURgMnPTihBzdNbiv4SIXZQANbOADZ9EA2NbmYEws3VgCpzGILo+GEF2zp2dw0gVh8ubFCUno2bOHgctID2dQETWLxcGMF"
    "N0kZDalwoEkPbppQbcTiI5UVfGzhAGTTA9nU5GJOLNxYAa6yArYwGk54kcosbuJabR3BhxuzSKVWo0lNSKUHsqkJmsTi4cYKHltq"
    "NVuYBSc9uGlChFmv4pHKLD40qQmp9EA2NbmYEws3VkAqs2ALo+GElxsE0AGavdq1V/FwYxbqwmjYQoDBCmTTEWjSq7i5Uc0lmi0E"
    "GMSCEwLoQJNeZU6v4pbKLL5OCDBYgWw6SgNzYqGm1aDCLNjCaDjhdfLogZjVxJxYPNyYBalENObcYoGYURNNiMXNjccstnAJgwPc"
    "eKuJJjVRU2JxS2UWX27cVoC40iUTc2KBuvBWq2ELo+GE18mjh6h3BOpSq7m5MQtchdHgolC9uIhrTcSVWNzceMzCRSnmSU0gUSAW"
    "mtQEdanVvKUyiz+4KFQvLuIKNTEnFmAqQrEa2MJoOOGVPHqJ0wtQo4KbKVGAC6u5JEwe4r1AjQpupjxWA8lqksmbOPQCNXoBalTw"
    "5kIUP0iYPMShF2pU8GZKFG8urIaEF/9xL/7jXvyv3HqAOQf/QmpN/h1NmMXfeIEqEM2vqPKI5i/ceoA5Bx9iRPPPUmvyI1Uei78y"
    "6QBEoZq/8RLMgFXNL5jzmMVfuPUAcw4+ZDOLf5Zakx+58RjNX6TW5HdeJ49Y/II5H7P4mVsPMOfgQzaz+GepNfmRGx+j+VlqTX7n"
    "pby5xAIXeoEak4c5k0syi4sprObNrQeYc/Ahm1ncxFkNCRVcxCEKSK0Jpr14uPUCxKkowBQmII4IxWo1iOJiCqu5uFTgQq8XN9eO"
    "wlV6IGY1eZhzALKZBagprO4G3HqAOQcfspnFTTaz4IRYgKhDRENqTXDrwcOtByCurAA1hUm3bG6jNWEWoKawqoHUClzo9eKRWhPc"
    "epDagw9zDkA2s4BU3mIBbj3AnIMP2cziJptZcEIswJxLLEitCW49eLj14O1kBWzhbYVsbqM1YRawhcssIJWPF7fUiAZRG6T24MOc"
    "A5DNLNgSASmxALceYM7Bh2xmcZPNLDghFrj24tKQWpPUWs3DrQegLrOQlFWwWYHg2pNGE2bBlghIIiCVnmDGi9uWWFw0F0YEH+Ys"
    "Ls4sOFkBZh0Fbj3AnIMP2cziJptZcEIsSK3JI7WmWUfx4dYBiDEa2cwC146C1JqAJsyCkxWwJRak0gPMeXHbEouLJhCLL3M+ZsHJ"
    "CsCtB7j1AHMOPmQzi5tsZsEJsSC1Jo/Umicr+HLjYzSymQVsqQmpNQFNmAUnK2BLLEilB5jz4iKbWbxpArH4MucxGtmwAnDrAW49"
    "wJyDD9nM4iabWXBCLE6oySOVywq+3HgcYA6zgC01IbUmoAmzNGEFkFqTVHqAOS9AzFY1b5pALL7MWajCaGTDCsCtB7j1AHMOPmQz"
    "i5tsZsEJsTihJo9ULhXFhxssLgHmMAvYUhNSawKaMEsTVoCr1CSVHmDOC0S9Z3PTBGLxZc6BmTAaSWEFiGsPcOsB5hx8yGYWN9nM"
    "ghNisYWaPFJphFh8uNGDh7owCySlJqTWBDRhlqSwArZQk1R6gDkvcOvBhyYQiy9zDtBkNHCyArbQA9x6gDkHH7KZxU02s+CEWJBa"
    "k0dqTbbE4sOtB1+ymQUn1ITUmoAmzIKTFbAlFqTSA8x54So9eJixMKnFhzkHaFJRcNIRqVQUuPUAc2o1N9n0Kt5k0w0KsSC1e2IE"
    "pNZETWrxcOvBl2w6ypWIhlRqgibMgpOOciUWpNIDzHmpC724FLjWwoxVPMw5QE2ZBalUJB0BuDELc5jFTTZEAd3iyqWUWOAqTKwX"
    "pNYEtx483HrwJa5UORUFmAmz0IRZkEqV0xGQSg8w53XyURNcJmDOwcOcA5DNLCCVywoubjDaHGZxk81jBZxcji2xAHMusSC1Jrj1"
    "4OHWgz9t4TKaN3MYrQmzgC1cZgGp9ABzXsJXg9BchOZDaC5CcxHemjcBGgSaD+HRgHBpgeYivDUINAg0D4HmT8Jb8xBoEGguwltz"
    "EaAB4cV/3Iv/uBf/oxMOwO3gX3BjBf9SyuBvvRABil9THsVfnXAAbgcfCsVvuLGCH4lwK/5KoZuLyeJvvTAHDn4tlbce/NUJB+B2"
    "8LGF0fwzN1bwI3NuB3+1hVn8ziu7MK0KfiVlAS61mp+d8P+og2NjSZIc0aI3zUIUEC4KCBcFBEQBAVGcgChOQJQgfkTGy+7qmdqt"
    "/q+2x2zOOYCwgy9bGM3/LgxPfmRBJWpVyV9tYRa/8jrTsSCdn1lMYCmz+KsTDiDs4MsWRvO/C8OTH1mQjgXp/NUWZvErL97OdGAL"
    "o9nCaB6LyUX2LC5LoQe3Ew4g7ODLFkbz2MJoljKLy1LoAYThSRiePCwObieMBgtgNOjibRZLBhfZXHpwOz0Jw/PF25kOhMpoNu3N"
    "YzG5yJ4FqGkJ3g2ccABhB1+2MJrHFkazlFkgElK0A2F4qmll8bA4uJ3dE1StUO9CQqHAmyUDUIkCwbuBM6vUtPLF25nOxWI0uycf"
    "i8lF9iyQTY8wPIETDiDs4MsWRvPYwmiWMgt00YO3MLw2PfiwOLid6cAWhixqAluYxWXJAJYyizA8gRMOOOHFRU3TuVgUaE0+lrQ3"
    "pjoLU80q0ehyOOEAwg6+bGE0jy2MZimzQFdW8RaG184qPiwqCzVNR00rSyRob7Ywi8uSASzxbkTDEzizCk54cbEgnYsFl5p8LGUW"
    "S5nFUmaBbHrACQcQdvBlC6N5bGE0S5kFumbxCMNre/IHC9KxIB0L0oEtjGYLs7gsGcCSwUW2J3B6Aie8gBMO3iyA0fxhKbcewFJm"
    "gWx6wAkHEHbwZQujeWxhNEuZxVJm8Qjj4skfLHg7AAvSgS2MZguzuCwZwJLBRbYncHoCJ7yAs3vyZgGM5g9LGpQewFJmgWx6wAkH"
    "EHbwZQujeWxhNEuZxVJm8QjjklV8WNANTMCCdGALo9nCLC5LBrBkcJHtCZyewAkv4EznYQGM5g+LiS56AEuZBbLpASccQNjBly2M"
    "5rGF0SxlFkuZxSOMWw8+LEjnYUE6sIXRbGEWlyUDWDK4yPYETk/ghNcCTedh4WJVycdiIhJS3qjELJBNDzjhAMIOvmxhNI8tjGYp"
    "s1CJauctjCxMBh8Ws5uHSJQDWxjNFmZxWTKApZWFqXoCpydwwusE0nlYDA1q8rGYwFJmgexZIJsecMIBhB182cJoHlsYzVJmgS56"
    "8BaGJ6GDD4uDP+1yYAuj2cIsLksGsJRZhOEJnJ7ACa+TLwfscmD35GMxgaXMAtm8eQIn4EkY6bxt4TGaLVwmaxaXpVxmEYYnYXjy"
    "sDj40xZuNbnoAmaxZHCRzaUHt9MTOOG1+DIhOoHo5CM6AVO8QYK3LGABWaiRxVsID29CuDjhzcWUSxamZGFKFg+1yZ9CuFVykQC8"
    "MXEuElzaua0sYMGL/3Iv/su9+C/34ptk1+Ry1uTvW3rw/0kXzOJ/8uKbZNfkctbk71t68P9JF8zif/JCF5fR/MxSHqP5K9k1uZw1"
    "eejy5BeWHvzVyaMH/0KXJ7/0QheX0fzMUh6j+SvZNbmcNXno8uQXlh781cmjB/9Clye/9OK2lB78xNKDy1J68Beya3I5a/LQ5ckv"
    "LD34qxPSYQs1+YFsLrP4hRe3pfTgJ5YeXJbSg7+QXZPLWZOHLk9+YenBX52QDluoyQ9kc5nFL7x4bAaEwaErnY+lB5el9IAwbumA"
    "7Jpczpo8dHnysRkQBgdYcKsJSw+wgNE8zprcZNeEpdxmIZvLLMBiFqCLW01YymPWi8dmQBgcutL5WHpwWUoPCOOWDsiuyeWsyUOX"
    "Jx+bAWFwgAW3mrD0AAsYzeOsyU12TVjKbRayucwCLGYBurjVhKU8Zr24LR3NbSmQzsfSg8vS0eiCWeiCWciuyeWsyUMXzOKxGRAG"
    "B1jM4rGU2yw+TkiHLdQMgwMsYDS6PAFdMAvZNbmcNblsBoTBi9vS0dyWAul8LD24LB2NLpiFLpiF7Jpczpo8dMEsHpsBYXCAxSwe"
    "S7nN4uOEdNhCzTA4wAJGo8sT0AWzkF2Ty1mTy2ZAGLwACxjNbSk1+dNSbrMAXTALsJiF7Jpczpo8dHnysRkQBgdYzOKxlNssPk7e"
    "RgNhcHBZOhpdnoAumIXsmlxOSF9KDwiDF2ABo7ktpSZ/WsptFqALZgEWs5Bdk8tZk4cuTz42A8LgAItZPJZym8XHydtoIAwOLktH"
    "o8sT0AWzkF2TywnpS+kBYfBCF8zisRRI52PpARYwGl0wC10wC9k1uZw1eejy5GMzIAwOsJjFYyk1LWbxcUI6jzA4wAJGo8sT0AWz"
    "kF2Ty1mTy2ZAGLzQBbN4LAXS+Vh6gAWMRhfMQhfMQnZNLmdNHro8+dgMCIMDLGbxWEpNi1l8nJDOIwwOsIDR6PIEdMEsZNfkctbk"
    "shkQBq+TyyxuYXDoSudj6cFl6WggjFs6IBs84azJQxfM4rGFxwEWMNg1YSk1YeloHmdN/rSU2yxAF8xCF8wCdHkupSaXzYAweJ1c"
    "ZnELg0NXOh9LDy5LRwNh3NIB2eAJZ00eumAWjy08DrCAwa4JS6kJS0fzOGvyp6XcZgG6YBa6YBagy3MpNblsBoTB6+TRA8JmARaz"
    "eCw9+KuzJj+ni0c6ILsmLD142wwuSw8uS0fzOGvyPwmbBVjM4hY2i8dmcFn6Onn0gLBZgMUsHksP/uqsyc/p4pEOyK4JSw/eNoPL"
    "0oPL0tE8zpr8T8JmARazuIXN4rEZXJa++C/34r/cC2TTg5/awlsPfoPsHvwNFqTztyxlNFs4XmyEHvzUFt568DuE5pc0BGgy+bWl"
    "jGYLx2sp0IOf2sJbD/5psoQ3T35tKaPZwvFSJOjBRY1KMCWLty1MbgUSlaiRxVsItwmrHYlKQI0swBRvIISJBO1IUIlaFo8QbpM3"
    "XVSC4c0tBLxhtSPRzkWNLG5LGc0WjhfIpgcXC9LRkPLmbQsHX3RlqSiVBZiocDuQ3UNCa4ohSnUVGjIaOOFANj3QRZaKVlcBJirc"
    "Dt50kQ5KcTFRgXQ4SQ/rAWKiVFcBSxnNFo4XyKYHFwmtrDA8eWzh4IuubuXiCRpSbUA6sjvFqGnBmycszWw44UA2PdBFoVw8QUMS"
    "A9J500U6XzSESzqckEYPxIxbecNSRrOF4wWy6cHNgszQ9uKxhcmlAF10I0Jms7S8w+AA2UBRqcZFJLNZymg4qYlseqALuhHBE5aW"
    "dxgcPHRRSTe3pRTgDSdQtItZN4jgCUsZzRaOF8imBzcNSay9+LKFWw9AF+mYCZ4s9YQtHCAb0vkIw5MwRiObA2TTA110JmF4wlJP"
    "2MLBQ0IEKrtBQpnF2wk1AV2kgwWesJTRbOF4gWx68GYBePKxhVsPQBfpEIYnYcxmSQ+QTQ8eAmZ4wtJZbOEA2fRAF+lggScsZTZL"
    "evChIUA6hNFevJ304KKLdLDAE5Yymi0cL5BNDx4W4Os4S+0AACAASURBVMnHFm49AF2kQxiesJTbAcimB28W3DxhKaO3cIBseqCL"
    "dCDME1jK7eAHFoAnYczicdKDiy7SgTA8WcpotnC8QDY9eLMAPPnYwsEXXaRDGJ6wFBjNRTY9uFhAehiesJTRWw5ANj3QRTqE4Qks"
    "BUbzVxbgGcYsHic9uOgiHQjDk6WMZgvHC2TTgzcLwJOPLRx80UU6hOFJ2GxobrLpAegiswnDE2TJ6C0HIJse6CIdwvCEpbOh+Vdh"
    "eIbRXryd9OCii3SwwBOWMpotHC+QTQ9uGpJYe/FlCwdfdJEOYXiydBZfZNMD0EU6hOEJbBmhHIBseqCLdAjDE5aO5kcS7aAheEoo"
    "s3g76cFFF+lggScsZTRbOF4LFIpKsCgntL14bKG4tIMu0iEMT5aWNw/Z9AB00dkmgiewpRRPQDY90EU6SKgnLC1v/iSh3SBCZrOU"
    "4jLhpAcXMesGETxhKeWti3qdPGoioemE4cljC289QBfpEIYnGlLNzZFND0BC6VbAE9AQOLjIpge6SAcN8QQNSd6cm5jx8AQN4Taa"
    "kx7cxIxbecNSGM0WXiePmhLaXmhIefO2hbceoIt0CMMTlvI4kE0PLhJKtQqeXLbAwUU2PdBFOoThCSzlcfAmJgpdVAEmKiQOJz14"
    "ExOlugowE0YTxmvxqFSjEjAli7cQ3tpBgkpQIwuN5qJwwKKdmxpZpmRxCYHJRYJ2JKgENbJAo7koHHxRg0q+hOANLNr5okYWb6Z4"
    "Q8iL75DQWcAWDr5DlowGTjj4LS++I4zZwJIefEcYs4FND37Li29ZyuPge5byOPg9L/4DZI/m/9TSmoAFLzCFyU+F8FbJb9Hi19S4"
    "VPI3LK0JWPBSTGE0P7OFt5r849SUS2Xxa0trAha8Tm6j+ZktvNXkH7eUtx782tKagAUvQBejuWxJh6U1eWxJ58vSmmxJ57GFm6ds"
    "ZuliNLrAk0tYD0AXs3TBLDhHI5tZ3Cy49eCxtCY/2JIOhPVgaU3AAkZzWVoTsOAF6GI0ly3psLQmjy3pfFnajdLlgATKzatlMzFl"
    "tJpCdzuE9QB0MUs0mAVnAUplAWbCrQePpTX5kEDpcgjrEdpZhIhAZQFLawIWvABdjOYS2lkaZPLYks6XpVCItBfoogBlNLJJkcZb"
    "DRDpAWE9AF3ljWxmwUk3KJ6gQYPS5TyWthcPMaOgHcLaV2XBlm7QzIalNQELXoAuRnML63HiyZct6XxZCgdhcIAuRqOL0cgGavIl"
    "rAeE9QB0HYBsZsGJJ5x4wpZ02JLOl6Vw8AiD0dzCgFnAlnTYkg5LawIWvABdjOYWxsWTL1u4eQJLawIWHKCL0ehiNLLBk4+wHhDW"
    "Ayw4QBfMghNPOPEEVjtsSefDgks6ENaDRxgcgGxmAVvSYWlNwIIXoIvR3MQMvJovW2iHbmBpTcCCA0SjAJ0FsslsbhIg0gPErLwt"
    "OEAXzIITTzjxBJY0aGbzISIBXQ5hPXiEtRcgm1nAli5naU3Aghegi9HcxAxm8bGly3ksrQlYcACyi8sEZDOLiyJRiPQAdDHarCfo"
    "gllw4gknnsCSBrL40UKkvQjrwSOsBxfZzAK20IOlNQELXoAuRnMLA2bxsSWdL0trAhYcgOzRPGQzi8tSOAjrAehitOkEdMEsOPGE"
    "E09gtfMTYXAQ1oNHWA8uspkFbKEHS2sCFrwAXYzmFtbjxJMvW9L5srQmYMEBGoMP2czisrQmhPXgInuE1gR0wSw48YQTT2C18xNh"
    "cBDWg0dYDy6yIR22pMPSmoAFLzBVRnMJ7awTT75s6XIeS2sCFhygq7x5yGYWl6XdM1R6cJFdIjUB0WAWnHjCiSewJJMfhHATaS/C"
    "KBJ1COvBTUO6fCnpsLTLwYKXYgre3bAlnSVVxWML7VwKltYELDhAF95cCmQzi4uZMEPowUU2dDkX2cwSDTzhxBNY2s6teAsVbl0O"
    "agqJTAjrwVuotC86E8ykB1jwOnmkw5Z0WFqTxxbeasLSmoAFB+jiMRrZzOJmwa0HF9mQzk02s3SBJ5x4Akt568FjKbd0Lrq41ISw"
    "HjyWcvHkEtYDLHjxLRoD0AWefMtqB8J68FtefIeaDEBk4cl3hJYDYT34LS++Q00nt1VZfMeWSsCknN/y4lt08RjNt2zhLZ3f8yKM"
    "dH4qjLeD/4ST28HfEEY6cKa/xIx0fiqM5jL45wkbGjn4G8JIB8701wmk81NhpPOfEQYcYQd/QxjpwJn+ChXSuYhSjSjVPMKyiodo"
    "ggHVXER5S7BqRBMQBRIQpZqLaIJBgkGKAsnN+JK8hdHlqs6bKJCAaIJVAwZUcwkjHTjTX4SRziWMdMJI5xF28BF2wAmkcwnj7YAz"
    "nbADCAMOIIx0LmEHnHDACUcYcHA7+XLwFkY6fwgDDiDsgDMdOIF0LmGkA2f6izDSuahEOmHexSMsq3iEJbQq6UDQqFKVcFZDJwSN"
    "alahEulAiB5wwgEnJB1wAKpWhSpVyVsY6XyEqEMCYQndhapVRbUDYaQDZ/qLMNJ5O9MJO/gII51HGHCEkQ6c6YSRDpxAOnCmE0Y6"
    "cKYDJxxwwgEnkH7CAYSRThjpPMJI5+OEg7cw4ADCSD/hAMJIB870F2Gk83Z2I3LwEUY3MIEwskpkpQNnOiIrHThhdgPajcjqnnB2"
    "TzizCk444ITZrWpVSRjphJHOQ2R1U8nFVLOKtzCyCgib3apWlYSRDpzpL8JI5+3kdvARxtsBhJEOnOnAmQ6c6cAJB3864YATDjjT"
    "gRMOOOEAwkgnjHTCSOfjBNK5hJHOI4x0LmEHEEY6YaQDZ/qLMNJ5EzMym48wMoEGwkgHznTgpIHZXE44eDMDBA4QswPOdOCEA044"
    "gDDSQTaNMJo/CGyaTMJI5xE2mssWDiCMdMJIB870F2Gk8wgjnT+EdSaPMNKBMx04aWBwO+HgJqaAwAGEHXCmAycccMIBhJEOnDQw"
    "+IstkE4Y6TzCDm4nHEAY6YSRDpzpL8JI5xFGOn8IO/gIIx0404EznY8TDm5nOnDCAYQdcKYDJxxwwgGEkQ6c6fy7MNIJI51H2MHt"
    "hAMII50w0oEz/UUY6bypCl3FR9js5hFGOnCmA2c6Hycc3M504IQDCJuw0oETDjjhAMJIR2Sl8yORAsJIJ4x0HmEHtyUyuwkjnTDS"
    "gTPrRRjpvJ3phB18hJHOI4x04EwHznQ+Tji4nenACQcQxiUdOOGAEw4gjHTCSOdHYQcQRjphpPMIO3gLI50w0gkjHTjhZapU0YVK"
    "pBPmXTzCqOLSRRjpwJkOnFVcuoATDm5nFRBwAGFAVgEnHHDCAYSRjqpVceniEeaAalahalVAAmEHb2FUoZpVqFpVwgmvk7d0wkgn"
    "jHQeYTzSCSMdONOBk7d04ISD28mXAwgDDm4nHHDCAYSRDpy8pfMI4+3gdnI7gLCDtzDeDm4nHHDCy3irRpRqRKnmIcqjGlGqAasG"
    "zioguhwMkpvxJQFRILkZJBgkIEo1cFYB0eW8ifKW3IxbAqLJmyhvyc0gweDFt5zpwAkH33SmAycc/JYX32Am6cAJB99iNmngzGx+"
    "y4tvCCMdOOHgW8IObmc6v+eFLpjFz2zhcfDPC+Pmya+FjQbCZr3QBbP4mS08Dv55Ydw8+bWw0UDYrBe6YBY/s4Wa/EdYwGj+prDR"
    "QNisF7pgFj+zhZr8R1jAaP6msNFA2KwXYDGL29LRWHjy2EJNHhY8ZgEWnsiuyeXkMgtd3HrAUnpA2GggbDS6eHgCutKX0oOHBYzm"
    "iy4uB5elQDps4TYaCBsNhM16ARazuC0djYUnjy3U5GHBYxZg4YnsmlxOLrPQxa0HLKUHhI0Gwkaji4cnoCt9KT14WMBovujicnBZ"
    "CqTDFm6jgbDRQNisF2Axi9tSIJ2PLTwOsIADLGA0Fp7IrsnlrMmfzh5cNgPCRmMBo9HlCejyhBPS4ezBRxhQk8sJnjyWHrxtBpfN"
    "gLDRQNisF2Axi9tSIJ2PLTwOsIADLGA0Fp7IrsnlrMmfzh5cNgPCRmMBo9HlCejyhBPS4ezBRxhQk8sJnjyWHrxtBpfNgLDRQNis"
    "F2Axi8cW0vnYQk0eFnCABYzGAujB21mTmy5uPbhsBoSNxgJGo8sT0OUJ6OJy8BeywRNO8OSx9OCylB5cNgPCRgNhs16AxSweW0jn"
    "Yws1eVjAARYwGgugB29nTW66uPXgshkQNhoLGI0uT0CXJ6CLy8FfyAZPOMGTx9KDy1J6cNkMCBsNhM16ARazuC0F0vnYQk0eFnCA"
    "BYzGwpOPsyaXE9Lh7MFlMyw8AQsYjS5PQJcnoCudf6cLRp/gyWPpwdtmcNkMCBsNhM16ARazuC0F0vnYQk0eFnCABYzGwpOPsyaX"
    "E9Lh7MFlMyw8AQsYjS5PQJcnoCudf6cLRp/gyWPpwdtmcNkMCBsNhM16oYvLwWXpaCw8eWyhJg8LOMACRmPhycdZk5uu9KX04CYb"
    "PLmFjUaXJ6DLE9CVzg8seHgCumAWt6UHb1tIDxsNhMEBYfBCF5eDy9LRWHjy2EJNHhZwgAWMxsKTj7MmN13pS+nBTTZ4cgsbjS5P"
    "QJcnoCudH1jw8AR0wSxuSw/etpAeNhoIgwPC4HXydvBh4cnHydvBv7Dg4QlnTf509uAmGzy5hY1GlyegyxPQxSOdj83gIwwOLksP"
    "Piw8eWw5uCx9nbwdfFh48nHydvAvLHh4wlmTP509uMkGT25ho9HlCejyBHTxSOdjM/gIg4PL0oMPC08eWw4uS198g2zwBHR58h1n"
    "TS4npPNbXnyDbPAEdHnyHWdNLiek81tefIsF0INv08Xl4Le9+BYLoAffpovLwW978c+TTQ/+Ty1lNFs4XnBCTX5qC281+Q2ye/A3"
    "6CKdv2Upo9nC8doI0D35iS289eB3CM0vaQjQZPJrSxnNFo7XSfuCmvzEFt568E/TEN48+bWljGYLx0ugdUE6GmSCGV68bWFwa9Ao"
    "x4xM3kK5DWT1RFY5YEYmEMpsYElPZFGOBpmYZfJYwqUnb7ooByObWyjMht0TWeVcNMjktpTRbOF4cbOgJhakYyaZzdsWDr7oyjIR"
    "2gsIUd4OZPeQJTXVEKE7C1kyGjjhQDY90EWWiXRnASHK28GbLtJBaC4hCtSEk/LQHqAmQncWsJTRbOF4cZHQ9kLM2isMTx5bOPii"
    "qxEunmAm3oQwC9kUSk0L3jxhaXnDCQey6YEuGuHiCWbizYJZvOkinS9mwsUTTiilB7KEW3vBUkazheMFgWh7ARZkhWQ2jy0kFwd0"
    "UYUq7cXSzGYLB8iGTrpEuahWFksZDSeeyKYHuqAKVTxhaTps4eChiy6quC0lGxI4oZMuCa0CVTxhKaPZwvGCE+jBRUIbKW++bOHW"
    "A9BFOhKKJ0vLmy0cIJv24iMMTzRkNGEcIJse6KKyCMMTlpY3Wzh4iIpBVxWYCbN4O8ET0EU6WOAJSxnNFo4XmBidyUVCwZOPLdx6"
    "ALpIhzA80ZAEIx1k04M3VRDFE5Zm9hYOkE0PdJEOYXiChiQYnnyIqkJlEUZm83bSg4su0kFNy5uljGYLx4tLYO0FSCh48rGFBDoB"
    "XaRDGJ6wFEgckE0PLqKq1aJ4wlJGb0kH2fRAF+kQhiewFEicH4iJUt5hzOJx0oOLLtKBMDxZymi2cLy4yaYmYAF48rGFgy+6SIcw"
    "PNHoBucmmx6AmHVVheEJZjJ6ywHIpge6SIcwPEGjG5x/oaZ4hpHZvJ304KKLdJDQymIpo9nC8bIEZFMTxKyRzObLFg6+6CIdwvBk"
    "6Sy+yKYHoIt0CMMT2DJkcQCy6YEu0iEMT1g6mh+JdoGE4mkmzOLtpAcXXaSDBZ6wlNFs4XidE5CgJli0E5LZPLYwuRXoIh3C8GSp"
    "J19k0wPQRTliiiewxU1qArLpgS7SQUM8YaknPxCzSlCjvViKN1Bw0oOLhFaCKZ6wFE/CmK+TRzpilk4Ynjy28NYDdJEOYXgSKt7c"
    "Ctn0ADSEagM8gTDg4CKbHugiHSTUE8Lw5lbcZAlv7QVmwm00Jz24aQi39oKlMJotvDYCdDlYdCZm4sljC289QBfpEIYnLOVxIJse"
    "XDSEBsGTyxY4uMimB7pIhzA8gaU8Dt40EGgyuYQKNLM56cGbBkKTCYTBaJbygg09AQ0yATO8eFvCW0/QoBzM8EJCuAgcyKInNw0y"
    "zfDisgQGF1n0RINyMMMLZHETOPiiAZl8CWU2sOnJFw0yeQtlNmxefMvSWcAWDr5DQkcDJxz8lhffEcYsYAsH37GUWcBJD37Li29Z"
    "yuPge5byOPg9L/4DZDOL/0tL6QEWvDABnJ8y4a2T32JU80tiQBV/w1J6gAUvWQIMaP7dFt5q8o8TNIDy5teW0gMseJ080vl3W3ir"
    "yT9uKW89+LWl9AALXsptkQ4hlRBSyWNLJZduMG0nhHbeQrhlSeCthjewoBIwZQISeCOBNyyyJPDmTYK3ydvSdm7FWwjtYNpOSCWg"
    "Bt5cltIDLHjxtiUdtlQWS2vy2JLOl6XthNBeIEKAAJ4SOtuM0SIsqCwI6wHoYhaymQUnWRJ4NSAiwa0mb0tr8iFCCDUhrIeG1AQx"
    "A68GltIDLHjxtiUdttCDpTV5bEnny1K+HKALpgTgCedUg9EW3HpAWA9AF7OQzSw4eXgCS3nrwWNpTT50cakJYT1OqAlLuXgCS+kB"
    "Fry4yBKvBgntsSWzeWyhJo+lMECDA3QxC13MAs6WchoEMOsBYT0AXcxCNrPghEw2nsDScgi8eSylB190MRsawmjxolmaCYtyWEoP"
    "sOAFKmKZzcVUMvDkyxY6oRpYCgdYcIAuRqOL0cBJVfIlrDNRU0/ELLORzSw4qSxOKguW1oTA+WKqOHQBqpbOWxhkNrAlHbZ0Jkvp"
    "ARa8IAxG82YBePJlCzdPYCkcYMEBuhiNLkYDJ558hMEBuhhtwQHIZhaceMIJNWFpTQicDwsu6UBYDx5hcHDbkg5b6MFSeoAFLy6y"
    "IZ2LBcziYws9eCyFAyw4ANncDm4nntx08XaALkZbcACymQUnnnBCTVjKLZ0fbaEHhPXgEdaDi2xIhy30YCk9wIIXNwvSuVjALD62"
    "VBaPpXCABQcg27kktxNPLmrqqMIBuhhtlgnIZhaceMIJNWFpJ9DFj9S0ywnrwSOsBxfZkA5b6MFSeoAFL962pANi1jKLjy3pfFkK"
    "B1hwALpG83HiCYhZD8LgAA0ZbTq5yGYWnHjCCTVhaTr/LgwOwno2b2E9uMj6f7zBsbEsR65o0d0RZQqENAVCmgIBpqQAUyDAlBRg"
    "Sgm/qqubn3xzI8g4dzhrCeGwhZqk0gNs8eJtSziwrMeJBx9bwvlIhQNscYAmo/k68QBSa8IyOADZo00nF9nMghMPOKEmZDu/sAwO"
    "lsFobst68LYlHLaEQyo9wBavJEqWEg4siTrx4GNLl/NIhQNscYAmo/k68QBSqblU4ABkF9KTi2xmwYkHnFATUsr5M1MuInAgZlSg"
    "Dst68Laly1MJB1naA2zxOomSRUeAWjupEc1jC+1AN6TCAbY4QE29uXXDiQdgJswlwAHIBmpykc0sOPGAE2pCaju34pHKrZsJakog"
    "E5b14G2ptCcdASxjFrZ4nbzNAraEQ2pNHlt4qwmpcIAtDkA2Dw848eBii8cByAZqcpHNLDjxgBNqQipvPXikcgvnJhuoCct68Ejl"
    "4sFlGYy2xUt4ay4CDQLNQ/hoEKABoUGXzAY2HiA0b8KjuQiX5iY0IDQgQEN2AEvpwZvwaN6ES4NA8xBuzU2ABuHFj2iGcznx4CfM"
    "yoFlXc7vePEjuga3Ew9+Yks4sKwHv+XFv0+Tmvw32SIcOMNfiHDp5hdE+Ch+ThYV/C0RLt38PVuEA2f4i2VcPPgFTR41+dct4+LB"
    "37NFOHCGv1g2Tely/pMm7dyKf1uKEL26nL9li3DgDH+x7FgGHPwnTWryv3ECXpse/C1bhANn+Iu3Ew5k0wPZ9OChSU0emtTcAuFc"
    "bPF2wOnBMjxYBj24yJ7FJZloUhPYPbdAOBdbPDx4O+nBH2QDs0BzFrsnsAXCudgiHDjDX7ydXQ4peLOrnYcmNXloUqEqhAMqCmj3"
    "hLMCFaIwRfBukB1VQDLRpCawO1SFigJVK1CoKN5OevClsgq8QdMb7UBk0XTRjS3CgTP8xdvpwWUZXnsWH5rU5KEJDF2EA2c4cIYD"
    "J+DBYxmzQDY9gGSiSU1gC0MXMJoTDjjh4OOkB1+pzOKmCYwGTWpii3BsEQ6c4S8gQT24iK5uncWHJt2AN2hSUSKrHDjDgTMcOGF2"
    "8xBd1Y5seiBLeqJJTWB3lMgSRnPCASccfKhp0c5FluDd3DRpL0DTu7BFOLYIB87wF3ACHtxkA7P40ORtNGhSE9jlwBkOnOHACQd/"
    "kE0PZNMDTWqiSU1g9wS2MJoTDjjh4GsZ9OAimx48NKnJRXM02CIcW4QDZ/iLtxMOLrLpwR80qclDk5rALgdObge3Ew7elnHrAaQM"
    "NGeBJjWB3RPYwmiwxSWcv5BND2TTg4fmLC5bGA22CMcW4cAZ/uLthIOLbNq7+dCkJg9NagK7o+DsBia3Ew5ualqg9ABSBpqzQJOa"
    "wO4JbGE02Cogir+QTQ9k04OH5iwuS3Q02CIcW4QDZ/iLtxMOLrKBWXxoUpOHJjWBLYzmDOfrhIOLbHogmx5AykBzFmhSE9g9gS2M"
    "BlsH/0k2PZBNDx6as7hpjgZbhGOLcOAMf2UUcMIBmBSyZvGhSU0emtQEtjCaM5yvEw4usqMK2fQAUgt0FmhSE9g9gS2MBlsHf5FR"
    "IJseoKblzU1zFjfNqsAW4dgiHDi7X6cHcMIBLB3InsWHJjV5aFIT2MJoznC+Tji4yPYA2fQAUrnMAk1qArsnsIXRYOvgL04PkE0P"
    "IJVZ3DRncdOkJrYIxxbhwAmvkzcPkE0PZNODhyaPmmhSE9jCaE7ewoETDi6yefTgIpuaXDSpCeyewBZGgy3eDj5O3jy4pHKZBZqz"
    "eGzhMprLCQec8EreooCkHVm085DFowI1KoAlTDi7Aa0oSNq5JY92LrJo5yKLCmB1AEuYgK0CRGY3b8lbFBdTLt4gy5vHEi7eXJYw"
    "IeHFz5zhwAkHP2PrAGzhwe948TNnOHDCwY8slQOwhQe/48XPnOHACQc/csIB2MKD3/FCk8vBL508avLv28JtNH9vywHL4IUml4Nf"
    "OnnU5N+3hdto/t6WA5bBi8fZg184a/I/smw0/9iWA5bBi8fZg184a/I/smw0/9iWA5bBi1sqPbhsBiwbzeOsyVcqj9HAssEGD0CT"
    "ywG2uIXDZnDZDFg2GljGYxaaMOuEcB7L6MHXMqAmpHKbhWxuPbhsOWAZvLil0oPLZsCy0TzOmnyl8hgNLBts8AA0uRxgi1s4bAaX"
    "zYBlo4FlPGahCbNOCOexjB58LQNqQiq3Wcjm1oPLlgOWwQuwBQdvWwAPvk7eDi6pB5fU0diC0Wh6AJoe/EF2OGwGl82AZaOBZaOB"
    "ZbPQDAdkh/O1BfAAND14pNKDyxbCYQs1YcsBy+AF2IKDty2AB18nbweX1INL6mhswWg0PQBND/4gOxw2g8tmwLLRwLLRwLJZaIYD"
    "ssP52gJ4AJoePFLpwWUL4bCFmrDlgGXw4nH24CYbPPg6wYNH6sEldTSwDKjJTdODmy1u4YDs8GWjgWWjgWWjgWWzAFtAD/5CE0aj"
    "6cEjlR5cthAOW6gJWw5YBi8eZw9ussGDrxM8eKQeXFJHA8uAmtw0PbjZ4hYOyA5fNhpYNhpYNhpYNguwBfTgLzRhNJoePFLpwWUL"
    "4bCFmrDlgGXw4nH24LIF8ODrrMlX6sEldTR/pekBaMIsZIcDssOXjQaWjQaWjQaWzUIznF9ZNhpNDx6p9OCyhXDYQk3YcsAyePE4"
    "e3DZAnjwddbkK/Xgkjqav9L0ADRhFrLDAdnhy0YDy0YDy0YDy2ahGc6vLBuNpgePVHpw2UI4bKEmbDlgGbxOCE+lB5fNsAWjeZzg"
    "wSP14JI6Glg2mg9ND0ATZp0QDsjmMhpYNhpYNhpYNgtNmMWfLOMxGk1uNSGVHtxkc+vBZQs1IfV1QngqPbhshi0YzeMEDx6pB5fU"
    "0cCy0XxoegCaMOuEcEA2l9HAstHAstHAsllowiz+ZBmP0Whyqwmp9OAmm1sPLluoCakvwNYsbqmjgWWjeZw8akLqwSV1NLCMx2g0"
    "PbjZmoXscG62PLgtGw0sGw0smwXY4hbOH2TX5Cv14P+wBaN5nDW5vABbs7iljgaWjeZx8qgJqQeX1NHAMh6j0fTgZmsWssO52fLg"
    "tmw0sGw0sGwWYItbOH+QXZOv1IP/wxaM5nHW5PLiR2x5AJowmh/QDAdkh/NbXvyILQ9AE0bzA5rhgOxwfsuLH1oG1OTHbAE9+E0v"
    "fmgZUJMfswX04De9+PfJpgf/VamMZgvHC06oyS9t4a0mv0F2D/4BTcL5R1IZzRaO10aA7skvbOGtB79DaP6WLgGaCP5eKqPZwvE6"
    "aU+oyS9s4a0H/zZdwpsHfy+V0WzheAm0JoSjiwgww4u3LQxuDbrKMSOCt6XcBpI9kSwHzIgAljIbSOmJJOXoIgKzCB4pXHrypkk5"
    "GNHcljIb2D2RLOeiiwhuqYxmC8eLmy1qYotwzCSiedvCwYdmlInQXsAS5e1Adg9JqamGCN1RSMpo4IQD2fRAkygT6Y4ClihvB2+a"
    "hIPQXJYoFBNOypf2ADURuqOAVEazhePFRZa2F2LWXsvw4LGFgw/NRrh4gJl4s4RZyKZQatrizQNSyxtOOJBNDzRphIsHmIk3CbN4"
    "0yScDzPh4gEnlNIDSeHWXpDKaLZwvGAh2l6ALaKWRDSPLQQXBzSpQpX2IjWi2cIBsqGDLlEuqhVFKqPhxAPZ9EATqlDFA1LDYQsH"
    "D026qOKWSjQEcEIHXbK0ClTxgFRGs4XjBSfQg4ssbaS8+djCrQegSTiyFA9Sy5stHCCb9uJrGR7oktEsihcFhQAAIABJREFU4wDZ"
    "9ECTimIZHpBa3mzh4CEqBl1VYCYRzdsJHoAm4WALD0hlNFs4XmCIdQQXWQoefG3h1gPQJByW4YEuCTDCQTY9eFMFUTwgNaK3cIBs"
    "eqBJOKipB+iSAMODL1FVqCiWMYvHSQ8umoSDmpY3qYxmC8eLi5i1FyBLwYOvLQTQAWgSDsvwgFQgcEA2PbiIqlaL4gGpjN4SDrLp"
    "gSbhoKYeQCoQOH8iJkp5L2MWj5MeXDQJB5bhQSqj2cLx4iabmoAtwIOvLRx8aBIOy/BAVzc4N9n0AMSsq2oZHmAmo7ccgGx6oEk4"
    "LMMDdHWD83+oKR7LmMXjpAcXTcJBllYUqYxmC8fLApBNTRCzRiKajy0cfGgSDsvwIHUWH7LpAWgSDsvwALYMSQ5ANj3QJByW4QGp"
    "o/kz0S7AFh5mEtG8nfTgokk42MIDUhnNFo7XOQFZ1ARb7SyJaB5bmNwKNAmHZXiQ6sGHbHoAmpQjpngAW9ykJiCbHmgSDrrEA1I9"
    "+BMxqwBM24tUvIGCkx5cZGkFmOIBqXiwhfk6eYQjZuEsw4PHFt56gCbhsAwPloo3t0I2PQBdQrUBHsAy4OAimx5oEg4s84BleHMr"
    "bpLCW3uBmXAbzUkPbrqEW3tBKoxOhddGgC4HWx2BmXjw2MJbD9AkHJbhAak8DmTTg4suoQHx4LIFDi6y6YEm4cAyDyCVx8GbLhCa"
    "CC5LBZrZnPTgTRdCEwEsg9Gk8oINPQFdRABmePGWwltP0EU5mOGFLOEicCBJT266iMDMi0sKDC6S9EQX5YCZF0hyEzj40kUEH0uZ"
    "DWx68qGLCN6WMhs2L34kdRawhYOfkKWjgRMOfsuLn1jGLGALBz+RyizgpAe/5cWPpPI4+JlUHge/58W/T5PR/Fel1oTUmi9MAOeX"
    "THjr4DeIEvw9VaCKfyK1JqTWfEkKMJpf2cJbTf51YgZ4Nf9Aak1Irfk6eZvFL2zhrSb/ulRu4fwDqTUhteZLAVnMgiQKWFLBY0sF"
    "l24wApZUcJPFmzeyJqhNQBZEAUvaucjCW40JsvBWA29uatzaeVsq7UA3N1lQAZi2s6q4qDF5S60JqTVfXGQzC1IjGl1E8NgSzkcS"
    "sKSiANHF22hkT1AdiMiCiIaleIHoKm9NRqOJtxp4NSiqrUAP3rZQky/RBRUFy3roigBFjUk3kFoTUmu+uMhmFrAlnBMPPraE85HK"
    "Ww9Ak8doZHPpQSq3cGBZD7DFAZqMRpMPD9hCzRPowdsWavKlyaUmLOtx4gFbuHkAqTUhteYL0CWjuWwJ58SDjy3hfKTCYCk9MGOC"
    "GaNBNkTQCJcUasKyHmCLAzQZjSZ4SYIHbIloSSlv3mQpPXiYMbk0LKMnjaQQwabLIbUmpNZ8oSLGaC5mXayK4mNLFVANpHY5asqB"
    "mgywxQHIpqL4MJMesKwH2OIATUajSUSLGR6wJRy2hPNhqjjVgJr24LGMcEA2FcVSCYfUmpBa80UqMJrbMmAWX1u4eQCpNQFbHKBr"
    "gC0OQDaz+MOyHrCsB9jiAE1Go8lo4MQDtoTDlnC+bAEeQCo9eCzrwUU2s4At4ZBaE1JrvrjIZhaXZcAsvraE85FaE7DFAZpcanKR"
    "zSxutrj1AHQNMJ2AJqPRZDRw4gGkcvHgz06gB6k1+VjWg4tsZgFbwiG1JqTWfHGzVVHAMmAWX1vC+UitCdjiAE0HurjIZhYXUwlQ"
    "7QFoRqgyAU1Go8lo4MQDSAqo5s8M1R6k1uRjWQ8uspkFbAmH1JqQWvPF25ZwkKUtzOJrSzgfqTUBWxyga/Alm1lcUmvCsh6AJmNp"
    "TUCT0WgyGjjxAFnt/MKyHqSWN49lPbjIZhawJRxSa0JqzRdvW8JhS8RmFl9bwvlIrQnY4gBdgy/ZzOKSWhOW9QA0GUtrApqMRpPR"
    "wIkHbAnnF5b1IJUePJb14CKbWcCWcEitCak1X+mthno1bAnXrCg+toTzkVoTsMUBmuXNQzazuKTWZKn0ADQp6ShAk9FoMho48YAt"
    "4fzZEm4iPZCllLeqw7IeXGTTUQuNaEjtnqRSr9NbDWaBLiI48eBjSwWXbkitCdjiAE28uRTIZhaX1HZUpQcgSyGciyaj0WQ0cOIB"
    "KR28FW9LhVuXg5ngrTJhWQ9uiXQtKgpIpQdmwuvkbRaceMCJBx9beKsJqTUBWxygyWM0spnFJRUYZj24yIZwLpqMRpPRwIkHkMpb"
    "Dx6p3MK5aHKpCct68EgFRnNJpQfY4iW8NSA0IDRfwkeDQHMRGnRNQJLRIDQ34dICzU2A5iY0IDQXoYHUCGBpDx7Co7kJtwaB5iFc"
    "mpsADQgvfkJVB6DJaH5kdxSwrAe/5cVPLOsBaDKaH9leXJb14Le8WAYc/JImb6P59y3j4sHfs0U4cIa/MAMZ0PwnTWhgNv86WUoj"
    "Hvw9W4QDZ/iLyzLg4D9pUpP/jRPw2h78PVuEA2f4i4uawgFGFxhdPDSrgodogAp0cRHlLcCqEaUaFejiZtVclEKULkTpUoEuLqI8"
    "qnk7IaqtijcDqkG0GqUAFejiYotw4Ax/8XbCgWx6IJsePDRn8aE5mi0QzsUWbwecHizDg2XQg4vsWVySiSY10aTmFgjnYouHB28n"
    "PfiDbGAWaM5i9wS2QDgXW4QDZ/iLt7MqwFQGsquCh2ZV8NAMaFXCgUUDqyrgrKahejWYRDTIngVi2hNNaqJJV6vS5bBEHRZ4F28n"
    "PfgysWiqQbOa7kJMCaOowhbhwBn+4u304LJ0IHsWH5rU5KEJDF2EA2c4cIYDJ+ABsj1YxiyQPQs0qYkmNdEEhi5gNCcccMLBx0kP"
    "vlKZxU0TGA2a1NwC4dgiHDjDX0CCenARMdBZfGhCAd6gSUWJrHLgDAfOcOCE2Q1oN6Kry5Hd5Wh6NZrURJOKElnCaE444ISDDzUt"
    "2rnIErybmybtBWh6taoRji3CgTP8BZyABzfZwCw+NHkbDZrUBHY5cIYDZzhwwsEfZNMD2fRAcxZoUhNNagJbGM0JB5xw8LUMenCR"
    "TQ8emtTkojkabBGOLcKBM/wFCGx6cJFNz+ZLk3KgAU1qArscOGlgNpcTDt6WAkIPkCUDzVmgSU00qQlsYTSiq0Eimj8IZk1PZNOD"
    "h+YsLqmMBluEY4tw4Ax/8XbCwUU2PZsvTWry0KQmsMuBkwYGtxMObmLWIPQAUgaas0CTmmhSE9jCaLDVQAR/tlTogWx68NCcxWUL"
    "o8EW4dgiHDjDX7ydcHCRDcziQ3MWH5rUBHY5cIbzdcLBRTY9kE0PIGWgOQs0qYkmNYEtjAZbB/9JNj2QTQ8emrO4bGE02CIcW4QD"
    "Z/hLu4ETDkDEQGfxoenVPDSpCexy4Azn64SDi+wuRzY9gBRH1izQpCaa1AS2MBpVO/gL7QbZ9EA27d3cNGdxWSpejS3CsUU4cFa8"
    "Tg/ghANYOpA9iw9NavLQpCawy4EznK8TDi6yPUA2PYBULrNAk5poUhPYwmhOOPiL0wNk0wPZwCxumrO4aVITW4Rji3DghNdZBaxq"
    "B1MZyK4KHpp0cOlCk5rALgfOKi5dwAkHF9lVIEYPwMToigZNaqJJTWALo1mizi34OKtArCoQUyGaatCcxU1MCVSjClWrCjjhdfLm"
    "AbLpgWx68NDkURNNagK7HDh5CwdOOLjI5tGDi2xqctGkJprUBLYwGmzxdvBx8ubBJZXLLNCcxWMLl9FcTjjghJfxVg0YXWB08RDl"
    "0YUoXYBSwFkFrC4Ho4ub8ejiIkoXF1G6EKULUCEAWw6oRhVvxls1FxUu1SBazUOFS3BTIUCFFz9zhgMnHPyMrQOwhQe/48VP6JJw"
    "4ISDH0mRA7A1aH7Hi5+wRThwwsGPnHAAtg5+z+vk7eCXTt4O/n3LuHnw95bBActmvU7eDn7p5O3g37eMmwd/bxkcsGzWi1sqPfiF"
    "syb/I8tG8w8tgwOWzXpxS6UHv3DW5H9k2Wj+oWVwwLJZL26pB5dUetjy4OusyVcqj9HYgsEGDzh5OzS59eCyGVw2A5aNRpOHB6AZ"
    "DieE81g2mg9NbjUhFQgHZHPrAcvggGWzXtxSDy6p9LDlwddZk69UHqOxBYMNHnDydmhy68FlM7hsBiwbjSYPD0AzHE4I57FsNB+a"
    "3GpCKhAOyObWA5bBActmvdDkcvC2BfDg6+Tt4JJ6gC0YjS0PZNfkcoIHXyeEw2bAstHAstFowmg0YRaa4XD24GsZUJObpgePVHpw"
    "2QwumwHL4IBls15ocjl42wJ48HXydnBJPcAWjMaWB7JrcjnBg68TwmEzYNloYNloNGE0mjALzXA4e/C1DKjJTdODRyo9uGwGl82A"
    "ZXDAslkvbqn04LKFcP6/syZfqQeX1NHAMqAml7MmD1vcwmEzYNloYNloNGE0mjALTW49+AtNGI2mB4/Ug7fN4LIZsAwOWDbrxS2V"
    "Hly2EM7/d9bkK/XgkjoaWAbU5HLW5GGLWzhsBiwbDSwbjSaMRhNmocmtB3+hCaPR9OCRevC2GVw2A5bBActmvXicPbhsATz4Omvy"
    "lXpwSR2NLQ++zprcNMPhhHBAdviy0cCy0WjCaDRhFprh/CdNGI2mB4/Ug7fN4LIZsAwOWDbrxePswWUL4MHXWZOv1INL6mhsefB1"
    "1uSmGQ4nhAOyw5eNBpaNRhNGowmz0AznP2nCaDQ9eKQevG0Gl82AZXDAslmvsyak0gNSR2PLg68TPHikHlxSR2MLRvM4a3LThFkn"
    "hAOyuYwGlo1GE0ajCbPQDOcvlvEYjSbMOmtC6sHbFsKX0YPLlgOWweusCan0gNTR2PLg6wQPHqkHl9TR2ILRPM6a3DRh1gnhgGwu"
    "o4Flo9GE0WjCLDTD+YtlPEajCbPOmpB68LaF8GX04LLlgGXwAmzN4pY6Glg2msfJ28El9eCSOhpbPDzgrMnD1ixkh3Oz5cFt2Wj+"
    "SpNHOF9bqMlX6sEl9eDLlgePLQeX1Bdgaxa31NHAstE8Tt4OLqkHl9TR2OLhAWdNHrZmITucmy0PbstG81eaPML52kJNvlIPLqkH"
    "X7Y8eGw5uKS++BFbHoCmBz+iGQ7IDue3vPgRWx6Apgc/ohkOyA7nt7z4oWVATX5Ik1sPftOLH1oG1OSHNLn14De9+PfJpgf/VamM"
    "ZgvHC06oyS9t4a0mv0F2D/4BTcL5R1IZzRaO10aA7skvbOGtB79DaP6WLgGaCP5eKqPZwvE6aU+oyS9s4a0H/zZdwpsHfy+V0Wzh"
    "eAm0JoSjiwgww4u3LQxuDbrKMSOCt6XcBpI9kSwHzIgAljIbSOmJJOXoIgKzCB4pXHrypkk5GNHcljIb2D2RLOeiiwhuqYxmC8eL"
    "my1qYotwzCSiedvCwYdmlInQXsAS5e1Adg9JqamGCN1RSMpo4IQD2fRAkygT6Y4ClihvB2+ahIPQXJYoFBNOypf2ADURuqOAVEaz"
    "hePFRZa2F2LWXsvw4LGFgw/NRrh4gJl4s4RZyKZQatrizQNSyxtOOJBNDzRphIsHmIk3CbN40yScDzPh4gEnlNIDSeHWXpDKaLZw"
    "vGAh2l6ALaKWRDSPLQQXBzSpQpX2IjWi2cIBsqGDLlEuqhVFKqPhxAPZ9EATqlDFA1LDYQsHD026qOKWSjQEcEIHXbK0ClTxgFRG"
    "s4XjBSfQg4ssbaS8+djCrQegSTiyFA9Sy5stHCCb9uJrGR7oktEs4wDZ9ECTimIZHpBa3mzh4CEqBl1VYCbM4u0ED0CTcLCFB6Qy"
    "mi0cLzAxOoKLLAUPvrZw6wFoEg7L8ECXBBjhIJsevKmCKB6QGtFbOEA2PdAkHJbhAbokwPDgS1QVKoplRDRvJz24aBIOalrepDKa"
    "LRwvLgtrL0CWggdfWwigA9AkHJbhAalA4IBsenARVa0WxQNSGb0lHGTTA03CYRkeQCoQOH8iJkp5L2MWj5MeXDQJB5bhQSqj2cLx"
    "4iabmoAtwIOvLRx8aBIOy/BAVzc4N9n0AMSsq2oZHmAmo7ccgGx6oEk4LMMDdHWD83+oKR7LiGjeTnpw0SQcZGlFkcpotnC8LADZ"
    "1AQxaySi+djCwYcm4bAMD1Jn8SGbHoAm4bAMD2DLkOQAZNMDTcJhGR6QOpo/E+0CbOFhJszi7aQHF03CwRYekMpotnC8zgnIoibY"
    "amdJRPPYwuRWoEk4LMODVA8+ZNMD0KQcMcUD2OImNQHZ9ECTcFiGB6R68CdiVgGYthepeAMFJz24yNIKMMUDUvFgGfN18ghHzMJZ"
    "hgePLbz1AE3CYRkeLBVvboVsegC6hGoDPIBlwMFFNj3QJBzMxAOW4c2tuEkKb+0FZsJtNCc9uOkSbu0FqTCaLbw2AnQ52OoIzMSD"
    "xxbeeoAm4bAMD0jlcSCbHlx0CQ2CB5ctcHCRTQ80CQcx8wBSeRy86UKgieCyVKCZzUkP3nQhNBHAMhhNKi/Y0BPQRQRghhdvKbz1"
    "BF2UgxleyBIuAgeS9OSmiwgzvLikwOAiSU90UQ5meIEkN4GDD10QwcdSZgObnnzoIoK3pcyGzYsfSZ0FbOHgJ2TpaOCEg9/y4ieW"
    "MQvYwsFPpDILOOnBb3nxI6k8Dn4mlcfB73nxPyB7NP9VqTUBW7xYAkx+aQlvFfwWLf6eGpcK/oHUmoAtXroE8Gp+YQtvNfnXqSmX"
    "iuLvpdYEbPE6eZvFL2zhrSb/ulTeevD3UmsCtnhxkQ3hsCUcUmvy2BLOR2pNtoTz2MLNQzazNBmNJnhwWdYD0GQWspkF52hkM4ub"
    "LW49eKTW5E+2hAPLepBaE7AFo7mk1gRs8eIiG8JhSzhkV/HYEs5HajdKlwOy0MDAq2UzMWW0mkJ3OyzrAWgy6/9RB/fGluY4okX3"
    "iaApEGgKBJoCgaZAgCkUYAoFmELhfT/39mR15VTly4qeiF4L2YyEk4CSkYAZ4UB1Xktz8E0cpXKCW3XXisRFBDISWJoDMOfDRTYZ"
    "Ca4VqR7Bly0x+bIUEpGaCbrIwJReyCZEillqgEh1cKsO6MpZyGYkHKpAmQHqRCylcvJaWjN5iRkJNcGt5spI2FIFGlGwNAdgzoeL"
    "bEZycat+mMGXLTH5shQabtBAF73QRS9kAzn44lYd3KoDuhogm5FwmAGHGbAlJmyJyZel0Hi5QS9ubsBIYEtM2BITluYAzPmAG/Ti"
    "5sZlBl+2cJsBLM0BmNNAF73QRS9kwwy+uVUHt+pgTgNkMxIOM+AwA1g1YUtMvplziQm4VeflBg2QzUhgS0xYmgMw5wMi4kkkIGYw"
    "s/iyhZpQBSzNAZjTQNQT0JEgm4jiJg4i1UHMcpY5DZDNSDjMgENFwJICjSi+iYhD5QS36rzcaiYgm5HAlsrJ0hyAOR8u4kpMQMxg"
    "JN+2VE5eS3MA5jRAdnIZgGxGclHEE5HqgC56mdUAUWckHGbAoSJgSQGR/GghUjNxq87LrToX2YwEtlCdpTkAcz48tsQE3ICRfNsS"
    "ky9LcwDmNEB2L16yGcllKTTcqgO66GU6AF0wEg4z4DADWDX5CTdouFXn5Vadi2xGAluoztIcgDkfHltiAm7VDzP4siUmX5bmAMxp"
    "oN75JpuRXJbmALfqXGR31xxcZDMSDjPgMANYNfkJN2i4VeflVp2LbIgJW2LC0hyAOZ9FpLgSE1wr8jCDL1sqJ6+lOQBzGujKWbxk"
    "M5LL0qrhKtW5yE6RHFxkMxIOM+AwA1gSwQ9cuInUTNxIAp3gVp2bulTOpcSEpZUTzPkcIsXJSNgSkyWZyWsLNbkkLM0BmNNAF7O4"
    "VclmJBczYbhQnYtsqJxcZDMSDjPgMANYWpNb8nAVbpUT1BQCGeBWnYer1FxUBJhJdTDnc3iMBLbEhKU5eG3hkQOW5gDMaaCLLzNk"
    "M5KbObfqXGRDTG6yGQmHGXCYASzlUZ3XUm4xuejikgPcqvNaymUGF7fqYM6H36LeAV0wg9+yagJu1flHPvwONemAyGIGv8M1J+BW"
    "nX/kw+9Q08FtZSS/Y0sGYFqdf+TDb9HFqxe/ZQuv6vwjH9yAxk/p4tGL/zw3LjP4e+bEBE7MD2YgHYo/0wUFjOI/TlwpZAZ/z5yY"
    "wIn54eIGNP5MFzn4v3GAmXsGf8+cmMCJ+eGiptDAqASjkpeuzOAlGqAClVxEeQRYFiIJqEAloEIWFyURpRJRKlWgkosoryweByLL"
    "MnkYkAWiWSgJqEAlF3NiAifmh8eBhmyqI5vqvHSN5IuuXmyBmFzMeTQ4M3BrgBtUB5YykstioIsc6CLHFojJxZzXDB6H6vyLbGAk"
    "6BrJrgFsgZhczIkJnJgfLqqWGWAqHdmZwUtXZvDSFVCqxAScAjwz4GRRBHiBSUShaiNBTGugixzoorJUiQm46ASHWcnjUJ1vJhZF"
    "FujKoioRU8LICZgTEzgxP1zcmMHFtSN7JF90kYOXLqCrExM4MYETEzjADJA9AzdGguyRoIsc6CIHuoCuTkzgQIMDjS+H6nxbykhu"
    "uoBeoIscW+gF5sQETswPsESYwcUtQUfyRRckMAt0kZEinhM4MYETEzgwqgCtQtQrJ7IrJ7pmFrrIgS4yUsSpAQcaHGh8UdOkJhdx"
    "YVZx00XNBHTNLFXLDMyJCZyYH+AAM7i4cRnJF108eoEucgA7J3BiAicmcKDxL7Kpjmyqo2sk6CIHusgBbKEXBxocaHxzg+pcZFOd"
    "ly5ycNHVC8yJiTkxgRPzAwhsqnORTY3imy5yAgXoIgewcwKHAkZxOdB4uAJCdRCXjq6RoIsc6CIHsIVeiHqBRBT/IpgVNZBNdV66"
    "RnJZSi8wJybmxAROzA+PA42LbKrzL7rIwUsXOYCdEzgU0LkdaNzErECoDizp6BoJusiBLnIAW+gF5gVE8CNXoTqyqc5L10guW+gF"
    "5sTEnJjAifnhcaBxkU11/kXXSL7oIgewcwInJt8ONC6yqY5sqgNLOrpGgi5yoIscwBZ6gXnjz2RTHdlU56VrJJct9AJzYmJOTODE"
    "/GgVcKABIgZRxRddM4uXLnIAOydwYvLtQOMiu3Iim+rAkon4SNBFDnSRA9hCL1St8QdaBbKpjmyq89I1kourzCzMiYk5MYGT8Tkz"
    "gAMNcO3IHskXXeTgpYscwM4JnJh8O9C4yJ4BsqkOLOUyEnSRA13kALbQiwONPzgzQDbVkU11XrpGctNFDsyJiTkxgQOfkwl41gRT"
    "6cjODF66qOBSiS5yADsncDK5VAIHGhfZmSBGdWApVEaBLnKgixzAFnrhopNb8OVkglhmIKYEkAW6RnLTRQWqkYmqZQYc+BweM0A2"
    "1ZFNdV66eOVAFzmAnRM4PGICBxoX2byqA0shBxdd5EAXOYAt9AJzHo0vh8cMLku5jARdI7np4tGLy4EGBz7GIwswKsGo5CXKqxJR"
    "KgElgZMJeOUEo5Kb8aoEVKCSiyiViFIJqBCAKBfVyORhPLK4qHDJAtEsbqI8gpsKASp8+D0nJnCg8U+YM4N/4sPvUJeYwIHGb1kZ"
    "XMw7xT/x4XeYExM40PgtJyYX88Y/8zk8Gj+xhVfjP8+N2wz+nlsvwG3k5/Bo/MQWXo3/PDduM/h7br0At5EfbksbP7GFHPyfMIde"
    "/CK3XoDbyA+3pY2f2EIO/k+YQy9+kVsvwG3kh9vSxmVpL8xn8NpCDl7mvEYC5jOQnYPL4TISXdyqw1Kqg1svwK0XunjNAHTFXEp1"
    "XubQiy+6uDQuS4GYsIVbL8CtF+A28sNtaeOytBfmM3htIQcvc14jAfMZyM7B5XAZiS5u1WEp1cGtF+DWC128ZgC6Yi6lOi9z6MUX"
    "XVwal6VATNjCrRfg1gtwG/lBF4zkthSIybctvBqYQwNz6IX5DGTn4HJy8D9OdS6bDm69ALde6JoB6JoBB2LCqc43NyAHlwMzeC1t"
    "PDady6aDWy/AbeQHXTCS21IgJt+28GpgDg3MoRfmM5Cdg8vJwf841blsOrj1Atx6oWsGoGsGHIgJpzrf3IAcXA7M4LW08dh0LpsO"
    "br0At5Efbksbjy3E5NsWcvAyhwbm0AtzoDqPk4ObLm7VuWw6uPUC3Hqhawagawagi0vjD2TDDDgwg9fSxmUp1blsOrj1AtxGfrgt"
    "bTy2EJNvW8jByxwamEMvzIHqPE4Obrq4Veey6eDWC3Drha4ZgK4ZgC4ujT+QDTPgwAxeSxuXpVTnsung1gtwG/nhtpTqsBSIybct"
    "5OBlDg3MoRfmM/h2cnA5EBNOdS6bbj4DMIde6JoB6JrB/0oX9Dowg9fSxmPTuWw6uPUC3EZ+uC2lOiwFYvJtCzl4mUMDc+iF+Qy+"
    "nRxcDsSEU53LppvPAMyhF7pmALpm8L/SBb0OzOC1tPHYdC6bDm69ALeRn5PDHBqXpb0wn8FrCzl4mUMDc+iF+Qy+nRzcdMVcSnVu"
    "smEGN7de6JoB6JoB6IrJD8x5zQB0wUhuSxuPLTyqgxs0cIPPyWEOjcvSXpjP4LWFHLzMoYE59MJ8Bt9ODm66Yi6lOjfZMIObWy90"
    "zQB0zQB0xeQH5rxmALpgJLeljccWHtXBDRq4wQddMfmB+Qy+HR6Nf2POawacHPyZbJjBza0XumYAumYAunjF5Num880NGpeljW/m"
    "M3htaVyWftAVkx+Yz+Db4dH4N+a8ZsDJwZ/Jhhnc3Hqhawagawagi1dMvm0639ygcVna+GY+g9eWxmXph98gG2YAumbwO04OLgdi"
    "8o98+A2yYQagawa/4+TgciAm/8iH32IOVOe36eLS+Mc+/BZzoDq/TReXxj/2AdnV+bktNP7OoTq6yMHDjZH8ki2Nh2xuMfk3hwbI"
    "Jgc/9Vmg1fkJFxSSwV87VEcXOXi4MZJfsqXxkM2tKoMfLaUBsmsUP/U5QHV+YguPxl87VEcXOXi4MZJfsqXxkE0lomQkPzjQALEK"
    "fu6zQKsDIlSBSBU3WZLcBihVIlQhQhU3EZLboTq6yMHDjZF8UUhAqQJEqgARktuWxkM2OVAXZgAiJBddMEhQqriIUMVFJEFJPiC7"
    "OqCLmOA2g9sWevGQTQ6xI2owAAAgAElEQVRdxMScGdy20IvLoTq6yMHDjZF8OdBANjkA85iAGyO5bGk8ZJMDzJkBLGUksAWojmxy"
    "cDFnBpelvdjS+IDs6lx0EdOcGdy20IuHbF5RDsyApdwacKiOLnLwcGMkjy1cqiM7B2AeEzduvWBL4yGbHGDODNy49WILUB3Z5ABz"
    "LjOApTzaB2RX56KLmOYRxU2WJIObbF5FYsyApbNcaMChOrrIwcONkTy2DFjVkU1M1CUmbpG49IItjYdscoA5M3BjmlCjdMEgkU0O"
    "1IXAaiYshWlCfkB2dS7iWik6g5eZEExANpUgSgamM8AkypyYcKiOLnLwcGMkN/OY4DZDNjkwz0j1moVZRrGl8ZBNDsQ1I9Ulp5rQ"
    "iwMNkE0OzCsT05zFUiLU4QOyq3NTF6iZfHEDBolscoB5ReAWUdxkCQ0O1dFFDh5ujOS2ZXBZ1WVJDsxj4hYJuPRiS+MhmwzUiIkb"
    "I3FjBgcaIJscYhYT3JjBUnqxhQ/Irs7DHGbwL1u4NGSTA8xjghszuG2BBofq6CIHDzdGctvCozq6cmAeEzdevdjSeMjmFRM3RsIW"
    "eh1ogGxy6CImuDGDpfRiCx+QXZ2HOczgRwcasskB5jHBjRks5dHgUB1d5ODhxkhuW3hUR1cOzGPixqsXWxoP2dxiAm6MhC30OtAA"
    "2eTQRUxwYwZL6cUWPiC7Ojd1gRn8SBc5ZJMDzGOCGzPcmIULDQ7V0UUOHm6M5LZlcKtCV0V5zcItklvClsZDNhlQBbgxErbQ60AD"
    "ZJNDFzHBjRkspRdb+IDs6tzMqzQjeVkWcKgumxxgHhPcmLGUXmyhwaE6usjBw42R3LbE5CVmmR4T3HIWry2Nh2xy8HJjJGYSkwMN"
    "kE0OcY0JbsxgKb3Ywgd01ShAzKKcGTxkRQGLHLLJAeYxwY0ZS+klS2hwqI4ucvBwYyS3pYwETUBXlsUEM4kopIAtI7nJJgcvM4lg"
    "Cb04MBJkkwPzjMK1ZrKUXmzhAweqA7qIcmbw2MKrIZscYB4T3JixlF5boMGhOrrIwcONkTy20JDVAV1ATMCNkaxZsIXGTTY5+OLG"
    "MIVeHKCBbHJgDoExA5bSiy18Do8c6IqJOTN4bOHWQDY5wDwmuDGDpTwaHKiOLmJyc+PRiy1cqgO6ICYXN269YAuNm2xy8MWNWy/g"
    "QHVkkwPMucwAltKLLXwOjxzqEhMxm8FDxIVBgmxygHlMcGMGsmQWiwa6qA7mMbm58eiFsoCRXMyJyUXElFkJ6KJxk00OvoiYMiu5"
    "6KI6sskBImpEFLCUXmzh4zwqxMgE1Si+mDC5iFEBYpmgShSYRGEyAacCxDK5qfKIAkyo4CZGJg9VoriZTG5iZPIvqkTxcCoQo4KL"
    "KplcTIjChA//5T78l/vwj8luoIte/P/aEpNf4Vadn/qgQPITItySvyG7gS568RAh+TVbYvJQXlX8gVIFuObkpz4spTo/oYtLdf6G"
    "7Aa66MXDnMav2RKTm2xeM/iDLTEBl8HPfZYI1fkzNWWWWg7+muwGuujFw5zGr9kSk5tsyBCnIvjRlpiASPJznwNU58/MoZc5jb8m"
    "u4EuevEwp/FrtsTkJhticiAmP9oSk7/yAbfq3E4vZDOSmzmNL+qdpdBwg8ZtCzm4yG6gi148zGl80QUzgFUTcKsO6IKRwJaY3GQz"
    "EtgSE3CDXsABqoNbdW6HGVzcqrM0xwfcqnM7M0t2zuJmzkhe6hMXGJhC46JewkxAdgNd9OJhTuMl6imZCYtIcKsOYpYaUbAlJjfZ"
    "jAS2xAQ1hZkFByonuFUHERaRJLgxMK35Abfq3A4zZDde5tCLhy5+0ADZDHEaILuBLnrxMKfxMqctzQFLc4BbdXCrviUmbInJTTYj"
    "gS0xYSmXkXAgJuBWHcy5VQc3Xh9wq85NnUIbLzEjyeCii1moMQvxnAVKoZ6zkN1AF714mNN4mDFTTXKyNAe4ROJakeo5YUtMbrIZ"
    "CUuJiWsFeGWgLjEBt+pgzgDVDm4MUOMDbtV5bAEaX3QBMbnoohe66IVsRvLQRS9kN9BFLx7mNB5Lc4BbdZbmAGfC0hywasKWmNxk"
    "MxIOxOQwA7bEhC0xAbfqYE4Dsw5u1cGcD7hV57GF6vxgC9BAF73QRS9kM5LLUqAXshvoohcPcxqPpTyqg+kAZ8JSHjnYEpObbF4z"
    "4DADWDVhS0zArTpLcwDmNNyqgzkfcKvOYwvV+YGLCA100Qtd9EI2I0FRQemF7Aa66MXDnMZjaRWXmmA2U60mLK3iksGWmNxkQxUQ"
    "CYcZwKoJW2ICbtVZmgMwp+FWHcz5gFt1Hluozh+Y00AXvdBFL2QzEtmM1EUvZDfQRS8e5jQeS3PwxZy2JSYszcFrS0xusiEmr8MM"
    "YNWELTEBt+oszQGY03CrDuZ8wK06jy2Qgx+Z00AXvdBFL2QzUlxnli56IbuBLnrxMKfxWJqDL+a0nVGwNAevLTG5ySaieB1mgGtO"
    "2BITcKvO0hyAOQ236mDOB9yq89gCNH5kTgNd9EIXvZDNSF30Qhe9kN1AF714mNN4LM3BF3PajgCW5uC1JSY32Yzky2EGbIkJW2IC"
    "btVZmgMwp+FWHcz5gFt1boeJ03iZ08CcBrrohS56IZuRuuhlDr2QzUhdMJKbOY3HUmh80QUzgKU5eG2JyU02I/lyIOeGmLAlJuBW"
    "HcxpuFUHt+pgzkcxrUkVnAxMRxU3NR2glgN00Qtd9EI2I8V1lhr0QjYjxZWR3MyZBSSm6ACSiy6YAbhWAFXgWpFcZDOSL65S4WQG"
    "bMlIcKsOajowyQlu1cGcz+ExEk4vZDOShy4u1QFd9EIXvZDNSGTz6IVsRiKbkdzMuVUHdAE5uOiCGVzcuMQE3Kpzkc1Ivi3lMhLY"
    "QnVwqw7oAmICbtXBnI/yqAJNQKniIcItARESREhAqQLlkYBSBUoVNxEeCYhwSS4iUMVFhEsVIEJyU6r4ptyqAAUSREhABKgCREgQ"
    "4cN/uc8BYvJnbjwaf+PEBE5MXm6NX+PW+HJ4xOSPTkz+0ucAMfkzNx6Nv3FiAicmL7fGr3FrfDk8YvJHJyZ/6aNqxOTP3Aa35G+c"
    "mMCJycut8WvcGl9OJLCqBj8w1Zj8pQ9uxOTP3Bq/5MQETkxebo1f49b4cmICBxo/cCMmf+mDGzG5qE7wTF5ujS/ODzK5qHLJBE5M"
    "4MTk5db44twmOExwmODcJuDW+HJiAgcaOLcJuJE1AdUJqHLJBJxH5gc3YnJxa3Bi8nJrfDn8ICYXNy4xgRMTODF5uTW+HG4NDjQ4"
    "0OBwa4Bb48uJCRxocLg1wA1ogFsD3LjEBA6PmB/ciMnFbcCKycttQHI7kKCQoBkJqAEaEzgxgROTl1vjIbKqEGlwoMGBBqcKiCrc"
    "Gl9OTOBAg1MFRBVuVA3ArYGaJmhGwoEEzfjgRkwublxi8nIDGrcDDQ40OND4cmICJyZwYvJyazzciIlbgwMNDjQ4MYETE7fGlxMT"
    "ONDgxAROTNyIycWtwYEGBxocaHDggxsxuZgJVAQvM4QOBQcaHGiwhcZNYMcETkzgxOTl1ni4EYFZL7bQ4FAd2RHAjolb48uJADbV"
    "4cQETkS5EZOLW4NDddhCgwMNDnxwIyaPA40fuAENDjQ40AC3xu0AMYETEzgxebk1Hm68YuLW4MTEjVdM3BpfDo+YwIkJHGhuxOTi"
    "1uDE5OLW4ECDAx/ciMnjQOMHbkCDAw0ONMCtcTtATODEBE5MXm6NhxuvmLg1ODFx4xUTt8aXwyMmcGICB5obMbm4NTgxubg1ONDg"
    "wAc3YvI40PiRYNbgQIMDDXBrsGHAjgmcmMCJycut8XAjgkuBW4MTEzciuBS4Nb6cCC7F5cQETkS5EZOLW4MTk4tbgwMNDnxwIyaP"
    "A40/cmtwoMGBBrg1ONDgxAROTODE5OXWeLgRk5dbgxMTN2Lycmt8OTH5dmICJyZuxOTi1uDE5OLW4ECDAx/ciMlFLUwzkh+5NTjQ"
    "4EAD3BqcjIQTEzgxgROTl1vj4UZMXiIGUYXIisnLLSN5nJh8OzGBExM3YnJxa3CqBiyRBgcaHPjgRkwubs2NmPzIrcGBBgca4Nbg"
    "xAROTODEBE5MXm6Nhxsx+XagcTsxebkRk8eJybcTEzgxcSMmF7cGBxocaHCgwYGPqZIZYKpN1WLyUuGi2uBAgwMNcGtwMgGPCZzM"
    "gJMZPNwmUImqZQLB7UDjdjKBANyIyePE5NvJBCQTVcsMwK2Bi07wrAkHGhz4HG4NDjQ4MXm58WhwoMGBBrg1ODxiAgcaHGg83LjE"
    "BA63xu1A43a4NcCNmDxOTL4dbo3bgQa4NcCNS0zgQIMDn8VtwIIBK4OXKY8BCwYsGIDpgMUjA1gwYMHgYcolA1jcBrcFg9viNgBT"
    "MnisDL4tboPbggGYDsCUSwawYMCCD//lPvyX+/AX3Ebyd3TFBGTn4GU+kl+ztPGSzWUk/+bk4LLp/NSHv+A2kr+jKyYgOwcv85H8"
    "mqWNl2wuI/k3JweXTeenPotLJH+mlpWsmvwlXTEB2Tl4mY/k1yxtPJZIBhiDPzo5uAjFT30Ol5H8ma4ZcHLwl3TFBGTn4GU+kl+z"
    "tPHYQg5Y2vijk4O/8jExGAmIZYJX8HDRGWCVYDJxyASv4OGQCeiKCcjOwct8JC8TIBOM4GIyQRWo4LK08dhCDljauJgAFWBilZlg"
    "BBcTIJOLV6jCB10wEtA1A04ObrJhBq+lnQ0z4OTgJhtmALpiArJz8DIfyWspEBM2ncvSBuZAdS5LG48t5ICljctSIAcsBWLCpnNZ"
    "CsQEZOdwgw+6YCSgKxKsJjdxNLKK29KJopFVq7IKEIesKnTFBGTn4GU+kpuIClBZtelcljYRUaCShKWNxxZywNIGIiqgGVUuWpUB"
    "mw4iKqAZVcjOYSryQReMBHRxaXzTBSO5LaW6LhiJrpi83EaiKyYgOwcv85Hc3EYC5iM3ncvSpismIDsHLG08tpADljYwH4lsmAEn"
    "B5dNB7eR6IKRyM4BSz/ogpGAugCNb+owCwqWFl0XjERXTB5iNhJdMQHZOXiZj+TmNgowG7kZFOLSdUVw2TlgaeOxhZzg0sF8JLKQ"
    "GXBycNl0cBuJLGEksnPA0g+6YCQ3N2j8aCk5YGkvdMFIdMXkpgtGoismIDsHL/OR3Nx4jUR2DreR6OKVA5Y2Hlu4jQTMRwK6ZsDJ"
    "wWXTwW0kYD4S2Tlg6QddMJKbGzR+tJQcsLQXumAkumJy0wUj0RUTkJ2Dl/lIbm68RiI7h9tIdPHKAUsbjy3cRgLmIwFdM+Dk4LLp"
    "4DYSMB+J7Byw9IMuGMnNDRo/EnYOWNoLXTASXTFh0xGzkeiKCcjOwct8JDe3UdwKZOdwG4muCB4FSxuPLeSE4mI+EtA1A04OLpsO"
    "biMB85HIzgFLP+iCkdzcoPFHJwcs7YUuGImumLDp4DYSXTEB2Tl4mY/k5jaSL7JzuI1EV0y+LW08tpCDl/lIQNcMODm4bDq4jQTM"
    "RyI7Byz9oAtGAmpZLlmTmzhEumgOWNoLXTASXTFh08FtJLqqIpGdg5f5SG4iKoOX7CqRkYiIRvJa2nhsIQcv82TilVVwcnDZdHBL"
    "hnhlFbJzwNIPumAkoGvGUnJwkw0zlpIDlvZCF4xEV0zYdHAbiS4YiewcvMxH8lraeMnmMhIwH8lraeOxhRy8zKGzc3A5ObhsOrhB"
    "0xUTkJ0Dln5MDKICxDJNLAcPh0KgApb2Qgyi0BUTTKpSNQox0ZHgFbzMo4BKMKlKHi6aFQWoFsHDZPIwoYKXKhRSwcWpSth0UIVC"
    "MgHZOWDp5/Doxevk4JvbSG5Le/FFV0xAdg5e5iP5gTm3HFxODl66ZvBa2ou/tOm8dMWETedxcnCTnQOWfhaPWbxWTb6ZzuLmMosv"
    "4hmAeE1eapH8QI1bTS6rJi+1SF4us/hLi8FLPAMWg8eqyU28Jrh8+C/34b/cB2RX5+e20Pg7h+roIgcPN0byS7Y0HrK5xeTfHBog"
    "mxz81GeBVucnXFBIBn/tUB1d5ODhxkh+yZbGQza3qgx+tJQGyK5R/NTnANX5iS08Gn/tUB1d5ODhxkh+yZbGQzaViJKR/OBAA8Qq"
    "+LnPAq0OiFAFIlXcZElyG6BUiVCFCFXcREhuh+roIgcPN0byRSEBpQoQqQJESG5bGg/Z5EBdmAGIkFx0wSBBqeIiQhUXkQQl+YDs"
    "6oAuYoLbDG5b6MVDNjl0ERNzZnDbQi8uh+roIgcPN0by5UAD2eQAzGMCbozksqXxkE0OMGcGsJSRwBagOrLJwcWcGVyW9mJL4wOy"
    "q3PRRUxzZnDbQi8esslYQJQDM2AptwYcqqOLHDzcGMljC5fqyM4BmMfEjVsv2NJ4yCYHmDMDN2692AJURzY5wJzLDGApj/YB2dW5"
    "6CKmeURxkyXJ4CYbSoAi/x918G5sWY4rUHCdCJoCgaZAoCkQaAoEmEIBplCAKRTe/pyeuf26oqbUzsSYAUtnudCAQ3V0kYOHGyN5"
    "bBmwqiObmKhLTNwicekFWxoP2eQAc2bgxjShRumCQSKbHKhLhlrNhKUwTcgPyK7ORVwrRWfw2gLBBGRTCaJkYDoDTKLMiQmH6ugi"
    "Bw83RnIzjwluM2STA/OMVK9ZmGUUWxoP2eRAXJmhLjnVhF4caIBscmBeM9U0Z7GUCHX4gOzq3NQFaiYvFwUGiWxygHlF4BZR3GQJ"
    "DQ7V0UUOHm6M5LZlcFnVZUkOzGPiFgm49GJL4yGbDNSoCDdG4sYMDjRANjnELCa4MYOl9GILH5BdnYc5zOA/tnBpyCYHmMcEN2Zw"
    "2wINDtXRRQ4ebozktoVHdXTlwDwmbrx6saXxkM0rJm6MhC30OtAA2eTQRUxwYwZL6cUWPiC7Og9zmMFPBxqyyQHmMcGNGSzl0eBQ"
    "HV3k4OHGSG5beFRHVw5zYuLGqxdbGg/Z3GICboyELfQ60ADZ5NBFTHBjBkvpxRY+ILs6N3WBGfykixyyyQHmMcGNGSydhQsNDtXR"
    "RQ4ebozktmVwq0JXBZ6zcIvklrCl8ZBNBlQBboyELfQ60ADZ5NBFTHBjBkvpxRY+ILs6N/MqzUhelgUcqssmB5jHBDdmqEsvttDg"
    "UB1d5ODhxkhuW2LyErNMjwluOYvXlsZDNjl4uTESM4nJgQbIJoe4xgQ3ZrCUXmzhA7pqFCBmUc4MHrKigEUO2eQA85jgxoyl9JIl"
    "NDhURxc5eLgxkttSRoImoCvLYoKZRBRSwJaR3GSTg5eZRLCEXhwYCbLJgXlG4VozWUovtvCBA9UBXUQ5M3hs4dWQTQ4wjwluzFhK"
    "ry3Q4FAdXeTg4cZIHltoyOqALiAm4MZI1izYQuMmmxx8uTFMoRcHaCCbHJhDYMyApfRiC5/DIwe6YmLODB5buDWQTQ4wjwluzGAp"
    "jwYHqqOLmNzcePRiC5fqgC6IycWNWy/YQuMmmxx8uXHrBRyojmxygDmXGcBSerGFz+GRQ11iImYzeIi4MEiQTQ4wjwluzECWzGLR"
    "QBfVwTwmNzcevVAWDJKLOTG5iJgyKwFdNG6yycGXiCmzkosuqiObHCCiRkQBS+nFFj7Oo0KMTFCN4suEyUWMChDLBFWiwCQKkwk4"
    "FSCWyU2VRxRgUsFDjEweqkRxM5ncxMjkP1SJ4uFUIEYFF1UyuZgQhQkf/uU+/Mt9WEp1fukA1fkfZDfQRS8e5jT+zJaY3GTzmsHf"
    "7AguLoNf+8gSqvMrugoYxe/JbqCLXjzMafyZLTG5yaYAIaL4aWcUYDL5tc8BqvMLuuhlTuP3ZDfQRS8e5jT+zJaY3GQzEg7E5Kct"
    "Mfmdj6NSnZsFiJLFTcwiSpUJIokKlahAcFOhkovsBrroxcOcxpcoZAFaBahUAqKQBWyJyU02I8GNmIAoBBczyUgQreRmZHERrUSl"
    "8gNu1bmdXshmJDdzGl/qnaXQcIPGbQs5uMhuoItePMxpfOmCGcCqCbhVB3TBSGBLTG6yGQlsiQm4QS/gANXBrTq3wwwubtVZmuMD"
    "btW5nYiSPbO4mRNRPHQFKhCoQOPiFiI5AdkNdNGLhzmNl5pOq0hYZIBbdVDT6RkJW2Jyk81IYEtMMBOIKDhQEeBWHVQxsirAjUCl"
    "8gNu1bkdZshuvMyhFw9d/NAA2QxxGiC7gS568TCn8TKnLc0BS3OAW3Vwq74lJmyJyU02I4EtMWEpl5FwICbgVh3MuVUHN14fcKvO"
    "TZ1CGy9RJ8ngoosB4sxCPGeBUqjnLGQ30EUvHuY0HmbMFJecLM0BLpG4VqRaTdgSk5tsRsJSYrI0EpwI1CUm4FYdzBmg2sGNAWp8"
    "wK06jy1A40sXEJOLLnqhi17IZiQPXfRCdgNd9OJhTuOxNAe4VWdpDnAmLM0BqyZsiclNNiPhQEwOM2BLTNgSE3CrDuY0MOvgVh3M"
    "+YBbdR5bqFH8RVhC0UEXvdBFL2QzkourQC9kN9BFLx7mNB5LKRCqg8sAZ8JSCoQcbInJTTYUCDPgMAPEa8KWmIBbddxqFJhXx606"
    "mPMBt+o8tlCdH5YINNBFL3TRC9mMBMFUoBeyG+iiFw9zGo+lFJcaYDpLvCYspbjUYEtMbrKBAmbCYQawasKWmIBbdZbmAMxpuFUH"
    "cz7gVp3HFqrzN+Y00EUvdNEL2YxENiN10QvZDXTRi4c5jcfSHHyZ07bEhKU5eG2JyU02xOR1mAGsmrAlJuBWnaU5AHMabtXBnA+4"
    "VeexhZrJT+Y00EUvdNEL2YwUWRmpi17IbqCLXjzMaTyW5uDLnLaJgKU5eG2JyU02FcHrMAPUasKWmIBbdZbmAMxpuFUHcz7gVp3H"
    "FqDxkzkNdNELXfRCNiN10Qtd9EJ2A1304mFO47E0B1/mtB0BLM3Ba0tMbrIZyddhBmyJCVtiAm7VWZoDMKfhVh3M+YBbdW5mhdJ4"
    "qUCWOQ100Qtd9EI2I3XRS8zoheyZpYuI4mZO47G0Inip6bQIYGkOXlticpPNSL4OGcmWmLAlJuBWHVOJQE1j4lYdzPmAW3Vuh4nT"
    "eJlDL3Ma6KIXuuiFbEbqopc59EI2I3XBSG7mNB5LofGlC2YAS3Pw2hKTm2xG8nUgB1tiwpaYgFt1MKfhVh3cqoM5H0eFIArOTNQj"
    "ipuYkSUSAbrohS56IZuRop6lAr2QzUhRZyQ3c7KAiYpYQAUXXTADUJMEMkFNcnKRzUi+1KUSiyjYUjnBrTqIWaAVCW7VwZzP4TES"
    "Ti9kM5KHLi7VAV30Qhe9kM1IZPPohWxGIpuR3My5VQd0ATm46IIZXNy4xATcqnORzUj+spTLSGAL1cGtOqALiAm4VQdzPsKjAClA"
    "KL6EW3ERChAKEAoQHgUIBQjFS3gUF+FS3ASKm/AoQKC4CcV/CLfiIkCBQHERLgUIFAh8+Jf74AY0/kk2j5H83pkBnBm8lnT+zInJ"
    "y41bdf5uMfitD25A459k8xjJ750ZwJnBa0nnz5yYvNy4VefvFoPf+iCyoPFPsmdxSf6HMwM4M3gt6fyZE5OX2wBMM5L/Etcc/NYH"
    "OND4J9kj+RNnBnBm8FrS+TMnJi+3Brgxg//SRQ5+6wMcaNw8E5XgJXskLxP+K5OLKpdM4MwAzgxeSzovMS4ViFGBGJmocskETkxe"
    "bg1wYwYmXKJAF5VRIBYFYlwyAeeR+QEONC6yZ+DaeckeyWsL/xWTizmXmMCZAZwZvJZ0Xrq45EAXOdBFTMy5xAROTF5uDXBjBku5"
    "jARdwEjQ1Qt0cYkJHB4xP8CBxkV2JCadl+xIqrhsIUEhQTMSUAM0JnBmAGcGryWdh4onSA10kQNdxMQ8gcqEE5OXWwPcmMHSBLIS"
    "XVTNAl29ULUEzUg4kKAZH+BA4yKbS3VesoGRXLbQiy30Ygu9eJ2YwJkBnBm8lnQeSxnJYqCLHOgiJua9wLzBicnLrQFuzGBJB5Z0"
    "dJGDi65ebKEXW+jFgQYHPsCBxkWWADl4yQIZRcEWerGFXiylFxeBHRM4M4Azg9eSzmMpo1g1S11yoKtyinoHzBqcmLzcOuBaM1nS"
    "gSWjdJGDi65ebKlRLKUXBxoc+AAHGg83ZvBfuoCRbKEXW+gF5r24HCAmcGYAZwavJZ3HUl692DXQ1YstvBqcmLzcuFUHlnRgKYNF"
    "Di66erFrcDHvxYEGBz7AgcbDjRn8ly5gJFvoxRZ6gXkvLgeICZwZwJnBa0nnsZRXL3YNdPViC68GJyYvN27VgSUdWMpgkYOLrl7s"
    "GlzMe3GgwYEPcKDxcGMGPwiyRrKFXmyhF5j3YsOAHRM4M4Azg9eSzmMpo7gU7Bro6sUWOreCE5OXW+dWwJIOLBmlixxcdPVi1+Bi"
    "3osDDQ58gAONhxsz+BtdI9lCL7bQC8x7caDBiQmcGcCZwWtJ57GUkbx2DXT1Ygu9eJ2YvNwaf1nSgSUdXeTgoqsXuwYX814caHDg"
    "Axxo3FbilZOfdI1kC73YQi8w78XJSDgxgTMDODN4Lek8ljKSl4pSmaBqvXidqsHDrfGXJR1Y0tFFDi66erGpWbhKLw40OPABDjQu"
    "smduqvOTrpFsoRdb6AXmvTgxgRMTODOAM4PXks5jKSP50kUOLua9eB1oPNwaf1nSgSUdXeTgoqsXW+jFFnpxoMGBj4HDzELFZ7jS"
    "eYlyERvJFnqxhV5g3ouTCXhM4GQGnMzgsSSALEw1Ciq56CIHF/MJVAIHGg+3xl+WBCAViCmRBbp6YapReOWEAw0OfA6PGbgxA9fO"
    "SzaPkWyhF1voBea9ODxiAgcaHKrzWMplJOjikoOLLnJwMecSEzjQeLg1/rKUy0guSxkJunqBLi4xgQMNDnwWj0hMicR08BLnMQsX"
    "ZrFgFqjNYvHIABYMWDB4uHCJBHEuNbmoUZOLGpcMYMHgYTr4iwuXSC4uzAK1WaDGJQNYMGDBh3+5D/9yH37DbST/i66YgOwcvMxH"
    "8meWNl6yuYzk/zk5uGw6v/ThN9xG8r/oignIzsHLfCR/ZmnjJZvLSP6fk+gegGgAACAASURBVIPLpvNLn8Ulkn9Sy0pWTX5LV0xA"
    "dg5e5iP5M0sbjyWSAcbg704OLkLxS5/DZST/pGsGnBz8lq6YgOwcvMxH8meWNh5byAFLG393cvA7HxODkYBYJngFDxedAVYJJhOH"
    "TPAKHg6ZgK6YgOwcvMxH8jIBMsEILiYTVIEKLksbjy3kgKWNiwlQASZWmQlGcDEBMrl4hSp80AUjAV0z4OTgJhtm8Fra2TADTg5u"
    "smEGoCsmIDsHL/ORvJYCMWHTuSxtYA5U57K08dhCDljauCwFcsBSICZsOpelQExAdg43+KALRgK6IsFqchNHI6u4LZ0oGlm1KqsA"
    "cciqQldMQHYOXuYjuYmoAJVVm85laRMRBSpJWNp4bCEHLG0gogKaUeWiVRmw6SCiAppRhewcpiIfdMFIQBeXxl90wUhuS6muC0ai"
    "KyYvt5HoignIzsHLfCQ3t5GA+chN57K06YoJyM4BSxuPLeSApQ3MRyIbZsDJwWXTwW0kumAksnPA0g+6YCSgLkDjL+owCwqWFl0X"
    "jERXTB5iNhJdMQHZOXiZj+TmNgowG7kZFOLSdUVw2TlgaeOxhZzg0sF8JLKQGXBycNl0cBuJLGEksnPA0g+6YCQ3N2j8tJQcsLQX"
    "umAkumJy0wUj0RUTkJ2Dl/lIbm68RiI7h9tIdPHKAUsbjy3cRgLmIwFdM+Dk4LLp4DYSMB+J7Byw9IMuGMnNDRo/LSUHLO2FLhiJ"
    "rpjcdMFIdMUEZOfgZT6SmxuvkcjO4TYSXbxywNLGYwu3kYD5SEDXDDg5uGw6uI0EzEciOwcs/aALRnJzg8ZPws4BS3uhC0aiKyZs"
    "OmI2El0xAdk5eJmP5OY2iluB7BxuI9EVwaNgaeOxhZxQXMxHArpmwMnBZdPBbSRgPhLZOWDpB10wkpsbNP7u5IClvdAFI9EVEzYd"
    "3EaiKyYgOwcv85Hc3EbyJTuH20h0xeQvSxuPLeTgZT4S0DUDTg4umw5uIwHzkcjOAUs/6IKRgFqWS9bkJg6RLpoDlvZCF4xEV0zY"
    "dHAbia6qSGTn4GU+kpuIyuAlu0pkJCKikbyWNh5byMHLPJl4ZRWcHFw2HdySIV5ZhewcsPSDLhgJ6JqxlBzcZMOMpeSApb3QBSPR"
    "FRM2HdxGogtGIjsHL/ORvJY2XrK5jATMR/Ja2nhsIQcvc+jsHFxODi6bDm7QdMUEZOeApR8Tg6gAsUwTy8HDoRCogKW9EIModMUE"
    "k6pUjUJMdCR4BS/zKKASTKqSh4tmRQGqRfAwmTxMqOClCoVUcHGqEjYdVKGQTEB2Dlj6OTx68To5+IvbSG5Le/GlKyYgOwcv85H8"
    "YM4tB5eTg5euGbyW9uK3Np2Xrpiw6TxODm6yc8DSz+Ixi9eqyV9MZ3FzmcWXeAYgXpOXWiQ/qHGryWXV5KUWyctlFr+1GLzEM2Ax"
    "eKya3MRrgsuHf7kP/3IfkF2dX9oCjf/lUB1d5ODhxkj+yJbGQza3mPw/hwbIJge/9Fmg1fkFFwWSwe8dqqOLHDzcGMkf2dJ4yOZW"
    "lcFPS2mA7BrFL30OUJ1f2MKj8XuH6ugiBw83RvJHtjQesqlElIzkhwMNEKvg1z4LtDogQhWIVHGTJcltgFIlQhUiVHETIbkdqqOL"
    "HDzcGMmXQgJKFSBSBYiQ3LY0HrLJgbowAxAhueiCQYJSxUWEKi4iCUryAdnVAV3EBLcZ3LbQi4dscugiJubM4LaFXlwO1dFFDh5u"
    "jOTrQAPZ5ADMYwJujOSypfGQTQ4wZwawlJHAFqA6ssnBxZwZXJb2YkvjA7Krc9FFTHNmcNtCLx6yeUU5MAOWcmvAoTq6yMHDjZE8"
    "tnCpjuwcgHlM3Lj1gi2Nh2xygDkzcOPWiy1AdWSTA8y5zYClfQnQPiC7OhddxDSPKG6yJBncZPMqEmMGLJ3lQgMO1dFFDh5ujOSx"
    "ZcCqjmxioi4xcYvEpRdsaTxkkwPMmYEb04QapQsGiWxyoC4ZasyApSXThPyA7OpcxLVSdAavLRBMQDaVIEoGpjkLkyhzYsKhOrrI"
    "wcONkdzMY4LbDNnkwDwj1WsWZhnFlsZDNjkQ14xUl5wqKr040ADZ5MC8ZqppzmIpEerwAdnVuakL1ExeLgoMEtnkAPOKwI0Z3GQJ"
    "DQ7V0UUOHm6M5LZlcFnVZUkOzGPiFgm49GJL4yGbDNSIiRsjYcsMDjRANjnELCa4MYOl9GILH5BdnYc5zOA/tnBpyCYHmMcEN2Zw"
    "2wINDtXRRQ4ebozktoVHdXTlwDwmbrx6saXxkM0rJm6MhC30OtAA2eTQRUxwYwZL6cUWPiC7Og9zmMFPBxqyyQHmMcGNGSzl0eBQ"
    "HV3k4OHGSG5beFRHVw5zYuLGqxdbGg/Z3GICboyELfQ60ADZ5NBFTHBjBkvpxRY+ILs6N3WBGfykixyyyQHmMcGNGSydhQsNDtXR"
    "RQ4ebozktmVwq0JXBZ6zcIvklrCl8ZBNBlQBboyELTM40ADZ5NBFTHBjBkvpxRY+ILs6N/MqzUhelgUcqssmB5jHBDdmqEsvttDg"
    "UB1d5ODhxkhuW2LyErNMjwluOYvXlsZDNjl4uTEStvTiQANkk0NcY4IbM1hKL7bwAV01ChCzKGcGD1lRwCKHbHKAeUxwY8ZSeskS"
    "Ghyqo4scPNwYyW0pI0ET0JVlMcFMIgopYMtIbrLJwctMIhCXXhwYCbLJgXlG4VozWUovtvCBA9UBXUQ5M3hs4dWQTQ4wjwluzFhK"
    "ry3Q4FAdXeTg4cZIHltoyOqALiAm4MZI1izYQuMmmxx8uTFMoRcHaCCbHJhDYMyApfRiC5/DIwe6YmLODB5buDWQTQ4wjwluzGAp"
    "jwYHqqOLmNzcePRiC5fqgC6IycWNWy/YQuMmmxx8uXHrBRyojmxygDm3GbCUXmzhc3jkUJeYiNkMHiIuDBJkkwPMY4IbM5Als1g0"
    "0EV1MI/JzY1HL5QFg+RiTkwuIqbMSkAXjZtscvAlYsqs5KKL6sgmB4ioEVkFS+nFFj7Oo0KMTFCN4suEyUWMChDLBFWiwCQKkwk4"
    "FSCWyU2VRxRgUsFDjEweqkRxM5ncxMjkP1SJ4uFUIEYFF1UyuZgQhQkf/uU+/Mt9WEp1fukA1fkfZDfQRS8e5jT+zJaY3GTzmsHf"
    "bIkJuAx+7SNLqM6v6CpgFL8nu4EuevEwp/FntsTkJpsChIjipy0xAZPJr30OUJ1f0EUvcxq/J7uBLnrxMKfxZ7bE5CabkXAgJj9t"
    "icnvfByV6twsQJQsbmIWUapMEElUqEQFgpsKlVxkN9BFLx7mNL5EIQvQKkClEhCFLGBLTG6yGQluxAREIbiYSUaCaCU3I4uLaCUq"
    "lR9wq87t9EI2I7mZ0/hS7yyFhhs0blvIwUV2A1304mFO40sXzABWTcCtOqALRgJbYnKTzUhgS0zADXoBB6gObtW5HWZwcavO0hwf"
    "cKvO7USU7JnFzZyI4qErUIFABRoXN6icgOwGuujFw5zGS02nVSQsMsCtOqjp9IyELTG5yWYksCUmmAlEFByoCHCrDqoYWRXgRqBS"
    "+QG36twOM2Q3XubQi4cufmiAbG4NkN1AF714mNN4mdOW5oClOcCtOrhV3xITtsTkJpuRwJaYsJTLSDgQE3CrDubcqoMbrw+4Veem"
    "TqGNl6iTZHDRxQBxZiGes0AB8ZyF7Aa66MXDnMbDjJnikpOlOcAlEteKVKsJW2Jyk81IWEpMlkaCE4G6xATcqoM5A9Pq4MYANT7g"
    "Vp3HFqDxpQuIyUUXvdBFL2QzkocueiG7gS568TCn8ViaA9yqszQHOBOW5oBVE7bE5CabkXAgJocZsCUmbIkJuFUHcxpu1cGtOpjz"
    "AbfqPLZQo/iLsISigy56oYteyGYkF1eBXshuoItePMxpPJZSIFQHlwHOhKUUCDnYEpObbCgQZsBhBojXhC0xAbfquNUoMK+OW3Uw"
    "5wNu1XlsoTo/LBFooIte6KIXshkJgqlAL2Q30EUvHuY0HkspLjXAdJZ4TVhKcanBlpjcZAMFzITDDGDVhC0xAbfqLM0BmNNwqw7m"
    "fMCtOo8tVOdvzGmgi17ooheyGYlsRuqiF7Ib6KIXD3Maj6U5+DKnbYkJS3Pw2hKTm2yIyeswA1g1YUtMwK06S3MA5jTcqoM5H3Cr"
    "zmMLNZOfzGmgi17ooheyGSmyMlIXvZDdQBe9eJjTeCzNwZc5bRMBS3Pw2hKTm2wqgtdhBqjVhC0xAbfqLM0BmNNwqw7mfMCtOo8t"
    "QOMncxroohe66IVsRuqiF7rohewGuujFw5zGY2kOvsxpOwJYmoPXlpjcZDOSr8MM2BITtsQE3KqzNAdgTsOtOpjzAbfq3MwKpfFS"
    "gSxzGuiiF7rohWxG6qKXmNEL2TNLFxHFzZzGY2lF8FLTaRHA0hy8tsTkJpuRfB0yki0xYUtMwK06phKBmsbErTqY8wG36twOE6fx"
    "Mode5jTQRS900QvZjNRFL3PohWxG6oKR3MxpPJZC40sXzACW5uC1JSY32Yzk60AOtsSELTEBt+pgTsOtOrhVB3M+jgpBFJyZqEcU"
    "NzEjSyQCdNELXfRCNiNFPUsFeiGbkaLOSG7mZAETFbGACi66YAagJglkgprk5CKbkXypSyUWUbClcoJbdRCzQCsS3KqDOZ/DYySc"
    "XshmJA9dXKoDuuiFLnohm5HI5tEL2YxENiO5mXOrDugCcnDRBTO4uHGJCbhV5yKbkfxlKZeRwBaqg1t1QBcQE3CrDuZ8hEcBUoBQ"
    "fAm34iIUIBQgFCA8ChAKEIqX8CguwqW4CRQ34VGAQHETiv8QbsVFgAKB4iJcChAoEPjwL/c5QEz+yY1H4384MYETk5db48+4Nb4O"
    "j5j83YnJb30OEJN/cuPR+B9OTODE5OXW+DNuja/DIyZ/d2LyWx9VIyb/5Da4Jf/DiQmcmLzcGn/GrfF1IoFVNfjBVGPyWx/ciMk/"
    "uTX+yIkJnJi83Bp/xq3xdWICBxo/uBGT3/rgRkwuqhM8k5db48v5IZOLKpdM4MQETkxebo0v5zbBYYLDBOc2AbfG14kJHGjg3Cbg"
    "RtYEVCegyiUTcB6ZH9yIycWtwYnJy63xdfghJhc3LjGBExM4MXm5Nb4OtwYHGhxocLg1wK3xdWICBxocbg1wAxrg1gA3LjGBwyPm"
    "BzdicnEbsGLychuQ3A4kKCRoRgJqgMYETkzgxOTl1niIrCpEGhxocKDBqQKiCrfG14kJHGhwqoCowo2qAbg1UNMEzUg4kKAZH9yI"
    "ycWNS0xebkDjdqDBgQYHGl8nJnBiAicmL7fGw42YuDU40OBAgxMTODFxa3ydmMCBBicmcGLiRkwubg0ONDjQ4ECDAx/ciMnFTKAi"
    "eJkhdCg40OBAgy00bgI7JnBiAicmL7fGw40IzHqxhQaH6siOAHZM3BpfJwLYVIcTEzgxcSMmF7cGh+qwhQYHGhz44EZMHgcaP7gB"
    "DQ40ONAAt8btADGBExM4MXm5NR5uvGLi1uDExI1XTNwaX4dHTODEBE5M3IjJxa3BicnFrcGBBgc+uBGTx4HGD25AgwMNDjTArXE7"
    "QEzgxAROTF5ujYcbr5i4NTgxceMVE7fG1+EREzgxgRMTN2JycWtwYnJxa3CgwYEPbsTkcaDxk2DW4ECDAw1wa7BhwI4JnJjAicnL"
    "rfFwI4JLgVuDExM3IrgUuDW+TgSX4nJiAicmbsTk4tbgxOTi1uBAgwMf3IjJ40Dj79waHGhwoAFuDQ40ODGBExM4MXm5NR5uxOTl"
    "1uDExI2YvNwaXycmfzkxgRMTN2JycWtwYnJxa3CgwYEPbsTkohamGclPbg0ONDjQALcGJyPhxAROTODE5OXWeLgRk5eIQVQhsmLy"
    "cstIHicmfzkxgRMTN2JycWtwqgYskQYHGhz44EZMLm7NjZj85NbgQIMDjf+jDo6NJUlyRIveNAtRQLgoIFwUEBAFBERxAqI4AVGc"
    "+JEZ73VV79afqmkbG7M9B8IuOOnASQdOOnDSeYRdfISRzrcDF28nnUcY6XycdL6ddOCkE0Y6t7ALDlxw4IIDFxx4mSpVCaZ6qVo6"
    "DxVuqhccuODABYRdcKqASAdOVcKpSj7CHOhC1aqA5O3AxdupAhIII52Pk863UwVIFapWlUDYBSHqENUOBy448Dq8XXDggpPOI4yP"
    "Cw5ccOACwi44fKQDBy44cPERxi0dOLxdvB24eDu8XUAY6XycdL4d3i7eDlxA2AWEcUsHDlxw4LV4m7BgwqrkYcrHhAUTFkzAdMLi"
    "oxJYMGHB5MOUWyWweJu8LZi8Ld4mYEolH6uSb4u3yduCCZhOwJRbJbBgwoIX/8e9+D/uxb8QNovf0ZUOyK7Jw2IWf2bpxUM2ePK/"
    "nJrcNoNfevEvhM3id3SlA7Jr8rCYxZ9ZevGQDZ78L6cmt83gl16LWxb/m1p1sdr5l3SlA7Jr8rCYxZ9ZevGxRCq7QyZ/d2pyE5pf"
    "eh1us/jfdHnCqcm/pCsdkF2Th8Us/szSi48t1ISlF393avKvvEwMZgFiVRCdfISoJ1gXmDgBVRCdfARUAbrSAdk1eVjM4mECVIGR"
    "3EwcVIFObksvPrZQE5Ze3EyATjCxriowkpsJUMUtOlXhhS6YBejyhFOTN9ngyWPpYIMnnJq8yQZPQFc6ILsmD4tZPJYC6bAZ3JZe"
    "YAH04Lb04mMLNWHpxW0pUBOWAumwGdyWAumA7Jph8EIXzAJ0ZYG18yaBZnXzttRRNKt7dXUDElDdja50QHZNHhazeBNRAbq6N4Pb"
    "0ktEFOiiYOnFxxZqwtILRFRAK7tDtLsSNgNEVEAru5Fd01TkhS6YBejidvFNF8zibSk9dMEsdKXzCJuFrnRAdk0eFrN4C5sFWMza"
    "DG5LL13pgOyasPTiYws1YekFFrOQDZ5wanLbDAibhS6YheyasPSFLpgFaAhw8U0DvKFhaTN0wSx0pfMhZrPQlQ7IrsnDYhZvYbMB"
    "s1mbSSMhQ1cmt10Tll58bKEcQgZYzEIW4gmnJrfNgLBZyBJmIbsmLH2hC2bxFgYXP1tKTVg6Gl0wC13pvOmCWehKB2TX5GExi7cw"
    "HrOQXTNsFrp41ISlFx9beJsFWMwCdHnCqcltMyBsFmAxC9k1YekLXTCLtzC4+NlSasLS0eiCWehK500XzEJXOiC7Jg+LWbyF8ZiF"
    "7Jphs9DFoyYsvfjYwtsswGIWoMsTTk1umwFhswCLWciuCUtf6IJZvIXBxc+EXROWjkYXzEJXOmwGYjYLXemA7Jo8LGbxFjabtwbZ"
    "NcNmoSuTj4alFx9bKIfmZjEL0OUJpya3zYCwWYDFLGTXhKUvdMEs3sLg4u9OTVg6Gl0wC13psBkQNgtd6YDsmjwsZvEWNosvsmuG"
    "zUJXOt+WXnxsoSYPi1mALk84NbltBoTNAixmIbsmLH2hC2YBatUh1c6bBGSFaE1YOhpdMAtd6bAZEDYLXd1ZyK7Jw2IWbyIqk4fs"
    "bpFZiIhm8Vh68bGFmjwsCie6uuHU5LYZEFZMia5uZNeEpS90wSxAl+dSavImGzyXUhOWjkYXzEJXOmwGhM1CF8xCdk0eFrN4LL14"
    "yOY2C7CYxWPpxccWavKwgMGuye3U5LYZEAaXrnRAdk1Y+jIxyE4QqzKxmnwENAKdsHQ0YpCNrnQw6S7VbMREZ0F08rDIBrrApLv4"
    "CNHqbEC1ST5MnA8TOnmoQiOd3ILugs0AVWikCpBdE5a+Dh+jeZyafAubxdvS0XzRlQ7IrsnDYhY/seCtJrdTk4cuTx5LR/MvbQYP"
    "XemwGXycmrzJrglLX4sPbx6rnW+m3ryFePNFohKQaOehlsVP1Hhr57baeahl8Qjx5l9aTB4SlbCYfKx23iTaIeTF/3Ev/o97Hd56"
    "8HtLmcWfsYB0/iFdpPNrSxnNX16Hj2rnd5Yyiz+hJgLdlfwDEijdVPILSxnNX14HCpT24jeWMos/oYuPdP59YsZHOr+wlNH85XXg"
    "Qjb04DeWMos/oYuPdP59unik8wtLGc1fXgcukE0Pbrqoyc0iHQs8eQtjmjKL2xZG83a44PQA2T34oot0voR5QhizWMqspYzm48DF"
    "TXYPZPfgpoua/CUMTx5LmaaM5raFC14HLsCiBxKgdFeCRTcitBdgJpQIs4AwKLyBw7VQMgOl2vnQRTpfwjwhjFkspRChvIEQhWKC"
    "7J6BeHHTRU2+qInQncXNTCgRRkOIQjFfBy7AogcS2o1SEyx4eIKEUiIwCzSkUDyBw1yl4MGtBx9qWtnNR5gnhDGLpUApeIIuCpQL"
    "ZHcGPXjTRWXxsKBbJLNBQygRGA1bCoX5OnCBbHqArpq6qAkWPDwhDKYpzIKljN7CaDjAdfjSg4cuSOcjzBPCmMVSYIbAaLZwweEC"
    "2dx68KYLavKwwDMMT1gK0xRGw5bRB3gduJANPXjooiYWpGOBJ2F4wlJmsZTRsIXRHLjg0ANk9+Chi1s6tzBPCGMWS5kFWxjNlovb"
    "4UI2Pfimi1s6YIEnhOG5lFmwlNE8DrwOFCjtxZsESk0sSEdCPQnDE5Yyi6WMhi2M5jALDj1Adg8eImrQXQlhnhDGLJYyC7Ywmi3F"
    "TbmQTQ++iahBdyUWeEIYnkuZBUsZzVuIwuvwSAdEUANqYkE6WHgShicsZRZLGQ1bGM3hAg49QHYPvqkhQnkT5glhzGIpsyCM0Wzh"
    "cSGbdH5QE4F0LPCEMDyXMguWMhoUFrfX4aMHN1181MSCdLDwJAxPWMosljIatjCawwUceoDsHvzEAtIJ84QwZrGUWcCW0WzhcSG7"
    "B39jAelY4AlheC5lFixlNGzh43Xgkk0PQDY10UVNLEgHC0/C8ISlzGIpo2ELozlcwKEHyO7BzyxIJ8wTwpjFUmbBFkaz5eKL7B78"
    "DxakW+AJYXguZRYsZTRbGM2B14ELC9JBdnuhi5pYkA4WnoThCUuZxVJGwxZGc7iAQw+Q3YOHSgIWpBPmCWHMYimzYAuj2VKTh+we"
    "/A8WpFvgCWF4LmUWLGU0WxjNgdeBC9n0ANntJWbUxIJ0sPDETLJaTJlFqHiiITXhcAGHHiC7Bx9ikoBaexGWBabMYilerSGMZgue"
    "oAWye/BNBGhR60wNKW8JbS8zyWwNYTRbGK0LXgcuZNMDZFNTF9TEgnSw8IQwmKYwC5Yyeguj4XABhx4guwcfunikQxiPWSyFWVtg"
    "NFvggnOB7B580wVVAelggWcYnrCUWUthNFsYfYDXgQtk0wPZPGpiQTpYeEIYj1nAFm6jgcMFHHqA7B586OKRDmE8ZrGUx2hgC28X"
    "yO7BN118pHML4+YJLOUxmi08XgcuwIJ0VKJdjZpYkA4WniBiSlbILEBD8C5uhws49ADZPfgQQY1KukFCycJ0FkvxDvEubsqCSYHs"
    "HnwTQY3Kbm4SSlY3oITgHTIaJcSbxWvRDkjQDhKVElSiRiWoZXEzJcvUm1sI3rwtJrBoB4l2vqlRyYcpWZhmsZRZId48Qpi8rXZ+"
    "okYlDzWyeJjiHeINhExYvPhvWsos/qNeh0c6v7Xa+TNbeEvnH9DFx2h+YWlNfngdGhDKm99Z7fwRWUIjpPMP6KJBGM0vLK3JD6+D"
    "J2yhB7+z2vkTsiGdLen8A7oYbcFofmFpTX54HTwhVHoAokAXIEoiSvKh0qVRzk0UqrmJkoh2gSjJF9lUJUEVqHSBSheIkoh28aEC"
    "yZt2Y1RzE7PMVsV5U6GLhyi5tCZvBtW8Dp5AWA9AF1ATsGC0BRcfYT22pHPTBZ7cLLgI6wEWjOYhG0++LK0JYT3AgouwHnwshYu3"
    "nSmbWdzCevDDUnrwsOBaWpObbEjndfAEwnqAmrpJl4MFiSiZDZgJaaQDagrVnWBBokKCKJnNh2wqi8fSmhDWAyxIVMhsILQLyQZ2"
    "N+bV3MLIbL6ECiTZgKmSKjUBMXMj83XwBMJ6gAXXUnqABY9ZwBbe0oEw3nqABT+bxYdsSOextCaE9QALHqOBLemcWcAWYDRvYTCa"
    "L4cPT2ApbzUBC0ZozdfBE0KlB4hQEtoDLJggwSxYmgWLdAjtBNRqYgHeEpAlwSweGtLN5G1pTQjrARZMbquyJNSrOe0FWyopPkSD"
    "opKbhHrDwhOWdEJITUCEErN6HTxhCz14hPUAC0aji1nIxhO2pMPSmoAFoy1gli7wlM0svmwBRnNbWhPCeoAFFyAbT9nMgoMnbEnn"
    "my4gnZsuZiEbT9iSDktr8sWC14EGobz5WEoPsGA0yJ6FbDxBoh2W1gQsGG3BaHQxC2TjyUPQoMmEpTUhrAdYcAGy8ZQNDYInbEnn"
    "L8ISmgG6mAWyJJ0t6bC0Jh8bgdeBRiCdm9BL6QEWjAbOLGTjCax2WFoTsGC0BRfoYjSwJZ1vGgjpsLQmhPUACy5ANp6yobllwpZ0"
    "frJEYDS6mAVsSWdLOiytyU1YCLwOnrLx5GbBRVgPsGA0cGYhG09gtcPSmoAFoy24QBejgS3p/GRLOiytCWE9wIILkI2nbGbxZUs6"
    "f2MBs3QxC9iSzpZ0WFoTsGC0Ba+DJ0szG7CoSVgPsGA0cGYhG09gtcPSmoAFoy24QBejgS3p/GRJe7O0JoT1AAsuQDaespnFly3p"
    "/I2aMksXs4At6WxJh6U1QcxqYsHr4Alb0gHTCWE9wILRwJmFbDyB1Q5LawIWjLbgAl2MBrak87OlNVlaE8J6gAUXIBtP2cziy5Z0"
    "/k42s3QxC9iSzpZ0WFoTwnqABa+DJ2xJB8wyCesBFowGzixkU1mYlYMZmahpOhZcoIvRwJZ0PoxqMCOTpZ1pJj3AAq8WjcwWs6zi"
    "sSWdLyokiFlm6yKzMesstlQWS2tCWA/UlNfBE7akAxZchPUAC0YDZxayIZ0t6UBYD8J6gAUX6GI0sCWdN9l4wpZ0WEqPLfQAC5il"
    "i9HAlnQeW9L5EtYDLBiNLvCUjSdsoSZLa0JYD5bC6+AJalIOFiQqPcCC0cCZBWbShZEOiFminQUWXKCL0cCWdD7MusEyG9SUNNOb"
    "7wAAIABJREFUNOgBFlAtymhAg4JsYEs6X8QsQSQTRIMuUa8GDelCpSaEkajA6+AJhPUAC956gAWjgTML2MJbOjddQDpgwQW6GA1s"
    "SeexhdssbmG89QALHqO5LQVmAVvS+aaLWw/eDm+juS3lrSaE8XgJNCDQIDwaEJqbNDfh0bwJtwYEGhCam0DzEN6aN+HRYMHgrXkT"
    "bs1NoPmL8Na8CW/Nm/BoEL68+G+y4OI/63X4cvE7smfxZ7Zwm8U/soXbaH5BNj344XX4cvE7smfxZ7Zwm8U/soXbaH5BNj344XVg"
    "AmoXvyN7Fn9CTSuB4p9Q00qg+BXZ9OCH14ELsLj4Hdmz+BO6qMk/pYua/P/Ipgc/vA5cgMUFqHLrBEx4ZIMYbzaLmyq3KiD4SRUP"
    "XdTkIUYnYCSgyofzFrw5BG/Ohy5q8s2EWzY3E8DoAahyq3oduACLC7DgVhPYwmMWyOZjFrcwbp7A4SfpPHRRk4cuagJLBhDGWw/e"
    "Dm8XHN5G86aLmnxbym0Wt6W89QDCuHm+DlygahegBmhlwRYKRJgFsoubzgJUBdCsggMFCgVaWXyoaTsUN13UBJYMIKwAYQAiBohc"
    "cIDuyYeaVhYfIkGDZhWoaYHSAzAF1PN14IIDF1+2MJotjGYps0D2LJA9C2R7AgcuOHDBgQu2MJrHFqjJTRc1gSUDCB1A6ADCLsDi"
    "ggOk820Lo3nTRU1k0wPZ9EA2PfhyPF8HBmx68JAljGYLo1kisxBZs0D2LJDtCRy44NADDlywhdE8liDl0OiiJrBkAKEDCBsNYQMw"
    "u+BAl/NtCd40oKt7IpseyO6eyKYHbwI783X4SOdhAYxmC6NB1yyWMgtkzwLZnsCBC44ncOCCLYzmL1ugJrqoCSwZQOgAwvAkjI8L"
    "Dlz8zRZGg65ZIJseyJ4FsunB2+HtdfhI52EBjGYLo0HXLJYyC2TPAtmewIELjidw4IItjOYvW6AmuqgJLBlA6ADC8CSMjwsOXPzN"
    "FkaDrlkgmx7IngWy6cHb4e11YMBO56YxW5Ywmi2MBl2zWMoskD0LZHsCBy44nsCBC7Ywmr+IBjXRRU1gyQBCBxCGJ2GDt4YDF38j"
    "Gl2Orlkgmx7IngWy6QEbJmx4HbjgpHOzGM0WRrOF0aBrFkuZBbJngWxP4MAFxxM4cMEWRvODLmqii5rAkgGEDiAMT8Iuvhy4+Dtd"
    "1ETXLJBND2TPAtn0gAMXHHgduOB0T8BiNFsYzRZGg65ZqMQskD0LZHc5HLjgeAIHLtjCaH7QRU10URMJYQChAwib3YRdfDlw8U3N"
    "G3RRE13Vjmx6ILvakU0POHDBgdeBCw5cgMVotjCaLYwGXbNA9iyQPQtk0wMOXHA8gQMXbGE0P+iiJrqoiWx6AKEDCB1A2MWXAxff"
    "dI0GXdREFzWRTQ9k0wPZ9IADFxx4HbggRC/AIhsTRrOF0aBrFsjOBrFZQKg4RLXD8QQOXLCF0byJchOrSsSURIweQJgDKgNQbd4S"
    "Dlx805UNYlWJmJKIVSWy6USMHnDAIeB14AIsLsCCj9FsYTTomgWy+ZjFLYybJ3A8gQMXbGE0b7r4mMVtKW89gDDeevB2eLvgwMU3"
    "XXyM5raU2yyQzaMHHL68FkxAbQJqfHgTgjdIeIMEH1ncTLllAasSWDBhgTdvanx4cwvhYwJhxdvkbfE2YcHkmxof3txCuGWBBF8m"
    "LL68+K8KHfxnvfivCh38Z70ON0/+hOya/BnZkM4/pSudX9PlyQ+vw82TPyG7Jn9GNqTzT+lK59d0efLD60Bld8jkt2TX5I8sEkSz"
    "+AcWdIlm8Su6PPnhdSAdtlz8luya/JHNAItZ/ANbqGkxi1/R5ckPr9PZBVsubiZAJzcTF4Ns3lS5WU1uwa0KEKtSBReDbL5tBqhU"
    "Q0AVRCeo8qjiTRWyAdVsE+dji3eJVvOmCnTyESDqCYhxy36dHty2XNyWAjW5bYYumMVbGG81uR1unoDs9DC4dIEn3zaDh2zwhM2A"
    "MB6evFnAaMDCc8vFx5aLH8KAHnwcbp6AbG6jX6cHty0XN1PQ9m7YDAmRrAIRFVCoCYqBSFY3stNNlSkK1cWXLZPiTTZ4wmZAGBSI"
    "eIKCKFQXWGQpzkdIQjdvIiqg7RQoBqgnIMGt+nV6cNty8eVAOmwGWMBodHnCgZqw9AILmIXsdNhCTQgbzWMLNXmTDZ6wGRAGF1h4"
    "woF02HKBBYzm24F03nR5whZqwtILdHnybcvr9OQWMvgQNqTDZoCZMBpdnrCRmrD0Ag1hFrLTYUv3hLDRPJbQDg2ywRM2A8LgAguv"
    "5kA5LLnAgp7Ntw2V0KDLEzZSEwm9QJcnHwJLXoeP0Ty2AOmwGdyWjkaXJyC7Jiy9uIXNQnY6bLm4hY3mL7pgFrLBEzYDwuACC5h1"
    "+HKBhSd/YwGj0eUJyK4ZBhfo8uTNgtvr8DGaxxYgHTaD29LR6PIEZNeEpRe3sFnIToctF7ew0fxFF8xCNnjCZkAYXGABsw5fLrDw"
    "5G8sYDS6PAHZNcPgAl2evFlwe52eEDoaMANvZKXDZnBbOhpdnoDsmrD04hY2C9npsOXiFjaaH8SsmWzwhM2AMLjAwqs5PflosPDk"
    "7yR0NLo8Adk1w+ACXZ6ArEpY8jo9IGw0YAGj0ZUOm8Ft6Wh0eQKya8LSi1vYLGSnw5aLW9hofmIBgw2esBkQBhdYeMLpwTcLT/6H"
    "paPR5QnIrhkGF+jyBGSnw5bX6QEiKhMsYPRC02EzuC0dja5u7xCtCUurXa26G9npsOXiFjaaR+ASIlmFqnmaag8IgwssPEFFK3lY"
    "ePIthEo1kdHo6vYOihIJuUCXJyA73VR5nR7ctlxgAaMPpMNmcFs6Gl0w60BNWEoPC09AdjpsubiFjeaxGbpgFqDLcyk9IAwusPAE"
    "ZKfzsPDk2xZqWsBodMGszeC29AJdnoDs9DB4nR7cTBxUVUaHaDpsBjcTBzGVWQGdYAKNVAGy02HLxS1sNA+TRiAbEKsyoRPC4MKQ"
    "KkCMrubNwpNvJtAIOIhBI53cTJoUqwLEqlRVXqcHPywdja502Ax+CJvFX2Sn8yY7HbZc3MJG80V2Tf6XMLhkp/Ow8OTNwpOf6Ern"
    "29LRPE4Pfrbltdr5IcQbiUpYTH4w9eYvEpW8SVRCyORm6s231c7/EgaXRCUPtSze1LL4iUQl30ImXxaTn4W8+G8Kg4v/qBf/TWFw"
    "8R/1Orz14PeWMos/YwHp/EO6SOfXljKav7wOH9XO7yxlFn9CTQS6K/kHJFC6qeQXljKav7wOFCjtxW8sZRZ/Qhcf6fz7xIyPdH5h"
    "KaP5y+vAhWzowW8sZRZ/Qhcf6fz7dPFI5xeWMpq/vA5cIJse3HRRk5tFOhZ48hbGNGUWty2M5u1wwekBsunBQxfpfAnzhDBmsZRZ"
    "SxnNx4GLm+weyO7BTRc1+UsYnjyWMk0ZzW0LF7wOXIBFDyRA6a4Ei25EaC/ATCgRZgFhUHgDh2uhZAYK6XzoIp0vYZ4QxiyWUohQ"
    "3kCIQjFBds9AvLjpoibfNITuLG5mQokwGkIUivk6cAEWPZDQbpSaYMHDEySUEoFZoCGF4gkc5ioFD249+FDTym4+wjwhjFksBUrB"
    "E3RRoFwguzPowZsuKouHhHaLZDZoCCUCo2FLoTBfBy6QTQ/QVVMXNcGChyeEwTSFWbCU0VsYDQe4Dl968NAF6XyEeUIYs1gKzBAY"
    "zRYuOFwgm1sP3nRBTR4WeIbhCUthmsJo2DL6AK8DF7KhBw9d1MSCdCzwJAxPWMosljIatjCaAxcceoDsHjx0cUvnFuYJYcxiKbNg"
    "C6PZcnE7XMimB990cUsHLPCEMDyXMguWMprHgdeBAqW9eJNAqYkF6UioJ2F4wlJmsZTRsIXRHGbBoQfI7sFDRA26KyHME8KYxVJm"
    "wRZGs6W4KRey6cE3ETXorsQCTwjDcymzYCmj+QiD1+GRDoigBtTEgnSw8CQMT1jKLJYyGrYwmsMFHHqA7B58U0OE8ibME8KYxVJm"
    "QRij2cLjQjbp/KAmAulY4AlheC5lFixlNCiwgNfhowc3XXzUxIJ0sPAkDE9YyiyWMhq2MJrDBRx6gOwe/MQC0gnzhDBmsZRZwJbR"
    "bOFxIbsHf2MB6VjgCWF4LmUWLGU0bOHjdeCSTQ9ANjXRRU0sSAcLT8LwhKXMYimjYQujOVzAoQfI7sHPLEgnzBPCmMVSZsEWRrPl"
    "4ovsHvwPFqRb4AlheC5lFixlNFsYzYHXgQsL0kF2e6GLmliQDhaehOEJS5nFUkbDFkZzuIBDD5Ddg4dKAhakE9ZehDGLpcyCLYxm"
    "S00esnvwP1iQboEnhOG5lFmwlNFsYTQHXgcuZNMDZLeXmFETC9LBwhMzyWoxZRah4omG1ITDBRx6gOwefIhJAmrtRRhZmDKLpXi1"
    "hjCaLXiCFsjuwTcRoEWtMzWkvCW0vcwkqyWE0WxhtC54HbiQTQ+QTU1dUBML0sHCE8JgmsIsWMroLYyGwwUceoDsHnzo4pEOYTxm"
    "sRRmbYHRbIELzgWye/BNF1QFpIMFnmF4wlKYpjCaLYw+wOvABbLpgWweNbEgHSw8IYzHLGALt9HA4QIOPUB2Dz508UiHMB6zWMpj"
    "NLCFtwtk9+CbLj7SuYVx8wSW8hjNFh6vAxdgQToq0a5GTSxIBwtPEDElK2QWoCF4F7fDBRx6gOwefIigRiXdIKFkYToLDfEO8S5u"
    "yoJJgewefBNBjcpubhJKVjeghOAdMholxJvFa9EOSNAOEpUSVKJGJahlcTMly9SbWwjevC0msGgHiXa+qVHJhylZmGahIbNCvHmE"
    "MHlb7fxEjUoeamTxMMU7xBsImbB48d+0lFn8R70Oj3R+a7XzZ7bwls4/oIuP0fzC0pr88Do0IJQ3v7Pa+SOyhEZI598nGjQIo/mF"
    "pTX54XXwhC304HdWO39CNqSzJZ1/XxiMtmA0v7C0Jj+8Dp4QKj0AUaALECURJflQ6dIo5yYK1dxESUS7QJTki2yqkqAKVLpApQtE"
    "SUS7+FCB5E27Maq5hZHZqjhvKnTxECWX1uTNoJrXwRMI6wHoAmoCFoy24OIjrMeWdG66wJObBRdhPcCC0Txk48mXpTUhrAdYcBHW"
    "g4+lcPG2M2Uzi1tYD35YSg8eFlxLa3KTDem8Dp5AWA9QUzfpcrAgESWzATMhjXRATaG6EyxIVEgQJbP5kE1l8VhaE8J6gAWJCpkN"
    "hHYhVMHuxryaWxiZzZdQgSQbMFVSpSYgZm5kvg6eQFgPsOBaSg+w4DEL2MJbOhDGWw+w4Gez+JAN6TyW1oSwHmDBYzSwJZ2DJ2wB"
    "RvMWBqP5cvjwBJbyVhOwYITWfB08IVR6gAgloT3AggkSzIKlWbBIh9BOQK0mFuAtAVn/jze4t5VkyRU1+hWQplAIUyiEKRRoCgWa"
    "EgJNCYGmhPAyq/bun4t+OD0Hg1lLgll8aEg3k8fSmhDWAyyY3FZlSahXc/CELZUUb6JBUclNQr1h4QlLOiGkJiBCiVm9Dp6whR58"
    "hPUAC0aji1nIxhO2pMPSmoAFoy1gli7wlM0svmwBRnNbWhPCeoAFFyAbT9nMgoMnbEnnmy4gnZsuZiEbT9iSDktr8sWC14EGobx5"
    "W0oPsGA0yJ6FbDxBoh2W1gQsGG3BaHQxC2TjyYegQZMJS2tCWA+w4AJk4ykbGgRP2JLOD8ISmgG6mAWyJJ0t6bC0Jm8bgdeBRiCd"
    "m9BL6QEWjAbOLGTjCax2WFoTsGC0BRfoYjSwJZ1vGgjpsLQmhPUACy5ANp6yobllwpZ0frFEYDS6mAVsSWdLOiytyU1YCLwOnrLx"
    "5GbBRVgPsGA0cGYhG09gtcPSmoAFoy24QBejgS3p/GJLOiytCWE9wIILkI2nbGbxZUs6v7GAWbqYBWxJZ0s6LK0JWDDagtfBk6WZ"
    "DVjUJKwHWDAaOLOQjSeotcPSmoAFoy24QBejgS3p/GJJe7O0JoT1AAsuQDaespnFly3p/EZNmaWLWcAmky3psLQmiFlNLHgdPGFL"
    "OmA6IawHWDAaOLOQjSdsSYelNQELRltwgS5GA1vS+dXSmiytCWE9wIILkI2nbGbxZUs6v5PNLF3MAnYmbEmHpTUhrAdY8Dp4wpZ0"
    "wCyTsB5gwWjgzEI2lcWWdDAjEzVNx4ILdDEa2JLOm1ENZmSytDPNpAdY4NWikdlillV8bEnniwoJYpbZushszDJhS2WxtCaE9UBN"
    "eR08YUs6YMFFWA+wYDRwZiEb0tmSDoT1IKwHWHCBLkYDW9J5yMYTtqTDUnpsoQdYwCxdjAa2pPOxJZ0vYT3AgtHoAk/ZeMIWarK0"
    "JoT1YCm8Dp6gJuVgQaLSAywYDZxZYCZdGOmAmCXaWWDBBboYDWxJ582sGyyzQU1Jgx5gAdWijAY0KMgGtqTzRcwSRDJBFKNEvRo0"
    "pAuVmqBqiQq8Dp5AWA+w4NEDLBgNnFnAFh7p3HQB6YAFF+hiNLAlnY8t3GZxC+PRAyz4GM1tKTAL2JLON13cevC2FBjNbSmPmoAF"
    "by+BBgQahI8GhOYmzU34aB7CrQGBBoTmJtB8CI/mIXw0WDB4NA/h1twEmh+ER/Mm3JqH8NHchLcX/0sWXPx3vQ5fLv6J7Fn8nS3c"
    "ZvGvbOE2mj+QTQ9+eh2+XPwT2bP4O1u4zeJf2cJtNH8gmx789DowAbWLfyJ7Fn9DTSuB4t9Q00qg+BPZ9OCn14ELsLj4J7Jn8Td0"
    "UZN/Sxc1+f+RTQ9+eh24AIsLUOXWCZjwkQ1iPGwWN1VuVUDwiyo+dFGTDzE6ASMBVd6cR/BwCB7Omy5q8s2EWzY3E8DoAahyq3od"
    "uACLC7DgVhPYwscskM3bLG5h3DyBwy/S+dBFTT50URNYMoAwHj14HB4XHB6jeeiiJt+WcpvFbSmPHkAYN8/XgQtU7QLUAK0s2EKB"
    "CLNAdnHTWYCaFmhWwYEChQKtLN7UtB2Kmy5qAksGEFaAMAARA0QuOED35E1NK4s3kaBBswrUtEDpAZgC6vk6cMGBiy9bGM0WRrOU"
    "WSB7FsieBbLpAQcuOHDBgQu2MJqPLVCTmy5qAksGEDqA0AGEXYDFBQdI59sWRvPQRU1k0wPZ9EA2PfhyPF8HBmx68CFLGM0WRrNE"
    "ZiGyZoHsWSCbHnDggkMPOHDBFkbzsQQph0YXNYElAwgdQNhoCBuA2QUHupxvS/CmAV3dE9n0QHb3RDY9eAjszNfhLZ0PC2A0WxgN"
    "umaxlFkgexbI9gQOXHA8gQMXbGE0P2yBmuiiJrBkAKEDCMOTMN4uOHDxmy2MBl2zQDY9kD0LZNODx+HxOryl82EBjGYLo0HXLJYy"
    "C2TPAtmewIELjidw4IItjOaHLVATXdQElgwgdABheBLG2wUHLn6zhdGgaxbIpgeyZ4FsevA4PF4HBux0bhqzZQmj2cJo0DWLpcwC"
    "2bNAtidw4ILjCRy4YAuj+UE0qIkuagJLBhA6gDA8CRs8Gg5c/EY0uhxds0A2PZA9C2TTAzZM2PA6cMFJ52Yxmi2MZgujQdcsljIL"
    "ZM8C2Z7AgQuOJ3Dggi2M5idd1EQXNYElAwgdQBiehF18OXDxO13URNcskE0PZM8C2fSAAxcceB244HRPwGI0WxjNFkaDrlmoxCyQ"
    "PQtkdzkcuOB4Agcu2MJoftJFTXRREwlhAKEDCJvdhF18OXDxTc0bdFETXdWObHogu9qRTQ84cMGB14ELDlyAxWi2MJotjAZds0D2"
    "LJA9C2TTAw5ccDyBAxdsYTQ/6aImuqiJbHoAoQMIHUDYxZcDF990jQZd1EQXNZFND2TTA9n0gAMXHHgduCBEL8AiGxNGs4XRoGsW"
    "yM4GsVlAqDhEtcPxBA5csIXRPES5iVUlYkoiRg8gzAGVAag2j4QDF990ZYNYVSKmJGJViZiSiNEDDjgEvA5cgMUFWPA2mi2MBl2z"
    "QDZvs7iFcfMEjidw4IItjOahi7dZ3Jby6AGE8ejB4/C44MDFN128jea2lNssbkt59IDDl9eCCahNQI03b0LwBglvkOAti5sptyxg"
    "VQILJizw5qHGmze3EN4mEFY8Jo/FY8KCyTc13ry5hXDL4hbC24TFlxf/U6GD/64X/1Ohg/+u1+Hmyd+QXZO/IxvS+bd0pfNnujz5"
    "6XW4efI3ZNfk78iGdP4tXen8mS5PfnodqOwOmfyTJVKTv7JIEM3iX1jQJZrFn+jy5KfXgXTYcvFPDtTkr2wGWMziX9hCTYtZ/Iku"
    "T356nc4u2HJxMwE6uZm4GGTzUAWDmtyCWxUgVqUKLgbZfNsMUKmGgCqITlDlowoQ45YNqGabOG9bvEu0mocq0MlbgKgnIMYt+3V6"
    "cNtycVsK1OS2GbpgFo8wHjW5HW6egOz0MLh0gSffNoMP2eAJmwFhfHgCsrmNBiw8t1y8bbn4KQzowdvh5gnI5jb6dXpw23JxMwVt"
    "74bNkBDJKhBRAYWaoBiIZHUjO91UmaJQXXzZMikessETNgPCoEDEE1SiG6oLLLIU5y0koZuHiApoOwWKAeoJSHCrfp0e3LZcfDmQ"
    "DpsBFjAaXZ5woCYsvcACZiE7HbZQE8JG87GFmjxkgydsBoTBBRaecCAdtlxgAaP5diCdhy5P2EJNWHqBLk++bXmdntxCBm/ChnTY"
    "DDATRqPLEzZSE5ZeoCHMQnY6bOmeEDaajyW0Q4Ns8ITNgDC4wMKrOVAOSy6woGfzbUMlNOjyhI3UREIv0OXJm8CS1+FtNB9bgHTY"
    "DG5LR6PLE5BdE5Ze3MJmITsdtlzcwkbzgy6YhWzwhM2AMLjAAmYdvlxg4clvLGA0ujwB2TXD4AJdnjwsuL0Ob6P52AKkw2ZwWzoa"
    "XZ6A7Jqw9OIWNgvZ6bDl4hY2mh90wSxkgydsBoTBBRYw6/DlAgtPfmMBo9HlCciuGQYX6PLkYcHtdXpC6GjADLyRlQ6bwW3paHR5"
    "wkZqwtKLW9gsZKfDlotb2Gh+ErNmssETNgPC4AILr+b05K3BwpPfSehodHkCsmuGwQW6PAFZlbDkdXpA2GjAAkajKx02g9vS0ejy"
    "hAM1YenFLWwWstNhy8UtbDS/sIDBBk/YDAiDCyw84fTgm4Un/8fS0ejyBGTXDIMLdHkCstNhy+v0ABGVCRYweqHpsBnclo5GV7f3"
    "gZqwtNrVqruRnQ5bLm5ho/kIXEIkq1A1T1PtAWFwgYUnqGglHxaefAuhUk1kNLq6vYOiREIu0OUJyE43VV6nB7ctF1jA6APpsBnc"
    "lo5GF8w6UBOW0sPCE5CdDlsubmGj+dgMXTAL0OW5lB4QBhdYeAKy0/mw8OTbFmpawGh0wazN4Lb0Al2egOz0MHidHty2XKCqMjpE"
    "02EzuJk4iKnMCugEE2ikCpCdDlsubmGj+TBpsepsQJenCZ0QBheGVAFidDUPC0++mUAj4CAGjXRyM2lSrAoQq1JVeZ0e3LZc3JaO"
    "Rlc6bAY/hc3iB9npPGSnw5aLW9hovsiGdB66PPkIg0t2Oh8WnjwsPPmFrnS+LR3Nx+nBr7a8Vju3kMktxBuJSlhMfjL15geJSh4S"
    "lRAyuZl6821BJQ+1Sj7C4JKo5EMti4daFr+QqORbyOTLYvKrkBf/S2Fw8V/14n8pDC7+q16HRw/+2VJm8XcsIJ1/SRfp/NlSRvPD"
    "6/BW7fyTpczib6iJQHcl/4IESjeV/MFSRvPD60CB0l78g6XM4m/o4i2d/5yY8ZbOHyxlND+8DlzIhh78g6XM4m/o4i2d/5wuPtL5"
    "g6WM5ofXgQtk04ObLmpys0jHAk8eYUxTZnHbwmgehwtOD5BNDz50kc6XME8IYxZLmbWU0bwduLjJ7oHsHtx0UZMfwvDkYynTlNHc"
    "tnDB68AFWPRAApTuSrDoRoT2AsyEEmEWhCgU3sDhWiiZgUI6b7pI50uYJ4Qxi6UUIpQ3EKJQTJDdMxAvbrqoyTcNoTuLm5lQIoyG"
    "EIVivg5cgEUPJLQbpSZY8OEJEkqJwCxYSqF4Aoe5SsGDWw/e1LSym7cwTwhjFkuBUvAEXRQoF8juDHrw0EVl8SGh3SKZDRpCicBo"
    "2FIozNeBC2TTA3TV1EVNsODDE8JgmsIsWMroLYyGA1yHLz340AXpvIV5QhizWArMEBjNFi44XCCbWw8euqAmHxZ4huEJS2GawmjY"
    "MvoArwMXsqEHH7qoiQXpWOBJGJ6wlFksZTRsYTQHLjj0ANk9+NDFLZ1bmCeEMYulzIItjGbLxe1wIZsefNPFLR2wwBPC8FzKLFjK"
    "aD4OvA4UKO3FQwKlJhakI6GehOEJS5nFUkbDFkZzmAWHHiC7Bx8iatBdCWGeEMYsljILtjCaLcVNuZBND76JqEF3JRZ4QhieS5kF"
    "SxnNWxi8Dh/pgAhqQE0sSAcLT8LwhKXMYimjYQujOVzAoQfI7sE3NUQob8I8IYxZLGUWhDGaLXxcyCadn9REIB0LPCEMz6XMgqWM"
    "BgUW8Dq89eCmi7eaWJAOFp6E4QlLmcVSRsMWRnO4gEMPkN2DX1hAOmGeEMYsljIL2DKaLXxcyO7BbywgHQs8IQzPpcyCpYyGLby9"
    "Dlyy6QHIpia6qIkF6WDhSRiesJRZLGU0bGE0hws49ADZPfiVBemEeUIYs1jKLNjCaLZcfJHdg//DgnQLPCEMz6XMgqWMZgujOfA6"
    "cGFBOshuL3RREwvSwcKTMDxhKbNYymjYwmgOF3DoAbJ78KGSgAXphLUXYcxiKbNgC6PZUpMP2T34PyxIt8ATwvBcyixYymi2MJoD"
    "rwMXsukBsttLzKiJBelg4YmZZLWYMotQ8URDasLhAg49QHYP3sQkG1FrL8LIwpRZLMWrNYTRbMETtEB2D76JAC1qnakh5S2h7WUm"
    "WS0hjGYLo3XB68CFbHqAbGrqgppYkA4WnhAG0xRmwVJGb2E0HC7g0ANk9+BNF2QHpEMYH7NYCrO2wGi2wAXnAtk9+KYLqgLSwQLP"
    "MDxhKUxTGM0WRh/gdeAC2fRANh81sSAdLDyf7O6xAAAgAElEQVQhjI9ZwBZuo4HDBRx6gOwevOniIx3C+JjFUj5GA1t4XCC7B990"
    "8ZbOLYybJ7CUj9Fs4eN14AIsSEcl2tWoiQXpYOEJIqZkhcwClBDv4na4gEMPkN2DNxHUqKQbJJQsTGexFO8Q7+KmLJgUyO7BNxHU"
    "qOzmJqFkdQNKCN4ho1FCvFm8Fu2ABO0gUSlBJWpUgloWN1OyTL15hHjzWExg0Q4S7XxTo5I3U7IwzWIps0K8+Qhh8ljt/EKNSj7U"
    "yOLDFO8QbyBkwuLF/9JSZvFf9Tp8pPOPVjt/ZwuPdP4FXbyN5g+W1uSn16EBobz5J6udvyJLaIR0/nOiQYMwmj9YWpOfXgdP2EIP"
    "/slq52/IhnS2pPOfC4PRFozmD5bW5KfXwRNCpQcgCnQBoiSiJG8qXRrl3EShmpsoiWgXiJJ8kU1VElSBSheodIEoiWgXbyqQPLQb"
    "o5pbGJmtivNQoYsPUXJpTR4G1bwOnkBYD0AXUBOwYLQFF29hPbakc9MFntwsuAjrARaM5kM2nnxZWhPCeoAFF2E9eFsKF4+dKZtZ"
    "3MJ68NNSevBhwbW0JjfZkM7r4AmE9QA1dZMuBwsSUTIbMBPSSAfUFKo7wYJEhQRRMps32VQWH0trQlgPsCBRIbOB0C6EKtjdmFdz"
    "CyOz+RIqkGQDpkqq1ATEzI3M18ETCOsBFlxL6QEWfMwCtvBIB8J49AALfjWLN9mQzsfSmhDWAyz4GA1sSefgCVuA0TzCYDRfDm+e"
    "wFIeNQELRmjN18ETQqUHiFAS2gMsmCDBLFiaBYt0CO0E1GpiAd4SkCXBLD40pJvJY2lNCOsBFkxuq7Ik1Ks5eMKWSoo30aCo5Cah"
    "3rDwhCWdEFITEKHErF4HT9hCDz7CeoAFo9HFLGTjCVvSYWlNwILRFjBLF3jKZhZftgCjuS2tCWE9wIILkI2nbGbBwRO2pPNNF5DO"
    "TRezkI0nbEmHpTX5YsHrQINQ3rwtpQdYMBpdzEI2nrAlHZbWBCwYbcFodDELZOPJh6BBkwlLa0JYD7DgAmTjKRsaBE/Yks4PwhKa"
    "AbqYBbIknS3psLQmbxuB14FGIJ2b0EvpARaMRpbMQjaesCUdltYELBhtwQW6GA1sSeebBkI6LK0JYT3AgguQjadsaG6ZsCWdXywR"
    "GI0uZgFb0tmSDktrchMWAq+Dp2w8uVlwEdYDLBgNnFnIxhO2pMPSmoAFoy24QBejgS3p/GJLOiytCWE9wIILkI2nbGbxZUs6v7GA"
    "WbqYBWxJZ0s6LK0JWDDagtfBk6WZDVjUJKwHWDAaOLOQjSdsSYelNQELRltwgS5GA1vS+cWS9mZpTQjrARZcgGw8ZTOLL1vS+Y2a"
    "MksXs4BNJlvSYWlNELOaWPA6eMKWdMB0QlgPsGA0cGYhG0/Ykg5LawIWjLbgAl2MBrak86ulNVlaE8J6gAUXIBtP2cziy5Z0fieb"
    "WbqYBexM2JIOS2tCWA+w4HXwhC3poCaZhPUAC0YDZxayqSy2pIMZmahpOhZcoIvRwJZ03oxqMCOTpZ1pJj3AAq8WjcwWs6ziY0s6"
    "X1QgEbPM1kVmY5YJWyqLpTUhrAdqyuvgCVvSYSlchPUAC0YDZxayIZ0t6UBYD8J6gAUX6GI0sCWdh2w8YUs6LKXHFnqABczSxWhg"
    "SzofW9L5EgajLRiNLvCUjSdsoSZLa0JYD5bC6+AJalKOmpKo9AALRiNms8BMujDSATFLtLPAggt0MRrYks6bWTdYZoOakq3aAyyg"
    "WpTRgAYF2cCWdL6IGdUimSCKUaJeDRrShUpNULVEBV4HTyCsB1jw6AEWjEYXs4AtPNK56QLSAQsu0MVoYEs6H1u4zeIWBsOsB1jw"
    "MZrbUmAWsCWdb7q49eBtKTCa21IeNQEL3l4CDQg0CB8NCA0IzU34aB7CrQGBBoTmJtB8CI/mIUALNFgweDQP4dbcBJofhEfzJtya"
    "h/DR3IS3F/9LFlz8d70OXy7+iexZ/J0t3Gbxr2zhNpo/kE0Pfnodvlz8E9mz+DtbuM3iX9nCbTR/IJse/PQ6MAG1i38iexZ/Q00r"
    "geLfUNNKoPgT2fTgp9eBC7C4+CeyZ/E3dFGTf0sXNfn/kU0PfnoduACLC1Dl1gmY8JENYjxsFjdVblVA8IsqPnRRkw8xOgEjAVXe"
    "nEfwcAgezpsuavLNhFs2NxPA6AGocqt6HbgAiwuw4FYT2MLHLJDN2yxuYdw8gcMv0vnQRU0+dFETWDKAMB49eBweFxweo3nooibf"
    "lnKbxW0pjx5AGDfP14ELVO0C1ACtLNhCgQizQHZx01mAmhZoVsGBAoUCrSze1LQdipsuagJLBhBWgDAAEQNELjhA9+RNTSuLN5Gg"
    "QbMK1LRA6QGYAur5OnDBgYsvWxjNFkazlFkgexbIngWy6QEHLjhwwYELtjCajy1Qk5suagJLBhA6gNABhF2AxQUHSOfbFkbz0EVN"
    "ZNMD2fRANj34cjxfBwZsevAhSxjNFkazRGYhsmaB7Fkgmx5w4IJDDzhwwRZG87EEKYdGFzWBJQMIHUDYaAgbgNkFB7qcb0vwpgFd"
    "3RPZ9EB290Q2PXgI7MzX4S2dDwtgNFsYDbpmsZRZIHsWyPYEDlxwPIEDF2xhND9sgZrooiawZAChAwjDkzDeLjhw8ZstjAZds0A2"
    "PZA9C2TTg8fh8Tq8pfNhAYxmC6NB1yyWMgtkzwLZnsCBC44ncOCCLYzmhy1QE13UBJYMIHQAYXgSxtsFBy5+s4XRoGsWyKYHsmeB"
    "bHrwODxeBwbsdG4as2UJo9nCaNA1i6XMAtmzQLYncOCC4wkcuGALo/lBNKiJLmoCSwYQOoAwPAkbPBoOXPxGNLocXbNANj2QPQtk"
    "0wM2TNjwOnDBSedmMZotjGYLo0HXLJYyC2TPAtmewIELjidw4IItjOYnXdREFzWBJQMIHUAYnoRdfDlw8Ttd1ETXLJBND2TPAtn0"
    "gAMXHHgduOB0T8BiNFsYzRZGg65ZLGUWyJ4FsrscDlxwPIEDF2xhND/poia6qImEMIDQAYTNbsIuvhy4+KbmDbqoia5qRzY9kF3t"
    "yKYHHLjgwOvABQcuwGI0WxjNFkaDrlksZRbIngWy6QEHLjiewIELtjCan3RRE13URDY9gNABhA4g7OLLgYtvukaDLmqii5rIpgey"
    "6YFsesCBCw68DlwQohdgkY0Jo9nCaNA1C1PNBrFZQKg4RLXD8QQOXLCF0TxEuYlVJWJKIkYPIMwBlQGoNo+EAxffdGWDWFUipiRi"
    "VYmYkojRAw44BLwOXIDFBVjwNpotjAZds0A2b7O4hXHzBI4ncOCCLYzmoYu3WdyW8ugBhPHowePwuODAxTddvI3mtpTbLG5LefSA"
    "w5fXggmoTUCNN29C8AYJb5DgLYubKbcsYFUCCyYs8Oahxps3txDeJhBWPCaPxWPCgsk3Nd68uYVwy+IWwtuExZcX/1Ohg/+uF/9T"
    "oYP/rtfh5slfOFCTv6UrnX9LVzp/psuTn16Hmyd/4UBN/paudP4tXen8mS5PfnodqOwOmfyTAzX5K4uJimbxLyzoEs3iT3R58tPr"
    "QDpsufgnB2ryVzYDLGbxL2yhpsUs/kSXJz+9TmcXbLm4mQCd3ExcDLJ5qIJBTW7BrQoQq1IFF4Nsvm0GqFRDQBVEJ6jyUQWIccsG"
    "VLNNnLct3iVazUMV6OQtQNQTEOOW/To9uG25uC0FanLbDF0wi0cYj5rcDjdPQHZ6GFy6wJNvm8GHbPCEzYAwPjwB2dxGAxaeWy7e"
    "tlz8FAb04O1w8wRkcxv9Oj24bbm4mYK2d8NmSIhkFYiogEJNUAxEsrqRnW6qTFGoLr5smRQP2eAJmwFhUCDiCSrRDdUFFlmK8xaS"
    "0M1DRAW0nQLFAPUEJLhVv04PblsuvhxIh80ACxiNLk84UBOWXmABs5CdDluoCWGj+dhCTR6ywRM2A8LgAgtPOJAOWy6wgNF8O5DO"
    "Q5cnbKEmLL1AlyfftrxOT24hgzdhQzpsBpgJo9HlCQdqwtILNIRZyE6HLd0TwkbzsYR2aJANnrAZEAYXWHg1B8phyQUW9Gy+baiE"
    "Bl2esJGaSOgFujx5E1jyOryN5mMLkA6bwW3paHR5woGasPTiFjYL2emw5eIWNpofdMEsZIMnbAaEwQUWMOvw5QILT35jAaPR5QnI"
    "rhkGF+jy5GHB7XV4G83HFiAdNoPb0tHo8oQDNWHpxS1sFrLTYcvFLWw0P+iCWcgGT9gMCIMLLGDW4csFFp78xgJGo8sTkF0zDC7Q"
    "5cnDgtvr9ITQ0YCZl4CsdNgMbktHo8sTDtSEpRe3sFnIToctF7ew0fwkZs1kgydsBoTBBRZezenJW4OFJ7+T0NHo8gRk1wyDC3R5"
    "ArIqYcnr9ICw0YDFLEBXOmwGt6Wj0eUJB2rC0otb2Cxkp8OWi1vYaH5hAYMNnrAZEAYXWHjC6cE3C0/+j6Wj0eUJyK4ZBhfo8gRk"
    "p8OW1+kBIioTLArvhabDZnBbOhpd3d4HasLSaler7kZ2Omy5uIWN5iNwsMgqVM3TVHtAGFxg4QkqWsmHhSffQqhUExmNrm7voCiR"
    "kAt0eQKy002V1+nBbcsFFjD6QDpsBrelo9EFsw7UhKX0sPAEZKfDlotb2Gg+NgMsZgG6PJfSA8LgAgtPQHY6HxaefNtCTQsYjS6Y"
    "tRncll6gyxOQnR4Gr9ODm4mDqsroEE2HzeBm4iCmMiugE0ygkSpAdjpsubiFjebDpLtUswGxKhM6IQwuDKkCxP4fcXBsJEuuK1p0"
    "V0SaAoGmQKApEGAKBZhCAaZQgCkUfjKruk+/mL7anD9rUVkcNjz4YgKFgIMYFFLBzaQIsUxALFNV5bWr8cfUVugMh0Xjj2E9+SYr"
    "nENWOCy5uA1rxYes7PzDMLhkhfNmw4PDhgc/6Azny9RWvO1q/LTkNcv5Y4gXMjJg0vnD1ItvMjI4ZGTAkM7N1Isvs5x/GAaXjAze"
    "1CI51CL5QUYGX4Z0Piadn4a8+P9pGFz8q178/zQMLv5VLzYPD36jEzz4q4bxJZxhtOKHJVz8T6/Nmwe/0Al48FcN40s4w2jFD0u4"
    "+M2wVrw2bx78QifgwV81jC/hIBQ/LeHiN1Nb8dpU51b8RmeWlSd/k3BbVAeKf1jCxS9s0IrXphpvU2igAzx50xk16MlDJhE8Fuk8"
    "htJ4mEEvbjKJ4G2RzmNKQ2bmAE9gSnW+LKnGYUYvDh14whIuQAee3Cadm5lQ8NpU402HZEcnEcVDpkSY9eQmQ4SqSJgoZAaYKiQd"
    "0CFQ1ZEhQhWRMFGqMrgtuZiaboYHsKnGlyXVOIbRCmQgQnmyhAt0SETBECXL0SEcr001PpZUQ2d68SaL8GHVC5jKLaIYxq16YSbc"
    "qoEO4eaBLI6IYhhHRQBLEiW7DTxgWHnyZUk1jmG0gqkcHizhQoamFwzjVhEylOO1qQQyAZ1EDA3nQ1Z5DqMnsKmALMwEh0p0SBQM"
    "wrFBFARMrQCyYAmOGOUJS8CplKHpxZJqfFtSjWMYrZAFmZDFEi4Zml5gJg6M7MhQHF6bR0YCG1LLk4+p2RlGTxhGdo6peHDYoCfY"
    "qIYNPDhsVASHDbgQMzxgCR7cbNCTJdX4tqQaxzBaMYzy5FjCJYtwYGo4yCpPhtGKl3FTxQOwAYTzIYvsqGl6sSlPjqlcPGyQBVg1"
    "bJAVBciiMhNYggfoxAOWcHHYoCdLPPi2pBrHMFqxKU8eSwisPIGpwc0IZxiteHHYwIPbhvLkQxYVoEorNtV4TOXiYYO3ashQiMqC"
    "YZCZxRIuQCcesISLQ4f0tMHFH0uqcQyjFZtqvC3hVp6gQ3gLZxiteHHYIL2ADeXJhyw+WrGpxmMqFw8bZHGrAFUVCAcxUUivJVyA"
    "TjxgCRePYRFTuPhjSTWOYbRiU423JRzhMAyCI5NhtOLFYYP0Ap1AOB82+GjFpjw5pnLxsEFPvpmo0AoQU6HnEnqCTjxgCRePYfQh"
    "4fyxpBrHMFqxKU8eSyBE0wszoRVvw2jFSxOwgQewSTS9eNtUcRPxYCrZOabSk8MGEcVDKJhKKzTBBj2HwYWY4QFLuHiYiZtc/LCk"
    "GscwWjGV6sWxhGo6CYeptOJtGB68dgfU8ACd1XSSXjw22blNpRWbcqBqGHSgykzwAhJMA0xppcNBjZ4soSOD8oQlXLwNAy5+WFKN"
    "YxitkAUZUMUSssuU9GIYnVsVmAler82jPJEp2WUK4RyyCOc2lVYs4fBgGEd2zIRbNbDBUY3NozyZylERwBIu3mxANX5YUo1jGK1g"
    "CYcHS7hAJxHFMI7swFTgtRCgImAJF+gknGNTjWMqPZGJUHjCFIFKh6ECVR10IBS9WCAUnsAUgYrgtoSLj6m04ocl1TiG0QpkIlCe"
    "LOECHYIHTBGodGCowAuZkM5tCg10QAS3RXWOodAAHUTwWFTnMYXGwwxPDh1E8LaozmMKjY+ptOKHRXWOofTipgMiYAoN0EEEt0V1"
    "3qbw4r8xlVb8C178J4bRin/DiyUcrfjNMKrxdw3jW6th2flJFj35xSyHF0s4WvGbYRDOX6VqfHigUslPsujJL6ZE8GLx6MVvhpXQ"
    "ir9KBwgFNP5JFj35JxmanRfLk/9tkJNW/HVLPPiVLHryT0vIzmtqT97UwAs1Oh9DMyeteAyBcm5q4MVtAhkcaoAXMIEMDjXAi9sk"
    "UgZ9SAY30wy+LPHgMC3nkAFEIoueyKBzkwFkwFSo4rXpyZua0krMsvMxNWJoTw4dAtVARA08C3QCGQmIGdATdAIZCYgZ4FnAJlIG"
    "19DyAjWJ4MsSD45h2QERGYAHsuiJTi5AdADpxebx2vTkQxathmXny9RwWfTktrlVg2EcPZHFUQ0Yxq0nOjmyA8M4PIDN42JYdlgS"
    "zrclHhzDsgPDODyQRU90cgE6ObKzebw2xa1xyCpXy86XWVGy6AkyBU8oGJYOFDqkATqqMSwdKNBJL6BgWAQsKgI2REAxLDssCefb"
    "Eg+OYdmBYdWBAln0NKMXmNEBk45MIZ3XsCxRPDg2IRLBh1kEsugJsshIbjqI4NDJBejkwgxPDp204jE1HIZKOGwyktuw7LAknG9L"
    "PDiGZQc1zc5DFlEq6YCNaoBZBEvIzovlqRNacdtAOF+WeCCLniCLnhxLwnno5AJ0csGwahw6acVjajgwNRw2HhzDssOScL4t8eAY"
    "lh2mkp2HLG7ZudmoBtioxhKy8+KQBT2BDYTzZYkHssADWfTkWBLOQycfFwwDWnHbQDgsIRyYGg4bDx42qrE8+WOJB8ew7DA1nDdZ"
    "3LIDw/ioxhKy8+KQBT2BDYTzZUkWGHggi54cS8J56MR5BKiIEVGAYVIRLCEcmBoOGw8eNqoN9eSPJR4cw7LD1IrgIYtbpcMwKngE"
    "S8jOi0MW9AQ2EM6HTOHNA1n05FgSURw6ufhDJuLBMYzsTCUcmBoOGw8eZrRNT/5Y4sExLDtMJTsPWVBINRgq1fhYQnZeHLKgJ7CB"
    "cN5k8cUDWfTkWEJ2Dp1c/B9LPDiGZYep4cDUcNh48KajbXryxxIPjmHZYSrZecgCZ1QDbFTjYwnZeU0vkIVnIUO9TNJ5yMKL26Qi"
    "ZJGR3NS00rnpJL34YYmHjA7DssPUSmcq4bDx4E1nKj35Y4kHx7DsIEPJziELT3RkBxtk501Ns/PaXiAjvUAWrYaVJ4csenKbSrgM"
    "JRIShlEOVWqKF5Agwm3gqbODaXYYKuVMKgI2HrzphIzkjyUeHMOyA2ZChypk0ROd9ESH0IEqYGoGr83j4iaLVsPg4pBFT46p4bC5"
    "VYNhHD2RxVENpnL0RCdHdmAYhwew8eBNJ7TihyUeHMOyc7PBzQNZ9EQn9EQnR3ZgKvAShlK9AB3SCtHBxSGLnhxTw0EYml4g6ICe"
    "gDCF9AJBB/QEZEEEBQg6aBS3jQcfOmnFD0s8OIZl59AJHiCLnqCTniAsPClAzOAFJlRwE8MBVZzHIIrDJJObagWHGERxmFDBIQZR"
    "3AZk8iaG8xhk8iGLVvxgksmhWsEhBlHAIAoYRHEbRPFQhRf/DVm04l/wYhhHOL+xAdX4q2TxrSdLuPhp0vmfXqbKEc5vbEA1/ipZ"
    "fIkoTHB+mnR+Ixrw2ryF8xsbUI2/ShYf1fjFpPMbna14bapzK35lo5k2/i4BptAofjPp/GIqrXhtqvHFskA0+KKm19DI4mbcKrmJ"
    "QiU3UajkJsotC0S5ZXEzbpXcRBLRLCyLm5J8W8LFQ0luKtwCmHRAq7ipcAswExxem2p8yOoJNi6+LOEaRk9um1t2bsMgO7dhkJ2b"
    "DW49wQa3ntw2t+zchjZ0tmJ7cJt0vi3h4rHSuU3ldgGTDqx0blO5Xcji8dpUGziHrKo+RS6+rIwaRk9um+pQ6ECqQwErkqHVC2w0"
    "oGCKNKAAM4lgaPWCYUV5wa7qwKTzbQkXj5UOMgV6UcCko0PCQaakY3aBDKUXryn4wKkCGYIPqvNlpWOqPUFkVjo3G1Q6N5Hpgam2"
    "AhsXjyVcvNnISKbSCoZR6cAUGuiozrclXDxWOsiiyotj0lUtI0FWZmCjVzGVVrwYxhHObSqE822lg6yeYAMPDht4cNjAA3S2AhsX"
    "jyVcvNm4gKm0gmH05BjakEV2vi3h4rHSQRbZeZv0JbQCZPUEG3gwlVa8EAEZhHObCuF8qGk4ZtITbODBYQMPDhtUgUgrsJGUA2KW"
    "0IEpcgGioxUMoyfH0IYsz+LbEi4eKx1kkZ23qanQCsykCkTwYCqteHHoJJzbVAjnQyeRmOJZ2MCDwwYeHDao4uYFpgiegBqCJyzh"
    "4qazFQyjJ8ewXqye/LGEi8dKB1lk520qt1YwjCqOSKbSiheHTsK5TYVwPnTykR0beHDYwIPDBh78MYyeHMPoyRIubjpbwTB6cgzD"
    "c/XkjyVcPFY6yCI7b1O5tYJh9ORjKq14cegkHGQIPtL50OkFyCA7NvDgsIEHhw08+EN0ZAY30ZEZqpaRmGorGEZPDtFRpT35YwkX"
    "j5UOssjO21RcLCMRHT35mEorXsJNR6WDrKq+youH6GgFyJTsmEkEUOiQCKDQIRHcCoSbzEoXbjIrHRtEMLR6wTB68pAF1Ys/lnDx"
    "WOkgU9KBAqZWlyERhaxe3AoYKr14bR6tAFk9WcLFYyqtOCYd2NyyA5tbdmDzaMUSjp4s4egJNjiycxtGTx6yqMZPS7h4rHRuU7ld"
    "wKQDS7iQxePiphN4mSpUBKCmPVG1yOQ2lVYcUzIKU4XsgKlCdsBUoSILNYWKLNQUKrJAFFUik9swevKQRTV+WsLFY6VzUzXgAiYd"
    "WMKFKGJkBjdRE14MherczPAEHURwm0Ivjin0gqFQndtQqM7NDKpzM4Pq3MygOm9D8eQww5OHLKrx04LGY5Zz6AAaMKQDCxo3HUTw"
    "tuDFf0IW1fg3vPgvqFpm8G948V8Yhgf/itfmqMavbMDF32aDj+ywaPwfi8YvZIXDa3NU41c24OJvs8FHdlg0/o9F4xeywuG1s/O/"
    "2QCy8/dt6MmvFo1fyAqH187O/2YDyM7ft6Env1o0fiErHF47Ox+ywmGDBx82eu7svC0hnGMY2TlswMWhE6jGbXO7OGRBT46dfRjV"
    "bPQEppKdLzuct0XjsAEXt0WDJYQDOoFqsITjtbPzISscNnjwYaPnzs7bEsI5hpGdwwZcHDqBatw2t4tDFvTk2NmHUc1GT2Aq2fmy"
    "w3lbNA4bcHFbNFhCOKATqAZLOF4bPHjIgp47Ox+yoOfOzjGsFccGD44lhMPODhs8OKaSnWMY1WDqxW1za4UNuGDqxR87nLdFA2RB"
    "T45Fg0XjtrPDogGyoOdrgwcPWdBzZ+dDFvTc2TmGteLY4MGxhHDY2WGDB8dUsnMMoxpMvbhtbq2wARdMvfhjh/O2aIAs6MmxaLBo"
    "3HZ2WDRAFvR8cSwahw0gOx+ywmGDBzqhFccGD44lhMPODhs8OKaSnWMY1WAq2WFn523qBVMv/tjhvC0aTCWctyVAK2Aq2QFZ4cgK"
    "hxfHonHYALLzISscNnigE1pxbPDgWEI47OywwYNjKtk5hlENppIddnbepl4w9eKPHc7bosFUwnlbArQCppIdkBWOrHB4cSzBA7AB"
    "F99k8eaBTg/ednbelvDIDugEqnHb3C4Y1gqYSnbY2XmbesHUiz92OG+LBlMJ520J0AqYykc4ssLhxbEED8AGXHyTxZsHOj1429l5"
    "W8IjO6ATqMZtc7tgWCtgKtlhZ+dt6gVTL/7Y4bwtGkwlnLclQCtgKh/hyAqHF8cSPAAbQHY+ZPHmgU5oxbHBg2MJ4fywaLxNvWAY"
    "1WAq2WFn520q0JMfdjhviwZTCedtCeGLxm1n50NWOLw4luAB2ACy8yGLNw90QiuODR4cSwjnh0XjbeoFw6gGU8kOOztvU4Ge/LDD"
    "eVs0mEo4b0sIXzRuOzsfssLhtbMPoxogKxx2dt6WEA7ohFYMoxqHTrg4ZIXztrPDosHUC6Ze3BbNBlzcdna+bOjJDzuct0UDZEFP"
    "jkWDJYTDBg8esqDna2cfRjVAVjjs7LwtIRzQCa0YRjUOnXBxyArnbWeHRYOpF0y9uC2aDbi47ex82dCTH3Y4b4sGyIKeHIsGSwiH"
    "DR48ZEHPFzqhFTdZ4bDBg2PROHRCK2AJ4RzDyM5hAy4OndCKY0NPHrKgJ8fOzpcNPflhh/O2aBw24OK2aICscEAnUI3DBrzQCa24"
    "yQqHDR4ci8ahE1oBSwjnGEZ2DhtwceiEVhwbevKQBT05dna+bOjJDzuct0XjsAEXt0UDZIUDOoFqHDbgxX9jh/OvePHf2OH8K16b"
    "t+z8RhZk5+9awkc1dBLOT5uL3yzh4rV5pBe/kCmQnb9rCR/VQKD4aXPxmyVcvDaP7PxGFpCdv2sJH9X4p83Fb5Zw8doQQAWIUgkq"
    "ZPEmq9LKkzcVsjgMgkOUSt4MgodBJQ8VsjiMACNEK7mpZHGYgEFABaJUcqiQBWwuQJRKQIUsQGzjQVIAABDxSURBVMWEqNemGm82"
    "8ECGphdvNson2bmJYIoHoEzKSUTUyKgCRIbglaAyoHoBIqZEVgFLLnRW01m9QIZ68GXDxaGTcEDEFK+EzQXYqAhE1IisYirHa1Md"
    "ipsNwhlGT95kkT4lO7dh3KoXsjiyYwNKCAcZWgjVYEMh2YFhHD2BJY1FNZ1kBxt48GXDxaGTcGAYt+rF5gKdZAcbUIIHU4HitblV"
    "47CBxzB68iarGjqzA8M4esISbtXQCeE28GAqPZe0gk01ndnBBm89YQm3ajrJDjbw4MuGi0Mn4TCMoxVsLmSRHWyAxzB6sgQuXptH"
    "dsAGLkZPPmRVQyfhMAwPjiVwcegkOwzzYCo9eexqPGyAB1PpCUvg4qaTcGx48G3DxaGTcGyAB4/NJYtqgA3CYVhPWMLFS2dHBoSD"
    "mBXiwZcl1dBJOAzDg2MJPTl0phfY8GAqPXlswjlsEFHI0OrFEnpy00m4DvHg24aLQyfhDCOieGyuqdULsJFeMKwnLOHihQViRnZA"
    "hkJPvmyqoZNwdAgeHEu4OGRoJaDigQ7JwrnZIKgAG3gAU2nFEi4OMQu3gQffNlwcOglnGB68bcKoBsjQSkClJyzh4sUhi+yADIWe"
    "fNlUIEY4NshIjiVcHDr58AAzAQ9uw6A8sYEHMJVWLOHioTPcRnnybcPFoZNwhuHB2+ZWnqCTj56whIsXhyyyAzaAnnzo5C29zCSi"
    "OJZwcciUKo5IYAhKT0CGCOllAw9gKq1YwsVDZ7oOD/7YcHHoJJxhePC2gZLqhQ6p4oiEJVy8OGSRHRgGePCx+RLOMDw4ltCKQ2d2"
    "flrCxSELstsgHJhKK5Zw8dBJ1PDgjw0Xh07CGYYHbxuqL7KDjXC+LOHitS9AFtnBBi5GT9421QCdhDMMD44lcHHoJDs/LOHioZPs"
    "NsCDqfSEJVy86QQ8+GPDxaGTcIZBTx4bLllkBxuE87GEi9cubpJeYCOcqeXJY1ONm41whlHceskUCqqjEyrdCBjqyRIuWNVlCtkZ"
    "BoVAT1jCxZtOCOeHDReHTsJhGAX0gk0rdJIdG1Ah6gksodpr88gOOsSDYfTkmEpPbjorQoZytEInR7jogCrBk6kJSk+mkijphZhx"
    "eABLuHgTM8L5YcPFoZNwkKHc0ovNBbLIjphBIeUJOoR8mRhUVCJDMxIdkl7cNtU4dBKOiglEFBgDnEBUFTKzUDEhKsAQo6ISUFEl"
    "MwtYwsWHDcL5YcPFoZNwQMWEqCw2F4hZRSCqCplZgA14wYRyQI1IwBQvbkPKOdTIAEzBi2NSzqEGkRymeHHIIIM3UyI5htB5E7Py"
    "5Ich5RwyyOAwxQsY0gEZZABqEMljCC/+EzYI59/w4r+gE8L5N7xYwuHBb5YAF3/X5iOcf9p48Jsl4bx0CIcHv1kCXPxdm49w/mnj"
    "wW+WhPPavHnwmyXAxd+1+QjnnzYe/GZJOK9NJLcqmETCJJKPqYFx8WYKnccQyrnJgEgONfDiMC3nbUgGhwy8VJ0hGYBpOQ8FNTpU"
    "wZAMDhkQCRsPYEgGNzU6IAOlitfGg4+NB2w8+Ng4g4u3YXDxWEI1brLAg8MGtOIYVo23JeEcsmhl1lgSDgyrxhcbXDyWhHPIAg/Y"
    "eABLwrnZ4AJk8XhtPPjYEM7Gg4+Nh6yLxxJurZDFrRoM4wiHJRwesDkuQBaPC5BFM6vGknBgWDW+2ODisSQcGMbNAzYesPEAlnBr"
    "hSwer00kkNymEq4zI/nYeMjqyU0HBXiJDhLKYRgJkg5LqoBI2FRBB9FBIkJPkIWLlDO0ImFYNb7Y4OKxJBzUlIRI2HigMyNBBwXq"
    "WTIUqnhtHq24LYlYtOLLxkMWrYCNB4cNaMUxrBoMHJaE87bx4LABrWxAK2SBB7dh1WBYNb7Y4OKxJByWUI3HxkMWrYCNB2w8YEM4"
    "Lx2ZMshIQE1KacWX7VmyaIUMxYPDBj05hlYkDE1nSThvGw8OG/REdNAKWXgWt2HVGFqRfLHBxWNJOCzJSB4bL9Oe3DYeoCMCNoTz"
    "YkXIAg9uw4BWfNmtkEUrZIEHhw0uHkvCgWHVWBLO28aDwwYXIItWyKIVx7BqLAnnmw0uHkvCYUk4bxtncHFsPIAVARvCefHYeHAb"
    "BhdfZIGHLFohCzw4bHDxWMJbNRgGtOK2hGqADS5AFq2QRSseZo0l4XyzwcVjSTgsCedtc1wcmzcP2BDOi8fGg9swuPgiCyJl4Fmy"
    "wIPDBhePJZDcysEUxbOAIYKT2OACZNEKWbTiYea5JJxvNrh4LAmHJeG8bY6e3DZV3CJhKuG8eGw8uA2Diy+y+PCQBR4cNrh4LKEa"
    "32SBB4cNaGWDC5BFK2TRiocNriXhfLPBxWNJOCwJ523zaAVsPPiyJJwXj40HMLRypBdvsvACJh7oxIPDBhePJRnJHzrx4BAdtLLB"
    "BciiFbJoxcMGqRHFNxtcPJaEw5JK57Ehg5mRsPHgy5JwXjw2HsCSiEUr3mTRCth4wMaDwwYXjyXh/LTx4CGLVja4AFm0QhateNgA"
    "PPjDBhePJeGwhGo8NoSz8YCNB1+WhPPaeMgCD2BFyKIVDxtcHBsP2BDObmUDcKzBsGq8rQjYeMBuhSxaIYtWNqAVsmjFmyzw4A8b"
    "XDyWhAPD4FoRsPGAjQdsCOdjSTivqZEyyEjQESFDPYvDBhfH1IhiKhnMVmoogTYww4EqWJkwMxK2FzLSCxnqpUZ6IYtWvMkCD/6w"
    "wcVjSThgJvSRUWw8YGpEMZUMoApYksGLJdxaARsP2Hhw2ODisSQclnBrBWygGmCDWzgs4dYK2BwXx+a4AFm04k0WePCHDS4eS8K5"
    "2eAWzsYDWBIOSzg8gCXAC+VIbkoVKFUcIiQPpQqUI7kptwREuFWBciQ35UgO5UhuSvIhC8/iDxGSh1LFTYRbFUoVoFSB8qgClNuL"
    "/4QsWvFveG0eHvxqKj35uzbfqvEPU2nFL2xc8No8PPjVVHryd22+VeMfptKKX9i44LXh4n+bCtn564ZBNX4zlVb8wsYFrw0X/9tU"
    "yM5fNwyq8ZuptOIXNi54bQ8+ZHmArJ586OzJpPNYAuHcbAAXxwY8uA2DatxkAT05dAKtuK3q2GjFSudm4+LLMDw4ZFGNmyygJ1Np"
    "BTpbcVsC4cDmeG0PPmR5gKyefOjsyaTzWALh3GwAF8cGPLgNg2rcZAE9OXQCrbit6thoxUrnZuPiyzA8OGRRjZssoCdTaQU6W3Fb"
    "AuHA5nhtjoubLKoNoycfOnsy6dx0kp3HEi4eNi7YcMGmGo+p9OTQSXZ0kh1YAuHASgc2XHwZhgeHLKohC+jJbSqtWNW52WjFEi7Y"
    "QPhrc1zcZFFtGD350NmTSeemk+w8lnDxsHHBhgs21XhMpSeHTrKjk+zAEggHVjqw4eLLMDw4ZFENWUBPblNpxarOzUYrlnDBBsJf"
    "24NheHAbBtX4MpWeTKUV6GzFYYNwHhsuYNgFm2o8ptKTQyfZgVUdWEIrbku4YIfzbRgeHLKohiyq8ZhKk0l2YAmtwMYF2LjgtT0Y"
    "hge3YVCNL1PpyVRagc5WHDYI57HhAoZdsKnGYyo9OXSSHVjVgSW04raEC3Y434bhwSGLasiiGo+pNJlkB5bQCmxcgI0LXjy2B7dh"
    "UI0vU3lrxRJacdggnMfm4wKGQTVusoCeoLMntyW0YlXnzcYFO5xvw/DgkEU1ZPXkbSpHdmAJbxdg44IXj+3BbRhU48tU3lqxhFYc"
    "Ngjnsfm4gGFQjZssoCfo7MltCa1Y1XmzccEO59swPDhkUQ1ZPXmbypEdWMLbBdi44MVje3AbBtX4MpW3ViyhFYcNwnlsuPhhGB4c"
    "sqiGzp7cVnVgVefNBuE7nG/D8OCQRTVkUY3HVI7swBJa8WHjgheP7cFtGFTjy1TeWrGEVhw2COex4eKHYXhwyKIaOntyW9WBVZ03"
    "G4TvcL4Nw4NDFtWQRTUeUzmyA0toxYeNC17chuEBsqg2jJ68TTo3nWRHJ9l5LOHi2HDxwzA8eJvS0El2dJIdWNX5suHih2F4cMii"
    "GrKoxmMqrVhCK5bQig8bhL+4DcMDZFFtGD15m3RuOsmOTrLzWMLFseHih2F48DaloZPs6CQ7sKrzZcPFD8Pw4JBFNWRRjcdUWrGE"
    "ViyhFR82CH9tjoubLA+Q1ZNDFtm56SQ7sIRbK5ZwhGODxwWbhwdTufXkNpVbK26rOl82XPwwDA8OWVQDpnLryVRagc5WYIPHBdgA"
    "Xpvj4ibLA2T15JBFdm46yQ4s4daKJRzh2OBxwebhwVRuPblN5daK26rOlw0XPwzDg0MW1YCp3HoylVagsxXY4HEBNoAX/40NF/+G"
    "F/+NDRf/hhc6OarxG53Qk79rCR/Z+SdZ4fxmWM8XOjmq8Rud0JO/awkf2fknWeH8ZljP1xSJBKr4jc5Io/NXiQCmHar4J1nh/GZY"
    "1WtDOP+TTo+pF3/fsFb8SlY4vxkGrw3hvJlQIRbFl0FlTb24mXBEIcZRAaocmTAg08RBFVwsE0x4c1DlyDShAkycP4a14v8VB8c2"
    "FuQ4AAXfBxQKDYVCQ6HIUCgyGAoNhkKDobRxra8bzGDtBbbqmEIZTOGwQtIWTIzXFMpUrZCpAp8HbHG5Un3uZfx4YoBr4+XKMQJJ"
    "juqwJ8cyeMCWa4O5oZO2IIWv6rAnxzJXYoBr49eevThSiAGuHCOQtAVJ55VCjD17oc7r46gtBQKmai2dy/jxxADXxss1eK1Csgqo"
    "JTI1AF0GD9iaOmDuYMgOg5TgpdVhTwiwmKoxwLXxa89eHCnEANfgtQrJMPDqvFIibGpUyBYJPqjbcqU6rxRgGT+eGODaeLk2Lklb"
    "HOrQC/Vl8IAtjrlHcCWdV9JhT2h8PTHAtfFrz14cKcQA18YlyVGdV9J5pTTYc8QHcbOtUp1XCtQKfjyxwKVT4Nq4JG1xqMModC+D"
    "RMyK15yroHglnVfSYU9ofD0xwLXxa89eHCnEANfGJclRnVcyeLk02HPEh+upzisFW/x6uGKAa+OStMWhzrUMUIcRHK5U55V0XkmH"
    "PaHx9cQA18avPXtxpBADXBuXJEd1XilcDfYc8eF6qvNKwRa/Hq4Y4Nq4JG1xqHMtA9RhBIcr1XklnVfSYU9ofD0xwLXxa89eHCnE"
    "ANfGJclRnVcKV4M9R3y4nuq8UqBWcLlILHAhBrg2LklbHOowCigOgS2dl4DsWJB0XkmHPaHxJbJhVfFrz14cKcQA18YlCSuczisZ"
    "fBXsOeLD9VTnlQIs40ohBrgSA1wbl6QtDnXoxR+ujUvSFiSdV9JhT2hc6jCCP/bsxZFCDHBtXJIwIum8ks6PPUd8HCymanWYGoXO"
    "ZVwpgwDFY4Br1NK5Cskqi80SmRq1+PIwcG2gcxWStiAlwqZqddgTGpc6jOCPPXtxpBADXIPXKiTDqlQ0DFIijGvP4POALVeqg2sv"
    "5l7GldL4emKAK9XnHoEkLEs67AmNrycGuDaYewSStiAFW3tSHfaExqUOI/hjz14cKcQAV44RSNoCJG1BCjG49oTPBkqgDFx7IbMw"
    "vlIaX08MmAKFWCETCikDVagKXpsCYYFqYTIjYAqUAAtUYXGpwwj+2LMXx5QZA6YgWmGFpC1A0hZMgYriUFX5AHOP4HDtBezZiyOl"
    "8fXE4JC0xbVnL64nBoc6jOBw7cX/zb2Mf1KHEfyxZy+uJwaHui1A0hYgaYtDfRmX6weYasGxZfCauopjy+DLa3HIDuOauorLa3HI"
    "hlUcWwY/dFrwT+pVFvwxdRWX1+KQHQbIDgNkh3HotODa8uG/oW6Lf8OH/4a6Lf4N/wMmEwzJzyunMQAAAABJRU5ErkJggg=="
)


def open_gui():
    """Этот файл — «мозги» макро, а не сам макро. Если его запустили напрямую —
    открываем нормальное окно (macro_gui.pyw)."""
    import subprocess
    here = os.path.dirname(os.path.abspath(__file__))
    gui = os.path.join(here, "macro_gui.pyw")
    if not os.path.exists(gui):
        pio.message("Merchant Macro", "macro_gui.pyw not found next to potion_macro.py. "
                                      "Extract the whole zip into one folder and run start_macro.command.")
        return
    exe = sys.executable
    if pio.WIN:
        pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        exe = pyw if os.path.exists(pyw) else exe
    subprocess.Popen([exe, gui], cwd=here, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))


if __name__ == "__main__":
    if len(sys.argv) >= 6 and sys.argv[1] == "--test":
        test(sys.argv[2], sys.argv[3:6])
    elif "--console" in sys.argv:
        main()          # старый консольный режим (F7/F9/F10) — только по явному флагу
    else:
        open_gui()
