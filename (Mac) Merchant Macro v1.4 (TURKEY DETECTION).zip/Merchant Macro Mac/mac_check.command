#!/bin/bash
# Проверка Mac для Merchant Macro (что разрешено, видит ли макро экран, работают ли горячие клавиши).
cd "$(dirname "$0")" || exit 1
clear
if [ ! -x ".venv/bin/python3" ]; then
    echo "Run start_macro.command first (it installs everything), then run this file again."
else
    .venv/bin/python3 mac_check.py
fi
echo
read -r -p "Press Enter to close..." _
