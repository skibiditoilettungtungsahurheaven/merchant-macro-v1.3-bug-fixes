"""
Всё, что зависит от системы: мышь, клавиатура, горячие клавиши, курсор, активное окно, проверка разрешений.
Работает на macOS (основная цель этой папки) и на Windows (так же, как ПК-версия, — удобно проверять).

Координаты везде в «точках» экрана: на Windows это обычные пиксели, на Mac — точки macOS
(на Retina-экране одна точка = 2×2 пикселя). mss на Mac тоже снимает экран в точках,
поэтому зрение макро получает картинку в тех же координатах, что и мышь.
"""
import os
import subprocess
import sys
import threading
import time

MAC = sys.platform == "darwin"
WIN = sys.platform == "win32"

# Python с python.org на Mac не видит системные сертификаты — без этого вебхук Discord падает с SSL-ошибкой.
if MAC:
    try:
        import certifi
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass


# ======================================================================= Windows
class _WinBackend:
    name = "windows"

    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self.ctypes, self.wintypes = ctypes, wintypes
        self.user32 = ctypes.windll.user32
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)  # реальные пиксели, без масштабирования Windows
        except Exception:
            self.user32.SetProcessDPIAware()

        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                        ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

        class KEYBDINPUT(ctypes.Structure):
            _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                        ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

        class _U(ctypes.Union):
            _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("pad", ctypes.c_byte * 32)]

        class INPUT(ctypes.Structure):
            _fields_ = [("type", wintypes.DWORD), ("u", _U)]

        self.MOUSEINPUT, self.KEYBDINPUT, self.INPUT = MOUSEINPUT, KEYBDINPUT, INPUT

    def _send(self, inp):
        self.user32.SendInput(1, self.ctypes.byref(inp), self.ctypes.sizeof(self.INPUT))

    def virtual_screen(self):
        u = self.user32
        return u.GetSystemMetrics(76), u.GetSystemMetrics(77), u.GetSystemMetrics(78) or 1920, \
            u.GetSystemMetrics(79) or 1080

    def mouse_move(self, x, y):
        vx, vy, vw, vh = self.virtual_screen()
        nx = int((x - vx) * 65535 / max(vw - 1, 1))
        ny = int((y - vy) * 65535 / max(vh - 1, 1))
        i = self.INPUT(type=0)
        i.u.mi = self.MOUSEINPUT(nx, ny, 0, 0x0001 | 0x8000 | 0x4000, 0, 0)  # MOVE|ABSOLUTE|VIRTUALDESK
        self._send(i)

    def mouse_button(self, down):
        i = self.INPUT(type=0)
        i.u.mi = self.MOUSEINPUT(0, 0, 0, 0x0002 if down else 0x0004, 0, 0)  # LEFTDOWN / LEFTUP
        self._send(i)

    def key(self, ch, down):
        vk = self.user32.VkKeyScanW(ord(ch)) & 0xFF
        scan = self.user32.MapVirtualKeyW(vk, 0)
        i = self.INPUT(type=1)
        i.u.ki = self.KEYBDINPUT(vk, scan, 0x0008 | (0 if down else 0x0002), 0, 0)  # SCANCODE (+KEYUP)
        self._send(i)

    def key_named(self, name, down):
        vk = WIN_PATH_KEYS[name]
        scan = self.user32.MapVirtualKeyW(vk, 0)
        flags = 0x0008 | (0 if down else 0x0002) | (0x0001 if name in ("left", "right", "up", "down") else 0)
        i = self.INPUT(type=1)
        i.u.ki = self.KEYBDINPUT(vk, scan, flags, 0, 0)       # SCANCODE (+KEYUP, +EXTENDED у стрелок)
        self._send(i)

    def key_state(self, name):
        return bool(self.user32.GetAsyncKeyState(WIN_PATH_KEYS[name]) & 0x8000)

    def cursor_pos(self):
        pt = self.wintypes.POINT()
        self.user32.GetCursorPos(self.ctypes.byref(pt))
        return pt.x, pt.y

    def hotkey_code(self, name):
        n = _norm_key(name)
        if len(n) >= 2 and n[0] == "F" and n[1:].isdigit() and 1 <= int(n[1:]) <= 24:
            return 0x70 + int(n[1:]) - 1
        return {"INSERT": 0x2D, "DELETE": 0x2E, "HOME": 0x24, "END": 0x23, "PRIOR": 0x21, "NEXT": 0x22,
                "PAGEUP": 0x21, "PAGEDOWN": 0x22, "PAUSE": 0x13, "SCROLLLOCK": 0x91}.get(n)

    def hotkey_pressed(self, code):
        # младший бит: клавишу нажимали после прошлого вызова
        return bool(self.user32.GetAsyncKeyState(code) & 1)

    def frontmost_name(self):
        hwnd = self.user32.GetForegroundWindow()
        buf = self.ctypes.create_unicode_buffer(256)
        self.user32.GetWindowTextW(hwnd, buf, 256)
        return buf.value

    def missing_permissions(self, ask=False):
        return []

    def open_permission_settings(self, which):
        pass

    def message(self, title, text):
        try:
            self.user32.MessageBoxW(None, text, title, 0x10)
        except Exception:
            print(title + ": " + text)


# ======================================================================= macOS
# Коды клавиш macOS (ANSI-раскладка, физические клавиши — как скан-коды на Windows).
MAC_KEYCODES = {
    "a": 0, "s": 1, "d": 2, "f": 3, "h": 4, "g": 5, "z": 6, "x": 7, "c": 8, "v": 9, "b": 11, "q": 12,
    "w": 13, "e": 14, "r": 15, "y": 16, "t": 17, "1": 18, "2": 19, "3": 20, "4": 21, "6": 22, "5": 23,
    "=": 24, "9": 25, "7": 26, "-": 27, "8": 28, "0": 29, "]": 30, "o": 31, "u": 32, "[": 33, "i": 34,
    "p": 35, "l": 37, "j": 38, "'": 39, "k": 40, ";": 41, "\\": 42, ",": 43, "/": 44, "n": 45, "m": 46,
    ".": 47, "`": 50, " ": 49, "\t": 48, "\r": 36, "\n": 36,
}
MAC_HOTKEYS = {
    "F1": 122, "F2": 120, "F3": 99, "F4": 118, "F5": 96, "F6": 97, "F7": 98, "F8": 100, "F9": 101,
    "F10": 109, "F11": 103, "F12": 111, "F13": 105, "F14": 107, "F15": 113, "F16": 106, "F17": 64,
    "F18": 79, "F19": 80, "F20": 90,
    "HOME": 115, "END": 119, "PAGEUP": 116, "PRIOR": 116, "PAGEDOWN": 121, "NEXT": 121,
    "DELETE": 117, "INSERT": 114, "HELP": 114,
}


# Клавиши пути к торговцу (Merchant Failsafe): W A S D, стрелки (камера), пробел, Shift — физические клавиши.
WIN_PATH_KEYS = {"w": 0x57, "a": 0x41, "s": 0x53, "d": 0x44, "left": 0x25, "right": 0x27, "up": 0x26, "down": 0x28,
                 "space": 0x20, "shift": 0xA0}
MAC_PATH_KEYS = {"w": 13, "a": 0, "s": 1, "d": 2, "left": 123, "right": 124, "down": 125, "up": 126,
                 "space": 49, "shift": 56}


def _norm_key(name):
    return (name or "").strip().upper().replace(" ", "").replace("_", "")


class _MacBackend:
    name = "mac"

    def __init__(self, libs=None):
        """libs — для проверок без Mac: подставные CoreGraphics/IOKit/objc."""
        import ctypes
        from ctypes import c_bool, c_double, c_int32, c_int64, c_uint16, c_uint32, c_void_p
        self.ctypes = ctypes

        class CGPoint(ctypes.Structure):
            _fields_ = [("x", c_double), ("y", c_double)]

        self.CGPoint = CGPoint
        if libs is None:
            cg = ctypes.cdll.LoadLibrary(
                "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices")
            cf = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
            try:
                iokit = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/IOKit.framework/IOKit")
            except OSError:
                iokit = None
            try:
                objc = ctypes.cdll.LoadLibrary("/usr/lib/libobjc.A.dylib")
                ctypes.cdll.LoadLibrary("/System/Library/Frameworks/AppKit.framework/AppKit")
            except OSError:
                objc = None
        else:
            cg, cf, iokit, objc = libs
        self.cg, self.cf, self.iokit, self.objc = cg, cf, iokit, objc

        def proto(lib, fname, restype, argtypes):
            f = getattr(lib, fname, None)
            if f is None:
                return None
            f.restype, f.argtypes = restype, argtypes
            return f

        self.CGEventCreate = proto(cg, "CGEventCreate", c_void_p, [c_void_p])
        self.CGEventGetLocation = proto(cg, "CGEventGetLocation", CGPoint, [c_void_p])
        self.CGEventCreateMouseEvent = proto(cg, "CGEventCreateMouseEvent", c_void_p,
                                             [c_void_p, c_uint32, CGPoint, c_uint32])
        self.CGEventCreateKeyboardEvent = proto(cg, "CGEventCreateKeyboardEvent", c_void_p,
                                                [c_void_p, c_uint16, c_bool])
        self.CGEventSetIntegerValueField = proto(cg, "CGEventSetIntegerValueField", None,
                                                 [c_void_p, c_uint32, c_int64])
        self.CGEventSetFlags = proto(cg, "CGEventSetFlags", None, [c_void_p, ctypes.c_uint64])
        self.CGEventPost = proto(cg, "CGEventPost", None, [c_uint32, c_void_p])
        self.CGEventSourceKeyState = proto(cg, "CGEventSourceKeyState", c_bool, [c_int32, c_uint16])
        self.CGPreflightScreenCaptureAccess = proto(cg, "CGPreflightScreenCaptureAccess", c_bool, [])
        self.CGRequestScreenCaptureAccess = proto(cg, "CGRequestScreenCaptureAccess", c_bool, [])
        self.AXIsProcessTrusted = proto(cg, "AXIsProcessTrusted", c_bool, [])
        self.CFRelease = proto(cf, "CFRelease", None, [c_void_p])
        self.IOHIDCheckAccess = proto(iokit, "IOHIDCheckAccess", c_uint32, [c_uint32]) if iokit else None
        self.IOHIDRequestAccess = proto(iokit, "IOHIDRequestAccess", c_bool, [c_uint32]) if iokit else None

        self.down = False
        self.key_prev = {}
        self.key_lock = threading.Lock()
        self._front = (0.0, "")
        self._front_lock = threading.Lock()
        self._objc_ok = objc is not None
        if self._objc_ok:
            try:
                objc.objc_getClass.restype = c_void_p
                objc.objc_getClass.argtypes = [ctypes.c_char_p]
                objc.sel_registerName.restype = c_void_p
                objc.sel_registerName.argtypes = [ctypes.c_char_p]
                objc.objc_autoreleasePoolPush.restype = c_void_p
                objc.objc_autoreleasePoolPush.argtypes = []
                objc.objc_autoreleasePoolPop.restype = None
                objc.objc_autoreleasePoolPop.argtypes = [c_void_p]
                addr = ctypes.cast(objc.objc_msgSend, c_void_p).value
                self._msg = ctypes.CFUNCTYPE(c_void_p, c_void_p, c_void_p)(addr)
                self._msg_str = ctypes.CFUNCTYPE(ctypes.c_char_p, c_void_p, c_void_p)(addr)
            except Exception:
                self._objc_ok = False

    # ---------------- мышь
    def _post(self, ev):
        if not ev:
            return
        try:
            self.CGEventPost(0, ev)          # kCGHIDEventTap — как настоящая мышь/клавиатура
        finally:
            self.CFRelease(ev)

    def _mouse(self, etype, x, y):
        ev = self.CGEventCreateMouseEvent(None, etype, self.CGPoint(float(x), float(y)), 0)  # левая кнопка
        if ev and etype in (1, 2):
            self.CGEventSetIntegerValueField(ev, 1, 1)   # kCGMouseEventClickState = 1 (одиночный клик)
        self._post(ev)

    def virtual_screen(self):
        """Прямоугольник всех мониторов в точках (как его видит mss). Запоминается на 2 секунды:
        его спрашивают при каждом снимке экрана (до 10 раз в секунду)."""
        t, r = getattr(self, "_vs", (0.0, None))
        if r is not None and time.time() - t < 2.0:
            return r
        try:
            import mss
            MSS = getattr(mss, "MSS", None) or mss.mss
            with MSS() as s:
                m = s.monitors[0]
            r = (m["left"], m["top"], m["width"] or 1440, m["height"] or 900)
        except Exception:
            r = (0, 0, 1440, 900)
        self._vs = (time.time(), r)
        return r

    def mouse_move(self, x, y):
        # с зажатой кнопкой macOS ждёт «перетаскивание», иначе — обычное движение
        self._mouse(6 if self.down else 5, x, y)   # kCGEventLeftMouseDragged / kCGEventMouseMoved

    def mouse_button(self, down):
        x, y = self.cursor_pos()
        self.down = down
        self._mouse(1 if down else 2, x, y)          # kCGEventLeftMouseDown / kCGEventLeftMouseUp

    # ---------------- клавиатура
    def key(self, ch, down):
        code = MAC_KEYCODES.get(ch.lower())
        if code is None:
            return
        ev = self.CGEventCreateKeyboardEvent(None, code, bool(down))
        if ev and self.CGEventSetFlags:
            self.CGEventSetFlags(ev, 0)              # без Shift/Cmd, даже если они сейчас зажаты
        self._post(ev)

    def key_named(self, name, down):
        ev = self.CGEventCreateKeyboardEvent(None, MAC_PATH_KEYS[name], bool(down))
        if ev and self.CGEventSetFlags and name != "shift":
            self.CGEventSetFlags(ev, 0)
        self._post(ev)

    def key_state(self, name):
        """Клавиша сейчас зажата? (Нужно разрешение «Мониторинг ввода».)"""
        return bool(self.CGEventSourceKeyState(1, MAC_PATH_KEYS[name]))

    def cursor_pos(self):
        ev = self.CGEventCreate(None)
        try:
            p = self.CGEventGetLocation(ev)
            return int(round(p.x)), int(round(p.y))
        finally:
            if ev:
                self.CFRelease(ev)

    # ---------------- горячие клавиши
    def hotkey_code(self, name):
        return MAC_HOTKEYS.get(_norm_key(name))

    def hotkey_pressed(self, code):
        """True один раз на каждое нажатие (как GetAsyncKeyState & 1 на Windows).
        Нужно разрешение «Мониторинг ввода», иначе macOS всегда отвечает «не нажата»."""
        now = bool(self.CGEventSourceKeyState(1, code))   # kCGEventSourceStateHIDSystemState
        with self.key_lock:
            was = self.key_prev.get(code, now)
            self.key_prev[code] = now
        return now and not was

    # ---------------- активное приложение
    def _front_objc(self):
        o = self.objc
        pool = o.objc_autoreleasePoolPush()
        try:
            ws = self._msg(o.objc_getClass(b"NSWorkspace"), o.sel_registerName(b"sharedWorkspace"))
            app = self._msg(ws, o.sel_registerName(b"frontmostApplication")) if ws else None
            name = self._msg(app, o.sel_registerName(b"localizedName")) if app else None
            s = self._msg_str(name, o.sel_registerName(b"UTF8String")) if name else None
            return s.decode("utf-8", "replace") if s else ""
        finally:
            o.objc_autoreleasePoolPop(pool)

    @staticmethod
    def _front_lsappinfo():
        asn = subprocess.run(["lsappinfo", "front"], capture_output=True, text=True, timeout=2).stdout.strip()
        if not asn:
            return ""
        out = subprocess.run(["lsappinfo", "info", "-only", "name", asn], capture_output=True,
                             text=True, timeout=2).stdout
        # "LSDisplayName"="Roblox"  или  "name"="Roblox"
        return out.split("=", 1)[1].strip().strip('"') if "=" in out else out.strip()

    def frontmost_name(self):
        with self._front_lock:
            t, name = self._front
            if time.time() - t < 0.3:
                return name
        name = ""
        if self._objc_ok:
            try:
                name = self._front_objc()
            except Exception:
                self._objc_ok = False
        if not name:
            try:
                name = self._front_lsappinfo()
            except Exception:
                name = ""
        with self._front_lock:
            self._front = (time.time(), name)
        return name

    # ---------------- разрешения macOS
    def missing_permissions(self, ask=False):
        """Каких разрешений не хватает: 'screen' (Запись экрана), 'access' (Универсальный доступ),
        'input' (Мониторинг ввода). ask=True — показать системные запросы."""
        miss = []
        try:
            if self.CGPreflightScreenCaptureAccess and not self.CGPreflightScreenCaptureAccess():
                miss.append("screen")
                if ask and self.CGRequestScreenCaptureAccess:
                    self.CGRequestScreenCaptureAccess()
        except Exception:
            pass
        try:
            if self.AXIsProcessTrusted and not self.AXIsProcessTrusted():
                miss.append("access")
                if ask:
                    self._ask_accessibility()
        except Exception:
            pass
        try:
            if self.IOHIDCheckAccess and self.IOHIDCheckAccess(1) != 0:   # kIOHIDRequestTypeListenEvent
                miss.append("input")
                if ask and self.IOHIDRequestAccess:
                    self.IOHIDRequestAccess(1)
        except Exception:
            pass
        return miss

    def _ask_accessibility(self):
        """AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: true}) — macOS сам показывает окно
        и добавляет Терминал в список «Универсальный доступ» (иначе его пришлось бы искать вручную через «+»)."""
        c = self.ctypes
        f = getattr(self.cg, "AXIsProcessTrustedWithOptions", None)
        mk = getattr(self.cf, "CFDictionaryCreate", None)
        if f is None or mk is None:
            return
        f.restype, f.argtypes = c.c_bool, [c.c_void_p]
        mk.restype = c.c_void_p
        mk.argtypes = [c.c_void_p, c.POINTER(c.c_void_p), c.POINTER(c.c_void_p), c.c_long, c.c_void_p, c.c_void_p]
        key = c.c_void_p.in_dll(self.cg, "kAXTrustedCheckOptionPrompt")
        val = c.c_void_p.in_dll(self.cf, "kCFBooleanTrue")
        keys = (c.c_void_p * 1)(key.value)
        vals = (c.c_void_p * 1)(val.value)
        kcb = c.addressof(c.c_char.in_dll(self.cf, "kCFTypeDictionaryKeyCallBacks"))
        vcb = c.addressof(c.c_char.in_dll(self.cf, "kCFTypeDictionaryValueCallBacks"))
        d = mk(None, keys, vals, 1, kcb, vcb)
        if d:
            try:
                f(d)
            finally:
                self.CFRelease(d)

    def open_permission_settings(self, which):
        pane = {"screen": "Privacy_ScreenCapture", "access": "Privacy_Accessibility",
                "input": "Privacy_ListenEvent"}.get(which, "Privacy")
        try:
            subprocess.Popen(["open", "x-apple.systempreferences:com.apple.preference.security?" + pane])
        except Exception:
            pass

    def message(self, title, text):
        try:
            script = 'display dialog %s with title %s buttons {"OK"} with icon stop' % (
                _applescript_str(text), _applescript_str(title))
            subprocess.run(["osascript", "-e", script], timeout=120)
        except Exception:
            print(title + ": " + text)


def _applescript_str(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


# ======================================================================= снимок экрана
def _mss():
    import mss
    return (getattr(mss, "MSS", None) or mss.mss)()


def monitors():
    """Мониторы как их видит mss: [0] — все вместе, [1:] — по одному (на Mac — в точках)."""
    with _mss() as s:
        return [dict(m) for m in s.monitors]


_shot_fail_logged = False


def grab_rect(left, top, width, height):
    """Кусок экрана в BGR (numpy), ровно width x height. На Mac, если mss не смог (новые версии macOS),
    — через системную утилиту screencapture (она снимает в пикселях Retina, уменьшаем до точек)."""
    import cv2
    import numpy as np
    left, top, width, height = int(left), int(top), max(1, int(width)), max(1, int(height))
    # часть прямоугольника за краем экрана: снимаем только видимую часть и кладём на чёрный фон
    # (macOS отдаёт картинку размером с видимую часть — растягивать её нельзя, всё бы съехало)
    try:
        vx, vy, vw, vh = virtual_screen()
    except Exception:
        vx = vy = -10 ** 6
        vw = vh = 2 * 10 ** 6
    x0, y0 = max(left, vx), max(top, vy)
    x1, y1 = min(left + width, vx + vw), min(top + height, vy + vh)
    if (x0, y0, x1, y1) != (left, top, left + width, top + height):
        out = np.zeros((height, width, 3), np.uint8)
        if x1 > x0 and y1 > y0:
            out[y0 - top:y1 - top, x0 - left:x1 - left] = grab_rect(x0, y0, x1 - x0, y1 - y0)
        return out
    try:
        with _mss() as s:
            shot = s.grab({"left": left, "top": top, "width": width, "height": height})
        img = cv2.cvtColor(np.array(shot), cv2.COLOR_BGRA2BGR)
    except Exception as e:
        if not MAC:
            raise
        global _shot_fail_logged
        if not _shot_fail_logged:
            _shot_fail_logged = True
            print("mss could not capture the screen (%s) - using screencapture instead" % e, flush=True)
        img = _screencapture(left, top, width, height)
    if img.shape[1] != width or img.shape[0] != height:
        img = cv2.resize(img, (width, height), interpolation=cv2.INTER_AREA)
    return img


def _screencapture(left, top, width, height):
    import tempfile
    import cv2
    fd, path = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    try:
        subprocess.run(["screencapture", "-x", "-t", "png", "-R", "%d,%d,%d,%d" % (left, top, width, height), path],
                       timeout=10, check=True)
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        if img is None:
            raise RuntimeError("screencapture gave no image (Screen Recording permission?)")
        return img
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


# ======================================================================= общий интерфейс
_backend = None


def backend():
    global _backend
    if _backend is None:
        _backend = _MacBackend() if MAC else _WinBackend()
    return _backend


def set_backend(b):
    """Для проверок: подставить свой «бэкенд»."""
    global _backend
    _backend = b


def init():
    backend()


def virtual_screen():
    return backend().virtual_screen()


def mouse_move(x, y):
    backend().mouse_move(x, y)


def click(x, y, firm=False):
    """firm=True — повторный клик после того, как игра «не услышала» первый: курсор подводится издалека и
    медленнее, кнопка держится дольше."""
    # Roblox игнорирует клик без движения мыши — поэтому «подводим» курсор
    b = backend()
    if firm:
        b.mouse_move(x - 14, y - 10)
        time.sleep(0.10)
    b.mouse_move(x - 3, y - 3)
    time.sleep(0.10 if firm else 0.05)
    b.mouse_move(x, y)
    time.sleep(0.20 if firm else 0.08)
    b.mouse_button(True)
    time.sleep(0.14 if firm else 0.06)
    b.mouse_button(False)
    time.sleep(0.14 if firm else 0.06)


def press_key(ch, hold=0.15):
    # Roblox пропускает слишком короткие нажатия, поэтому клавиша держится hold секунд
    b = backend()
    b.key(ch, True)
    time.sleep(hold)
    b.key(ch, False)
    time.sleep(hold)


def key_hold(name, down):
    """Нажимает (down=True) или отпускает клавишу пути: w a s d left right up down space shift."""
    backend().key_named(name, down)


def key_is_down(name):
    return backend().key_state(name)


def cursor_pos():
    return backend().cursor_pos()


def hotkey_code(name):
    return backend().hotkey_code(name)


def hotkey_pressed(code):
    return code is not None and backend().hotkey_pressed(code)


def roblox_focused():
    try:
        return "roblox" in (backend().frontmost_name() or "").lower()
    except Exception:
        return False


def missing_permissions(ask=False):
    return backend().missing_permissions(ask)


def open_permission_settings(which):
    backend().open_permission_settings(which)


def message(title, text):
    backend().message(title, text)
