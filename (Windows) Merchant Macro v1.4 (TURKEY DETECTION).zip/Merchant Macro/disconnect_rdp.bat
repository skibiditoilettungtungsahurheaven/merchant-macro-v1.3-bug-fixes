@echo off
rem Отключает RDP, НЕ блокируя рабочий стол: Roblox и макро продолжают работать.
rem Запускать на RDP-сервере ПРАВОЙ кнопкой -> "Запуск от имени администратора".
for /f "skip=1 tokens=3" %%s in ('query user %USERNAME%') do (
    %windir%\System32\tscon.exe %%s /dest:console
)
