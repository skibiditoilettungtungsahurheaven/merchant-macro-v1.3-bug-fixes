hi Newbloxfruitsacc1197 (@capybaralover419) here, feel free to dm me if u find any bugs or you just wanna dm me i dont mind getting dms from people :>

some tips for the macro

read the "IMPORTANT" section

be in fullscreen while using the macro or it wont work properly

extract the .zip folder (heres a quick guide)

1. drag .zip folder to your desktop

2. right click it

3. extract all

4. extract

5. open the extracted folder

u can run the macro now, if you dont do everything listed above it wont run properly

also after running the start_macro.bat it will install python and add it to path (if u dont have it, this is needed for the macro to run) it will take like 20-30 mins so just be patient. 

enjoy the macro!